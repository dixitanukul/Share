"""
Root conftest.py — Contract Intelligence V4
Sets up sys.path so all test modules can import from platform/v4, src, and pipeline.
"""
import sys
import os

# Project root = this file's directory
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# Add platform root so `from platform.v4.xxx import yyy` works
# Also add src root so `from chunking import is_quality_chunk` works
for path in [PROJECT_ROOT, os.path.join(PROJECT_ROOT, 'src')]:
    if path not in sys.path:
        sys.path.insert(0, path)

# ── Shared fixtures ──────────────────────────────────────────────────────────
import pytest


@pytest.fixture(scope="session")
def project_root():
    """Absolute path to the contract-intelligence-v4 root."""
    return PROJECT_ROOT


@pytest.fixture(scope="session")
def platform_v4_root():
    """Absolute path to platform/v4."""
    return os.path.join(PROJECT_ROOT, "platform", "v4")


@pytest.fixture(scope="session")
def docs_root():
    """Absolute path to docs/."""
    return os.path.join(PROJECT_ROOT, "docs")


# ── Markers ──────────────────────────────────────────────────────────────────
def pytest_configure(config):
    config.addinivalue_line(
        "markers",
        "live: marks tests that require a live Databricks connection (deselect with -m 'not live')"
    )
    config.addinivalue_line(
        "markers",
        "slow: marks tests that take > 10s"
    )
    config.addinivalue_line(
        "markers",
        "phase0: marks tests that validate Phase 0 data integrity fixes"
    )

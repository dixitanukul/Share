"""
platform/v4 — Contract Intelligence V4 package.

Import the runtime entry point to use the agent:

    from platform.v4.runtime.notebook_entry import init_runtime
"""
__version__ = "4.0.0-alpha"
__all__ = ["__version__"]

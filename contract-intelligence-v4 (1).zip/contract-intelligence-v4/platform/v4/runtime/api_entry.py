"""
platform/v4/runtime/api_entry.py

Internal callable API surface for V4.

Exposes the V4 agent as a Python-callable service for programmatic use
(e.g. from scheduled jobs, batch pipelines, or REST handlers).

Usage
-----
from platform.v4.runtime.api_entry import V4Api

api = V4Api(spark=spark, dispatch_fn=dispatch)
result = api.ask("What is the capitation rate for Cedars-Sinai?")
print(result["answer"])
"""
from __future__ import annotations

from typing import Any, Callable, Optional

from .notebook_entry import NotebookRuntime, init_runtime
from ..config.settings import Settings


class V4Api:
    """
    Thin API wrapper for V4 agent invocation.

    Suitable for batch pipelines and programmatic callers that need
    a clean dict-returning interface rather than AgentResponse objects.
    """

    def __init__(
        self,
        spark:       Any,
        dispatch_fn: Optional[Callable]  = None,
        retrieve_fn: Optional[Callable]  = None,
        verify_fn:   Optional[Callable]  = None,
        llm_client:  Optional[Any]       = None,
        settings:    Optional[Settings]  = None,
    ) -> None:
        self._runtime: NotebookRuntime = init_runtime(
            spark=spark,
            dispatch_fn=dispatch_fn,
            retrieve_fn=retrieve_fn,
            verify_fn=verify_fn,
            llm_client=llm_client,
            settings=settings,
        )

    def ask(
        self,
        question:      str,
        provider_name: Optional[str] = None,
        session_id:    Optional[str] = None,
    ) -> dict:
        """
        Ask the V4 agent a question.

        Returns
        -------
        dict with keys: answer, confidence, citations, total_cost,
                        execution_time_s, session_id, steps
        """
        response = self._runtime.ask(
            question=question,
            provider_name=provider_name,
            session_id=session_id,
        )
        return {
            "answer":           response.answer,
            "confidence":       response.confidence,
            "citations":        response.citations,
            "total_cost":       round(response.total_cost, 4),
            "execution_time_s": round(response.execution_time_s, 2),
            "session_id":       response.session_id,
            "steps":            [
                {"action": s.action, "tool": s.tool_name}
                for s in response.steps
            ],
        }

    def status(self) -> dict:
        return self._runtime.status()

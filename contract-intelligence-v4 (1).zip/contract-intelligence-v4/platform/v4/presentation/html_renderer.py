"""platform/v4/presentation/html_renderer.py

P5-RPT-4: HTML rendering service for V3 typed report objects.

Provides two layers:
  1. Primitives: card, section_header, table, confidence_banner, etc.
     (Extracted from V2 Cell 3)
  2. Report renderers: render_report() dispatches to full-page renderers
     for each report type (ClauseReport, ProviderReport, etc.)

Usage
-----
    from platform.v4.presentation.html_renderer import HtmlRenderer
    from platform.v4.contracts.report_types import ClauseReport

    renderer = HtmlRenderer()
    html = renderer.render_report(report)  # full page
    # -- or primitives --
    html = renderer.section_header("Results", "10 providers found")
    html += renderer.table(df, "Rate Summary")
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from platform.v4.contracts.report_types import (
        AnyReport, ClauseReport, StructuredExtractionReport, ProviderReport,
        RateReport, TemporalReport, ComparisonReport, ExplanationReport,
        MultiConceptReport,
    )


class HtmlRenderer:
    """HTML rendering service for contract intelligence outputs."""

    # ------------------------------------------------------------------
    # Cards
    # ------------------------------------------------------------------

    @staticmethod
    def card(title: str, value: str, color: str = "#1B3A5C", icon: str = "&#x1F4CA;") -> str:
        """Render a metric card (styled_card)."""
        return (
            f'<div style="display:inline-block;margin:8px;padding:20px 28px;'
            f'background:linear-gradient(135deg,{color},{color}cc);border-radius:14px;'
            f'color:white;text-align:center;min-width:185px;'
            f'box-shadow:0 6px 20px rgba(0,0,0,0.12);">'
            f'<div style="font-size:26px;margin-bottom:4px;">{icon}</div>'
            f'<div style="font-size:30px;font-weight:700;letter-spacing:-0.5px;">{value}</div>'
            f'<div style="font-size:12px;opacity:0.85;margin-top:6px;'
            f'text-transform:uppercase;letter-spacing:0.5px;">{title}</div></div>'
        )

    # ------------------------------------------------------------------
    # Section headers
    # ------------------------------------------------------------------

    @staticmethod
    def section_header(title: str, subtitle: str = "") -> str:
        """Render a section header with optional subtitle."""
        sub = (
            f'<div style="color:#666;font-size:14px;margin-top:4px;">{subtitle}</div>'
            if subtitle else ""
        )
        return (
            f'<div style="margin:30px 0 15px 0;padding-bottom:12px;'
            f'border-bottom:3px solid #2E86AB;">'
            f'<h2 style="color:#1B3A5C;margin:0;font-weight:700;">{title}</h2>'
            f'{sub}</div>'
        )

    # ------------------------------------------------------------------
    # Tables
    # ------------------------------------------------------------------

    @staticmethod
    def table(df: Any, title: str = "", max_rows: int = 25) -> str:
        """Render a pandas DataFrame as a styled HTML table."""
        df = df.head(max_rows)
        col_names = df.keys().tolist()
        html = (
            f'<h3 style="color:#1B3A5C;margin:20px 0 10px 0;font-weight:600;">{title}</h3>'
            if title else ""
        )
        html += (
            '<div style="overflow-x:auto;">'
            '<table style="border-collapse:collapse;width:100%;font-size:13px;'
            'font-family:system-ui,-apple-system,sans-serif;">'
        )
        # Header row
        html += "<tr>" + "".join(
            f'<th style="background:#1B3A5C;color:white;padding:11px 14px;'
            f'text-align:left;font-weight:500;white-space:nowrap;">{c}</th>'
            for c in col_names
        ) + "</tr>"
        # Data rows
        for i, row in df.iterrows():
            bg = "#f7f9fb" if i % 2 == 0 else "white"
            html += f'<tr style="background:{bg};">'
            html += "".join(
                f'<td style="padding:9px 14px;border-bottom:1px solid #edf0f4;">{v}</td>'
                for v in row.values
            )
            html += "</tr>"
        html += "</table></div>"
        return html

    # ------------------------------------------------------------------
    # Confidence / Status banners
    # ------------------------------------------------------------------

    @staticmethod
    def confidence_banner(
        level: str, score: float, kp_pass: int, total: int, num_errors: int
    ) -> str:
        """Render a confidence level banner."""
        configs = {
            "high": ("#1A7A6D", "#e6f7f4", "&#x2705;", "High Confidence \u2014 Verified against source"),
            "moderate": ("#F18F01", "#fff9e6", "&#x26A0;&#xFE0F;", "Moderate Confidence \u2014 Verify before use"),
            "low": ("#D64045", "#fef3e6", "&#x1F7E0;", "Low Confidence \u2014 Additional context may exist"),
            "insufficient": ("#D64045", "#fde8e8", "&#x1F534;", "INSUFFICIENT EVIDENCE \u2014 Raw evidence shown"),
            "numerical_warning": ("#D64045", "#fde8e8", "&#x1F6D1;", "NUMERICAL WARNING \u2014 Values not in source text"),
        }
        color, bg, icon, label = configs.get(level, configs["moderate"])
        return (
            f'<div style="background:{bg};border-left:4px solid {color};'
            f'padding:10px 16px;border-radius:0 8px 8px 0;margin:0 0 15px 0;'
            f'display:flex;align-items:center;gap:12px;">'
            f'<span style="font-size:18px;">{icon}</span>'
            f'<div><div style="font-size:13px;font-weight:600;color:{color};">{label}</div>'
            f'<div style="font-size:11px;color:#666;margin-top:2px;">'
            f'Score: {score:.0%} | Citations verified: {kp_pass}/{total} | '
            f'Numerical issues: {num_errors}</div></div></div>'
        )

    @staticmethod
    def degradation_banner(reason: str) -> str:
        """Render a VS degradation warning banner."""
        if not reason:
            return ""
        return (
            '<div style="background:#fff3cd;border-left:4px solid #ffc107;'
            'padding:12px 16px;border-radius:0 8px 8px 0;margin:0 0 15px 0;'
            'display:flex;align-items:center;gap:12px;">'
            '<span style="font-size:20px;">&#x26A0;&#xFE0F;</span>'
            '<div><div style="font-size:13px;font-weight:600;color:#856404;">'
            'Semantic Search Degraded</div>'
            f'<div style="font-size:11px;color:#856404;margin-top:2px;">'
            f'Results based on keyword matching only \u2014 recall may be reduced. '
            f'Reason: {reason}</div></div></div>'
        )

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @staticmethod
    def card_row(cards_html: str) -> str:
        """Wrap multiple cards in a flex row."""
        return f'<div style="display:flex;flex-wrap:wrap;margin:15px 0;">{cards_html}</div>'

    @staticmethod
    def citation_footnotes(citations: list) -> str:
        """Render citations as expandable footnotes."""
        if not citations:
            return ""
        items = ""
        for i, c in enumerate(citations, 1):
            source = c.get("source_filename", "Unknown")[-50:]
            page = c.get("page_number", "?")
            items += f'<li style="margin:4px 0;font-size:11px;color:#555;">[{i}] {source} (p.{page})</li>'
        return (
            '<details style="margin-top:15px;">'
            '<summary style="cursor:pointer;font-size:12px;color:#2E86AB;">'
            f'Show {len(citations)} source citations</summary>'
            f'<ol style="padding-left:20px;">{items}</ol></details>'
        )

    # ------------------------------------------------------------------
    # Status badges
    # ------------------------------------------------------------------

    @staticmethod
    def status_badge(status: str, size: str = "md") -> str:
        """Render a colored status badge (HAS, DENIED, MIXED, NO_MENTION)."""
        colors = {
            "HAS": ("#1A7A6D", "#e6f7f4"),
            "HAS_GRANT": ("#1A7A6D", "#e6f7f4"),
            "DENIED": ("#D64045", "#fde8e8"),
            "MIXED": ("#F18F01", "#fff3e0"),
            "NO_MENTION": ("#6c757d", "#f0f0f0"),
            "ACTIVE": ("#1A7A6D", "#e6f7f4"),
            "EXPIRED": ("#6c757d", "#f0f0f0"),
            "PASS": ("#1A7A6D", "#e6f7f4"),
            "FAIL": ("#D64045", "#fde8e8"),
            "WARN": ("#F18F01", "#fff3e0"),
        }
        fg, bg = colors.get(status.upper(), ("#333", "#f0f0f0"))
        font_size = {"sm": "10px", "md": "12px", "lg": "14px"}.get(size, "12px")
        padding = {"sm": "2px 6px", "md": "4px 10px", "lg": "6px 14px"}.get(size, "4px 10px")
        return (
            f'<span style="display:inline-block;background:{bg};color:{fg};'
            f'padding:{padding};border-radius:4px;font-size:{font_size};'
            f'font-weight:600;letter-spacing:0.3px;">{status}</span>'
        )

    # ------------------------------------------------------------------
    # Progress bar
    # ------------------------------------------------------------------

    @staticmethod
    def progress_bar(value: float, max_val: float = 1.0, label: str = "",
                     width: str = "200px", color: str = "#2E86AB") -> str:
        """Render a horizontal progress bar."""
        pct = min(100, max(0, (value / max(max_val, 0.001)) * 100))
        label_html = f'<span style="font-size:11px;color:#555;margin-left:8px;">{label}</span>' if label else ""
        return (
            f'<div style="display:inline-flex;align-items:center;">'
            f'<div style="width:{width};height:8px;background:#e9ecef;'
            f'border-radius:4px;overflow:hidden;">'
            f'<div style="width:{pct:.1f}%;height:100%;background:{color};'
            f'border-radius:4px;"></div></div>{label_html}</div>'
        )

    # ------------------------------------------------------------------
    # Collapsible section
    # ------------------------------------------------------------------

    @staticmethod
    def collapsible(title: str, content: str, open_default: bool = False) -> str:
        """Render a collapsible details/summary section."""
        open_attr = " open" if open_default else ""
        return (
            f'<details style="margin:10px 0;border:1px solid #e0e0e0;'
            f'border-radius:8px;padding:0;"{open_attr}>'
            f'<summary style="cursor:pointer;padding:12px 16px;background:#f8f9fa;'
            f'border-radius:8px;font-weight:600;font-size:13px;color:#1B3A5C;">'
            f'{title}</summary>'
            f'<div style="padding:12px 16px;">{content}</div></details>'
        )

    # ------------------------------------------------------------------
    # Narrative block
    # ------------------------------------------------------------------

    @staticmethod
    def narrative(text: str, max_chars: int = 0) -> str:
        """Render a narrative text block (for AI summaries)."""
        if not text:
            return ""
        display_text = text[:max_chars] + "..." if max_chars and len(text) > max_chars else text
        # Replace newlines with <br>
        display_text = display_text.replace("\n\n", "</p><p style='margin:8px 0;'>")
        display_text = display_text.replace("\n", "<br>")
        return (
            f'<div style="background:#f8f9fa;border-left:3px solid #2E86AB;'
            f'padding:14px 18px;border-radius:0 8px 8px 0;margin:10px 0;'
            f'font-size:13px;line-height:1.6;color:#333;">'
            f'<p style="margin:0;">{display_text}</p></div>'
        )

    # ------------------------------------------------------------------
    # Methodology panel
    # ------------------------------------------------------------------

    @staticmethod
    def methodology_panel(steps: list[tuple[str, str]]) -> str:
        """Render a methodology/steps panel.

        Args:
            steps: List of (step_name, description) tuples.
        """
        items = ""
        for i, (step, desc) in enumerate(steps, 1):
            items += (
                f'<div style="display:flex;gap:12px;margin:8px 0;align-items:flex-start;">'
                f'<div style="min-width:24px;height:24px;border-radius:50%;'
                f'background:#2E86AB;color:white;display:flex;align-items:center;'
                f'justify-content:center;font-size:11px;font-weight:700;">{i}</div>'
                f'<div><div style="font-weight:600;font-size:12px;color:#1B3A5C;">{step}</div>'
                f'<div style="font-size:11px;color:#555;">{desc}</div></div></div>'
            )
        return (
            '<div style="background:#f8fafe;border:1px solid #d4e5f7;'
            'border-radius:8px;padding:16px;margin:15px 0;">'
            '<div style="font-weight:700;font-size:13px;color:#1B3A5C;margin-bottom:10px;">'
            'Methodology</div>'
            f'{items}</div>'
        )

    # ------------------------------------------------------------------
    # Page wrapper
    # ------------------------------------------------------------------

    @staticmethod
    def page_wrapper(body: str, title: str = "") -> str:
        """Wrap HTML body in a styled page container."""
        title_html = (
            f'<div style="border-bottom:3px solid #1B3A5C;padding-bottom:15px;margin-bottom:25px;">'
            f'<h1 style="color:#1B3A5C;margin:0;font-size:24px;font-weight:700;">{title}</h1>'
            f'<div style="font-size:11px;color:#888;margin-top:4px;">'
            f'Generated {datetime.now().strftime("%B %d, %Y at %I:%M %p")}</div></div>'
        ) if title else ""
        return (
            '<div style="font-family:system-ui,-apple-system,sans-serif;'
            'max-width:1200px;margin:0 auto;padding:20px;">'
            f'{title_html}{body}</div>'
        )

    # ==================================================================
    # REPORT-LEVEL RENDERERS
    # ==================================================================

    def render_report(self, report: Any, question: str = "") -> str:
        """Dispatch to the appropriate report renderer.

        Args:
            report: Any typed report dataclass from report_types.
            question: Original user question (shown in header).

        Returns:
            Complete HTML string suitable for displayHTML().
        """
        # Lazy import to avoid circular deps at module load time
        from platform.v4.contracts.report_types import (
            ClauseReport, StructuredExtractionReport, ProviderReport,
            RateReport, TemporalReport, ComparisonReport,
            ExplanationReport, MultiConceptReport,
        )

        if isinstance(report, ClauseReport):
            return self._render_clause(report, question)
        elif isinstance(report, StructuredExtractionReport):
            return self._render_structured_extraction(report, question)
        elif isinstance(report, ProviderReport):
            return self._render_provider(report, question)
        elif isinstance(report, RateReport):
            return self._render_rate(report, question)
        elif isinstance(report, TemporalReport):
            return self._render_temporal(report, question)
        elif isinstance(report, ComparisonReport):
            return self._render_comparison(report, question)
        elif isinstance(report, ExplanationReport):
            return self._render_explanation(report, question)
        elif isinstance(report, MultiConceptReport):
            return self._render_multi_concept(report, question)
        else:
            return self.page_wrapper(
                self.narrative(f"Unknown report type: {type(report).__name__}"),
                title="Report"
            )

    # ------------------------------------------------------------------
    # Clause existence report
    # ------------------------------------------------------------------

    def _render_clause(self, report: Any, question: str) -> str:
        """Render ClauseReport as full-page HTML."""
        concept = report.target_concept
        total = report.total_universe or (
            len(report.provider_findings) + len(report.no_mention_providers)
        )
        has_n = report.has_count
        denied_n = report.denied_count
        mixed_n = report.mixed_count
        nm_n = report.no_mention_count

        body = ""

        # Metric cards
        cards = self.card("Total Providers", str(total), "#1B3A5C", "&#x1F3E2;")
        cards += self.card("Has Provision", str(has_n), "#1A7A6D", "&#x2705;")
        cards += self.card("No Mention", str(nm_n), "#6c757d", "&#x2796;")
        cards += self.card("Denied", str(denied_n), "#D64045", "&#x274C;")
        cards += self.card("Mixed", str(mixed_n), "#F18F01", "&#x26A0;&#xFE0F;")
        body += self.card_row(cards)

        # Status distribution
        body += self.section_header("Classification Summary",
                                    f"{concept} status across {total} providers")
        body += '<table style="width:100%;border-collapse:collapse;font-size:13px;">'
        for label, count, color in [
            ("Has provision", has_n, "#1A7A6D"),
            ("No mention", nm_n, "#6c757d"),
            ("Explicitly denied", denied_n, "#D64045"),
            ("Mixed (grant + deny)", mixed_n, "#F18F01"),
        ]:
            pct = count / max(1, total) * 100
            body += (
                f'<tr><td style="padding:8px;font-weight:500;">{label}</td>'
                f'<td style="padding:8px;">{self.status_badge(label.split()[0].upper(), "sm")}</td>'
                f'<td style="padding:8px;text-align:right;font-weight:600;">{count}</td>'
                f'<td style="padding:8px;">{self.progress_bar(pct, 100, f"{pct:.1f}%", "150px", color)}</td></tr>'
            )
        body += '</table>'

        # Category distribution
        if report.category_distribution:
            body += self.section_header("Category Distribution")
            body += '<div style="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0;">'
            for cat, cnt in sorted(report.category_distribution.items(),
                                   key=lambda x: x[1], reverse=True):
                label = report.code_to_label(cat)
                body += (
                    f'<div style="background:#f0f4f8;padding:6px 12px;border-radius:6px;'
                    f'font-size:12px;"><span style="font-weight:600;">{label}</span>'
                    f' <span style="color:#666;">({cnt})</span></div>'
                )
            body += '</div>'

        # Top findings (first 15)
        relevant = sorted(report.relevant_passages, key=lambda p: p.provider)[:15]
        if relevant:
            body += self.section_header("Sample Findings",
                                       f"Showing {len(relevant)} of {len(report.relevant_passages)} passages")
            body += '<table style="width:100%;border-collapse:collapse;font-size:12px;">'
            body += (
                '<tr style="background:#1B3A5C;color:white;">'
                '<th style="padding:8px;">Provider</th>'
                '<th style="padding:8px;">Document</th>'
                '<th style="padding:8px;">Category</th>'
                '<th style="padding:8px;">Key Phrase</th></tr>'
            )
            for i, p in enumerate(relevant):
                bg = "#f7f9fb" if i % 2 == 0 else "white"
                phrase = (p.key_phrase or p.text[:80])[:80]
                body += (
                    f'<tr style="background:{bg};">'
                    f'<td style="padding:6px 8px;font-weight:500;">{p.provider}</td>'
                    f'<td style="padding:6px 8px;font-size:11px;">{p.filename[-45:]}</td>'
                    f'<td style="padding:6px 8px;">{report.code_to_label(p.category)}</td>'
                    f'<td style="padding:6px 8px;font-size:11px;color:#555;">{phrase}</td></tr>'
                )
            body += '</table>'

        # Methodology
        plan = report.execution_plan
        if plan:
            body += self.methodology_panel([
                ("Execution Plan", f"Core: {', '.join(plan.core_keywords[:5])} | Strategy: {plan.precision_strategy}"),
                ("Dynamic Taxonomy", f"{len(report.taxonomy)} sub-categories generated"),
                ("Hybrid Retrieval", "Vector Search semantic + SQL keyword scan"),
                ("LLM Classification", f"{report.llm_model}"),
                ("Provider Rollup", f"HAS:{has_n} / DENIED:{denied_n} / MIXED:{mixed_n} / NO_MENTION:{nm_n}"),
            ])

        return self.page_wrapper(body, title=f"{concept.title()} Analysis Report")

    # ------------------------------------------------------------------
    # Structured extraction report
    # ------------------------------------------------------------------

    def _render_structured_extraction(self, report: Any, question: str) -> str:
        """Render StructuredExtractionReport as HTML."""
        fd = report.field_definition
        total = report.total_universe or (report.extracted_count + report.no_data_count)

        body = ""
        cards = self.card("Extracted", str(report.extracted_count), "#1A7A6D", "&#x2705;")
        cards += self.card("No Data", str(report.no_data_count), "#6c757d", "&#x2796;")
        cards += self.card("High Conf.", str(report.high_confidence_count), "#1B3A5C", "&#x1F4AA;")
        cards += self.card("Universe", str(total), "#2E86AB", "&#x1F3E2;")
        body += self.card_row(cards)

        # Extraction summary
        body += self.section_header("Field Definition",
                                    f"{fd.field_name.replace('_', ' ').title()} ({fd.value_type.value})")
        body += self.narrative(f"{fd.description}\n\nKeywords: {', '.join(fd.keywords[:8])}")

        # Top values
        if report.provider_values:
            body += self.section_header("Extracted Values",
                                       f"{report.extracted_count} providers")
            body += '<table style="width:100%;border-collapse:collapse;font-size:12px;">'
            body += (
                '<tr style="background:#1B3A5C;color:white;">'
                '<th style="padding:8px;">Provider</th>'
                '<th style="padding:8px;">Value</th>'
                '<th style="padding:8px;">Confidence</th>'
                '<th style="padding:8px;">Evidence</th></tr>'
            )
            for i, (prov, val) in enumerate(list(report.provider_values.items())[:20]):
                bg = "#f7f9fb" if i % 2 == 0 else "white"
                evidence = (val.evidence or "")[:100]
                body += (
                    f'<tr style="background:{bg};">'
                    f'<td style="padding:6px 8px;font-weight:500;">{prov}</td>'
                    f'<td style="padding:6px 8px;font-weight:600;">{val.display_value or val.raw_value}</td>'
                    f'<td style="padding:6px 8px;">{self.status_badge(val.confidence.value.upper(), "sm")}</td>'
                    f'<td style="padding:6px 8px;font-size:11px;color:#555;">{evidence}</td></tr>'
                )
            body += '</table>'

        return self.page_wrapper(body, title=f"Extraction: {fd.field_name.replace('_', ' ').title()}")

    # ------------------------------------------------------------------
    # Provider deep-dive report
    # ------------------------------------------------------------------

    def _render_provider(self, report: Any, question: str) -> str:
        """Render ProviderReport as HTML."""
        prov = report.provider_name
        prof = report.profile

        body = ""
        cards = self.card("Rates", str(prof.total_rates), "#2E86AB", "&#x1F4B0;")
        cards += self.card("Amendments", str(prof.total_amendments), "#1B3A5C", "&#x1F4DD;")
        if prof.avg_inpatient_per_diem:
            cards += self.card("Avg IP Per Diem", f"${int(prof.avg_inpatient_per_diem):,}", "#1A7A6D", "&#x1F3E5;")
        body += self.card_row(cards)

        # Profile details
        body += self.section_header("Provider Profile")
        body += '<table style="width:auto;border-collapse:collapse;font-size:13px;">'
        for label, val in [
            ("Agreement Type", prof.agreement_type or "N/A"),
            ("Latest Amendment", prof.latest_amendment_date or "N/A"),
        ]:
            body += f'<tr><td style="padding:6px 14px 6px 0;font-weight:600;color:#1B3A5C;">{label}</td><td style="padding:6px 0;">{val}</td></tr>'
        body += '</table>'

        # Rate schedule (first 15)
        if report.rates:
            body += self.section_header("Rate Schedule", f"{len(report.rates)} entries")
            body += '<table style="width:100%;border-collapse:collapse;font-size:12px;">'
            body += (
                '<tr style="background:#1B3A5C;color:white;">'
                '<th style="padding:8px;">Category</th>'
                '<th style="padding:8px;">Service</th>'
                '<th style="padding:8px;">Rate</th>'
                '<th style="padding:8px;">Program</th></tr>'
            )
            for i, r in enumerate(report.rates[:15]):
                bg = "#f7f9fb" if i % 2 == 0 else "white"
                body += (
                    f'<tr style="background:{bg};">'
                    f'<td style="padding:6px 8px;">{r.rate_category}</td>'
                    f'<td style="padding:6px 8px;">{r.service_category}</td>'
                    f'<td style="padding:6px 8px;font-weight:600;">{r.rate_text}</td>'
                    f'<td style="padding:6px 8px;font-size:11px;">{r.program_normalized}</td></tr>'
                )
            body += '</table>'

        return self.page_wrapper(body, title=f"Provider: {prov}")

    # ------------------------------------------------------------------
    # Rate report
    # ------------------------------------------------------------------

    def _render_rate(self, report: Any, question: str) -> str:
        """Render RateReport as HTML."""
        body = ""
        cards = self.card("Rows", str(report.row_count), "#2E86AB", "&#x1F4CA;")
        cards += self.card("Query Type", report.query_type.replace("_", " ").title(), "#1B3A5C", "&#x1F50D;")
        body += self.card_row(cards)

        if report.rows:
            body += self.section_header("Rate Data", f"{report.row_count} rows")
            body += '<table style="width:100%;border-collapse:collapse;font-size:12px;">'
            headers = report.columns[:8]  # cap at 8 columns for display
            body += '<tr style="background:#1B3A5C;color:white;">' + ''.join(
                f'<th style="padding:8px;">{c.replace("_", " ").title()}</th>' for c in headers
            ) + '</tr>'
            for i, row in enumerate(report.rows[:25]):
                bg = "#f7f9fb" if i % 2 == 0 else "white"
                body += f'<tr style="background:{bg};">' + ''.join(
                    f'<td style="padding:6px 8px;">{str(row.get(c, ""))[:60]}</td>' for c in headers
                ) + '</tr>'
            body += '</table>'

        return self.page_wrapper(body, title=f"Rate Analysis: {report.query_type.replace('_', ' ').title()}")

    # ------------------------------------------------------------------
    # Temporal report
    # ------------------------------------------------------------------

    def _render_temporal(self, report: Any, question: str) -> str:
        """Render TemporalReport as HTML."""
        body = ""
        cards = self.card("Amendments", str(report.amendment_count), "#1B3A5C", "&#x1F4C5;")
        if report.provider_filter:
            cards += self.card("Provider", report.provider_filter[:20], "#2E86AB", "&#x1F3E2;")
        body += self.card_row(cards)

        if report.llm_summary:
            body += self.section_header("AI Change Summary")
            body += self.narrative(report.llm_summary)

        if report.amendments:
            body += self.section_header("Amendment Timeline", f"{report.amendment_count} amendments")
            body += '<table style="width:100%;border-collapse:collapse;font-size:12px;">'
            body += (
                '<tr style="background:#1B3A5C;color:white;">'
                '<th style="padding:8px;">Provider</th>'
                '<th style="padding:8px;">Order</th>'
                '<th style="padding:8px;">Type</th>'
                '<th style="padding:8px;">Summary</th></tr>'
            )
            for i, a in enumerate(report.amendments[:20]):
                bg = "#f7f9fb" if i % 2 == 0 else "white"
                summary = (a.summary_of_changes or "")[:120]
                body += (
                    f'<tr style="background:{bg};">'
                    f'<td style="padding:6px 8px;">{a.provider_name}</td>'
                    f'<td style="padding:6px 8px;text-align:center;">{a.amendment_order}</td>'
                    f'<td style="padding:6px 8px;">{a.document_type}</td>'
                    f'<td style="padding:6px 8px;font-size:11px;">{summary}</td></tr>'
                )
            body += '</table>'

        return self.page_wrapper(body, title="Temporal Analysis")

    # ------------------------------------------------------------------
    # Comparison report
    # ------------------------------------------------------------------

    def _render_comparison(self, report: Any, question: str) -> str:
        """Render ComparisonReport as HTML."""
        providers_str = " vs ".join(report.providers)
        body = ""
        body += self.section_header("Provider Comparison", f"Focus: {report.target_concept}")

        if report.llm_summary:
            body += self.narrative(report.llm_summary)

        if report.comparison_data:
            body += self.section_header("Side-by-Side")
            # comparison_data is dict[provider, dict] — render as table rows
            cols = ["Provider"] + sorted({k for d in report.comparison_data.values() for k in d})
            body += '<table style="width:100%;border-collapse:collapse;font-size:12px;">'
            body += '<tr style="background:#1B3A5C;color:white;">' + ''.join(
                f'<th style="padding:8px;">{c.replace("_", " ").title()}</th>' for c in cols
            ) + '</tr>'
            for i, (prov, row) in enumerate(list(report.comparison_data.items())[:20]):
                bg = "#f7f9fb" if i % 2 == 0 else "white"
                body += f'<tr style="background:{bg};">' + ''.join(
                    f'<td style="padding:6px 8px;">{str(row.get(c, ""))[:100]}</td>' for c in cols
                ) + '</tr>'
            body += '</table>'

        return self.page_wrapper(body, title=f"Comparison: {providers_str}")

    # ------------------------------------------------------------------
    # Explanation report
    # ------------------------------------------------------------------

    def _render_explanation(self, report: Any, question: str) -> str:
        """Render ExplanationReport as HTML."""
        body = ""
        cards = self.card("Citations", str(report.citation_count), "#2E86AB", "&#x1F4DA;")
        body += self.card_row(cards)

        body += self.section_header("AI Narrative", f"Based on {report.citation_count} sources")
        body += self.narrative(report.narrative or "No narrative generated.")

        if report.evidence_passages:
            body += self.citation_footnotes(report.evidence_passages[:30])

        return self.page_wrapper(body, title=f"Explanation: {report.target_concept.title()}")

    # ------------------------------------------------------------------
    # Multi-concept report
    # ------------------------------------------------------------------

    def _render_multi_concept(self, report: Any, question: str) -> str:
        """Render MultiConceptReport as HTML."""
        body = ""
        cards = self.card("Operator", report.operator, "#1B3A5C", "&#x1F517;")
        cards += self.card("Matches", str(report.match_count), "#1A7A6D", "&#x2705;")
        cards += self.card("Universe", str(report.total_universe), "#2E86AB", "&#x1F3E2;")
        body += self.card_row(cards)

        # Concept coverage
        body += self.section_header("Concept Coverage")
        for concept, cnt in report.concept_results.items():
            pct = cnt / max(1, report.total_universe) * 100
            body += (
                f'<div style="margin:6px 0;display:flex;align-items:center;gap:12px;">'
                f'<span style="font-weight:500;min-width:180px;font-size:13px;">{concept}</span>'
                f'{self.progress_bar(pct, 100, f"{cnt} ({pct:.0f}%)", "250px")}'
                f'</div>'
            )

        # Result set
        body += self.section_header("Matching Providers", f"{report.match_count} providers")
        if report.result_set:
            items = ''.join(
                f'<span style="display:inline-block;background:#e6f7f4;padding:4px 10px;'
                f'border-radius:4px;margin:3px;font-size:12px;">{p}</span>'
                for p in sorted(report.result_set)[:50]
            )
            body += f'<div style="margin:10px 0;">{items}</div>'

        return self.page_wrapper(body, title=f"Multi-Concept: {report.operator}")

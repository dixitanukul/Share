"""V3 presentation layer — rendering outputs (HTML, Excel, reports)."""
# Lazy imports to avoid crashing on missing optional packages (e.g. xlsxwriter)
# in lightweight runtime environments like Databricks Apps containers.


def __getattr__(name: str):
    """Lazy-import presentation submodules on first access."""
    if name == "ExcelExportService":
        from platform.v4.presentation.excel_export import ExcelExportService
        return ExcelExportService
    elif name == "HtmlRenderer":
        from platform.v4.presentation.html_renderer import HtmlRenderer
        return HtmlRenderer
    elif name in ("ReportValidator", "ValidationResult", "Severity", "Finding"):
        from platform.v4.presentation.report_validator import (
            ReportValidator, ValidationResult, Severity, Finding,
        )
        return locals()[name]
    raise AttributeError(f"module 'platform.v4.presentation' has no attribute {name!r}")


__all__ = [
    "ExcelExportService",
    "HtmlRenderer",
    "ReportValidator",
    "ValidationResult",
    "Severity",
    "Finding",
]

"""platform/v4/presentation/report_validator.py

P5-RPT-5: Typed report validation QA gate.

Validates typed report objects (from contracts.report_types) before
rendering or export. Replaces the Cell 19 "Universal Report Validation
Harness" that operated on Excel files — this operates on dataclass
instances directly.

Checks (by report type):
  ClauseReport:
    1. Universe count parity (HAS + DENIED + MIXED + NO_MENTION = total_universe)
    2. No null required fields (provider_findings non-empty, target_concept set)
    3. Category completeness (all passage categories in taxonomy)
    4. Confidence distribution (not all LOW or all missing)
    5. Cross-sheet consistency (matrix counts match findings)
    6. Polarity sanity (MIXED has genuine RESTRICT, not just ABSENT)
    7. Template hygiene (offset_extraction only when offset concept)

  StructuredExtractionReport:
    1. Universe parity (extracted + no_data = total_universe)
    2. No null required fields
    3. Confidence distribution
    4. Value type consistency

  ProviderReport / RateReport / TemporalReport / ComparisonReport /
  ExplanationReport / MultiConceptReport:
    1. No null required fields
    2. Structural integrity (non-empty result data)

Returns a ValidationResult with verdict (PASS / WARN / BLOCK) and
diagnostic list.

Zero Spark dependency — importable without a running cluster.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from platform.v4.contracts.report_types import (
    AnyReport,
    ClauseReport,
    ClassifiedPassage,
    ComparisonReport,
    ConfidenceLabel,
    ExplanationReport,
    MultiConceptReport,
    Polarity,
    ProviderReport,
    ProviderStatus,
    RateReport,
    StructuredExtractionReport,
    TaxonomyEntry,
    TemporalReport,
)


# ============================================================
# TYPES
# ============================================================


class Severity(str, Enum):
    """Validation finding severity."""
    PASS = "PASS"
    WARN = "WARN"
    BLOCK = "BLOCK"


@dataclass(frozen=True)
class Finding:
    """A single validation finding."""
    severity: Severity
    check: str
    detail: str

    @property
    def icon(self) -> str:
        return {"PASS": "\u2705", "WARN": "\u26a0\ufe0f", "BLOCK": "\u26d4"}[self.severity.value]


@dataclass
class ValidationResult:
    """Complete validation result for a report."""
    report_type: str
    findings: list[Finding] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        if any(f.severity == Severity.BLOCK for f in self.findings):
            return "BLOCK"
        if any(f.severity == Severity.WARN for f in self.findings):
            return "WARN"
        return "PASS"

    @property
    def n_block(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.BLOCK)

    @property
    def n_warn(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.WARN)

    @property
    def n_pass(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.PASS)

    @property
    def passed(self) -> bool:
        return self.verdict == "PASS"

    @property
    def blocking(self) -> bool:
        return self.n_block > 0

    def summary_line(self) -> str:
        return f"{self.verdict} ({self.n_block} block, {self.n_warn} warn, {self.n_pass} pass)"

    def format_text(self) -> str:
        """Human-readable text report."""
        lines = [f"Validation: {self.report_type}", f"Verdict: {self.summary_line()}", ""]
        for f in sorted(self.findings, key=lambda x: {"BLOCK": 0, "WARN": 1, "PASS": 2}[x.severity.value]):
            lines.append(f"  {f.icon} [{f.severity.value:5}] {f.check}: {f.detail}")
        return "\n".join(lines)


# ============================================================
# VALIDATORS — ClauseReport
# ============================================================


def _validate_clause_report(report: ClauseReport) -> list[Finding]:
    findings: list[Finding] = []

    def rec(sev: Severity, check: str, detail: str) -> None:
        findings.append(Finding(sev, check, detail))

    # --- CHECK 1: Universe count parity ---
    has = report.has_count
    denied = report.denied_count
    mixed = report.mixed_count
    no_mention = report.no_mention_count
    computed_total = has + mixed + no_mention  # denied is subset of has_count per ProviderStatus logic

    # Actually: has_count counts HAS_GRANT + HAS_DENIED, denied_count counts HAS_DENIED only
    # So unique statuses: HAS_GRANT, HAS_DENIED, MIXED, NO_MENTION
    has_grant = sum(1 for f in report.provider_findings.values()
                    if f.status == ProviderStatus.HAS_GRANT)
    has_denied = denied
    total_accounted = has_grant + has_denied + mixed + no_mention

    if report.total_universe > 0:
        if total_accounted == report.total_universe:
            rec(Severity.PASS, "Universe count parity",
                f"HAS_GRANT({has_grant}) + DENIED({has_denied}) + MIXED({mixed}) "
                f"+ NO_MENTION({no_mention}) = {report.total_universe} \u2713")
        else:
            rec(Severity.BLOCK, "Universe count parity",
                f"HAS_GRANT({has_grant}) + DENIED({has_denied}) + MIXED({mixed}) "
                f"+ NO_MENTION({no_mention}) = {total_accounted} \u2260 total_universe({report.total_universe})")
    else:
        # total_universe not set — derive from provider data
        provider_count = len(report.provider_findings) + no_mention
        rec(Severity.WARN, "Universe count parity",
            f"total_universe=0 (not set); derived provider count = {provider_count}")

    # --- CHECK 2: Required fields ---
    if not report.target_concept:
        rec(Severity.BLOCK, "Required fields", "target_concept is empty")
    elif not report.provider_findings and not report.no_mention_providers:
        rec(Severity.BLOCK, "Required fields", "both provider_findings and no_mention_providers are empty")
    else:
        rec(Severity.PASS, "Required fields", "target_concept and provider data present \u2713")

    # --- CHECK 3: Category completeness (taxonomy compliance) ---
    if report.taxonomy:
        known_codes = {t.code for t in report.taxonomy}
        passage_codes = {p.category for p in report.classified_passages if p.is_relevant}
        unknown = passage_codes - known_codes - {"NOT_RELEVANT", "UNKNOWN", ""}
        if unknown:
            rec(Severity.WARN, "Category completeness",
                f"{len(unknown)} passage categories not in taxonomy: {sorted(unknown)[:5]}")
        else:
            rec(Severity.PASS, "Category completeness",
                f"all {len(passage_codes)} categories defined in taxonomy \u2713")
    else:
        rec(Severity.WARN, "Category completeness", "no taxonomy defined — cannot validate categories")

    # --- CHECK 4: Confidence distribution ---
    if report.confidence_scores:
        labels = [cs.label for cs in report.confidence_scores.values()]
        n_high = sum(1 for l in labels if l == ConfidenceLabel.HIGH)
        n_mod = sum(1 for l in labels if l == ConfidenceLabel.MODERATE)
        n_low = sum(1 for l in labels if l == ConfidenceLabel.LOW)
        total_conf = len(labels)
        if total_conf > 0 and n_low == total_conf:
            rec(Severity.WARN, "Confidence distribution",
                f"ALL {total_conf} providers have LOW confidence — possible scoring issue")
        elif total_conf > 0 and n_low / total_conf > 0.5:
            rec(Severity.WARN, "Confidence distribution",
                f"{n_low}/{total_conf} ({n_low/total_conf:.0%}) LOW — review scoring")
        else:
            rec(Severity.PASS, "Confidence distribution",
                f"HIGH={n_high} MODERATE={n_mod} LOW={n_low} \u2713")
    else:
        rec(Severity.WARN, "Confidence distribution",
            "no confidence_scores populated (enrichment not run?)")

    # --- CHECK 5: Cross-sheet consistency (matrix vs findings) ---
    # Provider set in provider_findings should align with classified_passages providers
    if report.classified_passages:
        passage_providers = {p.provider for p in report.classified_passages if p.is_relevant}
        finding_providers = set(report.provider_findings.keys())
        # Every passage provider should have a finding entry
        orphan_passages = passage_providers - finding_providers
        if orphan_passages:
            rec(Severity.WARN, "Cross-sheet consistency",
                f"{len(orphan_passages)} providers in passages but not in provider_findings: "
                f"{sorted(orphan_passages)[:4]}")
        else:
            rec(Severity.PASS, "Cross-sheet consistency",
                f"all {len(passage_providers)} passage providers have finding entries \u2713")

        # Category count consistency — provider_findings.categories should match passage counts
        mismatches = []
        for pname, psummary in report.provider_findings.items():
            if not psummary.categories:
                continue
            actual_count = sum(1 for p in report.classified_passages
                              if p.provider == pname and p.is_relevant)
            summary_count = sum(psummary.categories.values())
            if actual_count != summary_count:
                mismatches.append(f"{pname}({summary_count} vs {actual_count})")
        if mismatches:
            rec(Severity.WARN, "Category count consistency",
                f"{len(mismatches)} providers with category sum \u2260 passage count: {mismatches[:4]}")
        else:
            rec(Severity.PASS, "Category count consistency",
                "all provider category sums match passage counts \u2713")
    else:
        rec(Severity.WARN, "Cross-sheet consistency", "no classified_passages to validate")

    # --- CHECK 6: Polarity sanity (false MIXED detection) ---
    mixed_providers = report.get_mixed_providers()
    if mixed_providers and report.taxonomy:
        absence_codes = {t.code for t in report.taxonomy if t.is_absence_code}
        false_mixed = []
        for pname, psummary in mixed_providers.items():
            # Check if any deny-classified passage has a genuine RESTRICT category
            deny_passages = [p for p in report.classified_passages
                            if p.provider == pname and p.is_denial]
            has_genuine_restrict = any(
                p.category not in absence_codes for p in deny_passages
            )
            if not has_genuine_restrict and deny_passages:
                deny_cats = sorted({p.category for p in deny_passages})
                false_mixed.append(f"{pname} (deny only from: {deny_cats})")
        if false_mixed:
            rec(Severity.BLOCK, "Polarity sanity (MIXED)",
                f"{len(false_mixed)} false MIXED \u2014 deny driven by ABSENT category: "
                f"{false_mixed[:5]}")
        else:
            rec(Severity.PASS, "Polarity sanity (MIXED)",
                f"all {len(mixed_providers)} MIXED providers have genuine RESTRICT \u2713")
    elif not mixed_providers:
        rec(Severity.PASS, "Polarity sanity (MIXED)", "no MIXED providers \u2713")

    # --- CHECK 7: Template hygiene (offset_extraction when non-offset) ---
    concept_lower = report.target_concept.lower()
    if report.offset_extraction is not None and "offset" not in concept_lower:
        rec(Severity.WARN, "Template hygiene",
            "offset_extraction present in non-offset report (vestigial template bleed)")
    else:
        rec(Severity.PASS, "Template hygiene", "no concept-irrelevant data \u2713")

    # --- CHECK 8: Findings completeness (null passages) ---
    if report.classified_passages:
        blank_category = sum(1 for p in report.classified_passages
                           if not p.category or p.category in ("", "None"))
        blank_provider = sum(1 for p in report.classified_passages
                           if not p.provider or p.provider.strip() in ("", "None"))
        blank_reasoning = sum(1 for p in report.relevant_passages
                            if not p.reasoning.strip())
        issues = []
        if blank_category:
            issues.append(f"{blank_category} blank categories")
        if blank_provider:
            issues.append(f"{blank_provider} blank providers")
        if blank_reasoning:
            issues.append(f"{blank_reasoning} blank reasoning (relevant only)")
        if issues:
            rec(Severity.WARN, "Findings completeness", "; ".join(issues))
        else:
            rec(Severity.PASS, "Findings completeness",
                f"all {len(report.classified_passages)} passages have provider/category/reasoning \u2713")

    return findings


# ============================================================
# VALIDATORS — StructuredExtractionReport
# ============================================================


def _validate_structured_extraction(report: StructuredExtractionReport) -> list[Finding]:
    findings: list[Finding] = []

    def rec(sev: Severity, check: str, detail: str) -> None:
        findings.append(Finding(sev, check, detail))

    # --- Universe parity ---
    extracted = report.extracted_count
    no_data = report.no_data_count
    total_accounted = extracted + no_data
    if report.total_universe > 0:
        if total_accounted == report.total_universe:
            rec(Severity.PASS, "Universe parity",
                f"extracted({extracted}) + no_data({no_data}) = {report.total_universe} \u2713")
        else:
            rec(Severity.BLOCK, "Universe parity",
                f"extracted({extracted}) + no_data({no_data}) = {total_accounted} "
                f"\u2260 total_universe({report.total_universe})")
    else:
        rec(Severity.WARN, "Universe parity", f"total_universe not set; derived = {total_accounted}")

    # --- Required fields ---
    if not report.field_definition.field_name:
        rec(Severity.BLOCK, "Required fields", "field_definition.field_name is empty")
    elif not report.provider_values and not report.no_data_providers:
        rec(Severity.BLOCK, "Required fields", "both provider_values and no_data_providers empty")
    else:
        rec(Severity.PASS, "Required fields",
            f"field=\'{report.field_definition.field_name}\', "
            f"{extracted} extracted, {no_data} no_data \u2713")

    # --- Confidence distribution ---
    if report.provider_values:
        n_high = report.high_confidence_count
        n_med = report.medium_confidence_count
        n_low = report.low_confidence_count
        total = len(report.provider_values)
        if total > 0 and n_low == total:
            rec(Severity.WARN, "Confidence distribution",
                f"ALL {total} extractions LOW confidence")
        else:
            rec(Severity.PASS, "Confidence distribution",
                f"HIGH={n_high} MEDIUM={n_med} LOW={n_low} \u2713")

    # --- Value consistency ---
    if report.provider_values:
        null_values = sum(1 for v in report.provider_values.values()
                        if not v.raw_value and not v.display_value)
        if null_values > 0:
            rec(Severity.WARN, "Value consistency",
                f"{null_values}/{len(report.provider_values)} extractions have no raw_value or display_value")
        else:
            rec(Severity.PASS, "Value consistency", "all extractions have display values \u2713")

    return findings


# ============================================================
# VALIDATORS — Simple reports (structural integrity only)
# ============================================================


def _validate_provider_report(report: ProviderReport) -> list[Finding]:
    findings: list[Finding] = []
    if not report.profile.provider_name:
        findings.append(Finding(Severity.BLOCK, "Required fields", "profile.provider_name is empty"))
    elif not report.rates and not report.terms and not report.amendments:
        findings.append(Finding(Severity.WARN, "Structural integrity",
                               "no rates, terms, or amendments — report is empty"))
    else:
        findings.append(Finding(Severity.PASS, "Structural integrity",
                               f"provider=\'{report.provider_name}\', "
                               f"rates={len(report.rates)}, terms={len(report.terms)}, "
                               f"amendments={len(report.amendments)} \u2713"))
    return findings


def _validate_rate_report(report: RateReport) -> list[Finding]:
    findings: list[Finding] = []
    if not report.query_type:
        findings.append(Finding(Severity.BLOCK, "Required fields", "query_type is empty"))
    elif report.is_empty:
        findings.append(Finding(Severity.WARN, "Structural integrity",
                               f"zero rows returned for query_type=\'{report.query_type}\'"))
    else:
        findings.append(Finding(Severity.PASS, "Structural integrity",
                               f"query_type=\'{report.query_type}\', "
                               f"{report.row_count} rows, {len(report.columns)} columns \u2713"))
    return findings


def _validate_temporal_report(report: TemporalReport) -> list[Finding]:
    findings: list[Finding] = []
    if not report.provider_filter:
        findings.append(Finding(Severity.BLOCK, "Required fields", "provider_filter is empty"))
    elif not report.amendments and not report.llm_summary:
        findings.append(Finding(Severity.WARN, "Structural integrity",
                               "no amendments and no LLM summary"))
    else:
        findings.append(Finding(Severity.PASS, "Structural integrity",
                               f"provider=\'{report.provider_filter}\', "
                               f"{report.amendment_count} amendments \u2713"))
    return findings


def _validate_comparison_report(report: ComparisonReport) -> list[Finding]:
    findings: list[Finding] = []
    if not report.providers or len(report.providers) < 2:
        findings.append(Finding(Severity.BLOCK, "Required fields",
                               f"need >=2 providers, got {len(report.providers)}"))
    elif not report.comparison_data and not report.llm_summary:
        findings.append(Finding(Severity.WARN, "Structural integrity",
                               "no comparison_data and no LLM summary"))
    else:
        findings.append(Finding(Severity.PASS, "Structural integrity",
                               f"comparing {len(report.providers)} providers \u2713"))
    return findings


def _validate_explanation_report(report: ExplanationReport) -> list[Finding]:
    findings: list[Finding] = []
    if not report.narrative or len(report.narrative.strip()) < 20:
        findings.append(Finding(Severity.BLOCK, "Required fields",
                               "narrative is empty or trivially short"))
    else:
        findings.append(Finding(Severity.PASS, "Structural integrity",
                               f"narrative={len(report.narrative)} chars, "
                               f"{report.citation_count} citations \u2713"))
    return findings


def _validate_multi_concept_report(report: MultiConceptReport) -> list[Finding]:
    findings: list[Finding] = []
    if not report.concepts:
        findings.append(Finding(Severity.BLOCK, "Required fields", "concepts list is empty"))
    elif not report.operator:
        findings.append(Finding(Severity.BLOCK, "Required fields", "operator is empty"))
    else:
        # Universe parity check for multi-concept
        if report.total_universe > 0 and report.match_count > report.total_universe:
            findings.append(Finding(Severity.BLOCK, "Universe parity",
                                   f"match_count({report.match_count}) > total_universe({report.total_universe})"))
        else:
            findings.append(Finding(Severity.PASS, "Structural integrity",
                                   f"op={report.operator}, concepts={report.concepts}, "
                                   f"matches={report.match_count} \u2713"))
    return findings


# ============================================================
# PUBLIC API
# ============================================================


_VALIDATORS = {
    ClauseReport: _validate_clause_report,
    StructuredExtractionReport: _validate_structured_extraction,
    ProviderReport: _validate_provider_report,
    RateReport: _validate_rate_report,
    TemporalReport: _validate_temporal_report,
    ComparisonReport: _validate_comparison_report,
    ExplanationReport: _validate_explanation_report,
    MultiConceptReport: _validate_multi_concept_report,
}


class ReportValidator:
    """QA gate that validates typed report objects before export/render.

    Usage:
        validator = ReportValidator()
        result = validator.validate(clause_report)
        if result.blocking:
            raise ValueError(f"Report failed QA: {result.summary_line()}")
    """

    def validate(self, report: AnyReport) -> ValidationResult:
        """Validate a report object and return findings."""
        report_type = type(report)
        validator_fn = _VALIDATORS.get(report_type)
        if validator_fn is None:
            return ValidationResult(
                report_type=report_type.__name__,
                findings=[Finding(Severity.WARN, "Unknown report type",
                                 f"no validator registered for {report_type.__name__}")]
            )
        findings = validator_fn(report)
        return ValidationResult(
            report_type=report_type.__name__,
            findings=findings,
        )

    def validate_and_print(self, report: AnyReport) -> ValidationResult:
        """Validate and print a human-readable summary."""
        result = self.validate(report)
        print(result.format_text())
        return result

    def assert_pass(self, report: AnyReport, allow_warn: bool = True) -> ValidationResult:
        """Validate and raise ValueError if report has BLOCK findings.

        Args:
            report: The report to validate.
            allow_warn: If True, only BLOCK findings raise. If False, WARN also raises.
        """
        result = self.validate(report)
        if result.blocking:
            raise ValueError(
                f"Report QA BLOCKED: {result.summary_line()}\n"
                + "\n".join(f"  {f.check}: {f.detail}"
                           for f in result.findings if f.severity == Severity.BLOCK)
            )
        if not allow_warn and result.n_warn > 0:
            raise ValueError(
                f"Report QA has warnings (strict mode): {result.summary_line()}\n"
                + "\n".join(f"  {f.check}: {f.detail}"
                           for f in result.findings if f.severity == Severity.WARN)
            )
        return result

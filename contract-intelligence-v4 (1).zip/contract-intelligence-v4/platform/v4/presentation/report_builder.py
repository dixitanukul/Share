"""platform/v4/presentation/report_builder.py

Step 1.2: Report builder — converts ClauseExistenceResult (raw dict) into
typed ClauseReport with proper ProviderStatus enum mapping.

This is the MISSING BRIDGE between:
  - ClauseExistenceTool._run() → returns ToolResult(data=vars(ClauseExistenceResult))
  - report_enrichment.py / excel_export.py / html_renderer.py / report_validator.py
    which all expect a typed ClauseReport with ProviderFindingSummary objects

The polarity classification (HAS/MIXED/DENIED/NO_MENTION) is already computed
correctly by classifier.py (polarity-aware rollup). This module simply translates
the raw dict form into the typed dataclass form that the presentation layer consumes.

Ported from V2 notebook Cell 16 (P5-RPT-6) _build_clause_report().
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from platform.v4.contracts.report_types import (
    ClassifiedPassage,
    ClauseReport,
    ExecutionPlan,
    Polarity,
    ProviderFindingSummary,
    ProviderStatus,
    TaxonomyEntry,
)

logger = logging.getLogger(__name__)


# ============================================================
# Status string → ProviderStatus enum
# ============================================================

def status_from_raw(raw: str) -> ProviderStatus:
    """Map a raw status string from classifier.py to ProviderStatus enum.

    Classifier outputs:
      "HAS_<CONCEPT>"      → ProviderStatus.HAS_GRANT
      "<CONCEPT>_DENIED"   → ProviderStatus.HAS_DENIED
      "MIXED"              → ProviderStatus.MIXED
      (anything else)      → ProviderStatus.NO_MENTION

    This is order-sensitive: check DENIED before HAS because
    "HAS_DENIED" would match both.
    """
    s = (raw or "").upper()
    if "DENIED" in s:
        return ProviderStatus.HAS_DENIED
    if "MIXED" in s:
        return ProviderStatus.MIXED
    if "HAS" in s:
        return ProviderStatus.HAS_GRANT
    return ProviderStatus.NO_MENTION


# ============================================================
# Dict → typed dataclass conversions
# ============================================================

def _build_taxonomy(raw_taxonomy: List[Dict]) -> List[TaxonomyEntry]:
    """Convert raw taxonomy dicts to typed TaxonomyEntry objects."""
    entries = []
    for t in raw_taxonomy:
        pol_str = t.get("polarity", "")
        if pol_str in ("GRANT", "RESTRICT", "ABSENT"):
            polarity = Polarity(pol_str)
        elif t.get("is_denial"):
            polarity = Polarity.RESTRICT
        else:
            polarity = Polarity.GRANT

        entries.append(TaxonomyEntry(
            code=t.get("code", ""),
            label=t.get("label", t.get("code", "")),
            description=t.get("description", ""),
            polarity=polarity,
            is_denial=bool(t.get("is_denial", False)),
        ))
    return entries


def _build_classified_passages(raw_classified: List[Dict]) -> List[ClassifiedPassage]:
    """Convert raw classified dicts to typed ClassifiedPassage objects."""
    passages = []
    for c in raw_classified:
        passages.append(ClassifiedPassage(
            provider=c.get("provider", ""),
            filename=c.get("filename", ""),
            category=c.get("category", "NOT_RELEVANT"),
            is_denial=bool(c.get("is_denial", False)),
            text=c.get("text", ""),
            reasoning=c.get("reasoning", ""),
            key_phrase=c.get("key_phrase", ""),
            page=c.get("page"),
            keywords=c.get("keywords", []),
        ))
    return passages


def _build_provider_findings(
    raw_provider_data: Dict[str, Any],
    classified_passages: List[ClassifiedPassage],
) -> Dict[str, ProviderFindingSummary]:
    """Convert raw provider_data dict to typed ProviderFindingSummary objects.

    Also cross-links findings from classified_passages to each provider's
    findings list (for downstream Excel Sheet 4 / detailed findings).
    """
    # Build passage lookup by provider for findings linkage
    passages_by_provider: Dict[str, List[ClassifiedPassage]] = {}
    for p in classified_passages:
        if p.provider:
            passages_by_provider.setdefault(p.provider, []).append(p)

    findings: Dict[str, ProviderFindingSummary] = {}
    for prov, pd in raw_provider_data.items():
        status = status_from_raw(pd.get("status", ""))
        docs = pd.get("docs", set())
        # Handle both set and list forms (sets don't survive JSON round-trip)
        if isinstance(docs, list):
            docs = set(docs)
        categories = dict(pd.get("categories", {}))

        findings[prov] = ProviderFindingSummary(
            provider_name=prov,
            status=status,
            documents_found=docs,
            categories=categories,
            findings=passages_by_provider.get(prov, []),
        )

    return findings


# ============================================================
# Main builder
# ============================================================

def build_clause_report(
    tool_result_data: Dict[str, Any],
    question: str = "",
    cost_estimate: float = 0.0,
) -> ClauseReport:
    """Build a typed ClauseReport from a ClauseExistenceResult dict.

    Parameters
    ----------
    tool_result_data : dict
        The ``data`` field from ``ToolResult`` returned by ``ClauseExistenceTool``.
        This is ``vars(ClauseExistenceResult)`` — a flat dict with keys:
        concept, provider_data, no_mention, classified, taxonomy, plan,
        understanding, has_count, denied_count, mixed_count, etc.
    question : str
        The original user question (for metadata).
    cost_estimate : float
        LLM cost estimate (for metadata).

    Returns
    -------
    ClauseReport
        Fully typed report object ready for enrichment, validation, and export.

    Example
    -------
        result = clause_existence_tool._run(question="Which providers have offset clause?")
        report = build_clause_report(result.data, question="Which providers have offset clause?")
        enrichment_service.enrich_clause_report(report)
        excel_service.export(report, "/tmp/offset_clause_report.xlsx")
    """
    d = tool_result_data

    # 1. Taxonomy
    taxonomy = _build_taxonomy(d.get("taxonomy", []))

    # 2. Classified passages
    passages = _build_classified_passages(d.get("classified", []))

    # 3. Provider findings (with status enum mapping)
    provider_findings = _build_provider_findings(
        d.get("provider_data", {}),
        passages,
    )

    # 4. Execution plan
    pl = d.get("plan", {})
    execution_plan = ExecutionPlan(
        core_keywords=pl.get("core_keywords", []),
        extended_keywords=pl.get("extended_keywords", []),
        precision_strategy=pl.get("precision_strategy", "balanced"),
    )

    # 5. No-mention providers
    no_mention = set(d.get("no_mention", []))

    # 6. Assemble
    report = ClauseReport(
        target_concept=d.get("concept", "contract provision"),
        provider_findings=provider_findings,
        no_mention_providers=no_mention,
        classified_passages=passages,
        taxonomy=taxonomy,
        execution_plan=execution_plan,
        total_universe=d.get("total_universe", 0),
        question=question,
        elapsed_s=d.get("elapsed_s", 0.0),
        cost_estimate=cost_estimate,
    )

    # Log summary for debugging
    logger.info(
        "ClauseReport built: concept=%s  HAS=%d  MIXED=%d  DENIED=%d  "
        "NO_MENTION=%d  total=%d  passages=%d",
        report.target_concept,
        report.has_count, report.mixed_count, report.denied_count,
        report.no_mention_count, report.total_universe,
        len(report.classified_passages),
    )

    return report


def build_clause_report_from_tool_result(
    tool_result: Any,
    question: str = "",
) -> Optional[ClauseReport]:
    """Convenience wrapper: extract data from a ToolResult and build report.

    Returns None if the tool result is not from a clause_existence tool
    or if it failed.
    """
    if not hasattr(tool_result, "data") or not isinstance(tool_result.data, dict):
        return None
    if not tool_result.success:
        return None
    # Quick check: must have provider_data key
    if "provider_data" not in tool_result.data:
        return None
    cost = getattr(tool_result, "cost_estimate", 0.0) or 0.0
    return build_clause_report(tool_result.data, question=question, cost_estimate=cost)

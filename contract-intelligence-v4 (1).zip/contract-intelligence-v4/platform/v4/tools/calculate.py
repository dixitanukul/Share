"""
platform/v4/tools/calculate.py

Numeric calculation tool for the V3 agent.

Capabilities
------------
- Percent difference / change between two values
- Percentile rank within a list of values
- Benchmark comparison (provider vs. peers)
- Simple arithmetic on structured data rows
- Running totals / aggregations on in-memory result sets

This tool is called after sql_query has fetched raw numbers.
It operates entirely on in-memory data (no Spark required) and is
therefore synchronous and essentially zero-cost.
"""
from __future__ import annotations

import statistics
from typing import Any, Optional, Union

from ..contracts.tool_types import Confidence, ToolResult
from ..tools.base import BaseTool


# ---------------------------------------------------------------------------
# Calculation helpers
# ---------------------------------------------------------------------------

def _pct_diff(a: float, b: float) -> float:
    """Percent difference from b to a: (a-b)/b * 100."""
    if b == 0:
        return float("inf") if a != 0 else 0.0
    return round((a - b) / abs(b) * 100, 2)


def _percentile_rank(value: float, population: list[float]) -> float:
    """Return percentile rank (0–100) of value within population."""
    if not population:
        return 0.0
    n_below = sum(1 for v in population if v < value)
    return round(n_below / len(population) * 100, 1)


def _safe_float(v: Any) -> Optional[float]:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# CalculateTool
# ---------------------------------------------------------------------------

class CalculateTool(BaseTool):
    """
    Performs numeric calculations on data fetched by sql_query.

    All operations work on in-memory Python data; no Spark dependency.
    """

    @property
    def name(self) -> str:
        return "calculate"

    def _run(
        self,
        operation:  str = "percent_diff",
        value_a:    Optional[Union[float, str]] = None,
        value_b:    Optional[Union[float, str]] = None,
        values:     Optional[list] = None,
        rows:       Optional[list[dict]] = None,
        column:     Optional[str] = None,
        question:   str = "",
        **kwargs:   Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        operation   : One of: percent_diff | percentile | benchmark_compare |
                      aggregate | rate_compare
        value_a     : Primary numeric value (for percent_diff, benchmark_compare).
        value_b     : Comparison value (for percent_diff).
        values      : List of numeric values (for percentile).
        rows        : List of dicts from sql_query (for aggregate).
        column      : Column name to aggregate (for aggregate).
        question    : Original question (for result summary).
        """
        op = operation.lower()

        if op == "percent_diff":
            return self._percent_diff(value_a, value_b, question)
        elif op == "percentile":
            return self._percentile(value_a, values, question)
        elif op == "benchmark_compare":
            return self._benchmark_compare(value_a, values, question)
        elif op == "aggregate":
            return self._aggregate(rows, column, question)
        elif op == "rate_compare":
            return self._rate_compare(rows, question)
        else:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Unknown operation: {operation}",
                confidence=Confidence.LOW,
                error_message=f"Valid operations: percent_diff, percentile, benchmark_compare, aggregate, rate_compare",
            )

    # ------------------------------------------------------------------
    # Operation implementations
    # ------------------------------------------------------------------

    def _percent_diff(
        self,
        value_a: Any,
        value_b: Any,
        question: str,
    ) -> ToolResult:
        a = _safe_float(value_a)
        b = _safe_float(value_b)
        if a is None or b is None:
            return ToolResult(
                success=False,
                data=None,
                summary="Cannot compute percent difference: invalid inputs",
                confidence=Confidence.LOW,
                error_message=f"value_a={value_a}, value_b={value_b}",
            )
        diff = _pct_diff(a, b)
        direction = "higher" if diff > 0 else "lower" if diff < 0 else "equal"
        return ToolResult(
            success=True,
            data={"value_a": a, "value_b": b, "percent_diff": diff, "direction": direction},
            summary=f"{a:,.2f} is {abs(diff):.1f}% {direction} than {b:,.2f}",
            confidence=Confidence.HIGH,
        )

    def _percentile(
        self,
        value: Any,
        population: Optional[list],
        question: str,
    ) -> ToolResult:
        v = _safe_float(value)
        if v is None:
            return ToolResult(
                success=False,
                data=None,
                summary="Cannot compute percentile: invalid value",
                confidence=Confidence.LOW,
                error_message=f"value={value}",
            )
        if not population:
            return ToolResult(
                success=False,
                data=None,
                summary="Cannot compute percentile: empty population",
                confidence=Confidence.LOW,
            )
        pop_floats = [x for x in (_safe_float(x) for x in population) if x is not None]
        if not pop_floats:
            return ToolResult(
                success=False,
                data=None,
                summary="Cannot compute percentile: no numeric values in population",
                confidence=Confidence.LOW,
            )
        pct = _percentile_rank(v, pop_floats)
        return ToolResult(
            success=True,
            data={
                "value":       v,
                "percentile":  pct,
                "n_peers":     len(pop_floats),
                "peer_median": round(statistics.median(pop_floats), 4),
                "peer_mean":   round(statistics.mean(pop_floats), 4),
            },
            summary=f"{v:,.4f} is at the {pct:.0f}th percentile among {len(pop_floats)} peers",
            confidence=Confidence.HIGH,
        )

    def _benchmark_compare(
        self,
        provider_value: Any,
        peer_values: Optional[list],
        question: str,
    ) -> ToolResult:
        """Compare a provider's value against peer benchmark values."""
        v = _safe_float(provider_value)
        if v is None or not peer_values:
            return ToolResult(
                success=False,
                data=None,
                summary="Insufficient data for benchmark comparison",
                confidence=Confidence.LOW,
            )
        peers = [x for x in (_safe_float(x) for x in peer_values) if x is not None]
        if not peers:
            return ToolResult(
                success=False,
                data=None,
                summary="No numeric peer values for benchmark comparison",
                confidence=Confidence.LOW,
            )

        pct       = _percentile_rank(v, peers)
        p_median  = statistics.median(peers)
        diff_vs_median = _pct_diff(v, p_median)
        direction = "above" if diff_vs_median > 0 else "below" if diff_vs_median < 0 else "at"

        return ToolResult(
            success=True,
            data={
                "provider_value":     v,
                "percentile":         pct,
                "peer_median":        round(p_median, 4),
                "pct_vs_median":      diff_vs_median,
                "n_peers":            len(peers),
            },
            summary=(
                f"Provider at {pct:.0f}th percentile; "
                f"{abs(diff_vs_median):.1f}% {direction} peer median"
            ),
            confidence=Confidence.HIGH,
        )

    def _aggregate(
        self,
        rows: Optional[list[dict]],
        column: Optional[str],
        question: str,
    ) -> ToolResult:
        """Compute sum, mean, min, max for a column across data rows."""
        if not rows:
            return ToolResult(
                success=False,
                data=None,
                summary="No rows to aggregate",
                confidence=Confidence.LOW,
            )
        if not column:
            return ToolResult(
                success=False,
                data=None,
                summary="column parameter required for aggregate",
                confidence=Confidence.LOW,
                error_message="column is None",
            )
        values = [_safe_float(r.get(column)) for r in rows]
        values = [v for v in values if v is not None]
        if not values:
            return ToolResult(
                success=False,
                data=None,
                summary=f"No numeric values in column '{column}'",
                confidence=Confidence.LOW,
            )
        agg = {
            "column":  column,
            "count":   len(values),
            "sum":     round(sum(values), 4),
            "mean":    round(statistics.mean(values), 4),
            "median":  round(statistics.median(values), 4),
            "min":     round(min(values), 4),
            "max":     round(max(values), 4),
        }
        return ToolResult(
            success=True,
            data=agg,
            summary=f"{column}: count={agg['count']}, mean={agg['mean']:.4f}, range=[{agg['min']:.4f}, {agg['max']:.4f}]",
            confidence=Confidence.HIGH,
        )

    def _rate_compare(
        self,
        rows: Optional[list[dict]],
        question: str,
    ) -> ToolResult:
        """
        Compare rate_amount values across rows, grouping by provider.
        Expects rows with 'provider_name' and 'rate_amount' columns.
        """
        if not rows:
            return ToolResult(
                success=False,
                data=None,
                summary="No rate rows to compare",
                confidence=Confidence.LOW,
            )

        by_provider: dict[str, list[float]] = {}
        for r in rows:
            prov  = str(r.get("provider_name", "Unknown"))
            rate  = _safe_float(r.get("rate_amount") or r.get("rate"))
            if rate is not None:
                by_provider.setdefault(prov, []).append(rate)

        if not by_provider:
            return ToolResult(
                success=False,
                data=None,
                summary="No numeric rate_amount values found in rows",
                confidence=Confidence.LOW,
            )

        summary_rows = [
            {
                "provider_name": prov,
                "rate_count":    len(rates),
                "avg_rate":      round(statistics.mean(rates), 4),
                "max_rate":      round(max(rates), 4),
                "min_rate":      round(min(rates), 4),
            }
            for prov, rates in sorted(by_provider.items())
        ]
        return ToolResult(
            success=True,
            data=summary_rows,
            summary=f"Rate comparison across {len(summary_rows)} provider(s)",
            confidence=Confidence.HIGH,
        )

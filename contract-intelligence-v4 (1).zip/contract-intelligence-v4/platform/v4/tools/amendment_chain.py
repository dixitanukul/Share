"""AmendmentChainTool: Exposes fact_supersession for rate/doc version history."""
from __future__ import annotations
from typing import Any
from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus
from platform.v4.tools.base import BaseTool


class AmendmentChainTool(BaseTool):
    name = "amendment_chain"
    description = (
        "Trace rate supersession history for a provider — which document replaced which, "
        "rate changes over time, and amendment effective dates. Uses fact_supersession "
        "(provider_id 100% populated via Fix 3.5). Filter: confidence >= 0.7."
    )

    def __init__(self, spark):
        self.spark = spark
        self.tbl = "dev_adb.raw.fact_supersession"

    def _run(self, **kwargs: Any) -> ToolResult:
        provider_id = kwargs.get("provider_id", "")
        provider_name = kwargs.get("provider", "") or kwargs.get("provider_name", "")

        # Prefer provider_id if given; fallback to name lookup
        if provider_id:
            where = f"fs.provider_id = '{provider_id}'"
        elif provider_name:
            where = f"""fs.provider_id IN (
                SELECT provider_id FROM dev_adb.raw.dim_provider_canonical
                WHERE LOWER(provider_name) LIKE LOWER('%{provider_name}%')
            )"""
        else:
            return ToolResult(success=False, data=None,
                             summary="provider or provider_id required",
                             confidence=Confidence.LOW, status=ToolStatus.ERROR)

        sql = f"""
            SELECT fs.superseded_filename, fs.superseding_filename,
                   fs.superseding_effective_date, fs.superseded_effective_date,
                   fs.rate_change_pct, fs.confidence, fs.change_summary,
                   fs.rate_domain, fs.old_rate_numeric, fs.new_rate_numeric
            FROM {self.tbl} fs
            WHERE {where}
              AND fs.confidence >= 0.7
            ORDER BY fs.superseding_effective_date DESC
            LIMIT 50
        """

        df = self.spark.sql(sql)
        rows = [row.asDict() for row in df.collect()]
        return ToolResult(
            success=True, data=rows,
            summary=f"[amendment_chain] {len(rows)} supersession records (confidence>=0.7)",
            confidence=Confidence.HIGH if rows else Confidence.MEDIUM,
            status=ToolStatus.SUCCESS,
        )

"""
platform/v4/tools/clause_existence/revalidation.py

P4C-CE-5: Post-classification quality passes.

ClauseRevalidator:
  revalidate_denials() -- targeted LLM re-validation for denial-classified passages
  settlement_audit()   -- Step 6.25: downgrade settlement-only evidence
  latest_doc_gate()    -- Step 6.3: downgrade historical-evidence-only providers

Migrated from V2 Cell 6 _revalidate_denials(), Step 6.25, Step 6.3.
"""
from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Set, Tuple

from platform.v4.config.settings import LLM_REASONING

logger = logging.getLogger(__name__)

# Settlement file patterns (Step 6.25)
_SETTLEMENT_PATTERNS = ("settlementagmt", "settlement_agmt", "_settlement.")

# Version regex (Step 6.3)
_VER_RE = re.compile(r"_v(\d+)\.[pP][dD][fF]$")
_BASE_RE = re.compile(r"_v\d+\.[pP][dD][fF]$")


class ClauseRevalidator:
    """
    Post-classification quality passes for clause existence analysis.

    Constructor
    -----------
    llm_client : DatabricksLLMClient (required for revalidate_denials)
    spark      : SparkSession (required for latest_doc_gate version cache)
    catalog    : Unity Catalog catalog name
    schema     : Unity Catalog schema name
    """

    def __init__(
        self,
        llm_client: Optional[Any] = None,
        spark: Optional[Any] = None,
        catalog: str = "dev_adb",
        schema: str = "raw",
    ) -> None:
        self._llm = llm_client
        self._spark = spark
        self._fulltext_table = f"{catalog}.{schema}.tbl_vs_unified_ready"

    # ------------------------------------------------------------------
    # Step 5.5: Denial re-validation
    # ------------------------------------------------------------------

    def revalidate_denials(
        self,
        classified: List[Dict],
        taxonomy: List[Dict],
        target_concept: str,
    ) -> Tuple[List[Dict], int, int]:
        """
        Binary LLM confirmation pass for denial-classified passages.

        FALSE_DENIAL cases are reclassified to the first positive category.
        The written-consent exception is baked into the LLM prompt:
        "no right to offset without prior written approval" IS a restriction.

        Returns (classified, confirmed_count, reclassified_count).
        """
        denial_codes: Set[str] = {c["code"] for c in taxonomy if c.get("is_denial", False)}
        positive_codes = sorted({c["code"] for c in taxonomy if not c.get("is_denial", False)})
        denial_passages = [c for c in classified if c.get("category") in denial_codes]

        if not denial_passages:
            return classified, 0, 0

        logger.info("Re-validation: %d denial passages", len(denial_passages))

        def revalidate_batch(batch: List[Dict]) -> List[Dict]:
            batch_text = ""
            for j, c in enumerate(batch):
                batch_text += (
                    f"\n---PASSAGE {j+1} (Provider: {c['provider']})---\n"
                    f"{c['text'][:800]}\n"
                )
            prompt = (
                f'You are a senior healthcare contract attorney reviewing passages '
                f'classified as PROHIBITING "{target_concept}".\n\n'
                "TRUE PROHIBITION: contract EXPLICITLY states it is NOT ALLOWED / PROHIBITED / WAIVED.\n"
                "FALSE DENIAL (reclassify to positive): grants rights with conditions; "
                "limits scope; provider waives their own defenses; caps amount; "
                "discusses dispute procedures; settlement-specific waiver for past claims.\n"
                "EXCEPTION: do NOT reclassify as FALSE_DENIAL if passage says "
                "'no right to offset...without prior written approval/consent' -- "
                "a written-consent requirement IS a real restriction, return CONFIRMED_DENIAL.\n\n"
                f"Positive categories available: {positive_codes}\n\n"
                "Return ONLY JSON array: "
                '[{"passage_num":1,"verdict":"CONFIRMED_DENIAL or FALSE_DENIAL",'
                '"correct_category":null,"reason":"one sentence"}]'
                f"\n\nPassages:{batch_text}"
            )
            try:
                raw = self._ask_llm(prompt, max_tokens=2000)
                raw = raw.strip()
                if raw.startswith("```"):
                    raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0]
                if not raw.endswith("]"):
                    last = raw.rfind("}")
                    if last > 0:
                        raw = raw[:last+1] + "]"
                return json.loads(raw)
            except Exception as exc:
                logger.warning("Revalidation batch failed: %s", exc)
                return [
                    {"passage_num": j+1, "verdict": "CONFIRMED_DENIAL", "correct_category": None}
                    for j in range(len(batch))
                ]

        denial_batches = [denial_passages[i:i+5] for i in range(0, len(denial_passages), 5)]
        reclassified = 0
        confirmed = 0

        with ThreadPoolExecutor(max_workers=2) as executor:  # Reduced from 8: semaphore in LLMClient caps concurrency
            futures = {executor.submit(revalidate_batch, b): b for b in denial_batches}
            for future in as_completed(futures):
                batch = futures[future]
                try:
                    verdicts = future.result()
                    for v in verdicts:
                        idx = v.get("passage_num", 1) - 1
                        if 0 <= idx < len(batch):
                            if v.get("verdict") == "FALSE_DENIAL":
                                new_cat = v.get("correct_category") or (positive_codes[0] if positive_codes else "CONFIRMED_PRESENT")
                                if new_cat not in set(positive_codes):
                                    new_cat = positive_codes[0] if positive_codes else "CONFIRMED_PRESENT"
                                batch[idx]["category"] = new_cat
                                batch[idx]["reasoning"] = (
                                    f"[Re-validated: {v.get('reason', 'false denial')}] "
                                    + batch[idx].get("reasoning", "")
                                )
                                reclassified += 1
                            else:
                                confirmed += 1
                except Exception:
                    confirmed += len(batch)

        logger.info("Re-validation done: %d confirmed, %d reclassified", confirmed, reclassified)
        return classified, confirmed, reclassified

    # ------------------------------------------------------------------
    # Step 6.25: Settlement audit
    # ------------------------------------------------------------------

    def settlement_audit(
        self,
        provider_data: Dict,
        no_mention: List[str],
    ) -> Tuple[Dict, List[str], List[str]]:
        """
        Downgrade providers whose ONLY evidence is from settlement files.

        Settlement agreements describe resolved past disputes, not ongoing
        contractual rights. Providers with ALL docs = settlement files AND
        <= 2 findings are moved to no_mention.

        Returns (provider_data, no_mention, downgraded_list).
        """
        downgraded: List[str] = []
        for prov in list(provider_data.keys()):
            pdata = provider_data[prov]
            if not pdata["status"].startswith("HAS_"):
                continue
            docs_lower = [f.lower() for f in pdata.get("docs", set())]
            all_settlement = bool(docs_lower) and all(
                any(p in fn for p in _SETTLEMENT_PATTERNS) for fn in docs_lower
            )
            if all_settlement and len(pdata.get("findings", [])) <= 2:
                no_mention.append(prov)
                del provider_data[prov]
                downgraded.append(prov)
        if downgraded:
            logger.info("Settlement audit: %d downgraded to NO_MENTION", len(downgraded))
        return provider_data, no_mention, downgraded

    # ------------------------------------------------------------------
    # Step 6.3: Latest doc currency gate
    # ------------------------------------------------------------------

    def latest_doc_gate(
        self,
        provider_data: Dict,
        no_mention: List[str],
    ) -> Tuple[Dict, List[str], List[str]]:
        """
        Mark providers whose evidence comes only from historical versions.

        Builds a max-version cache from tbl_vs_unified_ready.
        Providers with HAS_ status but no evidence from the latest _vN.pdf
        are downgraded to HAS_*_HISTORICAL.

        Returns (provider_data, no_mention, historical_list).
        """
        if not self._spark:
            return provider_data, no_mention, []

        # Build max-version cache
        max_version_cache: Dict[str, int] = {}
        try:
            all_fns = (
                self._spark.sql(
                    f"SELECT DISTINCT source_filename FROM {self._fulltext_table}"
                ).toPandas()["source_filename"].tolist()
            )
            for fn in all_fns:
                vm = _VER_RE.search(str(fn))
                if vm:
                    base = _BASE_RE.sub("", str(fn))
                    vnum = int(vm.group(1))
                    if base not in max_version_cache or vnum > max_version_cache[base]:
                        max_version_cache[base] = vnum
            logger.info("Latest doc gate: cached %d contract bases", len(max_version_cache))
        except Exception as exc:
            logger.warning("Latest doc gate: version cache failed: %s", exc)
            return provider_data, no_mention, []

        no_current: List[str] = []
        for prov in list(provider_data.keys()):
            pdata = provider_data[prov]
            if not pdata["status"].startswith("HAS_"):
                continue
            if "_HISTORICAL" in pdata["status"]:
                continue
            fnames = list(pdata.get("docs", set()))
            if not fnames:
                continue
            has_latest = False
            for fn in fnames:
                vm = _VER_RE.search(str(fn))
                if not vm:
                    continue
                ver = int(vm.group(1))
                base = _BASE_RE.sub("", str(fn))
                max_v = max_version_cache.get(base, ver)
                if ver >= max_v and ver > 0:
                    has_latest = True
                    break
            if not has_latest:
                pdata["status"] = pdata["status"] + "_HISTORICAL"
                pdata["latest_doc_review"] = "Needs Review"
                no_current.append(prov)

        if no_current:
            logger.info(
                "Latest doc gate: %d providers downgraded (historical-only): %s",
                len(no_current), no_current[:5]
            )
        return provider_data, no_mention, no_current

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _ask_llm(self, prompt: str, max_tokens: int = 2000) -> str:
        if not self._llm:
            return "[]"
        return self._llm.chat(
            model=LLM_REASONING,
            system="You are a senior healthcare contract attorney. Return only valid JSON.",
            user=prompt,
            max_tokens=max_tokens,
            temperature=0.0,
        )

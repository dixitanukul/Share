"""
platform/v4/tools/clause_existence/passage_retrieval.py

P4C-CE-3: Hybrid retrieval pipeline for clause existence analysis.

Steps:
  apply_corpus_frequency_gate() -- auto-classify extended keywords strong/weak
  retrieve()                    -- VS semantic + SQL keyword, dedup, caps
  _hybrid_retrieval()           -- dual-channel search
  _score_and_dedup()            -- merge channels, per-file dedup
  _per_provider_sweep()         -- coverage guarantee for missed providers

Migrated from V2 Cell 5 _hybrid_retrieval(), _corpus_frequency_gate(),
Cell 6 _score_and_dedup(), _per_provider_retrieval_sweep().
"""
from __future__ import annotations

import logging
import math
from typing import Any, Callable, Dict, List, Optional, Tuple

import pandas as pd


logger = logging.getLogger(__name__)

# Sentinel for no keyword DataFrame
_NO_KW_DF: Optional[pd.DataFrame] = None


class PassageRetriever:
    """
    Hybrid retrieval for clause existence: VS semantic + SQL keyword.

    Constructor
    -----------
    spark         : SparkSession
    vs_search_fn  : callable(query: str, top_k: int) -> list[dict]
                    Each dict must have: chunk_text, provider_name,
                    source_filename, chunk_index, page_number,
                    total_pages, total_chunks.
                    If None, semantic channel is disabled (keyword-only).
    catalog/schema: table location overrides (default from settings).
    """

    # ------------------------------------------------------------------
    # Layer-3 hard ceiling (circuit breaker for extremely broad queries)
    # ------------------------------------------------------------------
    HARD_CEILING = 8000
    MAX_CHUNKS_PER_FILE = 5

    def __init__(
        self,
        spark: Any,
        vs_search_fn: Optional[Callable] = None,
        catalog: str = "dev_adb",
        schema: str = "raw",
    ) -> None:
        self._spark = spark
        self._vs_search_fn = vs_search_fn
        self._fulltext_table = f"{catalog}.{schema}.tbl_vs_unified_ready"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def apply_corpus_frequency_gate(self, plan: Dict) -> Dict:
        """
        Auto-classify extended keywords into strong/weak by corpus frequency.

        Rules:
          corpus_freq > 5%               -> auto-excluded (pure noise)
          corpus_freq > 1%               -> weak (needs co-occurrence partner)
          single-word + hits > 3,000     -> weak (ambiguous)
          else                           -> strong (specific enough alone)

        Known-taxonomy plans bypass this gate entirely
        (plan["bypass_frequency_gate"] == True).
        """
        if plan.get("bypass_frequency_gate", False):
            plan["extended_strong"] = plan.get("extended_keywords", [])
            plan["extended_weak"] = []
            return plan

        all_ext = plan.get("extended_keywords", [])
        if not all_ext:
            plan["extended_strong"] = []
            plan["extended_weak"] = []
            return plan

        safe_kws = [kw.lower().replace("'", "''") for kw in all_ext]
        cases = [
            f"SUM(CASE WHEN LOWER(chunk_text) LIKE '%{kw}%' THEN 1 ELSE 0 END) AS kw_{i}"
            for i, kw in enumerate(safe_kws)
        ]
        try:
            freq_row = self._spark.sql(
                f"SELECT COUNT(*) AS total, {chr(44).join(cases)} "
                f"FROM {self._fulltext_table} WHERE LENGTH(chunk_text) >= 50"
            ).first()
            total = freq_row["total"]
        except Exception as exc:
            logger.warning("Frequency gate query failed: %s -- treating all as strong", exc)
            plan["extended_strong"] = all_ext
            plan["extended_weak"] = []
            return plan

        excluded = [
            e["keyword"] if isinstance(e, dict) else e
            for e in plan.get("excluded_keywords", [])
        ]
        strong: List[str] = []
        weak: List[str] = []

        for i, kw in enumerate(all_ext):
            hits = freq_row[f"kw_{i}"]
            pct = hits / max(1, total)
            is_single = " " not in kw.strip()
            if pct > 0.05:
                excluded.append(kw)
                logger.info("Freq gate: excluded %r (%d hits, %.1f%%)", kw, hits, pct * 100)
            elif pct > 0.01:
                weak.append(kw)
            elif is_single and hits > 3000:
                weak.append(kw)
            else:
                strong.append(kw)

        plan["extended_strong"] = strong
        plan["extended_weak"] = weak
        plan["excluded_keywords"] = excluded
        return plan

    def retrieve(
        self,
        understanding: Dict,
        plan: Dict,
        all_provider_names: List[str],
        max_per_provider: int = 10,
        hard_ceiling: int = HARD_CEILING,
    ) -> List[Dict]:
        """
        Full retrieval pipeline.

        1. Hybrid retrieval (VS semantic + SQL keyword)
        2. Score & dedup (per-file cap = MAX_CHUNKS_PER_FILE)
        3. Per-provider sweep (coverage guarantee)
        4. Provider-level cap (max_per_provider)
        5. Hard ceiling (circuit breaker)

        Returns list of candidate dicts:
            text, provider, filename, page, score, source
        """
        # Step 3: dual-channel retrieval
        semantic_results, keyword_df = self._hybrid_retrieval(understanding, plan)
        logger.info(
            "Retrieval: %d semantic, %d keyword rows",
            len(semantic_results),
            len(keyword_df) if keyword_df is not None else 0,
        )

        # Step 4: merge + per-file dedup
        candidates = self._score_and_dedup(semantic_results, keyword_df, understanding)

        # Step 4.5: per-provider coverage sweep
        candidates, rescued, missed = self._per_provider_sweep(
            candidates, all_provider_names, plan, understanding
        )
        if rescued:
            logger.info("Per-provider sweep: rescued %d/%d providers", rescued, missed)

        # Provider-level passage cap
        if max_per_provider is not None:
            candidates = self._apply_provider_cap(candidates, max_per_provider)

        # Hard ceiling (circuit breaker)
        if hard_ceiling and len(candidates) > hard_ceiling:
            score3 = [c for c in candidates if c.get("score", 2) >= 3]
            if len(score3) >= 100:
                logger.warning(
                    "Hard ceiling: %d -> %d passages (score>=3 only)",
                    len(candidates), len(score3)
                )
                candidates = score3
            else:
                logger.warning(
                    "Hard ceiling: truncating %d -> %d passages",
                    len(candidates), hard_ceiling
                )
                candidates = candidates[:hard_ceiling]

        return candidates

    # ------------------------------------------------------------------
    # Internal: hybrid retrieval
    # ------------------------------------------------------------------

    def _hybrid_retrieval(
        self,
        understanding: Dict,
        plan: Dict,
    ) -> Tuple[List, Optional[pd.DataFrame]]:
        """VS semantic + SQL keyword retrieval."""
        semantic_results: List = []
        if self._vs_search_fn:
            try:
                raw = self._vs_search_fn(understanding.get("semantic_query", ""), 100)
                # Normalise: accept list-of-lists (V2) or list-of-dicts (V3)
                semantic_results = [self._normalise_vs_row(r) for r in raw]
            except Exception as exc:
                logger.warning("VS semantic search failed: %s", exc)

        keyword_df = self._keyword_sql_search(understanding, plan)
        return semantic_results, keyword_df

    def _normalise_vs_row(self, row: Any) -> Dict:
        """Convert V2 list-of-indexed-fields or V3 dict to a common dict."""
        if isinstance(row, dict):
            return row
        # V2 format: [chunk_text, provider_name, source_filename, chunk_index,
        #              page_number, total_pages, total_chunks]
        keys = ["chunk_text", "provider_name", "source_filename",
                "chunk_index", "page_number", "total_pages", "total_chunks"]
        return {k: (row[i] if i < len(row) else None) for i, k in enumerate(keys)}

    def _keyword_sql_search(
        self,
        understanding: Dict,
        plan: Dict,
    ) -> Optional[pd.DataFrame]:
        """Spark-side scored keyword search with ROW_NUMBER dedup."""
        keywords = understanding.get("search_keywords", [])
        if not keywords:
            return None

        core_kws = [k.lower().replace("'", "''") for k in plan.get("core_keywords", keywords)]
        strong_ext = [k.lower().replace("'", "''") for k in plan.get("extended_strong", plan.get("extended_keywords", []))]
        weak_ext = [k.lower().replace("'", "''") for k in plan.get("extended_weak", [])]

        # All effective keywords (exclude auto-excluded)
        excluded_set = {
            (e["keyword"].lower() if isinstance(e, dict) else e.lower())
            for e in plan.get("excluded_keywords", [])
        }
        all_kws = [kw.lower().replace("'", "''") for kw in keywords]
        effective_kws = [kw for kw in all_kws if kw not in excluded_set] or all_kws

        like_clauses = " OR ".join(f"LOWER(chunk_text) LIKE '%{kw}%'" for kw in effective_kws)

        provider_filter = understanding.get("provider_filter")
        provider_clause = (
            f"AND LOWER(provider_name) LIKE '%{provider_filter.lower().replace(chr(39), chr(39)+chr(39))}%'"
            if provider_filter else ""
        )

        def _score_sql(kws: List[str]) -> str:
            if not kws:
                return "0"
            return " + ".join(
                f"CASE WHEN LOWER(chunk_text) LIKE '%{kw}%' THEN 1 ELSE 0 END"
                for kw in kws
            )

        sql = f"""
        WITH matched AS (
            SELECT provider_name, source_filename, chunk_index,
                   page_number_est AS page_number,
                   NULL AS total_pages, NULL AS total_chunks,
                   SUBSTRING(chunk_text, 1, 1200) AS chunk_text,
                   LENGTH(chunk_text) AS text_length,
                   ({_score_sql(core_kws)}) AS core_hits,
                   ({_score_sql(strong_ext)}) AS strong_ext_hits,
                   ({_score_sql(weak_ext)}) AS weak_ext_hits
            FROM {self._fulltext_table}
            WHERE ({like_clauses}) AND LENGTH(chunk_text) >= 50 {provider_clause}
        ),
        scored AS (
            SELECT *,
                CASE
                    WHEN core_hits >= 2 OR (core_hits >= 1 AND (strong_ext_hits + weak_ext_hits) >= 1) THEN 3
                    WHEN core_hits >= 1 OR strong_ext_hits >= 1 OR weak_ext_hits >= 2 THEN 2
                    ELSE 1
                END AS score
            FROM matched
        ),
        deduped AS (
            SELECT *, ROW_NUMBER() OVER (
                PARTITION BY source_filename ORDER BY score DESC, text_length DESC
            ) AS rn FROM scored WHERE score >= 2
        )
        SELECT provider_name, source_filename, chunk_index, page_number,
               total_pages, total_chunks, chunk_text, text_length, score,
               core_hits, (strong_ext_hits + weak_ext_hits) AS ext_hits
        FROM deduped WHERE rn <= 5
        """
        try:
            return self._spark.sql(sql).toPandas()
        except Exception as exc:
            logger.warning("Keyword SQL failed: %s -- semantic-only mode", exc)
            return None

    # ------------------------------------------------------------------
    # Internal: score & dedup
    # ------------------------------------------------------------------

    def _score_and_dedup(
        self,
        semantic_results: List[Dict],
        keyword_df: Optional[pd.DataFrame],
        understanding: Dict,
    ) -> List[Dict]:
        """Merge semantic + keyword channels. Cap per-file at MAX_CHUNKS_PER_FILE."""
        candidates: List[Dict] = []
        keywords = [kw.lower() for kw in understanding.get("search_keywords", [])]

        for row in semantic_results:
            text = str(row.get("chunk_text") or "")[:1200]
            provider = str(row.get("provider_name") or "Unknown")
            filename = str(row.get("source_filename") or "Unknown")
            ci = int(row.get("chunk_index") or 0)
            pn = int(row.get("page_number") or 0)
            tp = int(row.get("total_pages") or 0)
            tc = int(row.get("total_chunks") or 0)
            if pn and tp and pn <= tp:
                page = pn
            elif ci and tp and tc:
                page = math.ceil(ci * tp / tc)
            else:
                page = pn if pn else 0
            text_lower = text.lower()
            kw_hits = sum(1 for kw in keywords if kw in text_lower)
            score = 3 if kw_hits >= 2 else (2 if kw_hits == 1 else 1)
            if score >= 2:
                candidates.append({
                    "text": text, "provider": provider, "filename": filename,
                    "page": page, "score": score, "source": "semantic",
                })

        if keyword_df is not None and not keyword_df.empty:
            for _, row in keyword_df.iterrows():
                kw_pn = int(row.get("page_number", 0)) if pd.notna(row.get("page_number")) else 0
                kw_tp = int(row.get("total_pages", 0)) if pd.notna(row.get("total_pages")) else 0
                kw_ci = int(row.get("chunk_index", 0)) if pd.notna(row.get("chunk_index")) else 0
                kw_tc = int(row.get("total_chunks", 0)) if pd.notna(row.get("total_chunks")) else 0
                if kw_pn and kw_tp and kw_pn <= kw_tp:
                    kw_page = kw_pn
                elif kw_ci and kw_tp and kw_tc:
                    kw_page = math.ceil(kw_ci * kw_tp / kw_tc)
                else:
                    kw_page = kw_pn if kw_pn else 0
                candidates.append({
                    "text": str(row.get("chunk_text", ""))[:1200],
                    "provider": str(row.get("provider_name", "Unknown")),
                    "filename": str(row.get("source_filename", "Unknown")),
                    "page": kw_page,
                    "score": int(row.get("score", 2)),
                    "source": "keyword",
                })

        # Per-file dedup (keep top MAX_CHUNKS_PER_FILE by score)
        candidates.sort(key=lambda x: x["score"], reverse=True)
        file_counts: Dict[str, int] = {}
        deduped: List[Dict] = []
        for c in candidates:
            fn = c["filename"]
            file_counts[fn] = file_counts.get(fn, 0) + 1
            if file_counts[fn] <= self.MAX_CHUNKS_PER_FILE:
                deduped.append(c)
        return deduped

    # ------------------------------------------------------------------
    # Internal: per-provider sweep (Step 4.5)
    # ------------------------------------------------------------------

    def _per_provider_sweep(
        self,
        candidates: List[Dict],
        all_provider_names: List[str],
        plan: Dict,
        understanding: Dict,
    ) -> Tuple[List[Dict], int, int]:
        """
        Guarantee every provider in the universe gets at least one passage.

        Targets providers absent from the main retrieval. Runs a targeted SQL
        scan with OR logic on core+extended keywords. Returns top-3 per missed
        provider (score >= 2).

        Returns (augmented_candidates, rescued_count, missed_count).
        """
        covered = {c["provider"].strip().lower() for c in candidates}
        all_lower = {p.strip().lower(): p for p in all_provider_names}
        missed = [all_lower[k] for k in all_lower if k not in covered]
        if not missed:
            return candidates, 0, 0

        core_kws = [k.lower().replace("'", "''") for k in plan.get("core_keywords", [])]
        ext_kws = [k.lower().replace("'", "''") for k in plan.get("extended_keywords", [])]
        all_kws = list(set(core_kws + ext_kws))
        if not all_kws:
            return candidates, 0, len(missed)

        like_clauses = " OR ".join(f"LOWER(chunk_text) LIKE '%{kw}%'" for kw in all_kws)
        core_score_sql = (
            " + ".join(f"CASE WHEN LOWER(chunk_text) LIKE '%{kw}%' THEN 1 ELSE 0 END" for kw in core_kws)
            if core_kws else "0"
        )
        ext_score_sql = (
            " + ".join(f"CASE WHEN LOWER(chunk_text) LIKE '%{kw}%' THEN 1 ELSE 0 END" for kw in ext_kws)
            if ext_kws else "0"
        )

        rescued_passages: List[Dict] = []
        batch_size = 100
        for start in range(0, len(missed), batch_size):
            batch = missed[start:start + batch_size]
            prov_sql = ", ".join(f"'{p.replace(chr(39), chr(39)+chr(39))}'" for p in batch)
            try:
                sql = f"""
                WITH matched AS (
                    SELECT provider_name, source_filename, chunk_index,
                           page_number_est AS page_number, NULL AS total_pages, NULL AS total_chunks,
                           SUBSTRING(chunk_text, 1, 1200) AS chunk_text,
                           LENGTH(chunk_text) AS text_length,
                           ({core_score_sql}) AS core_hits,
                           ({ext_score_sql}) AS ext_hits
                    FROM {self._fulltext_table}
                    WHERE ({like_clauses}) AND LENGTH(chunk_text) >= 50
                      AND provider_name IN ({prov_sql})
                ),
                scored AS (
                    SELECT *,
                        CASE WHEN core_hits >= 2 OR (core_hits >= 1 AND ext_hits >= 1) THEN 3
                             WHEN core_hits >= 1 OR ext_hits >= 2 THEN 2
                             WHEN ext_hits >= 1 THEN 2
                             ELSE 1 END AS score
                    FROM matched
                ),
                ranked AS (
                    SELECT *, ROW_NUMBER() OVER (
                        PARTITION BY provider_name
                        ORDER BY score DESC, core_hits DESC, text_length DESC
                    ) AS rn FROM scored WHERE score >= 2
                )
                SELECT provider_name, source_filename, chunk_index,
                       page_number, total_pages, total_chunks,
                       chunk_text, text_length, score
                FROM ranked WHERE rn <= 3
                """
                df = self._spark.sql(sql).toPandas()
                for _, row in df.iterrows():
                    pn = int(row.get("page_number", 0)) if pd.notna(row.get("page_number")) else 0
                    tp = int(row.get("total_pages", 0)) if pd.notna(row.get("total_pages")) else 0
                    ci = int(row.get("chunk_index", 0)) if pd.notna(row.get("chunk_index")) else 0
                    tc = int(row.get("total_chunks", 0)) if pd.notna(row.get("total_chunks")) else 0
                    if pn and tp and pn <= tp:
                        page = pn
                    elif ci and tp and tc:
                        page = math.ceil(ci * tp / tc)
                    else:
                        page = pn if pn else 0
                    rescued_passages.append({
                        "text": str(row.get("chunk_text", ""))[:1200],
                        "provider": str(row["provider_name"]),
                        "filename": str(row["source_filename"]),
                        "page": page,
                        "score": int(row.get("score", 2)),
                        "source": "per_provider_sweep",
                    })
            except Exception as exc:
                logger.warning("Per-provider sweep batch failed: %s", exc)

        rescued_count = len(set(r["provider"] for r in rescued_passages))
        return candidates + rescued_passages, rescued_count, len(missed)

    # ------------------------------------------------------------------
    # Internal: caps
    # ------------------------------------------------------------------

    def _apply_provider_cap(
        self, candidates: List[Dict], max_per_provider: int
    ) -> List[Dict]:
        """Keep best max_per_provider passages per provider (already sorted score DESC)."""
        prov_counts: Dict[str, int] = {}
        capped: List[Dict] = []
        for c in candidates:
            p = c["provider"]
            prov_counts[p] = prov_counts.get(p, 0) + 1
            if prov_counts[p] <= max_per_provider:
                capped.append(c)
        if len(capped) < len(candidates):
            logger.info(
                "Provider cap (%d/provider): %d -> %d passages",
                max_per_provider, len(candidates), len(capped)
            )
        return capped

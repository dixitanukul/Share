"""
platform/v4/tools/clause_existence/rescue.py

P4C-CE-6: Step 6.5 false-negative safety net.

FalseNegativeRescuer:
  rescue()                   -- scan NO_MENTION providers for strong-phrase hits
  _run_post_rescue_assertion() -- warn if NO_MENTION providers still have >=2 hits

Migrated from V2 Cell 6 Step 6.5.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from platform.v4.services.concepts import get_recall_signals, KNOWN_RECALL_SIGNALS

logger = logging.getLogger(__name__)


class FalseNegativeRescuer:
    """
    Step 6.5: Post-rollup false-negative safety net.

    Problem: LLM may classify sparse but genuine offset language as NOT_RELEVANT
    when a provider has very few keyword-matching chunks (1-4 out of thousands).

    Solution: For each NO_MENTION provider, do a direct strong-phrase SQL scan.
    If any chunk contains a genuine strong-signal phrase, force-reclassify that
    provider as HAS with the first positive taxonomy category.

    Constructor
    -----------
    spark   : SparkSession
    catalog : catalog name
    schema  : schema name
    """

    def __init__(
        self,
        spark: Any,
        catalog: str = "dev_adb",
        schema: str = "raw",
    ) -> None:
        self._spark = spark
        self._fulltext_table = f"{catalog}.{schema}.tbl_vs_unified_ready"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def rescue(
        self,
        no_mention: List[str],
        classified: List[Dict],
        provider_data: Dict,
        understanding: Dict,
        taxonomy: List[Dict],
        target_concept: str,
    ) -> Tuple[List[str], List[Dict], Dict, int]:
        """
        Step 6.5: Scan NO_MENTION providers for strong-phrase evidence.

        Uses get_recall_signals() for per-concept first_pass + strong phrases.
        Genuine rescue requires at least one strong-phrase hit.
        Rescued providers are moved from no_mention to provider_data as HAS.

        Returns (no_mention, classified, provider_data, rescued_count).
        """
        if not no_mention:
            return no_mention, classified, provider_data, 0

        sig = get_recall_signals(target_concept)
        if sig is None:
            # Novel concept — derive signals from concept term itself
            base = target_concept.lower()
            sig = {"first_pass": [base], "strong": [base]}
        first_pass = sig["first_pass"]
        strong = sig["strong"]

        if not first_pass:
            logger.info("Step 6.5: no recall signals -- skipping")
            return no_mention, classified, provider_data, 0

        prov_sql = ", ".join(
            f"'{p.replace(chr(39), chr(39)+chr(39))}'" for p in no_mention
        )
        like_clauses = " OR ".join(
            f"LOWER(chunk_text) LIKE '%{kw.replace(chr(39), chr(39)+chr(39))}%'"
            for kw in first_pass
        )

        try:
            fn_df = self._spark.sql(f"""
                SELECT provider_name, source_filename,
                       chunk_text,
                       page_number_est AS page_number, chunk_index,
                       COUNT(*) OVER (PARTITION BY provider_name) AS total_hits
                FROM {self._fulltext_table}
                WHERE provider_name IN ({prov_sql})
                  AND ({like_clauses})
                  AND LENGTH(chunk_text) >= 80
                ORDER BY provider_name, LENGTH(chunk_text) DESC
            """).toPandas()
        except Exception as exc:
            logger.error("Step 6.5 SQL failed: %s", exc)
            return no_mention, classified, provider_data, 0

        if fn_df.empty:
            logger.info("Step 6.5: no keyword hits -- all NO_MENTION confirmed")
            return no_mention, classified, provider_data, 0

        positive_codes = [t["code"] for t in taxonomy if not t.get("is_denial", False)]
        default_cat = (
            "GENERAL_OFFSET" if "GENERAL_OFFSET" in positive_codes
            else (positive_codes[0] if positive_codes else "CONFIRMED_PRESENT")
        )
        concept_label = target_concept.upper().replace(" ", "_").replace("-", "_")
        rescued = 0

        for prov in fn_df["provider_name"].unique():
            prov_chunks = fn_df[fn_df["provider_name"] == prov]
            genuine = False
            best_chunk = None
            for _, row in prov_chunks.iterrows():
                text_lower = str(row["chunk_text"]).lower()
                if any(sig_phrase in text_lower for sig_phrase in strong):
                    genuine = True
                    best_chunk = row
                    break

            if genuine and best_chunk is not None:
                total_hits = int(prov_chunks.iloc[0]["total_hits"])
                no_mention.remove(prov)
                rescue_finding = {
                    "provider": prov,
                    "filename": str(best_chunk["source_filename"]),
                    "page": int(best_chunk["page_number"]) if pd.notna(best_chunk.get("page_number")) else 0,
                    "category": default_cat,
                    "reasoning": (
                        f"[Safety-net rescued: sparse {target_concept} language "
                        f"({total_hits} chunks) confirmed via direct corpus scan]"
                    ),
                    "key_phrase": str(best_chunk["chunk_text"])[:150],
                    "score": 2,
                    "source": "false_negative_safety_net",
                    "kp_verified": True,
                    "num_verified": True,
                }
                classified.append(rescue_finding)
                provider_data[prov] = {
                    "status": f"HAS_{concept_label}",
                    "positive_count": 1,
                    "denial_count": 0,
                    "docs": {str(best_chunk["source_filename"])},
                    "categories": {default_cat: 1},
                    "findings": [rescue_finding],
                    "doc_count": 1,
                }
                rescued += 1
                logger.info("Step 6.5: rescued %s (%d strong-phrase hits)", prov, total_hits)

        if rescued:
            logger.info("Step 6.5: rescued %d false negatives", rescued)
        else:
            logger.info("Step 6.5: no genuine false negatives (hits lacked strong phrases)")

        # Post-rescue assertion
        self._run_post_rescue_assertion(no_mention, strong)

        return no_mention, classified, provider_data, rescued

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_post_rescue_assertion(
        self,
        no_mention: List[str],
        strong_signals: List[str],
    ) -> None:
        """
        Warn if any remaining NO_MENTION providers have >=2 strong-phrase hits.
        These are missed rescues -- likely a provider-name mismatch or signal gap.
        """
        if not no_mention or not strong_signals:
            return
        try:
            slike = " OR ".join(
                f"LOWER(chunk_text) LIKE '%{s.replace(chr(39), chr(39)+chr(39))}%'"
                for s in strong_signals
            )
            nm_sql = ", ".join(
                f"'{p.replace(chr(39), chr(39)+chr(39))}'" for p in no_mention
            )
            adf = self._spark.sql(f"""
                SELECT provider_name, COUNT(*) AS n
                FROM {self._fulltext_table}
                WHERE provider_name IN ({nm_sql}) AND ({slike})
                GROUP BY provider_name HAVING COUNT(*) >= 2 ORDER BY n DESC
            """).toPandas()
            if not adf.empty:
                names = [
                    f"{r['provider_name']} ({int(r['n'])} hits)"
                    for _, r in adf.iterrows()
                ]
                logger.warning(
                    "POST-RESCUE ASSERTION: %d NO_MENTION providers still have >=2 strong hits: %s",
                    len(adf), names[:10]
                )
            else:
                logger.info("Post-rescue assertion PASSED: all NO_MENTION have <2 strong hits")
        except Exception as exc:
            logger.warning("Post-rescue assertion skipped: %s", exc)

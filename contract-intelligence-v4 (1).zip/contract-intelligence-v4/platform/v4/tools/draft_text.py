"""
platform/v4/tools/draft_text.py

LLM-based contract language drafting tool.

Used when the agent is asked to generate draft clause language,
amendment summaries, or negotiation talking points.

All output is tagged Confidence.GENERATED — the agent must make clear
to the user that drafted text is AI-generated and not legally binding.
"""
from __future__ import annotations

import time
from typing import Any, Optional

from ..config.settings import Settings
from ..contracts.tool_types import Confidence, ToolResult
from ..tools.base import BaseTool

_SYSTEM_PROMPT = """\
You are a contract drafting assistant for Blue Shield of California.
Draft clear, professional contract language based on the provided context.

Rules:
1. Use plain English; avoid unnecessary legalese.
2. Mark all AI-drafted sections with [DRAFT] so reviewers know what to verify.
3. Base drafts on provided reference text where available.
4. Note when a provision conflicts with standard BSC contract templates.
5. NEVER fabricate specific rates, dollar amounts, or regulatory citations.
"""

_USER_TEMPLATE = """\
Task: {task}

Reference context:
{context}

Draft:
"""


class DraftTextTool(BaseTool):
    """
    Generate draft contract language or negotiation text.

    Parameters
    ----------
    llm_client : LLM client with .chat(model, system, user, max_tokens)->str.
    settings   : Settings instance.
    """

    def __init__(
        self,
        llm_client: Optional[Any]      = None,
        settings:   Optional[Settings] = None,
    ) -> None:
        self._llm      = llm_client
        self._settings = settings or Settings()

    def set_llm(self, llm: Any) -> None:
        self._llm = llm

    @property
    def name(self) -> str:
        return "draft_text"

    def _run(
        self,
        task:       str  = "",
        context:    str  = "",
        max_tokens: int  = 1000,
        **kwargs:   Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        task      : Description of what to draft (e.g. 'draft an offset clause').
        context   : Reference text or existing clause language to base the draft on.
        max_tokens: LLM max output tokens.
        """
        if not task:
            return ToolResult(
                success=False,
                data=None,
                summary="task is required for draft_text",
                confidence=Confidence.LOW,
                error_message="task is empty",
            )

        if self._llm is None:
            return ToolResult(
                success=True,
                data=f"[STUB] LLM not injected. Task requested: {task}",
                summary="[STUB] LLM not injected — returning stub draft",
                confidence=Confidence.GENERATED,
            )

        t0   = time.time()
        user = _USER_TEMPLATE.format(task=task, context=context or "(no reference context)")

        try:
            draft = self._llm.chat(
                model      = self._settings.LLM_MODEL,
                system     = _SYSTEM_PROMPT,
                user       = user,
                max_tokens = max_tokens,
            )
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=None,
                summary=f"Draft text error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

        return ToolResult(
            success=True,
            data=draft,
            summary=draft[:200],
            confidence=Confidence.GENERATED,   # AI-drafted text is always GENERATED
            execution_time_s=time.time() - t0,
            metadata={"task": task, "flagged_as_draft": True},
        )

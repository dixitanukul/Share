"""
P4C-COMP — ComparisonTool
==========================
Native V3 replacement for V2 Branch C (branch_comparison).
Side-by-side analysis of 2+ providers: profile KPIs, rate summary by category,
amendment count, optional concept passages, and LLM comparative summary.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..contracts.tool_types import Confidence, ToolResult, ToolStatus
from ..config.settings import (
    CATALOG, SCHEMA, LLM_REASONING,
    TBL_GENIE_PROVIDER_PROFILE,
    TBL_GENIE_AMENDMENT_TIMELINE,
    TBL_CONTRACT_RATES_ALL,
)
from ..services.sql_helpers import build_provider_id_filter, escape_sql, qualified_table
from .base import BaseTool

_VW_CONTRACT_TERMS = f"{CATALOG}.{SCHEMA}.vw_genie_contract_terms"


# ─── Dataclasses ─────────────────────────────────────────────────────────────

@dataclass
class ProviderSnapshot:
    """Data collected for one provider during a comparison."""
    name: str
    provider_ids: List[str] = field(default_factory=list)
    resolution_method: str = ""
    profile: Dict[str, Any] = field(default_factory=dict)
    rates: List[Dict[str, Any]] = field(default_factory=list)
    amendment_count: int = 0
    concept_passages: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ComparisonResult:
    """Full side-by-side comparison result."""
    providers: List[str]
    concept: Optional[str]
    snapshots: Dict[str, ProviderSnapshot] = field(default_factory=dict)
    llm_summary: str = ""
    rate_categories: List[str] = field(default_factory=list)


# ─── Tool ────────────────────────────────────────────────────────────────────

class ComparisonTool(BaseTool):
    """Side-by-side comparison of 2+ providers on contract rates, terms, and provisions.

    For each provider fetches: profile KPIs (agreement_type, total_rates,
    avg_inpatient_per_diem), rate summary by category, amendment count, and
    (optionally) concept-focused term passages. An LLM comparative analysis is
    generated when a concept focus is provided.
    """

    name = "comparison"
    description = (
        "Compare two or more providers side-by-side on contract rates, terms, "
        "and specific provisions. Use for 'compare X vs Y' questions."
    )
    is_adapter_backed = False

    def __init__(
        self,
        spark: Any,
        provider_service: Any,
        retrieval_service: Any = None,
        llm_client: Any = None,
    ) -> None:
        self._spark = spark
        self._provider_service = provider_service
        self._retrieval_service = retrieval_service
        self._llm_client = llm_client

    # ── Validation ───────────────────────────────────────────────────────

    def validate_inputs(self, **kwargs) -> list:
        return self._require(kwargs, "question")

    # ── Main execution ───────────────────────────────────────────────────

    def _run(
        self,
        question: str,
        providers: Optional[List[str]] = None,
        concept: Optional[str] = None,
        limit: int = 100,
    ) -> ToolResult:
        providers_raw = providers or self._extract_providers(question)
        if len(providers_raw) < 2:
            return ToolResult.error(
                f"Need at least 2 providers to compare. Detected: {providers_raw}.",
                tool_name=self.name,
            )

        # Resolve canonical names
        snapshots: Dict[str, ProviderSnapshot] = {}
        canonical_names: List[str] = []
        for p_raw in providers_raw[:4]:
            resolved, method, pids = self._provider_service.resolve(p_raw)
            if method == "unresolved" or not resolved:
                canonical = p_raw
                pids = []
            else:
                canonical = resolved[0]
            snapshots[canonical] = ProviderSnapshot(
                name=canonical, provider_ids=pids, resolution_method=method
            )
            canonical_names.append(canonical)

        if len(canonical_names) < 2:
            return ToolResult.error("Could not resolve enough providers.", tool_name=self.name)

        target_concept = concept or self._extract_concept(question)

        # Fetch data per provider
        for name, snap in snapshots.items():
            pf = build_provider_id_filter(snap.provider_ids) if snap.provider_ids else None
            snap.profile = self._fetch_profile(name, pf)
            snap.rates = self._fetch_rates(name, pf)
            snap.amendment_count = self._fetch_amendment_count(name, pf)
            if target_concept:
                snap.concept_passages = self._fetch_concept_passages(target_concept, name, pf)

        # Rate categories union across all providers
        all_cats: set = set()
        for snap in snapshots.values():
            for r in snap.rates:
                if r.get("rate_category"):
                    all_cats.add(r["rate_category"])
        rate_categories = sorted(all_cats)

        llm_summary = ""
        if target_concept and self._llm_client:
            llm_summary = self._generate_summary(target_concept, snapshots)

        has_rates = all(snap.rates for snap in snapshots.values())
        return ToolResult(
            success=True,
            data={
                "providers": canonical_names,
                "concept": target_concept,
                "snapshots": {
                    name: {
                        "profile": snap.profile,
                        "rates": snap.rates,
                        "amendment_count": snap.amendment_count,
                        "concept_passages": snap.concept_passages[:5],
                        "provider_ids": snap.provider_ids,
                        "resolution_method": snap.resolution_method,
                    }
                    for name, snap in snapshots.items()
                },
                "rate_categories": rate_categories,
                "llm_summary": llm_summary,
            },
            summary=(
                f"Comparison: {' vs '.join(canonical_names)}"
                + (f" on '{target_concept}'" if target_concept else "")
                + f" | {len(rate_categories)} rate categories"
                + (" | LLM analysis included" if llm_summary else "")
            ),
            confidence=Confidence.HIGH if has_rates else Confidence.LOW,
            status=ToolStatus.SUCCESS,
            citations=[],
        )

    # ── Section fetchers ─────────────────────────────────────────────────

    def _fetch_profile(
        self,
        provider_name: str,
        prov_filter: Optional[str],
    ) -> Dict[str, Any]:
        try:
            if prov_filter:
                where = f"WHERE {prov_filter}"
            else:
                safe = escape_sql(provider_name.lower())
                where = f"WHERE LOWER(provider_name) LIKE '%{safe}%'"
            pdf = self._spark.sql(
                f"SELECT agreement_type, total_rates, total_amendments,"
                f" avg_inpatient_per_diem, latest_amendment_date"
                f" FROM {qualified_table(TBL_GENIE_PROVIDER_PROFILE)} {where} LIMIT 1"
            ).toPandas()
            return pdf.iloc[0].to_dict() if not pdf.empty else {}
        except Exception:
            return {}

    def _fetch_rates(
        self,
        provider_name: str,
        prov_filter: Optional[str],
    ) -> List[Dict[str, Any]]:
        try:
            if prov_filter:
                where = (
                    f"WHERE {prov_filter} "
                    "AND rate_numeric IS NOT NULL AND rate_numeric > 0"
                )
            else:
                safe = escape_sql(provider_name.lower())
                where = (
                    f"WHERE LOWER(provider_name) LIKE '%{safe}%' "
                    "AND rate_numeric IS NOT NULL AND rate_numeric > 0"
                )
            pdf = self._spark.sql(
                f"SELECT rate_category,"
                f" COUNT(*) AS count,"
                f" ROUND(AVG(rate_numeric), 2) AS avg_rate,"
                f" ROUND(MAX(rate_numeric), 2) AS max_rate"
                f" FROM {qualified_table(TBL_CONTRACT_RATES_ALL)}"
                f" WHERE status = 'current' {where.replace('WHERE', 'AND') if where.startswith('WHERE') else where}"
                f" GROUP BY rate_category ORDER BY avg_rate DESC"
            ).toPandas()
            return pdf.to_dict("records") if not pdf.empty else []
        except Exception:
            return []

    def _fetch_amendment_count(
        self,
        provider_name: str,
        prov_filter: Optional[str],
    ) -> int:
        try:
            if prov_filter:
                where = f"WHERE {prov_filter}"
            else:
                safe = escape_sql(provider_name.lower())
                where = f"WHERE LOWER(provider_name) LIKE '%{safe}%'"
            pdf = self._spark.sql(
                f"SELECT COUNT(*) AS cnt"
                f" FROM {qualified_table(TBL_GENIE_AMENDMENT_TIMELINE)} {where}"
            ).toPandas()
            return int(pdf.iloc[0]["cnt"]) if not pdf.empty else 0
        except Exception:
            return 0

    def _fetch_concept_passages(
        self,
        concept: str,
        provider_name: str,
        prov_filter: Optional[str],
    ) -> List[Dict[str, Any]]:
        try:
            safe_concept = escape_sql(concept.lower())
            if prov_filter:
                where = (
                    f"WHERE {prov_filter} "
                    f"AND LOWER(content_text) LIKE '%{safe_concept}%' "
                    "AND is_from_latest_doc = true LIMIT 5"
                )
            else:
                safe_name = escape_sql(provider_name.lower())
                where = (
                    f"WHERE LOWER(provider_name) LIKE '%{safe_name}%' "
                    f"AND LOWER(content_text) LIKE '%{safe_concept}%' "
                    "AND is_from_latest_doc = true LIMIT 5"
                )
            pdf = self._spark.sql(
                f"SELECT title, content_text FROM {_VW_CONTRACT_TERMS} {where}"
            ).toPandas()
            return [
                {"title": str(row.get("title", "")), "text": str(row.get("content_text", ""))[:400]}
                for _, row in pdf.iterrows()
            ]
        except Exception:
            return []

    def _generate_summary(
        self,
        concept: str,
        snapshots: Dict[str, ProviderSnapshot],
    ) -> str:
        if not self._llm_client:
            return ""
        ctx_parts = []
        for name, snap in snapshots.items():
            lines = [f"--- {name} ---"]
            for p in snap.concept_passages[:5]:
                lines.append("Passage: " + p.get("text", "")[:300])
            if not snap.concept_passages:
                lines.append("No relevant passages found.")
            ctx_parts.append("\n".join(lines))
        prompt = (
            f"Compare these healthcare providers on \"{concept}\" "
            "based on their contract passages.\n\n"
            "Providers:\n" + "\n\n".join(ctx_parts) + "\n\n"
            "Provide a structured comparison covering:\n"
            "1. Which providers have this provision and which don't\n"
            "2. Key differences in conditions, limits, and timeframes\n"
            "3. Which position is more favorable for the health plan\n"
            "4. Recommended actions\n\n"
            "Be specific — cite actual language from the passages."
        )
        try:
            return self._llm_client.chat(
                model=LLM_REASONING,
                system=(
                    "You are a healthcare contract analyst. "
                    "Compare provider contract terms objectively."
                ),
                user=prompt,
                max_tokens=1500,
            )
        except Exception:
            return ""

    # ── Helpers ──────────────────────────────────────────────────────────

    def _extract_providers(self, question: str) -> List[str]:
        q_lower = question.lower()
        found = []
        for name in sorted(self._provider_service.all_names(), key=len, reverse=True):
            if name.lower() in q_lower and name not in found:
                found.append(name)
        return found

    def _extract_concept(self, question: str) -> Optional[str]:
        patterns = [
            r"(?:compare|comparison).+?(?:on|for|regarding)\s+[\"']?(.+?)[\"']?(?:\s+in|\?|$)",
            r"(?:on|regarding|about)\s+[\"']?(.+?)[\"']?\s+(?:provision|clause|term|terms)",
        ]
        q_lower = question.lower()
        for pat in patterns:
            m = re.search(pat, q_lower)
            if m:
                cand = m.group(1).strip().rstrip("?.,")
                if len(cand) >= 3:
                    return cand
        return None

"""
platform/v4/tools/sql_query.py

Native V3 SQL generation + execution tool.

Pipeline
--------
1. Get schema context from table_whitelist (column names + descriptions)
2. Build a SQL-generation prompt with the whitelist schema context
3. Call LLM to generate SQL
4. Parse and validate: extract SELECT statement, reject any table not
   in the whitelist, reject DDL / DML
5. Execute via Spark SQL
6. Return results as ToolResult (data = list[dict] rows)

Security
--------
- Only tables in CONTRACT_TABLES_FOR_SQL are allowed (13 tables)
- DDL/DML keywords (CREATE, INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE,
  GRANT, REVOKE) are blocked before execution
- Parameterised catalog+schema prefix is enforced on all table names

LLM client interface
--------------------
The injected llm_client must have:
    llm_client.chat(model: str, system: str, user: str, max_tokens: int) -> str
"""
from __future__ import annotations

import re
import time
from typing import Any, Optional

from ..config.settings import Settings
from ..config.table_whitelist import CONTRACT_TABLES_FOR_SQL, get_schema_context, is_allowed
from ..contracts.tool_types import Confidence, ToolResult
from ..data.schema_context_builder import SchemaContextBuilder
from ..services.sql_helpers import rewrite_superseded_by_join, rewrite_canonical_join
from ..tools.base import BaseTool


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CATALOG = "dev_adb"
SCHEMA  = "raw"

_DDL_DML_PATTERN = re.compile(
    r"\b(CREATE|INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|GRANT|REVOKE|MERGE)\b"
    r"|\bREPLACE\b(?!\s*\()",  # REPLACE as DDL (CREATE OR REPLACE) but NOT as function REPLACE(...)
    re.IGNORECASE,
)

_SQL_BLOCK_RE = re.compile(
    r"```(?:sql)?\s*(.*?)```",
    re.DOTALL | re.IGNORECASE,
)

_SYSTEM_PROMPT = """\
You are a Databricks SQL expert

CRITICAL RULE — PROVIDER FILTERING:
When the question is about a specific named provider (e.g. Scripps, Adventist, Sharp,
Providence, Cedars-Sinai, Stanford, UCSD, etc.), you MUST include a WHERE clause that
filters to that provider only. NEVER generate a SQL query that scans all providers when
the question is about one specific provider.
- Use: WHERE LOWER(provider_name) LIKE '%scripps%'  (or the relevant provider token)
- If a [PROVIDER SCOPE] prefix appears in the question, honor it strictly.
- If the specific provider has 0 matching rows, return the empty result — do NOT widen
  the search to other providers or remove the provider filter.

CRITICAL RULE — PROVIDER FILTERING:
When the question is about a specific named provider (e.g. Scripps, Adventist, Sharp,
Providence, Cedars-Sinai, Stanford, UCSD, etc.), you MUST include a WHERE clause that
filters to that provider only. NEVER generate a SQL query that scans all providers when
the question is about one specific provider.
- Use: WHERE LOWER(provider_name) LIKE '%scripps%'  (or the relevant provider token)
- If a [PROVIDER SCOPE] prefix appears in the question, honor it strictly.
- If the specific provider has 0 matching rows, return the empty result — do NOT widen
  the search to other providers or remove the provider filter. for the BSC Provider Contract Intelligence Platform.
Generate a single, read-only SELECT query against the contract database.

Rules:
1. ONLY use tables from the approved whitelist (provided below).
2. Always qualify table names as: dev_adb.raw.<table_name>
3. Never use CREATE, INSERT, UPDATE, DELETE, DROP, ALTER, or any DDL/DML.
4. Return ONLY the SQL query — no explanations, no markdown fences.
5. If the question cannot be answered with available tables, return:
   SELECT 'INSUFFICIENT_DATA' AS reason, '<explanation>' AS detail
6. Add a LIMIT of 200 rows unless the question asks for aggregations or specifies a smaller number.
7. Use LOWER() for string comparisons. Use status = 'current' for
   rate queries on tbl_contract_rates_all unless the question asks for historical data.
   NEVER use is_current_effective (this column does not exist and will cause UNRESOLVED_COLUMN errors).
8. When querying tbl_genie_provider_profile for specific providers
   (WHERE provider_name LIKE ...), do NOT automatically add AND is_active = TRUE.
   REASON: 29 providers have is_active=FALSE but still have current rates extracted
   (their document expired but rates exist). Auto-adding is_active=TRUE silently
   drops these providers from rate queries.
   ONLY add AND is_active = TRUE when the user explicitly asks about 'active',
   'in-network', 'contracted', or 'currently active' providers.
9. When the question asks about a SPECIFIC provider by name and the profile
   table returns multiple rows (name variants), prefer the row where
   is_active = TRUE. Only include inactive entries if the user asks.
   If the matching row has is_active=FALSE, mention this in your answer
   (e.g., 'Note: this provider\'s contract document has expired') but still
   return their rates if rates are available.
10. STRING boolean columns: Several tbl_genie_provider_profile columns store
   boolean values as STRING (not BOOLEAN). Always use string literals:
   - auto_renewal:                  WHERE auto_renewal = 'True'   (WRONG: = TRUE)
   - termination_for_convenience:   WHERE termination_for_convenience = 'True'
   - right_to_audit:                WHERE right_to_audit = 'True'
   - contract_assignable:           WHERE contract_assignable = 'True'
   - medicaid_participation:        WHERE medicaid_participation = 'True'
   EXCEPTION: is_active IS a real BOOLEAN — WHERE is_active = TRUE is correct.
11. EXISTENCE CHECK — "Does provider X have offset/DOFR/IPA?"
   CORRECT: SELECT ... FROM tbl_genie_provider_profile WHERE provider_name LIKE '%X%' AND is_active = TRUE
   WRONG:   SELECT ... WHERE provider_name LIKE '%X%' AND offset_clause_status = 'HAS'
   Never filter by status column when the question asks whether a clause exists.
   The status value (HAS / NO_MENTION) IS the answer — do not use it as a filter.
   Return the row and let the agent read the column value to answer Yes/No.
12. COUNT QUERIES — When the user asks 'how many', 'count', or similar:
   ALWAYS return a pure integer using COUNT(*) or SUM(CASE WHEN ... THEN 1 ELSE 0 END).
   NEVER use CASE WHEN to convert a count to 'Yes'/'No'/'True'/'False'.
   A result of 0 must be returned as the integer 0, not the string 'No'.
   CORRECT: SELECT COUNT(*) AS provider_count FROM ...
   WRONG:   SELECT CASE WHEN COUNT(*)>0 THEN 'Yes' ELSE 'No' END AS provider_count
12a. CLAUSE PROVIDER COUNT QUERIES — When the question asks 'how many providers have [X] clause'
   or 'how many providers in the network have [X] clause' using tbl_contract_clauses:
   ALWAYS use COUNT(DISTINCT provider_name), NOT COUNT(*).
   tbl_contract_clauses has multiple rows per provider (one per amendment version).
   COUNT(*) will over-count amendment rows and return an impossible inflated number
   (e.g. 498 instead of the real max of 300 distinct providers).
   CORRECT: SELECT COUNT(DISTINCT provider_name) AS provider_count
            FROM dev_adb.raw.tbl_contract_clauses
            WHERE clause_category = 'DISPUTE_RESOLUTION' AND clause_status = 'HAS'
   WRONG:   SELECT COUNT(*) AS provider_count
            FROM dev_adb.raw.tbl_contract_clauses
            WHERE clause_category = 'DISPUTE_RESOLUTION'
13. EXPIRATION DATE QUERIES — When the question asks "which contracts expire before [future date]",
   "expiring soon", "expire in the next N months", or similar FORWARD-looking queries:
   ALWAYS add BOTH bounds:
     expiration_date_parsed > CURRENT_DATE()   -- lower bound: exclude already-expired
     AND expiration_date_parsed < '[target date]'  -- upper bound: the requested cutoff
   This ensures results show contracts expiring BETWEEN today and the target date,
   not historical records that expired years ago.
   Use expiration_date_parsed column directly (do NOT compute from effective_date + term).
   IMPORTANT: Group results by provider to avoid showing multiple document rows per provider.
   Each provider may have many amendments with the same expiration date — the user wants to
   see WHICH PROVIDERS expire, not a list of every amendment document.
   CORRECT:
     SELECT provider_name, expiration_date_parsed AS expiration_date,
            COUNT(*) AS document_count, contract_status
     FROM dev_adb.raw.tbl_contract_documents_master
     WHERE expiration_date_parsed > CURRENT_DATE()
       AND expiration_date_parsed < DATE_ADD(CURRENT_DATE(), 180)
       AND contract_status = 'ACTIVE'
     GROUP BY provider_name, expiration_date_parsed, contract_status
     ORDER BY expiration_date_parsed
   WRONG:  SELECT * FROM tbl_contract_documents_master WHERE ... (returns 200+ individual docs)
   WRONG:  WHERE expiration_date_parsed < '2027-01-01' (missing lower bound)
14. HEALTH SYSTEM QUERIES — When the question mentions a health system umbrella name
   whose member facilities use different names in the database, expand using OR:
   - 'Dignity Health' → LOWER(provider_name) LIKE '%mercy%'
                         OR LOWER(provider_name) LIKE '%dominican hospital%'
                         OR LOWER(provider_name) LIKE '%chw mercy%'
   - 'Providence' → LOWER(provider_name) LIKE '%providence%'
   - 'Adventist Health' → LOWER(provider_name) LIKE '%adventist%'
   - 'Sutter Health' → LOWER(provider_name) LIKE '%sutter%'
    Do NOT use LIKE '%dignity health%' — no provider has 'dignity health' in their name.
15. RATE CATEGORIES LISTING — When the question asks "what rate categories does X have?",
    "list the rate categories/types for X", "what types of rates", "what payment categories":
    Use SELECT DISTINCT on the rate type/category columns:
    CORRECT: SELECT DISTINCT rate_category, rate_type, payment_type FROM dev_adb.raw.tbl_contract_rates_all WHERE LOWER(provider_name) LIKE '%x%' ORDER BY rate_category
    WRONG: SELECT COUNT(*), AVG(rate_numeric) — do NOT count or aggregate for category-listing questions.
    Do NOT include rate values (rate_numeric, median) for category-listing questions.
16. PER DIEM RATE QUERIES — When the question asks for "per diem rate", "daily rate", or
    "per day rate" for a specific provider:
    Filter by rate_type or rate_category: WHERE (LOWER(rate_type) LIKE '%per diem%' OR LOWER(rate_category) LIKE '%per diem%' OR LOWER(rate_category) LIKE '%daily%')
    Do NOT return median rate — return the actual rate value (rate_numeric or rate_amount).
    CORRECT: SELECT rate_category, rate_type, rate_numeric, rate_amount FROM dev_adb.raw.tbl_contract_rates_all WHERE LOWER(provider_name) LIKE '%x%' AND (LOWER(rate_type) LIKE '%per diem%' OR LOWER(rate_category) LIKE '%per diem%') AND status = 'current'
17. PAYMENT TYPE NORMALIZATION — When grouping or filtering by payment_type:
    Normalize case variants so 'Fee For Service', 'Fee for Service', 'fee for service' are
    treated as one group. Use:
    CASE WHEN LOWER(TRIM(payment_type)) LIKE '%fee%service%' OR LOWER(TRIM(payment_type)) LIKE '%ffs%' THEN 'Fee For Service'
         WHEN LOWER(TRIM(payment_type)) LIKE '%per diem%' THEN 'Per Diem'
         WHEN LOWER(TRIM(payment_type)) LIKE '%capitat%' THEN 'Capitation'
         ELSE INITCAP(LOWER(TRIM(COALESCE(payment_type,'Unknown')))) END AS payment_type_normalized
    GROUP BY the normalized form, not the raw column.
18. AMENDMENT COUNT QUERIES — For questions about total amendment count for a specific provider:
    PREFER tbl_genie_provider_profile.total_amendments (pre-computed, authoritative count).
    CORRECT: SELECT provider_name, total_amendments FROM dev_adb.raw.tbl_genie_provider_profile WHERE LOWER(provider_name) LIKE '%x%'
    WRONG: SELECT COUNT(*) FROM dev_adb.raw.tbl_contract_documents_master — this over-counts by including base agreements, exhibits, and duplicates.
    Only use COUNT() from documents table if total_amendments is null/unavailable.
21. NPI AND TIN IDENTIFIER QUERIES — When the question asks for a provider's NPI (National
   Provider Identifier), TIN (Tax Identification Number / EIN), or other identifier:
   ALWAYS query tbl_provider_identifiers JOIN tbl_genie_provider_profile on provider_id.
   Use WHERE identifier_type = 'NPI' AND end_date IS NULL for current NPIs.
   Use WHERE identifier_type = 'TIN' AND end_date IS NULL for current TINs.
   SOURCE PRIORITY (highest to lowest authority):
     1. PIMS_EXACT_NAME        — canonical facility EIN; ALWAYS show these rows first
     2. CLAIMS_TIN_EXACT_NAME  — verified claim TIN
     3. JSON_EXTRACT           — extracted from contract JSON
     4. CLAIMS_ATT_TIN         — attending billing TINs; providers may have 100s; omit if PIMS rows exist
   ALWAYS ORDER BY source priority, NOT alphabetically:
     ORDER BY CASE i.source
       WHEN 'PIMS_EXACT_NAME'       THEN 1
       WHEN 'CLAIMS_TIN_EXACT_NAME' THEN 2
       WHEN 'JSON_EXTRACT'          THEN 3
       ELSE 4
     END, i.identifier_value
   CORRECT TIN EXAMPLE:
     SELECT p.provider_name, i.identifier_type, i.identifier_value, i.source
     FROM dev_adb.raw.tbl_provider_identifiers i
     JOIN dev_adb.raw.tbl_genie_provider_profile p
       ON CAST(i.provider_id AS STRING) = CAST(p.provider_id AS STRING)
     WHERE LOWER(p.provider_name) LIKE '%stanford%'
       AND i.identifier_type = 'TIN'
       AND i.end_date IS NULL
     ORDER BY CASE i.source
       WHEN 'PIMS_EXACT_NAME' THEN 1 WHEN 'CLAIMS_TIN_EXACT_NAME' THEN 2
       WHEN 'JSON_EXTRACT' THEN 3 ELSE 4 END, i.identifier_value
     LIMIT 20
   CORRECT NPI EXAMPLE:
     SELECT p.provider_name, i.identifier_type, i.identifier_value, i.source
     FROM dev_adb.raw.tbl_provider_identifiers i
     JOIN dev_adb.raw.tbl_genie_provider_profile p
       ON CAST(i.provider_id AS STRING) = CAST(p.provider_id AS STRING)
     WHERE LOWER(p.provider_name) LIKE '%sharp%'
       AND i.identifier_type = 'NPI'
       AND i.end_date IS NULL
     ORDER BY CASE i.source
       WHEN 'PIMS_EXACT_NAME' THEN 1 WHEN 'CLAIMS_TIN_EXACT_NAME' THEN 2
       WHEN 'JSON_EXTRACT' THEN 3 ELSE 4 END, i.identifier_value
     LIMIT 10
   WRONG: ORDER BY i.source  (alphabetical — buries PIMS_EXACT_NAME after hundreds of CLAIMS_ATT_TIN rows)
   WRONG: Claiming NPI/TIN is unavailable without querying tbl_provider_identifiers.
   NOTE: A provider may have multiple TINs from multiple sources. Always show PIMS_EXACT_NAME rows first.

19. PROVIDER NAME WITH PERIODS — When a provider name in the question contains periods
    (e.g., 'St.', 'Mt.', 'Dr.'), add a period-stripped LIKE alternative:
    CORRECT: WHERE LOWER(REPLACE(provider_name, '.', '')) LIKE '%st mary medical center%'
      OR LOWER(provider_name) LIKE '%st mary medical center%'
      OR LOWER(provider_name) LIKE '%st. mary%'
    This ensures 'St. Mary Medical Center' and 'St Mary Medical Center' both match.
20. BENCHMARK / RANKING WITH NAMED PROVIDER — When the question asks "how does X rank among
    all providers by Y?" or "where does X rank?", always ensure X appears in results.
    Use UNION ALL approach:
    (SELECT ROW_NUMBER() OVER (ORDER BY metric DESC) AS rank, provider_name, metric
     FROM ... ORDER BY metric DESC LIMIT 20)
    UNION ALL
    (SELECT NULL AS rank, provider_name, metric FROM ... WHERE LOWER(provider_name) LIKE '%x%')
    This guarantees X is always shown regardless of rank position.

22. RANKING TABLE COLUMNS — When generating a TOP N ranking table, include ONLY essential
    columns: the rank alias, provider_name, and the ranking metric. Do NOT add columns like
    is_active, active, total_documents, max_amendment_depth unless explicitly asked.
    CORRECT: SELECT ROW_NUMBER() OVER (ORDER BY total_amendments DESC) AS amendment_rank,
             provider_name, total_amendments FROM ...
    WRONG: SELECT ... amendment_rank, provider_name, total_amendments, is_active, ...
    Reason: is_active shows 'Yes'/'No' which triggers boolean-coercion false positives.

23. SUPERSEDED_BY JOIN — The superseded_by column in tbl_contract_rates_all stores a
    COMPOSITE KEY, not a plain filename. Format: 'eff:YYYY-MM-DD|src:<source_filename>'
    (example: 'eff:2006-05-15|src:129086321_Providence_BaseAgmtRenew_v1.pdf').
    Direct equality joins against tbl_contract_documents_master.source_filename will
    always return 0 rows. To join correctly, extract the filename component:
    CORRECT: REGEXP_EXTRACT(r.superseded_by, 'src:(.+)
{schema_context}
"""

_USER_TEMPLATE = """\
Question: {question}

Generate the SQL query:
"""



# ---------------------------------------------------------------------------
# Provider filter tokens — maps provider name/alias → LIKE search tokens
# Used by _enforce_provider_filter to inject WHERE clause when LLM omits it.
# ---------------------------------------------------------------------------

_PROVIDER_FILTER_TOKENS: dict[str, list[str]] = {
    # Health system aliases → all member facility tokens
    "sharp healthcare": ["sharp"],
    "sharp health": ["sharp"],
    "sharp": ["sharp"],
    "dignity health": ["mercy", "chw", "dominican"],
    "dignity": ["mercy", "chw", "dominican"],
    "commonspirit": ["mercy", "chw", "dominican"],
    "chw": ["chw"],
    "scripps health": ["scripps"],
    "scripps": ["scripps"],
    "scripps memorial": ["scripps"],
    "adventist health": ["adventist"],
    "adventist": ["adventist"],
    "sutter health": ["sutter"],
    "sutter": ["sutter"],
    "providence health": ["providence"],
    "providence": ["providence"],
    "stanford health": ["stanford"],
    "stanford": ["stanford"],
    "cedars-sinai": ["cedars"],
    "cedars sinai": ["cedars"],
    "cedars": ["cedars"],
    "ucsd": ["ucsd"],
    "ucsf": ["ucsf"],
    "uci": ["uci"],
    "ucla": ["ucla"],
    "kaiser": ["kaiser"],
    "kaiser permanente": ["kaiser"],
    "palomar health": ["palomar"],
    "palomar": ["palomar"],
    "pih health": ["pih"],
    "pih": ["pih"],
    "keck medicine": ["keck"],
    "alpha care": ["alpha care"],
    "alpha care medical group": ["alpha care"],
}


# ---------------------------------------------------------------------------
# SQL validation helpers
# ---------------------------------------------------------------------------

def _extract_sql(raw: str) -> str:
    """
    Extract the SQL statement from LLM output.
    Handles both fenced (```sql...```) and bare SQL responses.
    """
    m = _SQL_BLOCK_RE.search(raw)
    if m:
        return m.group(1).strip()
    # Strip any leading/trailing explanation lines — find the SELECT
    # Handles both bare SELECT and (SELECT ...) UNION ALL format (Rule 20).
    lines = raw.strip().split("\n")
    sql_lines: list[str] = []
    in_sql = False
    for line in lines:
        # Match: SELECT ... or (SELECT ... for UNION ALL sub-queries
        if re.match(r"^\s*\(?\s*SELECT\b", line, re.IGNORECASE):
            in_sql = True
        if in_sql:
            sql_lines.append(line)
    return "\n".join(sql_lines).strip() if sql_lines else raw.strip()


def _validate_sql(sql: str) -> Optional[str]:
    """
    Return an error message if the SQL is unsafe or uses disallowed tables.
    Returns None if valid.
    """
    if _DDL_DML_PATTERN.search(sql):
        return "SQL contains forbidden DDL/DML keyword"

    # Check each table reference against the whitelist
    # Match patterns like: FROM table_name, JOIN table_name, dev_adb.raw.table_name
    table_refs = re.findall(
        r"(?:FROM|JOIN)\s+(?:dev_adb\.raw\.)?([a-zA-Z_][a-zA-Z0-9_]*)",
        sql,
        re.IGNORECASE,
    )
    for tbl in table_refs:
        # Strip catalog/schema prefix if present
        bare = tbl.lower()
        if not is_allowed(bare):
            return f"Table '{bare}' is not in the approved whitelist"

    return None


# ---------------------------------------------------------------------------
# SqlQueryTool
# ---------------------------------------------------------------------------

class SqlQueryTool(BaseTool):
    """
    Generates and executes SQL queries against approved contract tables.

    Parameters
    ----------
    spark      : Active Spark session (injected from notebook entry).
    llm_client : LLM client with .chat() method.
    settings   : Settings instance.
    """

    def __init__(
        self,
        spark:                  Optional[Any]                    = None,
        llm_client:             Optional[Any]                    = None,
        settings:               Optional[Settings]               = None,
        schema_context_builder: Optional[SchemaContextBuilder]   = None,
    ) -> None:
        self._spark      = spark
        self._llm        = llm_client
        self._settings   = settings or Settings()
        # W9-14: prefer injected builder (reads dim_table_schema with sample values)
        self._schema_ctx_builder: Optional[SchemaContextBuilder] = schema_context_builder

    @property
    def name(self) -> str:
        return "sql_query"

    def set_spark(self, spark: Any) -> None:
        self._spark = spark
        # Re-wire builder if it wasn't already injected
        if self._schema_ctx_builder is None:
            self._schema_ctx_builder = SchemaContextBuilder(spark)

    def set_llm(self, llm: Any) -> None:
        self._llm = llm

    def set_schema_context_builder(self, builder: SchemaContextBuilder) -> None:
        """Inject or replace the SchemaContextBuilder (W9-14)."""
        self._schema_ctx_builder = builder

    # ------------------------------------------------------------------
    # Input validation (called by BaseTool.__call__ before _run)
    # ------------------------------------------------------------------

    def validate_inputs(self, **kwargs: Any) -> list[str]:
        """Ensure 'question' is present before firing the LLM SQL-gen call.

        Returns a clean error list so the agent sees a human-readable
        'Missing required parameter: question' rather than a Python traceback,
        giving it a chance to retry with the correct parameter on the next step.
        """
        errors = self._require(kwargs, 'question')
        if errors:
            errors.append(
                "sql_query requires a natural-language 'question' parameter "
                "(e.g. question='How many providers have offset_clause_status HAS?'). "
                "Do NOT pass raw SQL — this tool generates SQL from the question."
            )
        return errors

    # ------------------------------------------------------------------
    # BaseTool._run implementation
    # ------------------------------------------------------------------

    def _run(self, question: str, max_rows: int = 100, **kwargs: Any) -> ToolResult:
        """
        Parameters
        ----------
        question : Natural language question to translate to SQL.
        max_rows : Maximum rows to return (default 100; overridden by
                   the generated SQL's own LIMIT if present).
        """
        t0 = time.time()

        if self._spark is None:
            return ToolResult(
                success=False,
                data=[],
                summary="[STUB] Spark not injected — sql_query unavailable",
                confidence=Confidence.GENERATED,
                error_message="SqlQueryTool.spark is None",
            )

        # Step 1: Generate SQL
        # PROVIDER SCOPE FIX: inject provider_name from kwargs into question
        # so the SQL LLM always filters to the right provider.
        # kwargs receives provider_name from direct dispatch (QuestionRouter).
        _pn = kwargs.get('provider_name') or kwargs.get('provider_hint')
        _pids = kwargs.get('provider_ids', [])
        _scoped_q = question
        if _pn:
            _scoped_q = (
                f"[PROVIDER SCOPE: This question is specifically about '{_pn}'. "
                f"ALL SQL queries MUST include a WHERE filter for this provider. "
                f"Use LOWER(provider_name) LIKE '%{_pn.lower().split()[0]}%' or similar. "
                f"Do NOT return data for any other provider.]\n{question}"
            )
        sql = self._generate_sql(_scoped_q)
        # D07 FIX: Strip periods from LIKE/ILIKE string literals in the generated SQL.
        # Root: LLM reconstructs punctuation (e.g. "St. Mary") inside LIKE patterns even
        # when the question has it stripped, because training data uses the period form.
        # DB stores "St Mary Medical Center" (no period), so LIKE '%st. mary%' returns
        # 0 rows. Fix: normalise all LIKE/ILIKE argument strings post-generation.
        if sql:
            sql = re.sub(
                r"((?:I?LIKE)\s+['\"])([^'\"]+)(['\"])",
                lambda m: m.group(1) + m.group(2).replace('.', '') + m.group(3),
                sql,
                flags=re.IGNORECASE,
            )
        # DOFR-ISCURRENT FIX: LLM often generates AND is_current=TRUE for DOFR queries
        # but only 60/1821 rows have is_current=TRUE, killing most results.
        # Also strip LIMIT 1 which prevents returning all responsibility rows.
        # Also inject boolean responsibility filter when question asks which party is responsible.
        if (sql
                and 'tbl_dofr_matrix_extracted' in sql
                and re.search(r'\bdofr\b|division\s+of\s+financial', question, re.I)):
            # Remove is_current = TRUE filter
            sql = re.sub(r'\s+AND\s+\w+\.?is_current\s*=\s*TRUE', '', sql, flags=re.IGNORECASE)
            sql = re.sub(r'\s+AND\s+is_current\s*=\s*TRUE', '', sql, flags=re.IGNORECASE)
            # Remove LIMIT 1 (but keep LIMIT N for N>1)
            sql = re.sub(r'\bLIMIT\s+1\b', '', sql, flags=re.IGNORECASE)
            # Inject responsibility boolean filter if question asks which party is responsible
            _dofr_resp_map = [
                (r'\bgroup\b[^.]*\bresponsib', 'group_responsible'),
                (r'\bhospital\b[^.]*\bresponsib', 'hospital_responsible'),
                (r'\bhealth[\s_]*plan\b[^.]*\bresponsib', 'health_plan_responsible'),
            ]
            for _dp, _dc in _dofr_resp_map:
                if (re.search(_dp, question, re.I)
                        and not re.search(rf'\b{_dc}\s*=\s*TRUE', sql, re.I)):
                    # Inject before ORDER BY or at end
                    _order_m = re.search(r'\bORDER\s+BY\b', sql, re.I)
                    if _order_m:
                        sql = sql[:_order_m.start()].rstrip() + f' AND {_dc} = TRUE ' + sql[_order_m.start():]
                    else:
                        sql = sql.rstrip().rstrip(';') + f' AND {_dc} = TRUE'
                    break

        # P2-AUDIT FIX: superseded_by stores composite key 'eff:DATE|src:filename'.
        # Direct equality joins against source_filename always return 0 rows.
        # Rewrite to REGEXP_EXTRACT before validation.
        if sql:
            sql = rewrite_superseded_by_join(sql)

        # C-04 FIX: Canonical join enforcement.
        # Rates→Profile join on provider_id loses 31% of rows.
        # Rewrite to canonical_provider_id automatically.
        _canonical_rewritten = False
        if sql:
            sql, _canonical_rewritten = rewrite_canonical_join(sql)
            if _canonical_rewritten:
                import logging as _log_cj
                _log_cj.getLogger('sql_query.canonical_join').warning(
                    'CANONICAL JOIN REWRITE: provider_id → canonical_provider_id in: %s',
                    sql[:200],
                )

        # ── HARD PROVIDER ENFORCEMENT (post-LLM) ───────────────────────────
        # If provider_name was specified but the generated SQL does NOT
        # contain a matching provider filter, inject one. This catches
        # cases where the LLM ignores the [PROVIDER SCOPE] prefix and
        # returns data for wrong providers (e.g. "Doctors Medical Center").
        if sql and _pn:
            _sql_before = sql
            sql = self._enforce_provider_filter(sql, _pn)
            if sql != _sql_before:
                import logging as _log
                _log.getLogger('sql_query.enforce').warning(
                    'PROVIDER ENFORCEMENT INJECTED for %r: %s',
                    _pn, sql[:200],
                )

        if sql is None:
            return ToolResult(
                success=False,
                data=[],
                summary="LLM SQL generation failed",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message="LLM did not return a usable SQL statement",
            )

        # Step 2: Validate
        err = _validate_sql(sql)
        if err:
            return ToolResult(
                success=False,
                data=[],
                summary=f"SQL validation failed: {err}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=err,
                metadata={"generated_sql": sql},
            )

        # Step 3: Execute
        return self._execute_sql(sql, question, t0)

    def execute_raw(self, sql: str) -> ToolResult:
        """
        Execute a pre-written SQL statement directly (bypasses LLM generation).
        Still enforces the whitelist and DDL guard.
        """
        t0  = time.time()
        err = _validate_sql(sql)
        if err:
            return ToolResult(
                success=False,
                data=[],
                summary=f"SQL validation failed: {err}",
                confidence=Confidence.LOW,
                error_message=err,
            )
        return self._execute_sql(sql, question="(raw)", t0=t0)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _generate_sql(self, question: str) -> Optional[str]:
        """Call the LLM to generate a SQL query for the question."""
        if self._llm is None:
            # Fallback: attempt a simple template-based SQL for common patterns
            return self._template_sql(question)

        # W9-14: use dim_table_schema-backed builder if available, else static whitelist
        if self._schema_ctx_builder is not None:
            schema_ctx = self._schema_ctx_builder.get()
        else:
            schema_ctx = get_schema_context()
        system     = _SYSTEM_PROMPT.format(schema_context=schema_ctx)

        # ── PROF-SQL active-status hint (2026-07-03 fix) ──────────────────────
        # DO NOT auto-inject is_active=TRUE for general profile queries.
        # 29 providers have is_active=FALSE but current_rates > 0 (expired doc).
        # Silently dropping them from rate queries produces wrong answers.
        # Only inject the active hint when the user explicitly asks about
        # 'active providers', 'in-network', etc.
        _q_lower = question.lower()
        _asks_active_status = any(kw in _q_lower for kw in (
            "active providers", "in-network", "currently active",
            "contracted providers", "active contracts",
        ))
        _asks_inactive = any(kw in _q_lower for kw in (
            "inactive", "not active", "historically", "retired",
        ))
        active_hint = ""
        if _asks_active_status and not _asks_inactive:
            active_hint = (
                "\nIMPORTANT: The user asks specifically about active providers. "
                "Add AND is_active = TRUE when querying tbl_genie_provider_profile. "
                "For rate queries, do NOT add is_active filter — inactive providers "
                "may still have current rates extracted."
            )
        user = _USER_TEMPLATE.format(question=question) + active_hint
        try:
            raw = self._llm.chat(
                model      = self._settings.LLM_MODEL,
                system     = system,
                user       = user,
                max_tokens = 512,
            )
            return _extract_sql(raw) if raw else None
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _template_sql(question: str) -> Optional[str]:
        """
        Very simple template-based SQL for when no LLM is available.
        Returns None if the question doesn't match known patterns.
        """
        q = question.lower()
        if "rate" in q and "provider" in q:
            return (
                "SELECT provider_name, service_category, rate_numeric, effective_date "
                "FROM dev_adb.raw.tbl_contract_rates_all "
                "WHERE is_latest_version = TRUE "
                "LIMIT 100"
            )
        if "contract" in q and ("expire" in q or "renew" in q):
            return (
                "SELECT provider_name, contract_id, "
                "CAST(effective_date_parsed AS STRING) AS effective_date, "
                "CAST(expiration_date_parsed AS STRING) AS expiration_date "
                "FROM dev_adb.raw.tbl_contract_documents_master "
                "WHERE doc_role = 'base_agreement' "
                "ORDER BY expiration_date_parsed "
                "LIMIT 100"
            )
        return None

    def _enforce_provider_filter(self, sql: str, provider_name: str) -> str:
        """Inject a provider WHERE clause if the LLM omitted one.

        Called after SQL generation when provider_name is set in tool_input.
        Ensures the query always filters to the specified provider, preventing
        wrong-provider results (e.g. 'Doctors Medical Center Modesto Campus').
        """
        pn_lower = provider_name.lower().strip()

        # Determine the search token(s) from the alias map
        tokens = _PROVIDER_FILTER_TOKENS.get(pn_lower)
        if not tokens:
            # Try first word as fallback
            first_word = pn_lower.split()[0] if pn_lower else ""
            tokens = _PROVIDER_FILTER_TOKENS.get(first_word, [first_word])

        # Check if sql already has a provider filter for ANY of the tokens
        sql_lower = sql.lower()
        for token in tokens:
            # Match: LIKE '%token%' or = 'token' in context of provider_name
            if f"'%{token}%'" in sql_lower or f"= '{token}'" in sql_lower:
                return sql  # Already filtered

        # Also check for provider_id filter in WHERE clause (numeric literal or IN list)
        # MUST NOT match JOIN conditions (e.g., "ON t.provider_id = dpc.provider_id")
        if re.search(r'WHERE\b[^;]*\bprovider_id\s*(?:=\s*[\x27"\d]|IN\s*\()', sql, re.IGNORECASE | re.DOTALL):
            return sql  # Has explicit provider_id filter in WHERE

        # Need to inject. Build the filter clause.
        if len(tokens) == 1:
            filter_expr = f"LOWER(provider_name) LIKE '%{tokens[0]}%'"
        else:
            # Multiple tokens (health system) — use OR
            parts = [f"LOWER(provider_name) LIKE '%{t}%'" for t in tokens]
            filter_expr = f"({' OR '.join(parts)})"

        # Find injection point: after WHERE (add AND) or before ORDER/GROUP/LIMIT (add WHERE)
        # Handle the last/outermost WHERE in the main query (not subqueries)
        where_matches = list(re.finditer(r'\bWHERE\b', sql, re.IGNORECASE))
        order_match = re.search(
            r'\b(ORDER\s+BY|GROUP\s+BY|LIMIT|HAVING)\b(?!.*\bWHERE\b)',
            sql, re.IGNORECASE,
        )

        if where_matches:
            # Insert AND before the first ORDER BY/GROUP BY/LIMIT after the last WHERE
            last_where_pos = where_matches[-1].end()
            # Find next ORDER BY/GROUP BY/LIMIT after this WHERE
            tail = sql[last_where_pos:]
            tail_order = re.search(r'\b(ORDER\s+BY|GROUP\s+BY|LIMIT|HAVING)\b', tail, re.IGNORECASE)
            if tail_order:
                insert_pos = last_where_pos + tail_order.start()
            else:
                insert_pos = len(sql.rstrip().rstrip(';'))
            injection = f" AND {filter_expr}"
            # Insert before the ORDER/LIMIT clause
            sql = sql[:insert_pos].rstrip() + injection + ' ' + sql[insert_pos:]
        else:
            # No WHERE at all — add one
            if order_match:
                insert_pos = order_match.start()
            else:
                insert_pos = len(sql.rstrip().rstrip(';'))
            injection = f" WHERE {filter_expr} "
            sql = sql[:insert_pos].rstrip() + injection + sql[insert_pos:]

        return sql

    def _execute_sql(self, sql: str, question: str, t0: float) -> ToolResult:
        """Execute validated SQL and return ToolResult."""
        try:
            df   = self._spark.sql(sql)
            rows = [r.asDict() for r in df.collect()]

            # DOFR-NOTES-FIX: strip raw Phase-3 extraction artifacts from the notes column.
            # The notes column in tbl_dofr_matrix_extracted contains raw VS-backfill OCR text
            # that pollutes the response with hundreds of chars of irrelevant contract boilerplate.
            if 'tbl_dofr_matrix_extracted' in sql.lower() and rows:
                _DOFR_NOISE = ('Phase 3 VS backfill', 'Proprietary and Confidential', 'blue V of california')
                for _r in rows:
                    _n = str(_r.get('notes') or '')
                    if _n and (any(_marker in _n for _marker in _DOFR_NOISE) or len(_n) > 80):
                        _r['notes'] = ''  # clear noisy OCR extraction text

            _q_safe = re.sub(r'<[^>]{0,300}>', '', question)  # strip HTML from echo
            summary = (
                f"SQL returned {len(rows)} row(s) for: {_q_safe[:80]}"
                if rows
                else f"SQL returned 0 rows for: {_q_safe[:80]}"
            )

            # DOFR RESPONSIBILITY POST-FILTER: If rows returned from DOFR table and
            # question asks which party is responsible, filter to rows where bool=TRUE.
            if (rows
                    and re.search(r'\bdofr\b|\bdivision\s+of\s+financial\b', question, re.I)
                    and any('group_responsible' in r for r in rows[:1])):
                _resp_patterns = [
                    (r'\bgroup\b[^.]*\bresponsib|\bresponsib[^.]*\bgroup\b', 'group_responsible'),
                    (r'\bhospital\b[^.]*\bresponsib|\bresponsib[^.]*\bhospital\b', 'hospital_responsible'),
                    (r'\bhealth[\s_]*plan\b[^.]*\bresponsib|\bresponsib[^.]*\bhealth[\s_]*plan\b', 'health_plan_responsible'),
                ]
                _resp_col = None
                for _pat, _col in _resp_patterns:
                    if re.search(_pat, question, re.I):
                        _resp_col = _col
                        break
                if _resp_col and not re.search(rf'{_resp_col}\s*=\s*TRUE', sql, re.I):
                    _filtered = [r for r in rows if r.get(_resp_col)]
                    _cats = sorted({r.get('service_category', '') for r in _filtered if r.get('service_category')})
                    if _filtered:
                        summary = (
                            f"Found {len(_filtered)} service categories where {_resp_col}=TRUE: "
                            f"{', '.join(_cats)}"
                        )
                        rows = _filtered
                    else:
                        summary = f"No service categories have {_resp_col}=TRUE for this query."
                        rows = []

            # DOFR FALLBACK: If 0 rows and question is about DOFR service categories,
            # automatically run a broader query to show available categories.
            if (not rows
                    and re.search(r'\bdofr\b|\bdivision\s+of\s+financial\b', question, re.I)
                    and self._spark is not None):
                # Try to find the provider token from the original SQL
                _prov_match = re.search(r"LIKE\s+'%([^%]+)%'", sql, re.I)
                _prov_token = _prov_match.group(1) if _prov_match else None
                if _prov_token:
                    try:
                        _fallback_sql = (
                            f"SELECT DISTINCT service_category, subcategory, "
                            f"group_responsible, hospital_responsible, health_plan_responsible "
                            f"FROM dev_adb.raw.tbl_dofr_matrix_extracted "
                            f"WHERE LOWER(provider_name) LIKE '%{_prov_token.lower()}%' "
                            f"ORDER BY service_category"
                        )
                        _fb_df = self._spark.sql(_fallback_sql)
                        _fb_rows = [r.asDict() for r in _fb_df.collect()]
                        if _fb_rows:
                            _cats = sorted({r.get('service_category','') for r in _fb_rows if r.get('service_category')})
                            # Detect what the original filter was and craft a precise summary
                            _cat_match = re.search(
                                r"(?:service_category|subcategory)\s+(?:LIKE|ILIKE)\s+'%([^%']{3,30})%'", sql, re.I
                            )
                            _filtered_cats = []
                            _bool_filter = re.search(
                                r"(health_plan_responsible|hospital_responsible|group_responsible)\s*=\s*TRUE",
                                sql, re.I
                            )
                            if _bool_filter:
                                _col = _bool_filter.group(1)
                                _filtered_cats = [r.get('service_category','') for r in _fb_rows if r.get(_col)]
                                if _filtered_cats:
                                    summary = (
                                        f"Found {len(_filtered_cats)} categories where {_col}=TRUE for '{_prov_token}': "
                                        f"{', '.join(sorted(set(_filtered_cats)))}. "
                                        f"All {len(_fb_rows)} DOFR categories: {', '.join(_cats)}"
                                    )
                                else:
                                    summary = (
                                        f"NO categories have {_col}=TRUE for '{_prov_token}'. "
                                        f"All {len(_fb_rows)} DOFR categories have {_col}=FALSE: {', '.join(_cats)}"
                                    )
                                    # Return empty data so answer uses summary (not a table of FALSE rows)
                                    return ToolResult(
                                        success=True,
                                        data=[],
                                        summary=summary,
                                        confidence=Confidence.HIGH,
                                        execution_time_s=time.time() - t0,
                                        metadata={"sql": sql, "row_count": 0, "filter_col": _col},
                                    )
                            elif _cat_match:
                                _req_cat = _cat_match.group(1)
                                # Skip provider token match (already in WHERE LIKE)
                                if _req_cat.lower() != _prov_token.lower():
                                    summary = (
                                        f"No '{_req_cat}' category exists in the DOFR matrix for '{_prov_token}'. "
                                        f"Available categories ({len(_cats)}): {', '.join(_cats)}"
                                    )
                                    # Return empty data so answer shows summary (not unrelated table)
                                    return ToolResult(
                                        success=True,
                                        data=[],
                                        summary=summary,
                                        confidence=Confidence.MODERATE,
                                        execution_time_s=time.time() - t0,
                                        metadata={"sql": sql, "fallback_sql": _fallback_sql, "row_count": 0},
                                    )
                                else:
                                    summary = (
                                        f"DOFR fallback found {len(_fb_rows)} rows for '{_prov_token}'. "
                                        f"Available categories: {', '.join(_cats)}"
                                    )
                            else:
                                summary = (
                                    f"DOFR matrix for '{_prov_token}': {len(_fb_rows)} rows. "
                                    f"Categories: {', '.join(_cats)}"
                                )
                            return ToolResult(
                                success=True,
                                data=_fb_rows,
                                summary=summary,
                                confidence=Confidence.MODERATE,
                                execution_time_s=time.time() - t0,
                                metadata={"sql": sql, "fallback_sql": _fallback_sql, "row_count": len(_fb_rows)},
                            )
                        else:
                            # Broad fallback also returned 0 rows: provider has NO DOFR matrix.
                            # Check profile to explain why (FFS / NO_MENTION).
                            try:
                                _prof_sql = (
                                    f"SELECT dofr_status, payment_type, agreement_type "
                                    f"FROM dev_adb.raw.tbl_genie_provider_profile "
                                    f"WHERE LOWER(provider_name) LIKE '%{_prov_token.lower()}%' LIMIT 1"
                                )
                                _prof_rows = [r.asDict() for r in self._spark.sql(_prof_sql).collect()]
                                if _prof_rows:
                                    _p = _prof_rows[0]
                                    _pay = _p.get("payment_type", "") or ""
                                    _ds = _p.get("dofr_status", "NO_MENTION") or "NO_MENTION"
                                    if "fee" in _pay.lower() or _ds == "NO_MENTION":
                                        summary = (
                                            f"No DOFR matrix found for '{_prov_token}'. "
                                            f"Profile shows payment_type='{_pay}', dofr_status='{_ds}'. "
                                            f"Fee-for-Service providers do not have a DOFR service-category matrix. "
                                            f"DOFR only applies to IPA/capitation contracts."
                                        )
                                    else:
                                        summary = (
                                            f"No DOFR matrix rows found for '{_prov_token}' "
                                            f"(payment_type='{_pay}', dofr_status='{_ds}')."
                                        )
                                    return ToolResult(
                                        success=True,
                                        data=[],  # empty: use summary not table
                                        summary=summary,
                                        confidence=Confidence.HIGH,
                                        execution_time_s=time.time() - t0,
                                        metadata={"sql": sql, "profile_check": True},
                                    )
                            except Exception:
                                pass  # Profile check failed
                    except Exception:
                        pass  # Fallback failed — return original 0-row result
                else:
                    # No provider token: cross-provider DOFR query
                    # e.g. "which providers have behavioral health assigned to health plan?"
                    _cp_resp_map = [
                        (r'\bgroup\b', 'group_responsible'),
                        (r'\bhospital\b', 'hospital_responsible'),
                        (r'\bhealth[\s_]*plan\b', 'health_plan_responsible'),
                    ]
                    _cp_resp_col = None
                    for _p, _c in _cp_resp_map:
                        if re.search(_p, question, re.I):
                            _cp_resp_col = _c
                            break
                    if _cp_resp_col:
                        _svc_kws = re.findall(
                            r'\b(behavioral\s+health|pharmacy|emergency|radiology|lab|'
                            r'mental\s+health|surgery|inpatient|outpatient|specialist|'
                            r'primary\s+care|delegated|dental|vision)\b',
                            question, re.I
                        )
                        _svc_filter = (
                            f"AND LOWER(service_category) LIKE '%{_svc_kws[0].lower().replace(' ', '%')}%'"
                            if _svc_kws else ""
                        )
                        try:
                            _cp_sql = (
                                f"SELECT DISTINCT provider_name, service_category, subcategory, "
                                f"group_responsible, hospital_responsible, health_plan_responsible "
                                f"FROM dev_adb.raw.tbl_dofr_matrix_extracted "
                                f"WHERE {_cp_resp_col} = TRUE {_svc_filter} "
                                f"ORDER BY provider_name, service_category"
                            )
                            _cp_rows = [r.asDict() for r in self._spark.sql(_cp_sql).collect()]
                            if _cp_rows:
                                _cp_providers = sorted({r.get('provider_name','') for r in _cp_rows if r.get('provider_name')})
                                _svc_label = _svc_kws[0] if _svc_kws else 'all categories'
                                summary = (
                                    f"Found {len(_cp_providers)} provider(s) where {_cp_resp_col}=TRUE "
                                    f"for '{_svc_label}': {chr(39).join(_cp_providers)}"
                                )
                                return ToolResult(
                                    success=True,
                                    data=_cp_rows,
                                    summary=summary,
                                    confidence=Confidence.HIGH,
                                    execution_time_s=time.time() - t0,
                                    metadata={"sql": _cp_sql, "row_count": len(_cp_rows)},
                                )
                        except Exception:
                            pass  # Cross-provider query failed — fall through

            # DOFR SERVICE-CATEGORY PAYER FALLBACK:
            # Handles follow-up questions like "And what about behavioral health?" or
            # "Who handles pharmacy?" where the word 'dofr' is absent from the question
            # (the prior block requires it) but the SQL targeted tbl_dofr_matrix_extracted.
            # Guards on: 0 rows + DOFR table in SQL + service-category keyword in question.
            # Returns network-wide responsible-party distribution for the matched category.
            _SVC_DIST_MAP = {
                'behavioral health': 'BEHAVIORAL HEALTH',
                'behavioral': 'BEHAVIORAL HEALTH',
                'pharmacy': 'PHARMACY',
                'emergency': 'EMERGENCY',
                'radiology': 'RADIOLOGY',
                'lab services': 'LAB SERVICES',
                'lab': 'LAB SERVICES',
                'general': 'GENERAL',
            }
            if (not rows and self._spark is not None
                    and re.search(r'tbl_dofr_matrix_extracted', sql, re.I)):
                _svc_dist_cat = None
                for _svc_kw, _svc_cat in _SVC_DIST_MAP.items():
                    if re.search(rf'\b{re.escape(_svc_kw)}\b', question, re.I):
                        _svc_dist_cat = _svc_cat
                        break
                if _svc_dist_cat:
                    _svc_prov_match = re.search(r"LIKE\s+'%([^%]+)%'", sql, re.I)
                    _svc_prov_ctx = _svc_prov_match.group(1) if _svc_prov_match else None
                    try:
                        # Step 1: aggregate stats
                        _svc_agg_sql = (
                            f"SELECT "
                            f"ROUND(100.0 * SUM(CASE WHEN group_responsible THEN 1 ELSE 0 END) / COUNT(*), 1) AS group_pct, "
                            f"ROUND(100.0 * SUM(CASE WHEN hospital_responsible THEN 1 ELSE 0 END) / COUNT(*), 1) AS hospital_pct, "
                            f"ROUND(100.0 * SUM(CASE WHEN health_plan_responsible THEN 1 ELSE 0 END) / COUNT(*), 1) AS hp_pct, "
                            f"COUNT(DISTINCT provider_name) AS provider_count "
                            f"FROM dev_adb.raw.tbl_dofr_matrix_extracted "
                            f"WHERE service_category = '{_svc_dist_cat}'"
                        )
                        _agg = [r.asDict() for r in self._spark.sql(_svc_agg_sql).collect()]
                        if not (_agg and _agg[0].get('provider_count', 0)):
                            raise ValueError('no network rows')
                        _a = _agg[0]
                        # Step 2: sample rows with real provider names (so agent can present named examples)
                        _svc_rows_sql = (
                            f"SELECT DISTINCT provider_name, service_category, subcategory, "
                            f"group_responsible, hospital_responsible, health_plan_responsible "
                            f"FROM dev_adb.raw.tbl_dofr_matrix_extracted "
                            f"WHERE service_category = '{_svc_dist_cat}' "
                            f"ORDER BY provider_name LIMIT 10"
                        )
                        _svc_net_rows = [r.asDict() for r in self._spark.sql(_svc_rows_sql).collect()]
                        _payer_prefix = (
                            f"'{_svc_prov_ctx}' is not a BSC-contracted provider (no DOFR matrix). "
                            if _svc_prov_ctx else ""
                        )
                        summary = (
                            f"{_payer_prefix}"
                            f"Network-wide DOFR distribution for {_svc_dist_cat} "
                            f"({_a.get('provider_count', 0)} contracted providers): "
                            f"Hospital responsible {_a.get('hospital_pct', 0)}%, "
                            f"Group responsible {_a.get('group_pct', 0)}%, "
                            f"Health Plan responsible {_a.get('hp_pct', 0)}%. "
                            f"Sample rows from contracted providers shown below."
                        )
                        # Prepend aggregate-stats row so agent renders exact pcts
                        # and does NOT recompute from sample rows.
                        _agg_display_row = {
                            "provider_name": (
                                f"=== NETWORK TOTAL ({_a.get('provider_count',0)} contracted providers) ==="
                            ),
                            "service_category": _svc_dist_cat,
                            "subcategory": "AGGREGATE — USE THESE EXACT PERCENTAGES",
                            "group_responsible": f"GROUP={_a.get('group_pct',0)}%",
                            "hospital_responsible": f"HOSPITAL={_a.get('hospital_pct',0)}%",
                            "health_plan_responsible": f"HEALTH_PLAN={_a.get('hp_pct',0)}%",
                        }
                        _data_with_agg = [_agg_display_row] + _svc_net_rows
                        return ToolResult(
                            success=True,
                            data=_data_with_agg,
                            summary=summary,
                            confidence=Confidence.HIGH,
                            execution_time_s=time.time() - t0,
                            metadata={"sql": _svc_rows_sql, "row_count": len(_svc_net_rows),
                                      "svc_payer_fallback": True, "category": _svc_dist_cat,
                                      "network_hospital_pct": float(_a.get('hospital_pct', 0)),
                                      "network_group_pct": float(_a.get('group_pct', 0))},
                        )
                    except Exception:
                        pass  # Service-category network fallback failed

            # DOFR YES/NO SYNTHESIS: If returning mixed dofr_status rows for a YES/NO question
            if (rows
                    and any('dofr_status' in r for r in rows[:1])
                    and re.search(r'^(?:does|do|is|has|have)\b.{0,60}\bdofr\b', question, re.I)):
                _has_cnt = sum(1 for r in rows if r.get('dofr_status') == 'HAS')
                _total = len(rows)
                if _has_cnt > 0:
                    summary = f"YES — {_has_cnt} of {_total} matching facilities have dofr_status='HAS'."
                else:
                    summary = f"NO — 0 of {_total} matching facilities have dofr_status='HAS'."
                # Return empty data so direct dispatch uses summary text (not table)
                # The summary already has the YES/NO answer
                return ToolResult(
                    success=True,
                    data=[],
                    summary=summary,
                    confidence=Confidence.HIGH,
                    execution_time_s=time.time() - t0,
                    metadata={"sql": sql, "row_count": _has_cnt, "total_checked": _total},
                )

            # C-44 FIX: Generate SQL_EVIDENCE citation for auditable evidence trail
            _sql_evidence_cite = []
            try:
                _tables_in_sql = re.findall(
                    r'(?:FROM|JOIN)\s+(?:dev_adb\.raw\.)?([a-zA-Z_][a-zA-Z0-9_]*)',
                    sql, re.IGNORECASE,
                )
                _temporal = None
                if re.search(r"status\s*=\s*'current'", sql, re.I):
                    _temporal = "status = 'current'"
                elif re.search(r'is_current\s*=\s*TRUE', sql, re.I):
                    _temporal = "is_current = TRUE"
                _sql_evidence_cite = [{
                    'type': 'SQL_EVIDENCE',
                    'tool': 'sql_query',
                    'tables': sorted(set(t.lower() for t in _tables_in_sql)),
                    'row_count': len(rows),
                    'temporal_filter': _temporal,
                    'reproducible': True,
                    'sql_hash': hex(hash(sql) & 0xFFFFFFFF),
                }]
            except Exception:
                pass

            return ToolResult(
                success=True,
                data=rows,
                summary=summary,
                citations=_sql_evidence_cite,
                confidence=Confidence.HIGH if rows else Confidence.LOW,
                execution_time_s=time.time() - t0,
                metadata={"sql": sql, "row_count": len(rows), "tables": sorted(set(t.lower() for t in _tables_in_sql)) if '_tables_in_sql' in dir() else []},
            )

        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=[],
                summary=f"SQL execution error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
                metadata={"sql": sql},
            )

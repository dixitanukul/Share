"""
BaseTool — abstract base class for all V3 tool implementations.

Both native tools (sql_query, calculate, …) and adapter-backed tools
(passage_search, clause_existence, …) implement this interface.

The agent controller and ToolRegistry never know which implementation backs
a tool; they only see BaseTool.__call__() → ToolResult.
"""
from __future__ import annotations

import time
from abc import ABC, abstractmethod
from typing import Any

from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus


class BaseTool(ABC):
    """
    Abstract base for every V3 tool.

    Subclass contract:
    - Set `name` and `description` as class-level strings.
    - Implement `_run(**kwargs) -> ToolResult`.
    - Optionally override `validate_inputs(**kwargs) -> list[str]` for
      pre-execution validation (return empty list if inputs are valid).
    - Set `is_adapter_backed = True` if the tool delegates to a legacy module.

    The `__call__` method handles timing, unhandled exception wrapping,
    and elapsed time injection — subclasses never need to do those.
    """

    # ── Subclasses must set these ─────────────────────────────────────────────
    name: str = ""
    description: str = ""
    is_adapter_backed: bool = False

    # ── Public interface ──────────────────────────────────────────────────────

    def __call__(self, **kwargs: Any) -> ToolResult:
        """
        Execute the tool.

        Records wall-clock time, injects it into the result, and wraps
        any unhandled exception into a clean ToolResult.ERROR envelope.
        Subclasses implement _run(), not __call__.
        """
        t0 = time.perf_counter()
        try:
            errors = self.validate_inputs(**kwargs)
            if errors:
                return ToolResult(
                    success=False,
                    data=None,
                    summary=f"[{self.name}] Validation failed: {'; '.join(errors)}",
                    error_message="; ".join(errors),
                    confidence=Confidence.LOW,
                    status=ToolStatus.ERROR,
                    execution_time_s=time.perf_counter() - t0,
                )
            result = self._run(**kwargs)
            result.execution_time_s = time.perf_counter() - t0
            return result
        except Exception as exc:
            elapsed = time.perf_counter() - t0
            return ToolResult(
                success=False,
                data=None,
                summary=f"[{self.name}] Unhandled error: {exc}",
                error_message=str(exc),
                confidence=Confidence.LOW,
                execution_time_s=elapsed,
                status=ToolStatus.ERROR,
            )

    # ── Subclass interface ────────────────────────────────────────────────────

    @abstractmethod
    def _run(self, **kwargs: Any) -> ToolResult:
        """Core tool logic. Must return a ToolResult. Never raises."""
        ...

    def validate_inputs(self, **kwargs: Any) -> list[str]:
        """
        Return a list of validation error strings.
        Empty list means inputs are valid and _run() may proceed.
        Override in subclasses that need strict input contracts.
        """
        return []

    # ── Utility helpers available to subclasses ───────────────────────────────

    def _require(self, kwargs: dict, *keys: str) -> list[str]:
        """Convenience: return error messages for any missing required keys."""
        return [f"Missing required parameter: '{k}'" for k in keys if not kwargs.get(k)]

    def __repr__(self) -> str:
        kind = "adapter" if self.is_adapter_backed else "native"
        return f"<Tool:{self.name!r} [{kind}]>"

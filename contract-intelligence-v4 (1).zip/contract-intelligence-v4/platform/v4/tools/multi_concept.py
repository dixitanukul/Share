"""
P4F — MultiConceptTool
======================
Native V3 replacement for V2 Branch F (branch_multi_concept).
Answers boolean-intersection questions ("Which providers have A AND B?",
"have A BUT NOT B?", "have A OR B?") using parallel keyword SQL per concept
followed by set arithmetic.

Note: uses keyword matching for speed. For production accuracy on specific
concepts, run ClauseExistenceTool for each concept individually.
"""
from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from ..contracts.tool_types import Confidence, ToolResult, ToolStatus
from ..config.settings import (
    CATALOG, SCHEMA, LLM_REASONING,
    TBL_VS_UNIFIED_READY,
)
from ..services.sql_helpers import escape_sql, qualified_table
from ..services.text_utils import STOPWORDS
from .base import BaseTool

_VW_CONTRACT_TERMS = f"{CATALOG}.{SCHEMA}.vw_genie_contract_terms"

# Boolean operator detection signals
_DIFFERENCE_SIGNALS = (" but not ", " but no ", " without ", " excluding ")
_UNION_SIGNALS = (" or ",)


# ─── Dataclass ───────────────────────────────────────────────────────────────

@dataclass
class MultiConceptResult:
    """Structured result from a multi-concept intersection query."""
    concepts: List[str]
    operator: str
    result_label: str
    result_set: List[str] = field(default_factory=list)
    complement: List[str] = field(default_factory=list)
    concept_hits: Dict[str, int] = field(default_factory=dict)
    venn: Dict[str, int] = field(default_factory=dict)
    completeness: Dict[str, Any] = field(default_factory=dict)


# ─── Tool ────────────────────────────────────────────────────────────────────

class MultiConceptTool(BaseTool):
    """Analyse multiple contract concepts and compute set intersections.

    Supports three boolean operators:
    - INTERSECTION (AND): providers that have both concepts
    - DIFFERENCE (BUT NOT): providers that have A but not B
    - UNION (OR): providers that have either concept

    Uses keyword matching for speed. For production accuracy on a specific
    concept, use ClauseExistenceTool for that concept individually.
    """

    name = "multi_concept"
    description = (
        "Find providers matching boolean combinations of contract concepts: "
        "AND (intersection), BUT NOT (difference), OR (union). "
        "Use for 'which providers have X AND Y' or 'have X but not Y' questions."
    )
    is_adapter_backed = False

    def __init__(
        self,
        spark: Any,
        provider_service: Any,
        llm_client: Any = None,
    ) -> None:
        self._spark = spark
        self._provider_service = provider_service
        self._llm_client = llm_client

    # ── Validation ───────────────────────────────────────────────────────

    def validate_inputs(self, **kwargs) -> list:
        return self._require(kwargs, "question")

    # ── Main execution ───────────────────────────────────────────────────

    def _run(
        self,
        question: str,
        concepts: Optional[List[str]] = None,
        operator: Optional[str] = None,
    ) -> ToolResult:
        resolved = list(concepts) if concepts else self._extract_concepts(question)
        if len(resolved) < 2:
            return ToolResult.error(
                f"Need at least 2 concepts to compare. Detected: {resolved}. "
                "Try: 'Which providers have offset clause AND auto-renewal?'",
                tool_name=self.name,
            )

        op = operator or self._detect_operator(question)

        # Parallel concept search (keyword SQL, one thread per concept)
        concept_sets: Dict[str, Set[str]] = {}
        with ThreadPoolExecutor(max_workers=min(3, len(resolved))) as pool:
            futures = {pool.submit(self._search_concept, c): c for c in resolved[:3]}
            for fut in as_completed(futures):
                concept, pset = fut.result()
                concept_sets[concept] = pset

        all_providers: Set[str] = set(self._provider_service.corpus_universe())
        keys = list(concept_sets.keys())
        set_a = concept_sets.get(keys[0], set())
        set_b = concept_sets.get(keys[1], set()) if len(keys) > 1 else set()

        if op == "DIFFERENCE":
            result_set = sorted(set_a - set_b)
            complement = sorted(set_b - set_a)
            result_label = f"Have '{keys[0]}' BUT NOT '{keys[1]}'"
        elif op == "UNION":
            result_set = sorted(set_a | set_b)
            complement = sorted(all_providers - (set_a | set_b))
            result_label = f"Have '{keys[0]}' OR '{keys[1]}'"
        else:  # INTERSECTION
            result_set = sorted(set_a & set_b)
            complement = sorted(all_providers - set_a - set_b)
            result_label = f"Have BOTH '{keys[0]}' AND '{keys[1]}'"

        completeness = {
            "concept_a_count": len(set_a),
            "concept_b_count": len(set_b),
            "overlap": len(set_a & set_b),
            "result_count": len(result_set),
            "universe_size": len(all_providers),
        }

        return ToolResult(
            success=True,
            data={
                "concepts": resolved,
                "operator": op,
                "result_label": result_label,
                "result_set": result_set,
                "complement": complement[:50],
                "concept_hits": {c: len(s) for c, s in concept_sets.items()},
                "venn": {
                    "only_a": len(set_a - set_b),
                    "both": len(set_a & set_b),
                    "only_b": len(set_b - set_a),
                    "neither": len(all_providers - set_a - set_b),
                },
                "completeness": completeness,
            },
            summary=(
                f"Multi-concept {op}: {result_label} — "
                f"{len(result_set)} providers match"
            ),
            confidence=Confidence.LOW,  # keyword-only; use ClauseExistenceTool for HIGH
            status=ToolStatus.SUCCESS if result_set else ToolStatus.EMPTY,
            citations=[],
        )

    # ── Helpers ──────────────────────────────────────────────────────────

    def _search_concept(self, concept: str):
        """Keyword SQL search for a single concept. Returns (concept, set_of_providers)."""
        words = [w for w in concept.lower().split() if w not in STOPWORDS and len(w) > 2]
        if not words:
            words = [concept.lower()]
        safe_words = [escape_sql(w) for w in words]
        ft_conds = " AND ".join(f"LOWER(chunk_text) LIKE '%{w}%'" for w in safe_words)
        terms_conds = " AND ".join(f"LOWER(content_text) LIKE '%{w}%'" for w in safe_words)

        providers: Set[str] = set()
        try:
            pdf = self._spark.sql(
                f"SELECT DISTINCT provider_name"
                f" FROM {qualified_table(TBL_VS_UNIFIED_READY)}"
                f" WHERE {ft_conds} AND LENGTH(chunk_text) >= 50"
            ).toPandas()
            providers.update(pdf["provider_name"].dropna().tolist())
        except Exception:
            pass
        try:
            pdf2 = self._spark.sql(
                f"SELECT DISTINCT provider_name"
                f" FROM {_VW_CONTRACT_TERMS}"
                f" WHERE {terms_conds} AND is_from_latest_doc = true"
            ).toPandas()
            providers.update(pdf2["provider_name"].dropna().tolist())
        except Exception:
            pass
        return concept, providers

    def _detect_operator(self, question: str) -> str:
        q = question.lower()
        for sig in _DIFFERENCE_SIGNALS:
            if sig in q:
                return "DIFFERENCE"
        for sig in _UNION_SIGNALS:
            if sig in q:
                return "UNION"
        return "INTERSECTION"

    def _extract_concepts(self, question: str) -> List[str]:
        """Extract concepts via regex patterns, with optional LLM fallback."""
        patterns = [
            r"have\s+(.+?)\s+(?:and|but not|but no|or)\s+(.+?)(?:\?|$)",
            r"with\s+(.+?)\s+(?:and|but not|but no|or)\s+(.+?)(?:\?|$)",
            r"both\s+(.+?)\s+and\s+(.+?)(?:\?|$)",
        ]
        q_lower = question.lower()
        for pat in patterns:
            m = re.search(pat, q_lower)
            if m:
                c1 = m.group(1).strip().rstrip(".,")
                c2 = m.group(2).strip().rstrip(".,")
                if c1 and c2:
                    return [c1, c2]
        if self._llm_client:
            try:
                raw = self._llm_client.chat(
                    model=LLM_REASONING,
                    system="You extract contract concept names from questions.",
                    user=(
                        "Extract the 2+ contract concepts from this question. "
                        "Return ONLY a JSON array.\n"
                        f"Question: \"{question}\"\n"
                        "Example: [\"offset clause\", \"auto-renewal\"]"
                    ),
                    max_tokens=200,
                )
                raw = raw.strip()
                if raw.startswith("```"):
                    raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0]
                result = json.loads(raw)
                if isinstance(result, list) and len(result) >= 2:
                    return [str(c) for c in result[:3]]
            except Exception:
                pass
        return []

"""ComplianceQueryTool: regulatory compliance, quality performance, notifications."""
from __future__ import annotations
import re
from typing import Any
from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus
from platform.v4.tools.base import BaseTool


class ComplianceQueryTool(BaseTool):
    name = "compliance_query"
    description = (
        "Query regulatory compliance status, quality performance programs, and contract notifications. "
        "Parameters: query_type (required), provider (optional: provider name for filtered queries), "
        "regulation (optional: exact regulation name for regulation_summary), program (optional: program_name filter). "
        "query_type options: "
        "  compliance_summary = overall distribution across all 7 regulations and all providers; "
        "  provider_compliance = all compliance records for a named provider (use provider='ProviderName'); "
        "  quality_scores = quality program data (use provider=\'\' for all, program='HEDIS|P4P|etc' to filter); "
        "  notifications = contract notification requirements for a provider (use provider='ProviderName'); "
        "  regulation_summary = all providers for a specific regulation (use regulation='AB_72|KNOX_KEENE|CMS_MA|DMHC_STANDARDS|AB_1455|SB_137|AB_352'). "
        "compliance_status values: PARTIAL | UNKNOWN | COMPLIANT | EXEMPT (never NON_COMPLIANT). "
        "program_name values: HEDIS | WITHHOLD | VALUE_BASED | P4P | STAR_RATING. "
        "Example: query_type='provider_compliance', provider='Sharp HealthCare' returns all regulations for Sharp. "
        "Example: query_type='regulation_summary', regulation='AB_72' returns all providers for AB 72."
    )

    def __init__(self, spark):
        self.spark = spark
        self.tbl_compliance  = "dev_adb.raw.tbl_compliance_tracking"
        self.tbl_quality     = "dev_adb.raw.tbl_quality_performance"
        self.tbl_notif       = "dev_adb.raw.tbl_contract_notifications"

    # Known regulation names (normalized forms for matching)
    _REGULATION_ALIASES = {
        "knox-keene": "KNOX_KEENE", "knox keene": "KNOX_KEENE", "knox_keene": "KNOX_KEENE",
        "cms": "CMS_MA", "cms_ma": "CMS_MA", "cms ma": "CMS_MA",
        "medicare advantage": "CMS_MA", "medicare": "CMS_MA",
        "dmhc": "DMHC_STANDARDS", "dmhc standards": "DMHC_STANDARDS", "dmhc_standards": "DMHC_STANDARDS",
        "ab 72": "AB_72", "ab72": "AB_72", "surprise billing": "AB_72",
        "ab 352": "AB_352", "ab352": "AB_352",
        "ab 1455": "AB_1455", "ab1455": "AB_1455",
        "sb 137": "SB_137", "sb137": "SB_137",
    }
    _KNOWN_REGULATIONS = frozenset({"KNOX_KEENE", "CMS_MA", "DMHC_STANDARDS", "AB_1455", "SB_137", "AB_352", "AB_72"})
    _QUALITY_PROGRAMS = ("hedis", "p4p", "withhold", "star rating", "value based", "value-based")
    _NOTIFICATION_TYPES = {
        "termination": "TERMINATION", "terminate": "TERMINATION", "terminating": "TERMINATION",
        "rate change": "RATE_CHANGE", "rate adjustment": "RATE_CHANGE", "repricing": "RATE_CHANGE",
        "audit": "AUDIT", "auditing": "AUDIT",
        "compliance": "COMPLIANCE",
        "renewal": "RENEWAL", "renew": "RENEWAL",
        "credentialing": "CREDENTIALING",
        "claims submission": "CLAIMS_SUBMISSION_DEADLINE", "claims deadline": "CLAIMS_SUBMISSION_DEADLINE",
    }

    def _infer_params_from_question(self, question: str) -> dict:
        """Infer query_type, provider, regulation, program from a natural-language question."""
        q = question.lower()
        params = {}

        # Detect regulation
        for alias, reg in self._REGULATION_ALIASES.items():
            if alias in q:
                params["regulation"] = reg
                break

        # 5F-FIX: Check for unknown regulations (e.g., HIPAA) not tracked in our system
        _UNKNOWN_REGS = {"hipaa", "state licensing", "ab 1107", "ab1107", "stark", "anti-kickback"}
        for unreg in _UNKNOWN_REGS:
            if unreg in q:
                params["_unknown_regulation"] = unreg.upper()
                break

        # Detect quality program
        for prog in self._QUALITY_PROGRAMS:
            if prog in q:
                params["program"] = prog.upper().replace(" ", "_").replace("-", "_")
                break

        # Detect notification type
        for alias, ntype in self._NOTIFICATION_TYPES.items():
            if alias in q:
                params["notification_type"] = ntype
                break

        # Determine query_type
        # 7C-FIX: "distribution / breakdown" → aggregate summary, not row list
        if params.get("regulation") and any(w in q for w in ("distribution", "breakdown", "how many comply", "summary of compliance")):
            params["query_type"] = "regulation_distribution"
        elif params.get("regulation") and (
            "which provider" in q or "all provider" in q or "covered" in q
            or "how many" in q or "list" in q
        ) and "required to comply" not in q:
            params["query_type"] = "regulation_summary"
        elif any(w in q for w in ("quality", "hedis", "p4p", "withhold", "star rating", "value based", "value-based",
                                   "performance program", "bonus", "penalty")):
            params["query_type"] = "quality_scores"
        elif any(w in q for w in ("notice", "days notice", "notification", "termination notice",
                                   "notice period", "advance notice")):
            params["query_type"] = "notifications"
        elif params.get("regulation"):
            params["query_type"] = "regulation_summary"
        elif "what regulation" in q or "which regulation" in q or "all regulation" in q or "all 7 regulation" in q:
            # 5C-FIX: "What regulations does X comply with?" → provider_regulations_summary
            params["query_type"] = "provider_regulations_summary"
        else:
            params["query_type"] = "compliance_summary"

        # Detect provider name from question
        _provider_q = re.search(
            r"(?:for|does|is)\s+([A-Z][A-Za-z]+(?:\s+[A-Za-z]+){0,4})\s+(?:comply|compliant|required|covered|meet|need|have|participate)",
            question
        )
        if _provider_q:
            params.setdefault("provider", _provider_q.group(1).strip())
            if params.get("query_type") == "compliance_summary":
                params["query_type"] = "provider_compliance"

        return params

    # Q11.3 QA fix: generic California-bill-code pattern (AB/SB/HB/etc + number).
    # The old _UNKNOWN_REGS denylist only caught a few named regulations (HIPAA,
    # Stark, ...) and silently let ANY other fabricated bill number (e.g. "SB 999")
    # fall through to a network-wide compliance_summary with no "not tracked"
    # disclosure. This pattern catches any bill-shaped code and cross-checks it
    # against the known regulation aliases, so only genuinely tracked bills
    # (AB_72, AB_352, AB_1455, SB_137) are allowed through.
    _BILL_CODE_RE = re.compile(r'\b(AB|SB|HB|HR|SCR|ACR|SR)[\s\-]?(\d{1,4})\b', re.IGNORECASE)

    # Helper to validate a pre-flight regulation check
    def _validate_params(self, question, query_type, provider, regulation):
        """Return early ToolResult if request is for an untracked regulation."""
        q = question.lower() if question else ""
        _UNKNOWN_REGS = {"hipaa", "state licensing", "ab 1107", "ab1107", "stark", "anti-kickback"}
        for unreg in _UNKNOWN_REGS:
            if unreg in q:
                return ToolResult(
                    success=True, data=[],
                    summary=(
                        f"{unreg.upper()} is not tracked in Blue Shield's compliance monitoring system. "
                        f"The 7 tracked regulations are: KNOX_KEENE, CMS_MA, DMHC_STANDARDS, AB_1455, SB_137, AB_352, AB_72. "
                        f"For {unreg.upper()} compliance information, consult the Legal/Compliance department directly."
                    ),
                    confidence=Confidence.HIGH, status=ToolStatus.SUCCESS,
                )
        # Q11.3 fix: any bill-shaped code (e.g. "SB 999") not present in the known
        # regulation aliases is untracked/fabricated — reject with the same
        # informative "not tracked" message instead of silently falling through
        # to compliance_summary for unrelated real regulations.
        for _m in self._BILL_CODE_RE.finditer(question or ""):
            _prefix, _num = _m.group(1).upper(), _m.group(2)
            _code_display = f"{_prefix} {_num}"
            _alias_spaced = f"{_prefix.lower()} {_num}"
            _alias_nospace = f"{_prefix.lower()}{_num}"
            if _alias_spaced in self._REGULATION_ALIASES or _alias_nospace in self._REGULATION_ALIASES:
                continue  # a real tracked regulation (e.g. "AB 72", "SB 137")
            return ToolResult(
                success=True, data=[],
                summary=(
                    f"{_code_display} is not tracked in Blue Shield's compliance monitoring system. "
                    f"The 7 tracked regulations are: KNOX_KEENE, CMS_MA, DMHC_STANDARDS, AB_1455, SB_137, AB_352, AB_72. "
                    f"For {_code_display} compliance information, consult the Legal/Compliance department directly."
                ),
                confidence=Confidence.HIGH, status=ToolStatus.SUCCESS,
            )
        return None

    def _run(self, **kwargs: Any) -> ToolResult:
        question   = kwargs.get("question", "")
        query_type = kwargs.get("query_type", "")
        provider   = kwargs.get("provider", "") or kwargs.get("provider_name", "")
        regulation = kwargs.get("regulation", "")
        program    = kwargs.get("program", "")

        # When called from direct dispatch (only question=...), infer params
        if question and not query_type:
            inferred = self._infer_params_from_question(question)
            query_type = inferred.get("query_type", "compliance_summary")
            if not provider:
                provider = inferred.get("provider", "")
            if not regulation:
                regulation = inferred.get("regulation", "")
            if not program:
                program = inferred.get("program", "")

        if not query_type:
            query_type = "compliance_summary"
        # If provider is specified, prefer provider-level query types
        if provider and query_type == "compliance_summary":
            query_type = "provider_compliance"

        # 5F-FIX: Early return for untracked regulations
        _val_result = self._validate_params(question, query_type, provider, regulation)
        if _val_result:
            return _val_result

        # 5C-FIX: "What regulations does X comply with?" → summary per regulation
        _q_lower = question.lower() if question else ""
        if provider and query_type in ("provider_compliance", "provider_regulations_summary"):
            _is_reg_list_q = bool(re.search(
                r"\b(?:what|which|show|list|all)\s+(?:\w+\s+){0,2}regulations?\b"
                r"|\ball\s+7\s+regulation"
                r"|\bcompliance\s+status\s+for\s+all"
                r"|\bregulations?.*comply",
                _q_lower
            ))
            if _is_reg_list_q or query_type == "provider_regulations_summary":
                query_type = "provider_regulations_summary"

        # Q11.9/Q11.21 fix: use the FULL provider name, not just the first token —
        # "Tricity Medical Center".split()[0] == "Tricity" would also match
        # "Tricity Regional Medical Center" (and "Anaheim" would match
        # "Anaheim Regional/Global/Community" as three distinct facilities).
        _prov_token = provider.strip() if provider else provider

        if query_type == "compliance_summary":
            sql = f"""
                WITH provider_worst AS (
                    SELECT regulation, provider_name,
                           CASE
                               WHEN MAX(CASE compliance_status WHEN 'UNKNOWN' THEN 3 WHEN 'PARTIAL' THEN 2 WHEN 'EXEMPT' THEN 1 ELSE 0 END) = 3 THEN 'UNKNOWN'
                               WHEN MAX(CASE compliance_status WHEN 'UNKNOWN' THEN 3 WHEN 'PARTIAL' THEN 2 WHEN 'EXEMPT' THEN 1 ELSE 0 END) = 2 THEN 'PARTIAL'
                               WHEN MAX(CASE compliance_status WHEN 'UNKNOWN' THEN 3 WHEN 'PARTIAL' THEN 2 WHEN 'EXEMPT' THEN 1 ELSE 0 END) = 1 THEN 'EXEMPT'
                               ELSE 'COMPLIANT'
                           END AS overall_status
                    FROM {self.tbl_compliance}
                    GROUP BY regulation, provider_name
                ),
                reg_totals AS (
                    SELECT regulation, COUNT(*) AS total_tracked
                    FROM provider_worst GROUP BY regulation
                )
                SELECT pw.regulation,
                       pw.overall_status AS compliance_status,
                       COUNT(*) AS provider_count,
                       rt.total_tracked,
                       ROUND(COUNT(*) * 100.0 / rt.total_tracked, 1) AS pct_of_regulation
                FROM provider_worst pw
                JOIN reg_totals rt ON pw.regulation = rt.regulation
                GROUP BY pw.regulation, pw.overall_status, rt.total_tracked
                ORDER BY pw.regulation, provider_count DESC
            """
            caveat = (
                "compliance_status values: PARTIAL | UNKNOWN | COMPLIANT | EXEMPT. "
                "7 regulations: CMS_MA | KNOX_KEENE | DMHC_STANDARDS | AB_1455 | SB_137 | AB_352 | AB_72."
            )

        elif query_type == "provider_regulations_summary":
            # 5C/5E-FIX: Summary across ALL regulations for a provider
            sql = f"""
                SELECT regulation,
                       compliance_status,
                       risk_level,
                       COUNT(*) AS entity_count
                FROM {self.tbl_compliance}
                WHERE LOWER(provider_name) LIKE LOWER('%{_prov_token}%')
                GROUP BY regulation, compliance_status, risk_level
                ORDER BY regulation, entity_count DESC
            """
            caveat = (
                f"All 7 tracked regulations for {provider}. "
                "UNKNOWN = no contractual language found; PARTIAL = partial mention only."
            )

        elif query_type == "provider_compliance":
            # 5H-FIX: Filter by specific regulation when question mentions one
            _reg_filter = ""
            _REG_KEYWORDS = {
                "knox": "KNOX_KEENE", "keene": "KNOX_KEENE",
                "cms": "CMS_MA", "medicare advantage": "CMS_MA",
                "dmhc": "DMHC_STANDARDS",
                "ab 1455": "AB_1455", "ab1455": "AB_1455",
                "sb 137": "SB_137", "sb137": "SB_137",
                "ab 352": "AB_352", "ab352": "AB_352",
                "ab 72": "AB_72", "ab72": "AB_72",
            }
            for kw, reg_val in _REG_KEYWORDS.items():
                if kw in _q_lower:
                    _reg_filter = f"AND regulation = '{reg_val}'"
                    break
            sql = f"""
                SELECT regulation, requirement_category, compliance_status,
                       risk_level, LEFT(evidence_text, 200) AS evidence_text,
                       source_filename
                FROM {self.tbl_compliance}
                WHERE LOWER(provider_name) LIKE LOWER('%{_prov_token}%')
                  {_reg_filter}
                ORDER BY regulation, compliance_status
                LIMIT 30
            """
            caveat = "UNKNOWN = no contractual language found; PARTIAL = partial mention only."

        elif query_type == "quality_scores":
            where_clauses = []
            if provider:
                _qual_token = provider.strip() if provider else provider  # Q11.9/Q11.21 fix: full name
                where_clauses.append(f"LOWER(provider_name) LIKE LOWER('%{_qual_token}%')")
            if program:
                where_clauses.append(f"UPPER(program_name) = UPPER('{program}')")
            where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
            sql = f"""
                SELECT provider_name, program_name, metric_name,
                       COALESCE(CAST(target_value AS STRING), 'N/A') AS target_value,
                       COALESCE(CAST(penalty_pct AS STRING), 'N/A') AS penalty_pct,
                       COALESCE(CAST(bonus_pct AS STRING), 'N/A') AS bonus_pct,
                       payment_mechanism
                FROM {self.tbl_quality}
                {where_sql}
                ORDER BY provider_name, program_name
                LIMIT 50
            """
            caveat = (
                "bonus_pct and penalty_pct may be NULL (contracts use prose, not bare N% patterns). "
                "program_name NOT program_type."
            )

        elif query_type == "notifications":
            # 5N/5P-FIX: Filter by notification_type when question specifies a type
            _notif_type_filter = ""
            for alias, ntype in self._NOTIFICATION_TYPES.items():
                if alias in _q_lower:
                    _notif_type_filter = f"AND UPPER(notification_type) = '{ntype}'"
                    break

            # 5O-FIX: When asking about "types" or "what notifications", return summary
            _is_type_listing = any(w in _q_lower for w in (
                "types of notification", "notification types", "what types",
                "what notifications", "which notifications",
            ))
            if _is_type_listing and provider and not _notif_type_filter:
                sql = f"""
                    SELECT notification_type, COUNT(*) as entry_count,
                           ROUND(AVG(notice_days), 0) AS avg_notice_days,
                           MAX(notice_days) AS max_notice_days
                    FROM {self.tbl_notif}
                    WHERE LOWER(provider_name) LIKE LOWER('%{_prov_token}%')
                    GROUP BY notification_type
                    ORDER BY entry_count DESC
                """
            else:
                sql = f"""
                    SELECT notification_type, trigger_event, notice_days,
                           notice_direction, delivery_method, cure_period_days,
                           provider_name
                    FROM {self.tbl_notif}
                    WHERE LOWER(provider_name) LIKE LOWER('%{_prov_token}%')
                      {_notif_type_filter}
                    ORDER BY notification_type, notice_days DESC
                    LIMIT 30
                """
            # 5P-FIX: For multi-provider notification queries (no specific provider)
            if not provider and _notif_type_filter:
                sql = f"""
                    SELECT provider_name, notification_type, notice_days,
                           notice_direction, delivery_method
                    FROM {self.tbl_notif}
                    WHERE 1=1 {_notif_type_filter}
                    ORDER BY notice_days DESC
                    LIMIT 30
                """
            caveat = (
                "notice_direction: TO_PROVIDER | TO_PLAN | MUTUAL | UNSPECIFIED. "
                "notification_type: TERMINATION | RATE_CHANGE | AUDIT | COMPLIANCE | "
                "RENEWAL | CREDENTIALING | CLAIMS_SUBMISSION_DEADLINE."
            )

        elif query_type == "regulation_summary":
            reg_filter = regulation.upper().replace(" ", "_")
            _prov_short = provider.strip() if provider else provider  # Q11.9/Q11.21 fix: full name
            prov_filter = f"AND LOWER(provider_name) LIKE LOWER('%{_prov_short}%')" if provider else ""
            _status_filter = ""
            _is_listing_q = bool(re.search(
                r"\b(?:which|what|list|all|how many)\s+(?:\w+\s+){0,3}providers?\b",
                _q_lower,
            ))
            if _is_listing_q and not provider:
                if "compliant" in _q_lower and "non" not in _q_lower.split("compliant")[0][-5:]:
                    _status_filter = "AND compliance_status = 'COMPLIANT'"
                elif "partial" in _q_lower:
                    _status_filter = "AND compliance_status = 'PARTIAL'"
                elif "unknown" in _q_lower:
                    _status_filter = "AND compliance_status = 'UNKNOWN'"
            count_sql = f"""
                SELECT COUNT(*) AS total
                FROM {self.tbl_compliance}
                WHERE UPPER(regulation) = '{reg_filter}'
                  {prov_filter}
                  {_status_filter}
            """
            _total_count = self.spark.sql(count_sql).collect()[0]['total']
            # 5H-FIX: When provider is specified, include requirement details
            if provider:
                sql = f"""
                    SELECT provider_name, compliance_status, risk_level,
                           requirement_category,
                           LEFT(evidence_text, 200) AS evidence_text,
                           source_filename
                    FROM {self.tbl_compliance}
                    WHERE UPPER(regulation) = '{reg_filter}'
                      {prov_filter}
                      {_status_filter}
                    ORDER BY compliance_status, provider_name
                    LIMIT 20
                """
            else:
                sql = f"""
                    SELECT provider_name, compliance_status, risk_level,
                           source_filename
                    FROM {self.tbl_compliance}
                    WHERE UPPER(regulation) = '{reg_filter}'
                      {prov_filter}
                      {_status_filter}
                    ORDER BY compliance_status, provider_name
                    LIMIT 30
                """
            caveat = f"Showing results from {_total_count} total matching entries" if _total_count > 30 else ""

        elif query_type == "regulation_distribution":
            # 7C-FIX: return GROUP BY distribution for "what is the DMHC compliance distribution?" style questions
            reg_filter = regulation.upper().replace(" ", "_")
            dist_count_sql = f"SELECT COUNT(*) AS total FROM {self.tbl_compliance} WHERE UPPER(regulation) = '{reg_filter}'"
            _dist_total = self.spark.sql(dist_count_sql).collect()[0]['total']
            sql = f"""
                SELECT compliance_status,
                       COUNT(*) AS provider_count,
                       ROUND(COUNT(*) * 100.0 / {max(_dist_total, 1)}, 1) AS pct_of_total
                FROM {self.tbl_compliance}
                WHERE UPPER(regulation) = '{reg_filter}'
                GROUP BY compliance_status
                ORDER BY provider_count DESC
            """
            caveat = (
                f"Distribution of {_dist_total} {reg_filter} compliance entries across "
                f"all providers (COMPLIANT / PARTIAL / UNKNOWN / EXEMPT counts)."
            )

        else:
            return ToolResult(
                success=False, data=None,
                summary=f"Unknown query_type: {query_type}",
                confidence=Confidence.LOW, status=ToolStatus.ERROR,
            )

        df   = self.spark.sql(sql)
        rows = [r.asDict() for r in df.collect()]

        # 7B-FIX: When regulation_summary returns 0 rows (e.g. COMPLIANT filter on AB_72),
        # provide an informative distribution fallback so the user isn't left with empty output.
        if not rows and query_type == "regulation_summary" and '_status_filter' in dir():
            _sf = locals().get('_status_filter', '') or ''
            if _sf:  # status filter caused the zero result
                _reg_f = locals().get('reg_filter', regulation.upper().replace(' ', '_'))
                _dist_sql = f"""
                    SELECT compliance_status, COUNT(*) AS cnt
                    FROM {self.tbl_compliance}
                    WHERE UPPER(regulation) = '{_reg_f}'
                    GROUP BY compliance_status ORDER BY cnt DESC
                """
                try:
                    _dist_rows = [r.asDict() for r in self.spark.sql(_dist_sql).collect()]
                    _dist_str = ", ".join(f"{r['compliance_status']}: {r['cnt']}" for r in _dist_rows)
                    caveat = (
                        f"No providers match the requested filter for {_reg_f}. "
                        f"Actual distribution: {_dist_str}."
                    )
                except Exception:
                    caveat = f"No providers match the requested compliance status for {_reg_f}."
                rows = []  # keep empty so summary renders the caveat
        # Coerce floats (penalty_pct, bonus_pct) to avoid JSON serialisation issues
        for r in rows:
            for k in ("penalty_pct", "bonus_pct", "target_value"):
                if r.get(k) is not None:
                    try:
                        r[k] = float(r[k])
                    except (TypeError, ValueError):
                        pass

        summary = f"[compliance_query:{query_type}] {len(rows)} results"
        if caveat:
            summary += f" | {caveat}"
        return ToolResult(
            success=True, data=rows, summary=summary,
            confidence=Confidence.HIGH, status=ToolStatus.SUCCESS,
        )

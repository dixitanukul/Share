"""
platform/v4/tools/clause_existence_tool.py

P4C-CE-7: Clause Existence Tool -- V3 orchestrator.

Replaces V2 Branch A (Cell 5 + Cell 6). Returns structured ToolResult (NOT HTML).

Pipeline:
  1.   Build understanding from question + params
  1.5. Load provider universe
  2.   Resolve taxonomy + execution plan (TaxonomyBuilder)
  2.5. Apply corpus frequency gate (PassageRetriever)
  3.   Hybrid retrieval + dedup (PassageRetriever)
  4.   Per-provider sweep / coverage guarantee (PassageRetriever)
  P1.  Evidence sufficiency gate
  5.   Parallel LLM classification (ClauseClassifier)
  5.5. Denial re-validation (ClauseRevalidator)
  5.75 Post-classification recall sweep
  6.   Provider rollup -- HAS/DENIED/MIXED/NO_MENTION (ClauseClassifier)
  6.25 Settlement audit (ClauseRevalidator)
  6.3  Latest doc currency gate (ClauseRevalidator)
  6.5  False-negative safety net (FalseNegativeRescuer)
  7.5  Citation verification (ClauseClassifier)

Tool name: "clause_existence"

V2 baseline (offset clause v8): HAS=304, MIXED=3, DENIED=4, NO_MENTION=15.
Regression tolerance: +-2 per bucket.
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from platform.v4.tools.base import BaseTool
from platform.v4.contracts.tool_types import Confidence, ToolResult, ToolStatus
from platform.v4.config.settings import LLM_REASONING

from platform.v4.tools.clause_existence.taxonomy_builder import TaxonomyBuilder
from platform.v4.tools.clause_existence.passage_retrieval import PassageRetriever
from platform.v4.tools.clause_existence.classifier import ClauseClassifier
from platform.v4.tools.clause_existence.revalidation import ClauseRevalidator
from platform.v4.tools.clause_existence.rescue import FalseNegativeRescuer

logger = logging.getLogger(__name__)

# Concept regex patterns (mirrors V2 Cell 6 _CE_CONCEPT_PATTERNS)
_CE_CONCEPT_PATTERNS: List[tuple] = [
    (r"\b(offset\s+clause|offset\s+provision|right\s+to\s+offset|offset\s+rights?)\b", "offset clause"),
    (r"\b(dofr|division\s+of\s+financial\s+responsibility)\b", "division of financial responsibility"),
    (r"\b(ipa\s+delegation|delegation\s+to\s+ipa|ipa\s+delegate)\b", "ipa delegation"),
    (r"\b(ab\s*352|reproductive\s+health)\b", "ab 352 reproductive health"),
    (r"\b(encounters?\s+reconciliation|encounter\s+data\s+reconcil)\b", "encounters reconciliation"),
    (r"\b(auto[\s\-]?renewal|automatic\s+renewal)\b", "auto renewal"),
    (r"\b(termination\s+clause|right\s+to\s+terminate)\b", "termination clause"),
    (r"\b(dispute\s+resolution)\b", "dispute resolution clause"),
    (r"\b(coordination\s+of\s+benefits)\b", "coordination of benefits"),
    (r"\b(indemnification)\b", "indemnification clause"),
    (r"\b(subrogation)\b", "subrogation clause"),
    (r"\b(credentialing)\b", "credentialing provision"),
    (r"\b(hold\s+harmless)\b", "hold harmless clause"),
    (r"\b(reconciliation)\b", "reconciliation provision"),
    (r"\b(grievance)\b", "grievance provision"),
]


@dataclass
class ClauseExistenceResult:
    """Structured result from a full clause existence analysis."""
    concept: str
    provider_data: Dict[str, Any] = field(default_factory=dict)
    no_mention: List[str] = field(default_factory=list)
    classified: List[Dict] = field(default_factory=list)
    taxonomy: List[Dict] = field(default_factory=list)
    plan: Dict = field(default_factory=dict)
    understanding: Dict = field(default_factory=dict)
    has_count: int = 0
    denied_count: int = 0
    mixed_count: int = 0
    no_mention_count: int = 0
    total_universe: int = 0
    deduped_count: int = 0
    elapsed_s: float = 0.0
    validation_stats: Dict = field(default_factory=dict)


class ClauseExistenceTool(BaseTool):
    """
    Full clause existence analysis across the provider universe.

    Determines which healthcare provider contracts contain a specific clause
    or provision. Returns structured ToolResult (NOT HTML).

    Concept resolution priority:
      1. Explicit ``target_concept`` parameter
      2. Routing dict ``target_concept`` (from route_question)
      3. Regex rescue from question text
      4. "contract provision" (last resort -- both paths failed)
    """

    name = "clause_existence"
    description = (
        "Determine which healthcare provider contracts contain a specific clause or provision. "
        "Returns HAS/DENIED/MIXED/NO_MENTION for every provider in the contract universe. "
        "Use for: 'Which providers have offset clause?', "
        "'Do all IPA providers have auto-renewal?', 'Which contracts lack DOFR language?'"
    )
    is_adapter_backed = False

    def __init__(
        self,
        spark: Any,
        provider_service: Any,
        retrieval_service: Optional[Any] = None,
        llm_client: Optional[Any] = None,
        catalog: str = "dev_adb",
        schema: str = "raw",
    ) -> None:
        self._spark = spark
        self._provider_service = provider_service
        self._retrieval_service = retrieval_service
        self._llm_client = llm_client
        self._catalog = catalog
        self._schema = schema

        # Wire sub-modules
        vs_fn = self._make_vs_fn(retrieval_service)
        self._taxonomy_builder = TaxonomyBuilder(llm_client=llm_client)
        self._retriever = PassageRetriever(
            spark=spark, vs_search_fn=vs_fn, catalog=catalog, schema=schema
        )
        self._classifier = ClauseClassifier(llm_client=llm_client)
        self._revalidator = ClauseRevalidator(
            llm_client=llm_client, spark=spark, catalog=catalog, schema=schema
        )
        self._rescuer = FalseNegativeRescuer(
            spark=spark, catalog=catalog, schema=schema
        )

    # ------------------------------------------------------------------
    # BaseTool interface
    # ------------------------------------------------------------------

    def validate_inputs(self, **kwargs: Any) -> List[str]:
        errors: List[str] = []
        if not kwargs.get("question", "").strip():
            errors.append("question is required")
        return errors

    def _run(
        self,
        question: str,
        target_concept: Optional[str] = None,
        provider_filter: Optional[str] = None,
        max_passages_per_provider: int = 10,
        min_denials_for_revalidation: int = 5,
        routing: Optional[Dict] = None,
        **kwargs: Any,
    ) -> ToolResult:
        """
        Run full clause existence analysis (Steps 1 -> 7.5).

        Parameters
        ----------
        question                   : natural language question
        target_concept             : override concept extraction
        provider_filter            : limit analysis to one provider
        max_passages_per_provider  : passage cap (default 10)
        min_denials_for_revalidation : skip re-val when few denials (default 5)
        routing                    : pre-computed routing dict from route_question()
        """
        t0 = time.time()

        # Step 1: Build understanding
        understanding = self._build_understanding(
            question, target_concept, provider_filter, routing
        )

        # Step 1.5: Provider universe
        full_universe: List[str] = self._provider_service.corpus_universe()

        # GAP-006 fix: Apply provider_filter to narrow universe before analysis.
        # When report() filters by a subset, total_universe must reflect the
        # filtered set, not ALL 326 providers.
        pf = understanding.get("provider_filter")
        all_providers = self._apply_provider_filter(full_universe, pf)
        total_universe = len(all_providers)
        logger.info(
            "Provider universe: %d providers%s",
            total_universe,
            f" (filtered from {len(full_universe)})" if pf else "",
        )

        # Step 2: Taxonomy + execution plan
        taxonomy, plan = self._taxonomy_builder.resolve(
            understanding["target_concept"],
            understanding.get("search_keywords", []),
        )

        # Step 2.5: Corpus frequency gate
        plan = self._retriever.apply_corpus_frequency_gate(plan)

        # Refine search keywords based on plan strategy
        strategy = plan.get("precision_strategy", "balanced")
        ext = plan.get("extended_strong", []) + plan.get("extended_weak", [])
        if strategy == "strict":
            understanding["search_keywords"] = plan["core_keywords"]
        else:
            understanding["search_keywords"] = plan["core_keywords"] + ext
        understanding["_plan"] = plan

        # Step 3-4.5: Hybrid retrieval + dedup + per-provider sweep
        candidates = self._retriever.retrieve(
            understanding, plan, all_providers,
            max_per_provider=max_passages_per_provider,
        )
        deduped_count = len(candidates)
        logger.info("Candidates after retrieval: %d", deduped_count)

        # P1-1: Evidence sufficiency gate
        if not candidates:
            result = ClauseExistenceResult(
                concept=understanding["target_concept"],
                total_universe=total_universe,
                elapsed_s=time.time() - t0,
            )
            return ToolResult(
                success=False,
                data=vars(result),
                summary="Insufficient evidence: no relevant passages found",
                confidence=Confidence.LOW,
                status=ToolStatus.EMPTY,
                error_message="No passages matched the query keywords",
            )
        max_score = max(c.get("score", 1) for c in candidates)
        if max_score < 2:
            result = ClauseExistenceResult(
                concept=understanding["target_concept"],
                total_universe=total_universe,
                deduped_count=deduped_count,
                elapsed_s=time.time() - t0,
            )
            return ToolResult(
                success=False,
                data=vars(result),
                summary="Evidence quality too low: no passages above relevance threshold",
                confidence=Confidence.LOW,
                status=ToolStatus.EMPTY,
                error_message=f"Max passage score {max_score}/3, need >= 2",
            )

        # Step 5: LLM classification
        classified = self._classifier.classify_all(candidates, understanding, taxonomy)
        logger.info("Classified %d passages", len(classified))

        # Step 5.5: Denial re-validation
        denial_codes = {cat["code"] for cat in taxonomy if cat.get("is_denial", False)}
        denial_count = sum(1 for c in classified if c.get("category") in denial_codes)
        if denial_count >= min_denials_for_revalidation:
            classified, _, _ = self._revalidator.revalidate_denials(
                classified, taxonomy, understanding["target_concept"]
            )
        else:
            logger.info(
                "Re-validation skipped: %d denials < threshold %d",
                denial_count, min_denials_for_revalidation,
            )

        # Step 5.75: Post-classification recall sweep
        classified = self._post_classification_recall_sweep(
            classified, all_providers, plan, understanding, taxonomy
        )

        # Step 6: Provider rollup
        provider_data, no_mention = self._classifier.provider_rollup(
            classified, taxonomy, all_providers, understanding["target_concept"]
        )

        # Step 6.25: Settlement audit
        provider_data, no_mention, _ = self._revalidator.settlement_audit(
            provider_data, no_mention
        )

        # Step 6.3: Latest doc currency gate
        provider_data, no_mention, _ = self._revalidator.latest_doc_gate(
            provider_data, no_mention
        )

        # Step 6.5: False-negative safety net
        no_mention, classified, provider_data, rescued = self._rescuer.rescue(
            no_mention, classified, provider_data,
            understanding, taxonomy, understanding["target_concept"],
        )

        # Step 7.5: Citation verification
        classified = self._classifier.verify_key_phrases(classified)
        classified = self._classifier.verify_numbers(classified)

        # Rollup stats
        has_n = sum(1 for d in provider_data.values() if d["status"].startswith("HAS_"))
        denied_n = sum(1 for d in provider_data.values() if d["status"].endswith("_DENIED"))
        mixed_n = sum(1 for d in provider_data.values() if d["status"] == "MIXED")
        relevant = [c for c in classified if c.get("category") not in ("NOT_RELEVANT", "UNKNOWN", "")]

        validation_stats = {
            "total_classified": len(classified),
            "relevant_classified": len(relevant),
            "kp_verified": sum(1 for c in relevant if c.get("kp_verified")),
            "num_errors": sum(1 for c in relevant if not c.get("num_verified", True)),
            "rescued_by_safety_net": rescued,
        }

        result = ClauseExistenceResult(
            concept=understanding["target_concept"],
            provider_data=provider_data,
            no_mention=no_mention,
            classified=classified,
            taxonomy=taxonomy,
            plan=plan,
            understanding=understanding,
            has_count=has_n,
            denied_count=denied_n,
            mixed_count=mixed_n,
            no_mention_count=len(no_mention),
            total_universe=total_universe,
            deduped_count=deduped_count,
            elapsed_s=time.time() - t0,
            validation_stats=validation_stats,
        )

        confidence = Confidence.HIGH if (has_n + denied_n + mixed_n) > 0 else Confidence.LOW
        status = ToolStatus.SUCCESS if (has_n + denied_n + mixed_n) > 0 else ToolStatus.EMPTY

        # Use natural language in summary (avoid leaking raw classification labels into answers)
        concept_title = understanding['target_concept'].title()
        if total_universe == 1:
            # Single-provider query — give a direct answer
            if has_n > 0:
                summary = f"{concept_title}: YES — clause language found for this provider."
            elif denied_n > 0:
                summary = f"{concept_title}: DENIED — clause is explicitly excluded for this provider."
            elif mixed_n > 0:
                summary = f"{concept_title}: MIXED — both granting and restricting language found."
            else:
                summary = f"{concept_title}: No relevant clause language found for this provider."
        else:
            # Multi-provider / network query — use counts with natural labels
            summary = (
                f"{concept_title}: "
                f"{has_n} providers have this clause, "
                f"{denied_n} explicitly exclude it, "
                f"{mixed_n} have mixed language, "
                f"{len(no_mention)} have no relevant language "
                f"({total_universe} providers, {deduped_count:,} docs, {result.elapsed_s:.0f}s)"
            )

        return ToolResult(
            success=True,
            data=vars(result),
            summary=summary,
            confidence=confidence,
            status=status,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_understanding(
        self,
        question: str,
        target_concept: Optional[str],
        provider_filter: Optional[str],
        routing: Optional[Dict],
    ) -> Dict:
        """Build understanding dict. Concept resolution order: param -> routing -> regex -> fallback."""
        concept = (
            target_concept
            or (routing or {}).get("target_concept")
            or ((routing or {}).get("concepts") or [None])[0]
            or self._extract_concept(question)
            or "contract provision"
        )
        search_keywords = (routing or {}).get("search_keywords", [])
        semantic_query = (routing or {}).get("semantic_query", question)
        is_negative = any(
            neg in question.lower()
            for neg in ("no ", "not ", "without ", "lack ", "missing ")
        )
        # Resolve provider_filter: explicit param > routing > auto-extract from question
        resolved_pf = provider_filter
        if not resolved_pf and routing and (routing or {}).get("providers"):
            resolved_pf = (routing or {}).get("providers", [None])[0]
        if not resolved_pf:
            resolved_pf = self._auto_extract_provider(question)
        return {
            "target_concept": concept,
            "search_keywords": search_keywords,
            "semantic_query": semantic_query,
            "analysis_type": "existence",
            "is_negative": is_negative,
            "provider_filter": resolved_pf,
        }

    def _auto_extract_provider(self, question: str) -> Optional[str]:
        """Auto-extract a single provider name from the question using ProviderService.
        
        Enables single-provider clause queries to get the DENIED/HAS status
        directly instead of network-wide counts.
        """
        try:
            # Use provider service to resolve any provider mentioned in question
            if not hasattr(self, '_provider_service') or self._provider_service is None:
                return None
            # Try resolve on common patterns: "for X", "X's", "of X"
            import re
            patterns = [
                r"(?:for|of|at)\s+(.+?)(?:\s*\?|$|\s+(?:contract|agreement|hospital|medical))",
                r"(.+?)(?:'s|\s+hospital|\s+medical center)",
            ]
            for pat in patterns:
                m = re.search(pat, question, re.IGNORECASE)
                if m:
                    candidate = m.group(1).strip()
                    if len(candidate) > 3:
                        names, method, ids = self._provider_service.resolve(candidate)
                        if ids:
                            return names[0] if names else candidate
            return None
        except Exception:
            return None

    def _extract_concept(self, question: str) -> Optional[str]:
        """Regex rescue of target concept from question text."""
        q_lower = question.lower()
        for pattern, concept in _CE_CONCEPT_PATTERNS:
            if re.search(pattern, q_lower):
                return concept
        return None

    @staticmethod
    def _apply_provider_filter(
        full_universe: List[str],
        provider_filter: Optional[str],
    ) -> List[str]:
        """
        GAP-006: Apply provider_filter to narrow the analysis universe.

        When a report is run for a subset of providers (e.g., via the Report
        page or a single-provider query), total_universe must reflect only the
        filtered set. Previously, total_universe was always 326 (full corpus),
        making percentages wrong for filtered reports.

        Supports:
          - None / empty string → return full universe (no filtering)
          - Single provider name → filter to that provider (case-insensitive)
          - Comma-separated list → filter to matching providers
          - List passed as string with brackets → parsed and filtered

        Parameters
        ----------
        full_universe : Complete provider list from corpus_universe().
        provider_filter : Filter string from request/routing.

        Returns
        -------
        Filtered provider list (subset of full_universe), or full_universe if
        no filter is active.
        """
        if not provider_filter or not provider_filter.strip():
            return full_universe

        # Parse filter: could be "Provider A" or "Provider A, Provider B"
        # or even "['Provider A', 'Provider B']" (JSON-like from frontend)
        pf = provider_filter.strip()
        if pf.startswith("[") and pf.endswith("]"):
            # JSON-style list: strip brackets and split
            pf = pf[1:-1]

        # Split by comma, strip quotes and whitespace
        filter_names = [
            name.strip().strip("'").strip('"').strip()
            for name in pf.split(",")
            if name.strip()
        ]

        if not filter_names:
            return full_universe

        # Case-insensitive matching against the full universe
        filter_lower = {n.lower() for n in filter_names}
        matched = [p for p in full_universe if p.lower() in filter_lower]

        # If filter didn't match anything (typo?), fall back to full universe
        # to avoid zero-division. Log a warning.
        if not matched:
            logger.warning(
                "GAP-006: provider_filter %r matched 0 of %d providers; "
                "falling back to full universe",
                provider_filter, len(full_universe),
            )
            return full_universe

        return matched

    def _post_classification_recall_sweep(
        self,
        classified: List[Dict],
        all_providers: List[str],
        plan: Dict,
        understanding: Dict,
        taxonomy: List[Dict],
    ) -> List[Dict]:
        """
        Step 5.75: Classify passages for providers that got zero findings.

        Uses core keywords with OR logic. Scans in batches of 200 providers.
        Adds classified results to the classified list.
        """
        found_providers = {
            c.get("provider", "").strip().lower()
            for c in classified
            if c.get("category") not in ("NOT_RELEVANT", "UNKNOWN", "")
        }
        unchecked = [p for p in all_providers if p.strip().lower() not in found_providers]
        if not unchecked:
            return classified

        sweep_kws = [k.lower().replace("'", "''") for k in plan.get("core_keywords", [])]
        if not sweep_kws:
            return classified

        sweep_like = " OR ".join(f"LOWER(chunk_text) LIKE '%{kw}%'" for kw in sweep_kws)
        fulltext_table = self._retriever._fulltext_table
        rescue_candidates: List[Dict] = []

        for start in range(0, len(unchecked), 200):
            batch = unchecked[start:start + 200]
            prov_sql = ", ".join(f"'{p.replace(chr(39), chr(39)+chr(39))}'" for p in batch)
            try:
                df = self._spark.sql(f"""
                    WITH ranked AS (
                        SELECT provider_name, source_filename,
                               SUBSTRING(chunk_text, 1, 1200) AS chunk_text,
                               LENGTH(chunk_text) AS text_length,
                               ROW_NUMBER() OVER (
                                   PARTITION BY provider_name
                                   ORDER BY LENGTH(chunk_text) DESC
                               ) AS rn
                        FROM {fulltext_table}
                        WHERE ({sweep_like})
                          AND LENGTH(chunk_text) >= 50
                          AND provider_name IN ({prov_sql})
                    )
                    SELECT provider_name, source_filename, chunk_text
                    FROM ranked WHERE rn <= 2
                """).toPandas()
                for _, row in df.iterrows():
                    rescue_candidates.append({
                        "text": str(row["chunk_text"])[:1200],
                        "provider": str(row["provider_name"]),
                        "filename": str(row.get("source_filename", "")),
                        "page": 0,
                        "score": 2,
                        "source": "recall_sweep_575",
                    })
            except Exception as exc:
                logger.warning("Recall sweep batch failed: %s", exc)

        if rescue_candidates:
            logger.info(
                "Recall sweep: %d candidates from %d providers",
                len(rescue_candidates),
                len(set(r["provider"] for r in rescue_candidates)),
            )
            rescue_classified = self._classifier.classify_all(
                rescue_candidates, understanding, taxonomy
            )
            rescued = [
                c for c in rescue_classified
                if c.get("category") not in ("NOT_RELEVANT", "UNKNOWN", "")
            ]
            classified.extend(rescued)
            logger.info("Recall sweep rescued %d findings", len(rescued))

        return classified

    @staticmethod
    def _make_vs_fn(retrieval_service: Optional[Any]):
        """Create a VS search callable from a RetrievalService (or return None)."""
        if retrieval_service is None:
            return None
        def _vs_fn(query: str, top_k: int = 100):
            return retrieval_service.retrieve(
                query=query, provider_name=None, top_k=top_k, current_only=False
            )
        return _vs_fn

"""
P4E — ExplanationTool
=====================
Native V3 replacement for V2 Branch E (branch_explanation).
Retrieves relevant passages (VS semantic + SQL keyword on vw_genie_contract_terms),
then synthesises a narrative explanation with citations using an LLM.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..contracts.tool_types import Confidence, ToolResult, ToolStatus
from ..config.settings import CATALOG, SCHEMA, LLM_REASONING
from ..services.sql_helpers import build_provider_id_filter, escape_sql, safe_limit
from .base import BaseTool

_VW_CONTRACT_TERMS = f"{CATALOG}.{SCHEMA}.vw_genie_contract_terms"


# ─── Dataclass ───────────────────────────────────────────────────────────────

@dataclass
class ExplanationResult:
    """Structured result from an explanation query."""
    concept: str
    provider_filter: Optional[str]
    narrative: str
    evidence_passages: List[Dict[str, Any]] = field(default_factory=list)
    evidence_count: int = 0
    confidence_level: str = "low"


# ─── Tool ────────────────────────────────────────────────────────────────────

class ExplanationTool(BaseTool):
    """Generate a narrative explanation of a contract concept with cited evidence.

    Retrieves passages via VS semantic search (when retrieval_service is wired)
    and SQL keyword search on vw_genie_contract_terms, then synthesises a
    structured 5-section narrative using an LLM.
    """

    name = "explanation"
    description = (
        "Explain or describe a contract concept or provision in narrative form. "
        "Use for 'explain', 'describe', 'summarize', or 'how does X work' questions."
    )
    is_adapter_backed = False

    def __init__(
        self,
        spark: Any,
        provider_service: Any,
        retrieval_service: Any = None,
        llm_client: Any = None,
    ) -> None:
        self._spark = spark
        self._provider_service = provider_service
        self._retrieval_service = retrieval_service
        self._llm_client = llm_client

    # ── Validation ───────────────────────────────────────────────────────

    def validate_inputs(self, **kwargs) -> list:
        return self._require(kwargs, "question")

    # ── Main execution ───────────────────────────────────────────────────

    def _run(
        self,
        question: str,
        concept: Optional[str] = None,
        provider_name: Optional[str] = None,
        max_passages: int = 25,
        limit: int = 30,
    ) -> ToolResult:
        target_concept = concept or self._extract_concept(question) or "contract provision"

        # Resolve optional provider
        canonical_name: Optional[str] = None
        prov_filter_sql: Optional[str] = None
        raw_prov = provider_name or self._extract_provider(question)
        if raw_prov:
            resolved, method, pids = self._provider_service.resolve(raw_prov)
            if method != "unresolved" and resolved:
                canonical_name = resolved[0]
                prov_filter_sql = build_provider_id_filter(pids)
            else:
                canonical_name = raw_prov

        lim = safe_limit(limit)
        semantic = self._fetch_semantic(target_concept, canonical_name, lim)
        structured = self._fetch_structured(target_concept, prov_filter_sql, canonical_name, lim)
        passages = self._merge(semantic, structured, max_passages)

        if not passages:
            return ToolResult(
                success=True,
                data={
                    "concept": target_concept,
                    "provider_filter": canonical_name,
                    "narrative": "",
                    "evidence_passages": [],
                    "evidence_count": 0,
                    "confidence_level": "low",
                },
                summary=f"No evidence found for '{target_concept}'",
                confidence=Confidence.LOW,
                status=ToolStatus.EMPTY,
                citations=[],
            )

        narrative = self._synthesize(target_concept, canonical_name, passages)
        n = len(passages)
        conf_level = "high" if n >= 10 else ("moderate" if n >= 5 else "low")
        confidence = Confidence.HIGH if conf_level == "high" else Confidence.LOW
        scope = f"{canonical_name}'s contracts" if canonical_name else "portfolio"

        return ToolResult(
            success=True,
            data={
                "concept": target_concept,
                "provider_filter": canonical_name,
                "narrative": narrative,
                "evidence_passages": passages[:15],
                "evidence_count": n,
                "confidence_level": conf_level,
            },
            summary=(
                f"Explanation of '{target_concept}' from {scope}: "
                f"{n} passages, {conf_level} confidence"
            ),
            confidence=confidence,
            status=ToolStatus.SUCCESS,
            citations=[],
        )

    # ── Section fetchers ─────────────────────────────────────────────────

    def _fetch_semantic(
        self,
        concept: str,
        provider_name: Optional[str],
        limit: int,
    ) -> List[Dict[str, Any]]:
        if not self._retrieval_service:
            return []
        try:
            passages = self._retrieval_service.retrieve(
                query=concept + " in healthcare provider contract",
                provider_name=provider_name,
                top_k=limit,
                current_only=True,
            )
            results = []
            for p in passages:
                text = (
                    p.get("chunk_text", p.get("text", ""))
                    if isinstance(p, dict)
                    else getattr(p, "chunk_text", "") or ""
                )
                if len(str(text)) >= 30:
                    results.append({
                        "text": str(text)[:800],
                        "provider": (
                            p.get("provider_name", "Unknown")
                            if isinstance(p, dict)
                            else getattr(p, "provider_name", "Unknown")
                        ),
                        "source": (
                            p.get("source_filename", "")
                            if isinstance(p, dict)
                            else getattr(p, "source_filename", "")
                        ),
                        "origin": "semantic",
                        "topic": "",
                        "title": "",
                    })
            return results
        except Exception:
            return []

    def _fetch_structured(
        self,
        concept: str,
        prov_filter: Optional[str],
        canonical_name: Optional[str],
        limit: int,
    ) -> List[Dict[str, Any]]:
        try:
            safe_concept = escape_sql(concept.lower())
            if prov_filter:
                where = (
                    f"WHERE {prov_filter} "
                    f"AND LOWER(content_text) LIKE '%{safe_concept}%' "
                    "AND is_from_latest_doc = true AND LENGTH(content_text) >= 30"
                )
            elif canonical_name:
                safe_name = escape_sql(canonical_name.lower())
                where = (
                    f"WHERE LOWER(provider_name) LIKE '%{safe_name}%' "
                    f"AND LOWER(content_text) LIKE '%{safe_concept}%' "
                    "AND is_from_latest_doc = true AND LENGTH(content_text) >= 30"
                )
            else:
                where = (
                    f"WHERE LOWER(content_text) LIKE '%{safe_concept}%' "
                    "AND is_from_latest_doc = true AND LENGTH(content_text) >= 30"
                )
            pdf = self._spark.sql(
                f"SELECT provider_name, title, topic, content_text, source_filename"
                f" FROM {_VW_CONTRACT_TERMS} {where}"
                f" ORDER BY LENGTH(content_text) DESC LIMIT {limit}"
            ).toPandas()
            results = []
            for _, row in pdf.iterrows():
                text = str(row.get("content_text", ""))
                if len(text) >= 30:
                    results.append({
                        "text": text[:800],
                        "provider": str(row.get("provider_name", "Unknown")),
                        "source": str(row.get("source_filename", "")),
                        "origin": "structured",
                        "topic": str(row.get("topic", "")),
                        "title": str(row.get("title", "")),
                    })
            return results
        except Exception:
            return []

    def _merge(
        self,
        semantic: List[Dict],
        structured: List[Dict],
        max_passages: int,
    ) -> List[Dict]:
        seen: set = set()
        merged: List[Dict] = []
        for p in semantic + structured:
            src = p.get("source", "")
            if src not in seen:
                seen.add(src)
                merged.append(p)
            if len(merged) >= max_passages:
                break
        return merged

    def _synthesize(
        self,
        concept: str,
        provider_name: Optional[str],
        passages: List[Dict],
    ) -> str:
        if not self._llm_client:
            return ""
        scope = (
            f"the contracts of {provider_name}" if provider_name
            else "healthcare provider contracts"
        )
        ctx_lines = []
        for i, p in enumerate(passages[:15], 1):
            src = p.get("source", "")
            src_short = src.split("/")[-1] if "/" in src else src
            prov = p.get("provider", "Unknown")
            prov_tag = f" (Provider: {prov})" if prov != "Unknown" else ""
            ctx_lines.append(f"[Source {i}: {src_short}{prov_tag}]")
            ctx_lines.append(p["text"][:500])
        ctx = "\n".join(ctx_lines)
        prompt = (
            f"Based on the following contract passages, provide a comprehensive "
            f"explanation of \"{concept}\" as it appears in {scope}.\n\n"
            f"EVIDENCE:\n{ctx}\n\n"
            "Provide a well-structured explanation covering:\n"
            "1. **Definition & Purpose**: What is this provision and why does it exist?\n"
            "2. **Key Terms & Conditions**: Specific conditions, thresholds, timeframes.\n"
            "3. **Variations Observed**: How does this provision vary across providers?\n"
            "4. **Implications for the Plan**: Operational meaning for Blue Shield.\n"
            "5. **Notable Exceptions**: Unusual or restrictive language.\n\n"
            "Rules: cite sources using [Source N]; use exact quotes; "
            "be specific about amounts, timeframes, and conditions. "
            "Provide 4-6 paragraphs."
        )
        try:
            return self._llm_client.chat(
                model=LLM_REASONING,
                system=(
                    "You are a healthcare contract analyst. "
                    "Explain contract provisions based on evidence."
                ),
                user=prompt,
                max_tokens=2500,
            )
        except Exception:
            return ""

    # ── Helpers ──────────────────────────────────────────────────────────

    def _extract_provider(self, question: str) -> Optional[str]:
        q_lower = question.lower()
        for name in sorted(self._provider_service.all_names(), key=len, reverse=True):
            if name.lower() in q_lower:
                return name
        return None

    def _extract_concept(self, question: str) -> Optional[str]:
        patterns = [
            r"explain(?:ing)?\s+(?:the\s+)?(?:concept\s+of\s+)?[\"']?(.+?)[\"']?"
            r"(?:\s+(?:provision|clause|term|process|policy))?(?:\s+in|\?|$)",
            r"describe\s+(?:the\s+)?[\"']?(.+?)[\"']?"
            r"(?:\s+(?:provision|clause|term))?(?:\s+in|\?|$)",
            r"summarize\s+(?:the\s+)?[\"']?(.+?)[\"']?"
            r"(?:\s+(?:provision|clause|term))?(?:\s+in|\?|$)",
            r"how\s+does\s+[\"']?(.+?)[\"']?\s+work",
            r"what\s+is\s+(?:a\s+|the\s+)?[\"']?(.+?)[\"']?\s+(?:provision|clause|term|policy)",
        ]
        q_lower = question.lower()
        for pat in patterns:
            m = re.search(pat, q_lower)
            if m:
                candidate = m.group(1).strip().rstrip("?.,")
                if len(candidate) >= 3:
                    return candidate
        return None

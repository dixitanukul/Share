"""
platform/v4/tools/citation_verify.py

Citation verification tool — verifies retrieved passages for grounding,
supersession, numerical consistency, and temporal validity.

Dual-path architecture:
  1. Native path (preferred): Uses CitationVerifier from
     platform/v4/services/verification/citation_verifier.py — no V2 dependency.
  2. Legacy path (backward-compat): Falls through to CitationAdapter which
     wraps platform/07_citation_verification.py functions.

After passage_search retrieves passages, the agent calls this tool to
verify them.  The verified citations inform the final confidence level
of the AgentResponse.
"""
from __future__ import annotations

from typing import Any, Optional

from ..adapters.citation_adapter import CitationAdapter
from ..contracts.citation_types import (
    VerificationResult as LegacyVerificationResult,
    VerificationStatus,
)
from ..contracts.tool_types import Confidence, ToolResult
from ..services.verification.citation_verifier import (
    CheckStatus,
    CitationVerifier,
    VerificationResult as NativeVerificationResult,
)
from ..tools.base import BaseTool


class CitationVerifyTool(BaseTool):
    """
    Verifies retrieved passages using native or legacy verification.

    Priority:
      1. If a CitationVerifier is provided (native), use it directly.
      2. Otherwise, fall back to CitationAdapter (legacy V2 wrapper).

    Parameters
    ----------
    verifier : CitationVerifier, optional
        Native verifier (preferred). No V2 dependency.
    adapter : CitationAdapter, optional
        Legacy adapter wrapping V2 07_citation_verification functions.
    """

    def __init__(
        self,
        verifier: Optional[CitationVerifier] = None,
        adapter: Optional[CitationAdapter] = None,
    ) -> None:
        self._verifier = verifier
        self._adapter = adapter or CitationAdapter()

    def set_verifier(self, verifier: CitationVerifier) -> None:
        """Inject native verifier (preferred path)."""
        self._verifier = verifier

    def set_adapter(self, adapter: CitationAdapter) -> None:
        """Inject legacy adapter (backward-compat)."""
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "citation_verify"

    @property
    def uses_native(self) -> bool:
        """True if this tool uses the native verifier (no V2 dependency)."""
        return self._verifier is not None

    def _run(
        self,
        passages: Optional[list] = None,
        claim_text: str = "",
        **kwargs: Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        passages : list of passage dicts/objects from passage_search.
                   Each should contain: passage_text (or text), source_filename,
                   is_current_effective, doc_role, effective_date.
        claim_text : str
            The claim being verified against the passages.
        """
        if not passages:
            return ToolResult(
                success=True,
                data=None,
                summary="No passages provided for citation verification",
                confidence=Confidence.LOW,
                metadata={"skipped": True},
            )

        # Normalise: passages may be RetrievedPassage objects or plain dicts
        passage_dicts: list[dict] = []
        for p in passages:
            if isinstance(p, dict):
                passage_dicts.append(p)
            elif hasattr(p, "as_citation"):
                d = p.as_citation()
                d["text"] = getattr(p, "text", "")
                passage_dicts.append(d)
            else:
                passage_dicts.append({"doc_id": str(p), "text": str(p)})

        # ── Native path (preferred) ──────────────────────────────────────
        if self._verifier is not None:
            return self._run_native(passage_dicts, claim_text)

        # ── Legacy path (backward-compat) ────────────────────────────────
        return self._run_legacy(passage_dicts, claim_text, **kwargs)

    # ------------------------------------------------------------------
    # Native verification path
    # ------------------------------------------------------------------

    def _run_native(self, passages: list[dict], claim_text: str) -> ToolResult:
        """Run native CitationVerifier and convert to ToolResult."""
        # Normalise passage keys for native verifier
        normalised = []
        for p in passages:
            normalised.append({
                "passage_text": p.get("passage_text") or p.get("text") or p.get("unit_text", ""),
                "source_filename": p.get("source_filename") or p.get("doc_id", ""),
                "is_current_effective": p.get("is_current_effective", True),
                "doc_role": p.get("doc_role", ""),
                "effective_date": p.get("effective_date", ""),
            })

        native_result = self._verifier.verify(claim=claim_text, citations=normalised)

        # Convert NativeVerificationResult → ToolResult with metadata
        # Determine overall status
        status = self._map_native_status(native_result)
        risk_flags = []
        supersession_risk = False
        numerical_passed = None
        temporal_passed = None

        for verdict in native_result.verdicts:
            for check in verdict.checks:
                if check.check_name == "supersession" and check.status in (CheckStatus.WARN, CheckStatus.FAIL):
                    supersession_risk = True
                    risk_flags.append(f"supersession:{verdict.source_filename}")
                if check.check_name == "numerical":
                    if check.status == CheckStatus.PASS:
                        numerical_passed = True
                    elif check.status in (CheckStatus.WARN, CheckStatus.FAIL):
                        numerical_passed = False
                if check.check_name == "temporal":
                    if check.status == CheckStatus.PASS:
                        temporal_passed = True
                    elif check.status in (CheckStatus.WARN, CheckStatus.FAIL):
                        temporal_passed = False

        # Build legacy-compatible VerificationResult for downstream consumers
        legacy_result = LegacyVerificationResult(
            claim_text=claim_text[:500],
            status=status,
            supporting_citations=[],
            risk_flags=risk_flags,
            numerical_check_passed=numerical_passed,
            temporal_check_passed=temporal_passed,
            supersession_risk=supersession_risk,
            notes=f"Native verification: {native_result.n_passed}/{native_result.n_citations} passed",
        )

        # Confidence scoring
        confidence = self._compute_confidence(native_result)

        return ToolResult(
            success=True,
            data=legacy_result,
            summary=f"Verified {native_result.n_citations} citations: "
                    f"{native_result.n_passed} passed, {native_result.n_failed} failed",
            confidence=confidence,
            metadata={
                "native": True,
                "n_citations": native_result.n_citations,
                "n_passed": native_result.n_passed,
                "n_failed": native_result.n_failed,
                "pass_rate": native_result.pass_rate,
                "overall_confidence": native_result.overall_confidence,
            },
        )

    def _map_native_status(self, result: NativeVerificationResult) -> VerificationStatus:
        """Map native verification result to legacy VerificationStatus."""
        if not result.verdicts:
            return VerificationStatus.PENDING

        if result.all_passed:
            return VerificationStatus.VERIFIED

        # Check for specific failure types
        has_grounding_fail = False
        has_supersession_issue = False
        for verdict in result.verdicts:
            for check in verdict.checks:
                if check.check_name == "grounding" and check.status == CheckStatus.FAIL:
                    has_grounding_fail = True
                if check.check_name == "supersession" and check.status in (CheckStatus.WARN, CheckStatus.FAIL):
                    has_supersession_issue = True

        if has_grounding_fail:
            return VerificationStatus.HALLUCINATED
        if has_supersession_issue:
            return VerificationStatus.SUPERSEDED
        # Warnings but no hard failures
        return VerificationStatus.VERIFIED

    def _compute_confidence(self, result: NativeVerificationResult) -> Confidence:
        """Map native pass rate to confidence level."""
        if not result.verdicts:
            return Confidence.LOW
        rate = result.pass_rate
        if rate >= 0.8:
            return Confidence.HIGH
        elif rate >= 0.4:
            return Confidence.MODERATE
        return Confidence.LOW

    # ------------------------------------------------------------------
    # Legacy verification path (backward-compat)
    # ------------------------------------------------------------------

    def _run_legacy(self, passages: list[dict], claim_text: str, **kwargs: Any) -> ToolResult:
        """Delegate to CitationAdapter (legacy V2 wrapper)."""
        result = self._adapter.verify(passages, claim_text=claim_text, **kwargs)

        # Confidence scoring based on verification outcome
        if result.success and isinstance(result.data, list):
            verified = [r for r in result.data if r.get("verified", False)]
            total = len(result.data)
            if total > 0:
                ratio = len(verified) / total
                if ratio >= 0.8:
                    result.confidence = Confidence.HIGH
                elif ratio >= 0.4:
                    result.confidence = Confidence.MODERATE
                else:
                    result.confidence = Confidence.LOW
        elif result.success:
            result.confidence = Confidence.MODERATE
        return result

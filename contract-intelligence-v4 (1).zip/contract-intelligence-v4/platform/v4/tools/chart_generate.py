"""
platform/v4/tools/chart_generate.py

Chart / visualisation generation tool.

Converts structured data rows (from sql_query or calculate) into
chart-specification dicts that can be rendered in Databricks notebooks
via displayHTML() or passed to a dashboard.

No LLM or Spark required — operates on in-memory data only.
"""
from __future__ import annotations

from typing import Any, Optional

from ..contracts.tool_types import Confidence, ToolResult
from ..tools.base import BaseTool

# Supported chart types
_CHART_TYPES = {"bar", "line", "scatter", "pie", "histogram", "table"}


class ChartGenerateTool(BaseTool):
    """
    Generate chart specifications from structured data.

    Returns a ToolResult where .data is a chart spec dict with:
        - chart_type : str
        - title      : str
        - x_column   : str
        - y_columns  : list[str]
        - rows       : list[dict]   (the raw data)
        - html       : str          (simple HTML table fallback)

    The spec is intentionally renderer-agnostic; notebook cells can
    pass it to matplotlib, plotly, or displayHTML as needed.
    """

    @property
    def name(self) -> str:
        return "chart_generate"

    def _run(
        self,
        rows:        Optional[list[dict]] = None,
        chart_type:  str                  = "bar",
        x_column:    str                  = "",
        y_columns:   Optional[list[str]]  = None,
        title:       str                  = "",
        sort_by:     Optional[str]        = None,
        descending:  bool                 = True,
        top_n:       Optional[int]        = None,
        **kwargs:    Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        rows       : Data rows (list of dicts) to visualise.
        chart_type : One of: bar, line, scatter, pie, histogram, table.
        x_column   : Column to use for the x-axis / labels.
        y_columns  : Columns to use for y-axis values.
        title      : Chart title.
        sort_by    : Sort rows by this column before charting.
        descending : Sort direction.
        top_n      : Keep only the top N rows after sorting.
        """
        if not rows:
            return ToolResult(
                success=False,
                data=None,
                summary="No data rows provided for chart generation",
                confidence=Confidence.LOW,
                error_message="rows is empty",
            )

        if chart_type not in _CHART_TYPES:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Unknown chart type: {chart_type}. Valid: {sorted(_CHART_TYPES)}",
                confidence=Confidence.LOW,
                error_message=f"chart_type='{chart_type}' not supported",
            )

        # Auto-detect x and y columns if not provided
        if not x_column and rows:
            x_column = list(rows[0].keys())[0]
        if not y_columns and rows:
            y_columns = [
                k for k in rows[0].keys()
                if k != x_column and self._is_numeric_column(rows, k)
            ][:3]

        # Sort and cap
        display_rows = list(rows)
        if sort_by and sort_by in (rows[0] if rows else {}):
            try:
                display_rows = sorted(
                    display_rows,
                    key=lambda r: r.get(sort_by) or 0,
                    reverse=descending,
                )
            except TypeError:
                pass
        if top_n:
            display_rows = display_rows[:top_n]

        spec = {
            "chart_type": chart_type,
            "title":      title or f"{chart_type.title()} Chart",
            "x_column":   x_column,
            "y_columns":  y_columns or [],
            "rows":       display_rows,
            "html":       self._to_html_table(display_rows, title),
            "row_count":  len(display_rows),
        }

        return ToolResult(
            success=True,
            data=spec,
            summary=f"{chart_type} chart: {len(display_rows)} rows, x={x_column}",
            confidence=Confidence.HIGH,
        )

    @staticmethod
    def _is_numeric_column(rows: list[dict], col: str) -> bool:
        """Return True if the column contains mostly numeric values."""
        sample = [r.get(col) for r in rows[:10] if r.get(col) is not None]
        try:
            [float(v) for v in sample]
            return True
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _to_html_table(rows: list[dict], title: str) -> str:
        """Generate a simple HTML table for displayHTML() fallback."""
        if not rows:
            return "<p>No data</p>"
        cols = list(rows[0].keys())
        header_cells = "".join(f"<th>{c}</th>" for c in cols)
        body_rows = ""
        for r in rows:
            cells = "".join(f"<td>{r.get(c, '')}</td>" for c in cols)
            body_rows += f"<tr>{cells}</tr>"
        t = title or "Data"
        return (
            f"<h4>{t}</h4>"
            f"<table border='1' style='border-collapse:collapse;font-size:12px'>"
            f"<thead><tr>{header_cells}</tr></thead>"
            f"<tbody>{body_rows}</tbody>"
            f"</table>"
        )

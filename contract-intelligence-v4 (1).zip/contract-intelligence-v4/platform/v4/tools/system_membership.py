"""SystemMembershipTool: Exposes dim_health_system + tbl_provider_system_membership."""
from __future__ import annotations
from typing import Any
from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus
from platform.v4.tools.base import BaseTool


class SystemMembershipTool(BaseTool):
    name = "system_membership"
    description = (
        "Query health system groupings, provider-to-system membership, and geographic service areas. "
        "Uses system_id (NOT health_system_id) as FK. "
        "query_type: systems_overview | system_members | provider_system | region_providers | reverse_lookup"
    )

    def __init__(self, spark):
        self.spark = spark
        self.tbl_systems = "dev_adb.raw.dim_health_system"
        self.tbl_membership = "dev_adb.raw.tbl_provider_system_membership"
        self.tbl_areas = "dev_adb.raw.tbl_service_areas"
        self.tbl_ids = "dev_adb.raw.tbl_provider_identifiers"

    _SYSTEM_NAMES = {
        'dignity health', 'adventist health', 'providence', 'st joseph',
        'sutter health', 'sharp healthcare', 'sharp health',
        'scripps health', 'scripps', 'uc health', 'uc san diego',
        'cedars-sinai', 'cedars sinai', 'kindred', 'select medical',
        'prime', 'prospect medical', 'cottage health', 'emanate health',
        'commonspirit', 'loma linda', 'palomar health', 'eisenhower health',
        'kaiser', 'ventura county', 'st. joseph', 'sjhc',
    }

    def _infer_params_from_question(self, question: str, provider: str, system_name: str) -> dict:
        """Infer query_type and key params from question text."""
        q = question.lower()
        params = {}

        # BUG-2-FIX: "Is X in our/the network?" → lookup that specific provider
        # instead of dumping all 20 systems. This covers yes/no membership questions.
        import re as _re
        _in_network_re = _re.compile(
            r'\bis\s+.+\s+(?:in|part of|a member of)\s+(?:our|the|bsc)\s*(?:network|contracted)',
            _re.IGNORECASE,
        )
        if _in_network_re.search(q):
            params['query_type'] = 'provider_system'
            return params

        # 9B-FIX: "which providers belong to X" / "who is in X system" / "members of X"
        if any(w in q for w in ('belong to', 'part of', 'member of', 'members of',
                                 'facilities in', 'providers in', 'who is in',
                                 'hospitals in', 'clinics in')):
            params['query_type'] = 'system_members'
            # Use provider_name as system_name when it looks like a health system
            sn = system_name or provider
            if sn:
                params['system_name'] = sn
            return params

        # 9C-FIX: "service area" / "geographic coverage" / "what region"
        if any(w in q for w in ('service area', 'geographic', 'service region',
                                 'coverage area', 'what region', 'which region',
                                 'what county', 'which county', 'geography')):
            params['query_type'] = 'provider_service_area'
            return params

        # "which system does X belong to" / "what system is X in"
        if any(w in q for w in ('what system', 'which system', 'system does',
                                 'system is ', 'belong to a system')):
            params['query_type'] = 'provider_system'
            return params

        return params  # empty → caller keeps default

    def _run(self, **kwargs: Any) -> ToolResult:
        query_type = kwargs.get("query_type", "systems_overview")
        system_name = kwargs.get("system_name", "")
        provider = kwargs.get("provider", "") or kwargs.get("provider_name", "")
        region = kwargs.get("region", "")
        identifier = kwargs.get("identifier", "")

        # 9BC-FIX: When no explicit query_type given and a question + provider/system are
        # present, infer the right query type from question text instead of defaulting to
        # systems_overview (which returns all 20 systems regardless of context).
        _question = kwargs.get("question", "")
        if query_type == "systems_overview" and _question and (provider or system_name):
            _inferred = self._infer_params_from_question(_question, provider, system_name)
            if _inferred.get("query_type"):
                query_type = _inferred["query_type"]
                system_name = _inferred.get("system_name", system_name)

        if query_type == "systems_overview":
            sql = f"""
                SELECT hs.system_id, hs.system_name, hs.system_type, hs.facility_count,
                       COUNT(psm.provider_id) as member_count
                FROM {self.tbl_systems} hs
                LEFT JOIN {self.tbl_membership} psm ON hs.system_id = psm.system_id
                GROUP BY hs.system_id, hs.system_name, hs.system_type, hs.facility_count
                ORDER BY member_count DESC
            """
            caveat = "63% of providers not yet mapped to a health system."

        elif query_type == "system_members":
            sql = f"""
                SELECT p.canonical_name AS provider_name, psm.membership_type, psm.effective_date
                FROM {self.tbl_membership} psm
                JOIN dev_adb.raw.dim_provider_canonical p ON psm.provider_id = p.provider_id
                JOIN {self.tbl_systems} hs ON psm.system_id = hs.system_id
                WHERE LOWER(hs.system_name) LIKE LOWER('%{system_name}%')
                ORDER BY p.provider_name
            """
            caveat = "Showing mapped providers only."

        elif query_type == "provider_system":
            sql = f"""
                SELECT hs.system_name, hs.system_type, psm.membership_type, psm.match_pattern
                FROM {self.tbl_membership} psm
                JOIN {self.tbl_systems} hs ON psm.system_id = hs.system_id
                JOIN dev_adb.raw.dim_provider_canonical p ON psm.provider_id = p.provider_id
                WHERE LOWER(p.canonical_name) LIKE LOWER('%{provider}%')
            """
            caveat = ""

        elif query_type == "region_providers":
            sql = f"""
                SELECT provider_name, county, assignment_method
                FROM {self.tbl_areas}
                WHERE LOWER(region) LIKE LOWER('%{region}%')
                ORDER BY provider_name
            """
            caveat = ""

        elif query_type == "provider_service_area":
            # 9C-FIX: Return service area data for a specific provider
            _prov_short = provider.split()[0] if provider else provider
            prov_filter = f"LOWER(provider_name) LIKE LOWER('%{_prov_short}%')" if _prov_short else "1=1"
            sql = f"""
                SELECT provider_name, region, county, assignment_method
                FROM {self.tbl_areas}
                WHERE {prov_filter}
                ORDER BY provider_name
            """
            caveat = f"Service area data for providers matching '{provider}'."

        elif query_type == "reverse_lookup":
            sql = f"""
                SELECT pi.provider_id, p.canonical_name AS provider_name, pi.identifier_type,
                       pi.identifier_value, pi.effective_date
                FROM {self.tbl_ids} pi
                JOIN dev_adb.raw.dim_provider_canonical p ON pi.provider_id = p.provider_id
                WHERE pi.identifier_value = '{identifier}'
                  AND (pi.end_date IS NULL OR pi.end_date >= CURRENT_DATE())
            """
            caveat = "Only NPI and TIN identifier types exist in live data."

        else:
            return ToolResult(success=False, data=None, summary=f"Unknown query_type: {query_type}",
                             confidence=Confidence.LOW, status=ToolStatus.ERROR)

        df = self.spark.sql(sql)
        rows = [row.asDict() for row in df.collect()]
        summary = f"[system_membership:{query_type}] {len(rows)} results"
        if caveat:
            summary += f" | {caveat}"
        return ToolResult(
            success=True, data=rows, summary=summary,
            confidence=Confidence.HIGH, status=ToolStatus.SUCCESS,
        )

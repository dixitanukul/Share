"""
P4B-SP-1: Provider Deep Dive Tool
==================================
Native V3 replacement for V2 Branch B (branch_single_provider).
Assembles a comprehensive single-provider view: profile, rates,
key contract terms, amendment timeline, and optional concept search.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..contracts.tool_types import Confidence, ToolResult, ToolStatus
from ..config.settings import (
    CATALOG, SCHEMA,
    TBL_GENIE_PROVIDER_PROFILE,
    TBL_GENIE_AMENDMENT_TIMELINE,
    TBL_CONTRACT_RATES_ALL,
)
from ..services.sql_helpers import (
    build_provider_id_filter,
    qualified_table,
    safe_limit,
)
from ..services.rate_query_templates import RateQueryTemplates
from .base import BaseTool


# ─── Dataclasses ─────────────────────────────────────────────────────────────

@dataclass
class ProviderProfile:
    """Structured provider profile from tbl_genie_provider_profile.

    Key fields:
        line_of_business: LOB classification (e.g. 'HMO/PPO/Medicare',
            'Commercial', 'PPO', 'Fee For Service').
        contract_term_years: Contract duration (e.g. '1', '2', '3', '5').
        auto_renewal: Whether contract auto-renews ('True'/'False'/terms).
        payment_type: Primary reimbursement model (Fee For Service,
            Capitation, Percent of Charges, etc.).
        is_active: Whether provider has current rates (True/False).
        offset_clause_status: Pre-computed clause status ('HAS'/'NO_MENTION').
        dofr_status: Pre-computed DOFR status ('HAS'/'NO_MENTION').
        ipa_delegation_status: Pre-computed IPA delegation ('HAS'/'NO_MENTION').
    """
    provider_name: str = ""
    agreement_type: str = ""
    contract_term_years: str = ""
    auto_renewal: str = ""
    line_of_business: str = ""
    payment_type: str = ""
    total_rates: int = 0
    current_rates: int = 0
    total_amendments: int = 0
    is_active: bool = True
    offset_clause_status: str = ""
    dofr_status: str = ""
    ipa_delegation_status: str = ""
    avg_inpatient_per_diem: Optional[float] = None
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DeepDiveResult:
    """Structured result from a single-provider deep dive."""
    provider_name: str
    resolution_method: str
    provider_ids: List[str]
    profile: Optional[ProviderProfile] = None
    rates: List[Dict[str, Any]] = field(default_factory=list)
    rate_stats: Dict[str, Any] = field(default_factory=dict)
    terms: List[Dict[str, Any]] = field(default_factory=list)
    terms_by_topic: Dict[str, int] = field(default_factory=dict)
    amendments: List[Dict[str, Any]] = field(default_factory=list)
    concept_results: List[Dict[str, Any]] = field(default_factory=list)
    target_concept: Optional[str] = None
    include_historical: bool = False


# ─── Constants ───────────────────────────────────────────────────────────────

DEFAULT_SECTIONS = ("profile", "rates", "terms", "amendments")
ALL_SECTIONS = ("profile", "rates", "terms", "amendments", "concept")

# BUG-2 fix: aligned with rate_query_templates.RATES_CURRENT_SQL
# Added is_valid_rate=true filter + QUALIFY dedup to match rate_query counts.
RATES_CURRENT_SQL = f"""(
    SELECT provider_name, rate_category, service_category, rate_text,
           rate_numeric, rate_type_detail, formula,
           effective_date_parsed, program_normalized
    FROM {TBL_CONTRACT_RATES_ALL}
    WHERE status = 'current'
      AND is_valid_rate = true
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY provider_name, rate_category, service_category,
                     rate_numeric, rate_text, effective_date_parsed,
                     program_normalized
        ORDER BY source_filename
    ) = 1
)"""


# ─── Tool ────────────────────────────────────────────────────────────────────

class ProviderDeepDiveTool(BaseTool):
    """Comprehensive single-provider contract intelligence.

    Assembles profile, rate schedule, key contract terms, amendment
    timeline, and optional concept-focused retrieval for one provider.
    """

    name = "provider_deep_dive"
    description = (
        "Comprehensive deep dive into a single provider's contract landscape: "
        "profile, rates, key terms, amendments, and optional concept search."
    )
    is_adapter_backed = False

    def __init__(
        self,
        spark,
        provider_service,
        retrieval_service=None,
        llm_client=None,
    ):
        self._spark = spark
        self._provider_service = provider_service
        self._retrieval_service = retrieval_service
        self._llm_client = llm_client

    # ── Validation ───────────────────────────────────────────────────────

    def validate_inputs(self, **kwargs) -> list:
        return self._require(kwargs, "question")

    # ── Main execution ───────────────────────────────────────────────────

    def _run(
        self,
        question: str,
        provider_name: Optional[str] = None,
        include_historical: bool = False,
        sections: Optional[List[str]] = None,
        concept: Optional[str] = None,
        limit: int = 200,
    ) -> ToolResult:
        # Resolve provider
        provider_name_raw = provider_name or self._extract_provider(question)
        if not provider_name_raw:
            return ToolResult.error(
                "No provider identified in question or parameters.",
                tool_name=self.name,
            )

        resolved, method, provider_ids = self._provider_service.resolve(provider_name_raw)
        if method == "unresolved" or not resolved:
            return ToolResult.error(
                f"Could not resolve provider: '{provider_name_raw}'",
                tool_name=self.name,
            )

        canonical_name = resolved[0]
        prov_filter = build_provider_id_filter(provider_ids)

        # Determine sections
        active_sections = set(sections) if sections else set(DEFAULT_SECTIONS)
        if concept:
            active_sections.add("concept")

        # Build result
        result = DeepDiveResult(
            provider_name=canonical_name,
            resolution_method=method,
            provider_ids=provider_ids,
            include_historical=include_historical,
            target_concept=concept,
        )

        # --- Fetch each section ---
        if "profile" in active_sections:
            result.profile = self._fetch_profile(prov_filter, canonical_name)

        if "rates" in active_sections:
            result.rates, result.rate_stats = self._fetch_rates(
                prov_filter, include_historical, safe_limit(limit)
            )

        if "terms" in active_sections:
            result.terms, result.terms_by_topic = self._fetch_terms(prov_filter)

        if "amendments" in active_sections:
            result.amendments = self._fetch_amendments(prov_filter)

        if "concept" in active_sections and concept:
            result.concept_results = self._fetch_concept(
                concept, canonical_name
            )

        # Assemble summary
        summary_parts = [f"Deep dive: {canonical_name}"]
        if result.profile:
            summary_parts.append(f"type={result.profile.agreement_type}")
            if result.profile.contract_term_years:
                summary_parts.append(f"term={result.profile.contract_term_years}yr")
            if result.profile.auto_renewal:
                summary_parts.append(f"auto_renewal={result.profile.auto_renewal}")
            if result.profile.line_of_business:
                summary_parts.append(f"lob={result.profile.line_of_business}")
            if result.profile.payment_type:
                summary_parts.append(f"payment={result.profile.payment_type[:60]}")
        summary_parts.append(f"{len(result.rates)} rates")
        summary_parts.append(f"{len(result.terms)} terms")
        # BUG-1-FIX: Use authoritative total_amendments from profile (per-facility count).
        # Previously used len(result.amendments) which counts ALL amendment rows across
        # ALL facilities in a system alias (e.g., Sharp → 6 facilities → 125 rows),
        # creating contradictory counts vs sql_query which correctly returns per-facility.
        _amend_total = (
            result.profile.total_amendments
            if result.profile and result.profile.total_amendments
            else len(result.amendments)
        )
        summary_parts.append(f"{_amend_total} amendments")
        if concept:
            summary_parts.append(f"{len(result.concept_results)} '{concept}' passages")

        return ToolResult(
            success=True,
            data={
                "provider_name": canonical_name,
                "resolution_method": method,
                "provider_ids": provider_ids,
                "profile": result.profile.__dict__ if result.profile else None,
                "rates": result.rates,
                "rate_stats": result.rate_stats,
                "terms": result.terms[:50],
                "terms_by_topic": result.terms_by_topic,
                "amendments": result.amendments,
                "total_amendments_count": _amend_total,  # BUG-1-FIX: authoritative count for LLM
                "concept_results": result.concept_results,
                "target_concept": concept,
                "include_historical": include_historical,
            },
            summary=" | ".join(summary_parts),
            confidence=Confidence.HIGH,
            status=ToolStatus.SUCCESS,
            citations=[],
        )

    # ── Section fetchers ─────────────────────────────────────────────────

    def _fetch_profile(
        self, prov_filter: str, canonical_name: str
    ) -> Optional[ProviderProfile]:
        """Fetch provider profile from tbl_genie_provider_profile."""
        try:
            pdf = self._spark.sql(f"""
                SELECT *
                FROM {qualified_table(TBL_GENIE_PROVIDER_PROFILE)}
                WHERE {prov_filter}
                LIMIT 1
            """).toPandas()

            if pdf.empty:
                return None

            row = pdf.iloc[0]
            return ProviderProfile(
                provider_name=canonical_name,
                agreement_type=str(row.get("agreement_type", "")),
                contract_term_years=str(row.get("contract_term_years", "") or ""),
                auto_renewal=str(row.get("auto_renewal", "") or ""),
                line_of_business=str(row.get("line_of_business", "") or ""),
                is_active=bool(row.get("is_active", True)),
                current_rates=int(row.get("current_rates", 0) or 0),
                offset_clause_status=str(row.get("offset_clause_status", "") or ""),
                dofr_status=str(row.get("dofr_status", "") or ""),
                ipa_delegation_status=str(row.get("ipa_delegation_status", "") or ""),
                payment_type=str(row.get("payment_type", "") or ""),
                total_rates=int(row.get("total_rates", 0) or 0),
                total_amendments=int(row.get("total_amendments", 0) or 0),
                avg_inpatient_per_diem=(
                    float(row["avg_inpatient_per_diem"])
                    if row.get("avg_inpatient_per_diem") is not None
                    else None
                ),
                raw=row.to_dict(),
            )
        except Exception:
            return None

    def _fetch_rates(
        self, prov_filter: str, include_historical: bool, limit: int
    ) -> tuple:
        """Fetch rate schedule with summary statistics."""
        try:
            if include_historical:
                source = qualified_table(TBL_CONTRACT_RATES_ALL)
            else:
                source = RATES_CURRENT_SQL

            pdf = self._spark.sql(f"""
                SELECT rate_category, service_category, rate_text,
                       rate_numeric, rate_type_detail, formula,
                       effective_date_parsed, program_normalized
                FROM {source}
                WHERE {prov_filter}
                ORDER BY rate_category, rate_numeric DESC
                LIMIT {limit}
            """).toPandas()

            rates = pdf.to_dict("records") if not pdf.empty else []

            # Compute stats
            stats = {}
            if not pdf.empty:
                numeric = pdf[pdf["rate_numeric"].notna() & (pdf["rate_numeric"] > 0)]
                stats = {
                    "total_entries": len(pdf),
                    "categories": int(pdf["rate_category"].nunique()),
                    "numeric_count": len(numeric),
                    # BUG-3 fix: added median_rate to match rate_query output
                    "median_rate": round(float(numeric["rate_numeric"].median()), 2) if not numeric.empty else 0,
                    "avg_rate": round(float(numeric["rate_numeric"].mean()), 2) if not numeric.empty else 0,
                    "max_rate": round(float(numeric["rate_numeric"].max()), 2) if not numeric.empty else 0,
                    "min_rate": round(float(numeric["rate_numeric"].min()), 2) if not numeric.empty else 0,
                }

            return rates, stats
        except Exception:
            return [], {}

    def _fetch_terms(self, prov_filter: str) -> tuple:
        """Fetch key contract terms from vw_genie_contract_terms."""
        try:
            pdf = self._spark.sql(f"""
                SELECT topic, title, content_text, content_type, source_filename
                FROM {CATALOG}.{SCHEMA}.vw_genie_contract_terms
                WHERE {prov_filter}
                  AND is_from_latest_doc = true
                  AND LENGTH(content_text) >= 20
                ORDER BY topic, title
                LIMIT 200
            """).toPandas()

            terms = pdf.to_dict("records") if not pdf.empty else []

            # Group by topic
            by_topic = {}
            if not pdf.empty:
                for topic, count in pdf.groupby("topic").size().items():
                    by_topic[str(topic)] = int(count)

            return terms, by_topic
        except Exception:
            return [], {}

    def _fetch_amendments(self, prov_filter: str) -> List[Dict[str, Any]]:
        """Fetch amendment timeline from tbl_genie_amendment_timeline."""
        try:
            pdf = self._spark.sql(f"""
                SELECT document_type, summary_of_changes,
                       amendment_order, source_filename
                FROM {qualified_table(TBL_GENIE_AMENDMENT_TIMELINE)}
                WHERE {prov_filter}
                ORDER BY amendment_order
                LIMIT 250
            """).toPandas()

            return pdf.to_dict("records") if not pdf.empty else []
        except Exception:
            return []

    def _fetch_concept(
        self, concept: str, provider_name: str
    ) -> List[Dict[str, Any]]:
        """Search for a specific concept in the provider's contracts."""
        if not self._retrieval_service:
            return []

        try:
            passages = self._retrieval_service.retrieve(
                query=concept,
                provider_name=provider_name,
                top_k=20,
                current_only=True,
            )
            # Normalize to list of dicts
            results = []
            for p in passages[:15]:
                if isinstance(p, dict):
                    results.append({
                        "text": p.get("chunk_text", p.get("text", ""))[:500],
                        "source": p.get("source_filename", ""),
                        "score": p.get("score", 0),
                    })
                elif hasattr(p, "chunk_text"):
                    results.append({
                        "text": (p.chunk_text or "")[:500],
                        "source": getattr(p, "source_filename", ""),
                        "score": getattr(p, "score", 0),
                    })
            return results
        except Exception:
            return []

    # ── Helpers ──────────────────────────────────────────────────────────

    def _extract_provider(self, question: str) -> Optional[str]:
        """Extract provider name from question using known names."""
        q_lower = question.lower()
        all_names = self._provider_service.all_names()
        # Longest match first
        for name in sorted(all_names, key=len, reverse=True):
            if name.lower() in q_lower:
                return name
        return None

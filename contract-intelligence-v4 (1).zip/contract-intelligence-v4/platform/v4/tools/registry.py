"""
ToolRegistry — central registration and dispatch for all V3 tools.

The AgentController calls registry.call(tool_name, **kwargs) and receives
a ToolResult. Policy checks (budget, feature flags, call counts) happen here,
not in the tools themselves or in the agent controller.

Usage:
    registry = ToolRegistry(feature_flags=settings.get_all_flags())
    registry.register(SqlQueryTool())
    registry.register(PassageSearchTool())
    result = registry.call("sql_query", cumulative_cost=0.1, session_budget=5.0,
                           nl_question="What are Kaiser's rates?")
"""
from __future__ import annotations

from typing import Any

from platform.v4.contracts.tool_types import ToolResult, ToolStatus, Confidence
from platform.v4.tools.base import BaseTool
from platform.v4.config.tool_policies import get_policy, ToolPolicy


class ToolRegistry:
    """
    Registers, validates, and dispatches tool calls.

    The registry is stateless between calls except for per-session call counters
    (reset via reset_counters()). One registry instance per agent session.
    """

    def __init__(self, feature_flags: dict | None = None, settings=None):
        if settings is not None and feature_flags is None:
            feature_flags = settings.get_all_flags() if hasattr(settings, "get_all_flags") else {}
        self._tools: dict[str, BaseTool] = {}
        self._feature_flags: dict = feature_flags or {}
        self._call_counts: dict[str, int] = {}  # tool_name → calls this session

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self, tool: BaseTool) -> None:
        """Register a tool. Raises ValueError if the name is already taken."""
        if not tool.name:
            raise ValueError(f"Tool {tool!r} has no name set.")
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' is already registered.")
        self._tools[tool.name] = tool
        self._call_counts[tool.name] = 0

    def register_many(self, *tools: BaseTool) -> None:
        """Register multiple tools at once."""
        for t in tools:
            self.register(t)

    # ── Dispatch ──────────────────────────────────────────────────────────────

    def call(
        self,
        tool_name: str,
        cumulative_cost: float = 0.0,
        session_budget: float = 5.0,
        **kwargs: Any,
    ) -> ToolResult:
        """
        Invoke a registered tool after applying policy checks.

        Checks (in order):
          1. Tool is registered
          2. Tool policy is enabled
          3. Required feature flag is active
          4. Remaining budget >= tool's max_cost_usd estimate
          5. Per-session call count has not been exceeded
          6. Tool's own input validation passes
          7. Execute the tool

        Returns a ToolResult in all cases; never raises.
        """
        tool = self._tools.get(tool_name)
        if tool is None:
            return ToolResult.error(f"Tool '{tool_name}' is not registered.", tool_name)

        policy: ToolPolicy = get_policy(tool_name)

        if not policy.enabled:
            return ToolResult.skipped(f"Tool '{tool_name}' is disabled by policy.")

        if policy.requires_flag:
            if not self._feature_flags.get(policy.requires_flag, False):
                return ToolResult.skipped(
                    f"Tool '{tool_name}' requires feature flag "
                    f"'{policy.requires_flag}' to be enabled."
                )

        remaining = session_budget - cumulative_cost
        if remaining < policy.max_cost_usd:
            # If the session budget was NEVER sufficient for this tool, hard-block.
            # Otherwise, allow — prior reasoning/tools consumed budget, but this
            # tool was always intended to be affordable within the session.
            if session_budget < policy.max_cost_usd:
                return ToolResult.skipped(
                    f"Insufficient budget for '{tool_name}': "
                    f"session budget ${session_budget:.2f} < tool cost ${policy.max_cost_usd:.3f}."
                )
            # else: allow with soft warning (sequencing issue, not true overspend)

        call_count = self._call_counts.get(tool_name, 0)
        if call_count >= policy.max_calls_per_session:
            return ToolResult.skipped(
                f"Tool '{tool_name}' has reached its per-session call limit "
                f"({policy.max_calls_per_session})."
            )

        # Execute
        result = tool(**kwargs)
        self._call_counts[tool_name] = call_count + 1
        return result

    # ── Introspection ─────────────────────────────────────────────────────────

    def list_tools(self) -> list[str]:
        """Return names of all registered tools."""
        return list(self._tools.keys())

    def get(self, name: str) -> BaseTool | None:
        return self._tools.get(name)

    def describe_tools(self) -> str:
        """Return a newline-separated tool catalogue for LLM prompts."""
        lines = []
        for name, tool in self._tools.items():
            flag = f" [requires: {get_policy(name).requires_flag}]" if get_policy(name).requires_flag else ""
            lines.append(f"  {name}: {tool.description}{flag}")
        return "\n".join(lines)

    def reset_counters(self) -> None:
        """Reset per-session call counters (use between sessions)."""
        self._call_counts = {k: 0 for k in self._call_counts}

    def __repr__(self) -> str:
        return f"<ToolRegistry tools={self.list_tools()}>"

"""Question Decomposer — W9-25.

Detects complex multi-hop questions and decomposes them into
parallel-executable sub-tasks with a dependency graph.

Design:
  - Fast heuristic check first (regex/keyword) to avoid LLM cost on simple Qs
  - LLM-based decomposition only for genuinely complex questions
  - Returns a DecompositionPlan with execution groups for parallel scheduling
  - Fully testable without LLM (heuristic path + mock LLM path)

Integration:
  - AgentController._maybe_decompose() calls decomposer before ReAct loop
  - If plan.is_simple → normal single ReAct loop
  - If complex → run sub-questions (respecting dependencies), then synthesize
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from platform.v4.contracts.decomposition_types import (
    ComplexityLevel,
    DecompositionPlan,
    SubQuestion,
    SubQuestionType,
)

logger = logging.getLogger(__name__)

# ── Complexity signals (heuristic) ────────────────────────────────────────────────

# Patterns that indicate multiple independent information needs
_CONJUNCTION_PATTERNS = [
    r'\band\b.*\b(?:also|as well|too|additionally)\b',
    r'\bboth\b.*\band\b',
    r'\bcompare\b.*\b(?:between|with|to|and)\b',
    r'\bversus\b|\bvs\.?\b',
]

# Patterns indicating conditional/multi-hop logic
_CONDITIONAL_PATTERNS = [
    r'\bfor\s+providers\s+(?:that|who|which)\b',
    r'\bamong\s+(?:those|providers)\s+(?:that|who|which)\b',
    r'\bif\s+.*\bthen\b',
    r'\b(?:given|assuming)\s+that\b',
]

# Patterns indicating calculation/derivation
_CALCULATION_PATTERNS = [
    r'\b(?:difference|ratio|percentage|percent|average|median)\b.*\b(?:between|across|of)\b',
    r'\bhow\s+much\s+(?:higher|lower|more|less)\b',
    r'\bcompared\s+to\s+(?:the|network|average)\b',
    r'\byear-over-year\b|\bYoY\b',
]

# Multi-provider detection (2+ explicit provider names in question)
_PROVIDER_SEPARATOR = re.compile(
    r'\b(?:and|vs\.?|versus|compared\s+to|between)\b',
    re.IGNORECASE,
)

# Complexity keywords that add signal
_COMPLEXITY_KEYWORDS = {
    'compare', 'comparison', 'contrast', 'difference',
    'ratio', 'percentage', 'calculate', 'compute',
    'also', 'additionally', 'furthermore',
    'given that', 'assuming', 'conditional',
    'highest', 'lowest', 'rank', 'top', 'bottom',
    'across all', 'network-wide', 'each provider',
}

# ── LLM decomposition prompt ──────────────────────────────────────────────────

_DECOMPOSE_SYSTEM = """\
You are a question decomposition engine for a contract intelligence system.
Given a complex question about provider contracts, break it into independent
sub-questions that can be answered individually and then synthesized.

Available tool capabilities:
- passage_search: Find contract text by keyword/concept
- sql_query: Run analytical SQL on structured tables (rates, amendments, providers)
- provider_lookup: Resolve provider names to canonical IDs
- calculate: Arithmetic on retrieved values
- document_fetch: Get specific document content by ID
- citation_verify: Verify claims against source documents

Output valid JSON:
{{
  "complexity": "MODERATE" or "COMPLEX",
  "reasoning": "<why this needs decomposition>",
  "sub_questions": [
    {{
      "id": 1,
      "question": "<specific, self-contained sub-question>",
      "type": "RETRIEVAL|SQL_QUERY|CALCULATION|COMPARISON|LOOKUP|SYNTHESIS",
      "depends_on": [],
      "suggested_tools": ["tool_name"],
      "provider_hint": "<provider name if specific, else null>"
    }}
  ],
  "synthesis_prompt": "<instruction for combining sub-results into final answer>"
}}

Rules:
- Each sub-question must be answerable independently (or only after its deps)
- depends_on lists IDs of sub-questions whose results are needed as input
- Maximize parallelism: minimize dependencies where possible
- Use 2-5 sub-questions (never more than 6)
- Always include a final SYNTHESIS sub-question that depends on all others
- The SYNTHESIS sub-question merges results into the final answer
"""

_DECOMPOSE_USER = """\
Question: {question}

Decompose this into sub-questions. Output only valid JSON.
"""


class QuestionDecomposer:
    """
    Detects complex questions and decomposes them into parallel sub-tasks.

    Usage:
        decomposer = QuestionDecomposer(llm_client=client)
        plan = decomposer.analyze("Compare rates for X and Y")
        if plan.is_simple:
            # Normal ReAct loop
        else:
            # Execute plan.execution_groups in order
    """

    # Threshold: if complexity_score >= this, use LLM decomposition
    COMPLEXITY_THRESHOLD = 3

    def __init__(self, llm_client: Any = None, model: str | None = None):
        self._llm = llm_client
        self._model = model or "databricks-claude-sonnet-4-5"

    def analyze(self, question: str) -> DecompositionPlan:
        """
        Analyze a question and return a decomposition plan.

        Fast path: heuristic check → if simple, return immediately.
        Slow path: if complex, call LLM for structured decomposition.
        """
        score, signals = self._complexity_score(question)

        if score < self.COMPLEXITY_THRESHOLD:
            return DecompositionPlan(
                is_simple=True,
                complexity=ComplexityLevel.SIMPLE,
                original_question=question,
                reasoning=f"Heuristic score {score} < threshold {self.COMPLEXITY_THRESHOLD}. "
                          f"Signals: {signals}",
            )

        # Complex — attempt LLM decomposition
        if self._llm is None:
            # No LLM available — fall back to heuristic decomposition
            return self._heuristic_decompose(question, score, signals)

        return self._llm_decompose(question, score, signals)

    def is_complex(self, question: str) -> bool:
        """Quick check: does this question likely need decomposition?"""
        score, _ = self._complexity_score(question)
        return score >= self.COMPLEXITY_THRESHOLD

    # ── Heuristic scoring ─────────────────────────────────────────────────────

    def _complexity_score(self, question: str) -> tuple[int, list[str]]:
        """
        Score question complexity (0–10+). Higher = more complex.
        Returns (score, list_of_detected_signals).
        """
        score = 0
        signals: list[str] = []
        q_lower = question.lower()

        # 1. Conjunction/comparison patterns (+2 each)
        for pattern in _CONJUNCTION_PATTERNS:
            if re.search(pattern, q_lower):
                score += 2
                signals.append(f"conjunction:{pattern[:30]}")
                break  # Only count once

        # 2. Conditional/multi-hop patterns (+3: always requires multi-step)
        for pattern in _CONDITIONAL_PATTERNS:
            if re.search(pattern, q_lower):
                score += 3
                signals.append(f"conditional:{pattern[:30]}")
                break

        # 3. Calculation patterns (+2)
        for pattern in _CALCULATION_PATTERNS:
            if re.search(pattern, q_lower):
                score += 2
                signals.append(f"calculation:{pattern[:30]}")
                break

        # 4. Multiple providers mentioned (+2)
        # Simple heuristic: count capitalized multi-word phrases
        provider_candidates = re.findall(
            r'[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+', question
        )
        if len(provider_candidates) >= 2:
            score += 2
            signals.append(f"multi_provider:{len(provider_candidates)}")

        # 5. Complexity keywords (+1 each, max +3)
        kw_hits = sum(1 for kw in _COMPLEXITY_KEYWORDS if kw in q_lower)
        kw_score = min(kw_hits, 3)
        if kw_score > 0:
            score += kw_score
            signals.append(f"keywords:{kw_hits}")

        # 6. Question length bonus (very long questions tend to be complex)
        word_count = len(question.split())
        if word_count > 25:
            score += 1
            signals.append(f"long:{word_count}w")

        return score, signals

    # ── Heuristic decomposition (no LLM) ──────────────────────────────────

    def _heuristic_decompose(
        self, question: str, score: int, signals: list[str]
    ) -> DecompositionPlan:
        """
        Rule-based decomposition when LLM is unavailable.
        Handles common patterns: comparison, conditional, calculation.
        """
        sub_questions: list[SubQuestion] = []
        q_lower = question.lower()

        # Pattern: comparison between two providers
        comparison_match = re.search(
            r'compare.*?([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+).*?'
            r'(?:and|vs\.?|versus|with|to)\s+'
            r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
            question,
        )
        if comparison_match:
            p1, p2 = comparison_match.group(1), comparison_match.group(2)
            # Extract what to compare (simplistic: use original question terms)
            sub_questions = [
                SubQuestion(
                    id=1, question=f"What are the relevant contract terms for {p1}?",
                    sub_type=SubQuestionType.RETRIEVAL,
                    suggested_tools=["passage_search", "sql_query"],
                    provider_hint=p1,
                ),
                SubQuestion(
                    id=2, question=f"What are the relevant contract terms for {p2}?",
                    sub_type=SubQuestionType.RETRIEVAL,
                    suggested_tools=["passage_search", "sql_query"],
                    provider_hint=p2,
                ),
                SubQuestion(
                    id=3, question=f"Compare and contrast the results for {p1} vs {p2}.",
                    sub_type=SubQuestionType.SYNTHESIS,
                    depends_on=[1, 2],
                    suggested_tools=["summarize"],
                ),
            ]
        # Pattern: conditional ("for providers that X, what is Y?")
        elif any('conditional' in s for s in signals):
            sub_questions = [
                SubQuestion(
                    id=1, question="Identify the set of qualifying providers.",
                    sub_type=SubQuestionType.SQL_QUERY,
                    suggested_tools=["sql_query"],
                ),
                SubQuestion(
                    id=2, question="For those providers, answer the main question.",
                    sub_type=SubQuestionType.SQL_QUERY,
                    depends_on=[1],
                    suggested_tools=["sql_query", "passage_search"],
                ),
                SubQuestion(
                    id=3, question="Synthesize final answer.",
                    sub_type=SubQuestionType.SYNTHESIS,
                    depends_on=[2],
                    suggested_tools=["summarize"],
                ),
            ]
        # Pattern: calculation ("difference/ratio between X and Y")
        elif any('calculation' in s for s in signals):
            sub_questions = [
                SubQuestion(
                    id=1, question="Retrieve the first value needed for calculation.",
                    sub_type=SubQuestionType.SQL_QUERY,
                    suggested_tools=["sql_query"],
                ),
                SubQuestion(
                    id=2, question="Retrieve the second value needed for calculation.",
                    sub_type=SubQuestionType.SQL_QUERY,
                    suggested_tools=["sql_query"],
                ),
                SubQuestion(
                    id=3, question="Compute the result from retrieved values.",
                    sub_type=SubQuestionType.CALCULATION,
                    depends_on=[1, 2],
                    suggested_tools=["calculate"],
                ),
            ]
        # Fallback: generic 2-part decomposition
        else:
            sub_questions = [
                SubQuestion(
                    id=1, question="Gather primary evidence for the question.",
                    sub_type=SubQuestionType.RETRIEVAL,
                    suggested_tools=["passage_search", "sql_query"],
                ),
                SubQuestion(
                    id=2, question="Synthesize final answer from evidence.",
                    sub_type=SubQuestionType.SYNTHESIS,
                    depends_on=[1],
                    suggested_tools=["summarize"],
                ),
            ]

        execution_groups = self._build_execution_groups(sub_questions)

        return DecompositionPlan(
            is_simple=False,
            complexity=(
                ComplexityLevel.COMPLEX if score >= 5
                else ComplexityLevel.MODERATE
            ),
            original_question=question,
            sub_questions=sub_questions,
            execution_groups=execution_groups,
            synthesis_prompt=(
                f"Combine the results of {len(sub_questions)} sub-questions "
                f"to answer: {question}"
            ),
            reasoning=(
                f"Heuristic decomposition (no LLM). Score={score}, "
                f"signals={signals}"
            ),
        )

    # ── LLM-based decomposition ──────────────────────────────────────────

    def _llm_decompose(
        self, question: str, score: int, signals: list[str]
    ) -> DecompositionPlan:
        """Use LLM to produce a structured decomposition."""
        try:
            raw = self._llm.chat(
                model=self._model,
                system=_DECOMPOSE_SYSTEM,
                user=_DECOMPOSE_USER.format(question=question),
                max_tokens=1500,
            )
            return self._parse_llm_plan(raw, question, score, signals)
        except Exception as exc:
            logger.warning(
                "LLM decomposition failed (%s), falling back to heuristic.", exc
            )
            return self._heuristic_decompose(question, score, signals)

    def _parse_llm_plan(
        self, raw: str, question: str, score: int, signals: list[str]
    ) -> DecompositionPlan:
        """Parse LLM JSON output into a DecompositionPlan."""
        try:
            cleaned = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
            parsed = json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("Failed to parse LLM decomposition JSON, fallback.")
            return self._heuristic_decompose(question, score, signals)

        # Validate structure
        subs_raw = parsed.get("sub_questions", [])
        if not subs_raw or len(subs_raw) > 6:
            logger.warning(
                "LLM returned %d sub-questions (expected 2-6), fallback.",
                len(subs_raw),
            )
            return self._heuristic_decompose(question, score, signals)

        sub_questions: list[SubQuestion] = []
        for sq in subs_raw:
            try:
                sub_type = SubQuestionType(sq.get("type", "RETRIEVAL"))
            except ValueError:
                sub_type = SubQuestionType.RETRIEVAL

            sub_questions.append(SubQuestion(
                id=sq.get("id", len(sub_questions) + 1),
                question=sq.get("question", ""),
                sub_type=sub_type,
                depends_on=sq.get("depends_on", []),
                suggested_tools=sq.get("suggested_tools", []),
                provider_hint=sq.get("provider_hint"),
            ))

        # Validate dependency graph (no cycles, all refs valid)
        valid_ids = {sq.id for sq in sub_questions}
        for sq in sub_questions:
            sq.depends_on = [d for d in sq.depends_on if d in valid_ids and d != sq.id]

        execution_groups = self._build_execution_groups(sub_questions)

        complexity_str = parsed.get("complexity", "MODERATE")
        try:
            complexity = ComplexityLevel(complexity_str)
        except ValueError:
            complexity = ComplexityLevel.MODERATE

        return DecompositionPlan(
            is_simple=False,
            complexity=complexity,
            original_question=question,
            sub_questions=sub_questions,
            execution_groups=execution_groups,
            synthesis_prompt=parsed.get("synthesis_prompt", ""),
            reasoning=parsed.get("reasoning", f"LLM decomposition. score={score}"),
        )

    # ── Execution group builder ───────────────────────────────────────────

    @staticmethod
    def _build_execution_groups(
        sub_questions: list[SubQuestion],
    ) -> list[list[int]]:
        """
        Topological sort into parallel execution groups.

        Group 0: all sub-questions with no dependencies (can run in parallel)
        Group 1: sub-questions whose deps are all in group 0
        ... etc.

        Returns list of groups, each group is a list of sub-question IDs.
        """
        if not sub_questions:
            return []

        id_to_deps: dict[int, set[int]] = {
            sq.id: set(sq.depends_on) for sq in sub_questions
        }
        all_ids = set(id_to_deps.keys())
        placed: set[int] = set()
        groups: list[list[int]] = []

        # Safety: max iterations = number of sub-questions
        for _ in range(len(sub_questions)):
            # Find all IDs whose deps are fully satisfied
            ready = [
                sid for sid in all_ids - placed
                if id_to_deps[sid].issubset(placed)
            ]
            if not ready:
                # Cycle detected or bug — dump remaining into last group
                remaining = list(all_ids - placed)
                if remaining:
                    groups.append(remaining)
                break
            groups.append(sorted(ready))
            placed.update(ready)

            if placed == all_ids:
                break

        return groups

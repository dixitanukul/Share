"""Response assembler — constructs user-facing responses from agent output."""
from __future__ import annotations
from typing import Any, Optional
import logging

logger = logging.getLogger(__name__)


class ResponseAssembler:
    """Assembles final user-facing response from AgentController output.

    Handles:
    - Provenance tagging (source attribution)
    - Inactive provider note surfacing
    - Display formatting
    """

    def __init__(
        self,
        provenance_resolver: Optional[Any] = None,
        current_effective_filter: Optional[Any] = None,
    ) -> None:
        self._provenance = provenance_resolver
        self._current_filter = current_effective_filter

    def assemble(self, response: Any, request: Optional[Any] = None) -> Any:
        """Assemble final response with provenance and metadata.

        Applies:
        - Provenance tags to answer text
        - Inactive-provider warnings if relevant
        - Citation cross-references
        """
        if self._provenance and hasattr(response, 'answer'):
            try:
                response = self._provenance.tag(response)
            except Exception as exc:
                logger.debug("Provenance tagging skipped: %s", exc)

        if self._current_filter and hasattr(response, 'metadata'):
            try:
                inactive_notes = self._current_filter.get_inactive_notes(response)
                if inactive_notes:
                    if not hasattr(response, 'warnings') or response.warnings is None:
                        response.warnings = []
                    response.warnings.extend(inactive_notes)
            except Exception as exc:
                logger.debug("Inactive filter skipped: %s", exc)

        return response

    @staticmethod
    def format_for_display(response: Any) -> str:
        """Format an AgentResponse for notebook display."""
        parts = []

        # Answer
        answer = getattr(response, 'answer', str(response))
        parts.append(answer)

        # Confidence
        confidence = getattr(response, 'confidence', None)
        if confidence:
            conf_val = confidence.value if hasattr(confidence, 'value') else str(confidence)
            parts.append(f"\n[Confidence: {conf_val}]")

        # Warnings
        warnings = getattr(response, 'warnings', None)
        if warnings:
            parts.append("\n⚠️ " + " | ".join(str(w) for w in warnings))

        # Citations
        citations = getattr(response, 'citations', None)
        if citations:
            parts.append(f"\n📎 {len(citations)} citation(s)")

        return "".join(parts)

"""platform/v4/core/answer_validator.py

Answer Validation + Fallback ("Prove It" Guardrail)
=====================================================

Post-tool validation that detects when the LLM claims data is absent
or routes to the wrong domain, then triggers a targeted fallback query
to the correct structured table.

Design:
  1. After a tool returns (or the LLM synthesizes), scan the answer for
     "absence claims" — phrases like "does not have", "no data exists",
     "not available", "no traditional DOFR", etc.
  2. If an absence claim is detected, determine which structured table
     SHOULD contain the data (using question keywords → table mapping).
  3. Run a cheap existence-check SQL: SELECT 1 FROM table WHERE ... LIMIT 1
  4. If data EXISTS → return ValidationResult(needs_retry=True) with
     a correction instruction for the agent to re-query the correct table.
  5. If no data → pass through (the claim is valid).
  6. Also detects DOMAIN MISMATCH: question asks about X but tool answered
     from domain Y (e.g., "expired contracts" answered from alerts table).

This module does NOT hardcode keyword→tool mappings. It only validates
post-hoc and triggers retry when evidence contradicts the answer.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Optional, List

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Absence-claim detection patterns
# ---------------------------------------------------------------------------

_ABSENCE_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in [
        # Flexible: "does not have" + up to 10 words + domain keyword
        r'(?:does not|doesn\'t)\s+(?:appear to )?(?:have|contain|include)\b.{0,80}\b(?:dofr|matrix|offset|delegation|amendment timeline)',
        r'\bno\s+(?:traditional |structured )?(?:dofr|division of financial)',
        r'\bnot\s+(?:found|available|present|stored|indexed)\s+(?:in|for)',
        r'\bno\s+(?:data|records?|rows?|results?|entries|information)\s+(?:found|available|exist|returned|were)',
        r'(?:zero|0)\s+(?:rows?|records?|results?|entries|dofr)',
        r'\bunable to (?:find|locate|retrieve)',
        r'\bno\s+(?:relevant |matching )?(?:data|information|records?)\s+(?:for|about|regarding)',
        r'this provider (?:does not|doesn\'t) have',
        r'(?:not|no)\s+(?:applicable|relevant)\s+(?:to|for)',
        # Specifically for DOFR/offset absence
        r'(?:does not|doesn\'t)\s+have\s+a\s+(?:\w+\s+){0,6}(?:dofr|offset|delegation|matrix)',
        r'\bno\s+(?:\w+\s+){0,4}(?:dofr|offset clause|delegation|matrix|amendment)',
        # "not a contracted provider" is valid, don't trigger
    ]
]

# Wrong-table indicators: patterns in the ANSWER that suggest wrong routing
# even when the answer has data (e.g., returns alert rows for "expired contracts")
_WRONG_TABLE_INDICATORS = {
    # (question_keyword, answer_pattern) → the answer is from the wrong table
    'expired contract': [
        re.compile(r'\balert[_\s]?(?:id|priority|queue)\b', re.IGNORECASE),
        re.compile(r'\bdeadline[_\s]?type\b', re.IGNORECASE),
        re.compile(r'\bdays[_\s]?until[_\s]?due\b', re.IGNORECASE),
        re.compile(r'\bCONTRACT_EXPIR(?:Y|ATION)\b'),
    ],
    'contract expir': [
        re.compile(r'\balert[_\s]?(?:id|priority|queue)\b', re.IGNORECASE),
        re.compile(r'\bdeadline[_\s]?type\b', re.IGNORECASE),
    ],
}

# Domain mismatch: question asks about X but answer came from Y
_DOMAIN_SIGNALS = {
    # question_keywords → expected table domain
    'dofr': 'tbl_dofr_matrix_extracted',
    'division of financial responsibility': 'tbl_dofr_matrix_extracted',
    'dofr matrix': 'tbl_dofr_matrix_extracted',
    'offset clause': 'tbl_genie_provider_profile',
    'delegation': 'tbl_delegation_matrix',
    'delegated functions': 'tbl_delegation_matrix',
    'compliance': 'tbl_compliance_tracking',
    'amendment history': 'tbl_genie_amendment_timeline',
    'amendment timeline': 'tbl_genie_amendment_timeline',
    'expired contract': 'tbl_contract_documents_master',
    'contract expir': 'tbl_contract_documents_master',
    'rate escalat': 'tbl_rate_escalators',
    'financial exposure': 'tbl_financial_exposure',
    'repricing': 'tbl_repricing_scenarios',
    'clause text': 'tbl_contract_clauses',
    'clause language': 'tbl_contract_clauses',
    'extraction provenance': 'tbl_extraction_provenance',
    'quality performance': 'tbl_quality_performance',
}

# Table → provider column mapping for existence checks
_TABLE_PROVIDER_COL = {
    'tbl_dofr_matrix_extracted': 'provider_name',
    'tbl_genie_provider_profile': 'provider_name',
    'tbl_delegation_matrix': 'provider_name',
    'tbl_compliance_tracking': 'provider_name',
    'tbl_genie_amendment_timeline': 'provider_name',
    'tbl_contract_documents_master': 'provider_name',
    'tbl_rate_escalators': 'provider_name',
    'tbl_financial_exposure': 'provider_id',  # requires JOIN
    'tbl_repricing_scenarios': 'provider_name',
    'tbl_contract_clauses': 'provider_name',
    'tbl_extraction_provenance': 'provider_id',  # requires JOIN
    'tbl_quality_performance': 'provider_name',
    'tbl_contract_rates_all': 'provider_name',
}

# Mismatch detection: tool_name used → domains it does NOT cover
_TOOL_DOMAIN_EXCLUSIONS = {
    'risk_alert': {'tbl_contract_documents_master', 'tbl_contract_rates_all',
                   'tbl_dofr_matrix_extracted', 'tbl_delegation_matrix'},
    'financial_analysis': {'tbl_contract_documents_master', 'tbl_dofr_matrix_extracted'},
    'compliance_query': {'tbl_contract_documents_master', 'tbl_dofr_matrix_extracted',
                         'tbl_rate_escalators'},
}

# Domain-specific filter hints for correction instructions
# Maps (domain_signal) → (SQL WHERE clause, extra instruction)
_DOMAIN_FILTER_HINTS = {
    'expired contract': (
        "WHERE contract_status = 'EXPIRED'",
        "Group by provider_name and show counts. There are 9,349 expired docs total."
    ),
    'contract expir': (
        "WHERE contract_status = 'EXPIRED'",
        "Group by provider_name and show counts."
    ),
    'dofr': (
        "",  # Provider filter is sufficient
        "Return ALL rows for the provider (do NOT filter by is_current). "
        "Show service_category, group_responsible, hospital_responsible, health_plan_responsible."
    ),
    'dofr matrix': (
        "",
        "Return ALL rows (do NOT filter by is_current). "
        "Show service_category, group_responsible, hospital_responsible, health_plan_responsible."
    ),
    'division of financial responsibility': (
        "",
        "Return ALL rows (do NOT filter by is_current). "
        "Show service_category, group_responsible, hospital_responsible, health_plan_responsible."
    ),
    'amendment history': (
        "",
        "ORDER BY amendment_effective_date. Show the full amendment progression."
    ),
    'amendment timeline': (
        "",
        "ORDER BY amendment_effective_date. Show the full amendment progression."
    ),
}


# ---------------------------------------------------------------------------
# ValidationResult
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Result of answer validation."""
    valid: bool = True
    needs_retry: bool = False
    reason: str = ''
    correction_instruction: str = ''
    target_table: str = ''
    target_provider: str = ''
    domain_mismatch: bool = False
    findings: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# AnswerValidator
# ---------------------------------------------------------------------------

class AnswerValidator:
    """Post-tool answer validation with existence-check fallback.

    Usage in AgentController:
        validator = AnswerValidator(spark=spark, catalog=CATALOG, schema=SCHEMA)
        result = validator.validate(
            question=request.question,
            answer=tool_answer_text,
            provider_name=resolved_provider,
            tool_used=tool_name,
        )
        if result.needs_retry:
            # Re-route to sql_query with result.correction_instruction
            ...
    """

    def __init__(self, spark: Any = None, catalog: str = 'dev_adb',
                 schema: str = 'raw'):
        self._spark = spark
        self._catalog = catalog
        self._schema = schema

    def validate(
        self,
        question: str,
        answer: str,
        provider_name: str = '',
        tool_used: str = '',
        tool_result_data: Any = None,
    ) -> ValidationResult:
        """Validate an answer against structured data evidence.

        Returns ValidationResult with needs_retry=True if the answer
        makes an absence claim that is contradicted by data in the DB.
        """
        result = ValidationResult()

        if not answer or not question:
            return result

        # GROUNDED TOOL EXEMPTION: If sql_query was used, the answer is
        # usually grounded in structured data. HOWEVER, the LLM can still
        # ignore SQL results in favor of VS context (e.g., DOFR poisoning).
        # So we ALWAYS check absence claims — the existence check validates.
        _GROUNDED_TOOLS = {'rate_query', 'compliance_query',
                           'clause_existence', 'field_extraction'}

        # Step 1: Check for domain mismatch (wrong tool used)
        expected_table = self._infer_expected_table(question)
        domain_mismatch = self._detect_domain_mismatch(
            question, tool_used, expected_table
        )

        # Step 2: Check for absence claims in the answer
        # Always check for DOFR/critical domains. Skip only for known-safe tools.
        has_absence_claim = False
        if tool_used not in _GROUNDED_TOOLS:
            has_absence_claim = self._detect_absence_claim(answer)

        # Step 2B: Check for wrong-table indicators in the answer
        # Even if there's no absence claim, the answer might contain data
        # from the WRONG table (e.g., alert rows for "expired contracts")
        if not has_absence_claim and not domain_mismatch:
            wrong_table = self._detect_wrong_table_answer(question, answer)
            if wrong_table:
                domain_mismatch = True  # Treat as domain mismatch
                logger.info(
                    '[AnswerValidator] Wrong-table indicator detected: %s',
                    wrong_table
                )

        if not has_absence_claim and not domain_mismatch:
            return result  # Answer looks fine

        # Step 3: Run existence check if we can identify the target table
        if not expected_table:
            # Can't determine which table to check — pass through
            if domain_mismatch:
                result.findings.append(
                    f'Possible domain mismatch: tool={tool_used} '
                    f'may not cover this question domain'
                )
            return result

        # Step 4: Existence check against the structured table
        data_exists = self._existence_check(
            table=expected_table, provider_name=provider_name
        )

        if data_exists:
            # Data EXISTS but answer claims it doesn't → needs retry
            result.valid = False
            result.needs_retry = True
            result.target_table = expected_table
            result.target_provider = provider_name
            result.domain_mismatch = domain_mismatch

            if domain_mismatch:
                result.reason = (
                    f'Domain mismatch: tool {tool_used!r} was used but '
                    f'{expected_table} has data for this provider. '
                    f'The answer addressed a different domain than the question.'
                )
            else:
                result.reason = (
                    f'Absence claim contradicted: answer claims no data '
                    f'but {expected_table} has rows for provider '
                    f'{provider_name!r}.'
                )

            result.correction_instruction = self._build_correction(
                question=question,
                expected_table=expected_table,
                provider_name=provider_name,
                domain_mismatch=domain_mismatch,
                tool_used=tool_used,
            )
            result.findings.append(result.reason)
            logger.info(
                '[AnswerValidator] RETRY triggered: %s', result.reason
            )
        else:
            # Data genuinely doesn't exist — absence claim is valid
            result.valid = True
            if has_absence_claim:
                result.findings.append(
                    f'Absence claim validated: {expected_table} has no data '
                    f'for provider {provider_name!r}'
                )

        return result

    # ── Private helpers ───────────────────────────────────────────────────

    def _detect_absence_claim(self, answer: str) -> bool:
        """Return True if the answer contains language claiming data is absent."""
        for pattern in _ABSENCE_PATTERNS:
            if pattern.search(answer):
                return True
        return False

    def _infer_expected_table(self, question: str) -> str:
        """Infer which structured table SHOULD answer this question."""
        q_lower = question.lower()
        for signal, table in _DOMAIN_SIGNALS.items():
            if signal in q_lower:
                return table
        return ''

    def _detect_domain_mismatch(
        self, question: str, tool_used: str, expected_table: str
    ) -> bool:
        """Check if the tool used doesn't cover the expected table domain."""
        if not tool_used or not expected_table:
            return False
        exclusions = _TOOL_DOMAIN_EXCLUSIONS.get(tool_used, set())
        if expected_table in exclusions:
            return True
        return False

    def _detect_wrong_table_answer(self, question: str, answer: str) -> str:
        """Check if the answer contains columns/data from the wrong table.

        Returns a description string if wrong-table indicators found, else ''.
        """
        q_lower = question.lower()
        for keyword, patterns in _WRONG_TABLE_INDICATORS.items():
            if keyword in q_lower:
                for pat in patterns:
                    if pat.search(answer):
                        return f'question contains "{keyword}" but answer has alert/wrong-table indicators'
        return ''

    def _existence_check(self, table: str, provider_name: str) -> bool:
        """Run a lightweight SQL check: does the table have data for this provider?

        Returns True if at least 1 row exists.
        Uses the shortest provider token (e.g., 'Cedars' not 'Cedarssinai Medical Center')
        for broad matching. For portfolio questions (no provider), checks if table has any rows.
        """
        if not self._spark:
            return False  # Fail-open: can't check → don't block

        # Portfolio-level: no provider specified, just check table has rows
        if not provider_name:
            fqn = f'{self._catalog}.{self._schema}.{table}'
            try:
                df = self._spark.sql(f'SELECT 1 FROM {fqn} LIMIT 1')
                return df.count() > 0
            except Exception:
                return False

        provider_col = _TABLE_PROVIDER_COL.get(table)
        if not provider_col:
            return False

        # Extract shortest meaningful token from provider name for LIKE matching
        # "Adventist Health" → '%adventist%', "Cedars Sinai" → '%cedars%'
        tokens = [t for t in provider_name.lower().split()
                  if t not in ('health', 'medical', 'center', 'hospital',
                               'of', 'the', 'and', 'inc', 'llc', 'system')]
        search_token = tokens[0] if tokens else provider_name.lower().split()[0]

        fqn = f'{self._catalog}.{self._schema}.{table}'

        if provider_col == 'provider_id':
            # Need to JOIN through provider_profile for provider_id tables
            sql = f"""
                SELECT 1
                FROM {fqn} t
                JOIN {self._catalog}.{self._schema}.tbl_genie_provider_profile p
                  ON t.provider_id = p.provider_id
                WHERE LOWER(p.provider_name) LIKE '%{search_token}%'
                LIMIT 1
            """
        else:
            sql = f"""
                SELECT 1
                FROM {fqn}
                WHERE LOWER({provider_col}) LIKE '%{search_token}%'
                LIMIT 1
            """

        try:
            df = self._spark.sql(sql)
            exists = df.count() > 0
            logger.debug(
                '[AnswerValidator] existence_check: %s provider=%r → %s',
                table, search_token, exists
            )
            return exists
        except Exception as exc:
            logger.warning(
                '[AnswerValidator] existence_check failed: %s — %s',
                table, exc
            )
            return False  # Fail-open

    def _build_correction(
        self,
        question: str,
        expected_table: str,
        provider_name: str,
        domain_mismatch: bool,
        tool_used: str,
    ) -> str:
        """Build an instruction for the agent to retry with the correct table."""
        provider_col = _TABLE_PROVIDER_COL.get(expected_table, 'provider_name')
        fqn = f'{self._catalog}.{self._schema}.{expected_table}'

        # Use first meaningful token for LIKE matching (same logic as _existence_check)
        # "Cedars Sinai" → '%cedars%' (matches "Cedarssinai Medical Center")
        _search_token = ''
        if provider_name:
            _stop = ('health', 'medical', 'center', 'hospital',
                     'of', 'the', 'and', 'inc', 'llc', 'system')
            _tokens = [t for t in provider_name.lower().split() if t not in _stop]
            _search_token = _tokens[0] if _tokens else provider_name.lower().split()[0]

        # Find domain-specific filter hint
        q_lower = question.lower()
        domain_where = ''
        domain_extra = ''
        for signal, (where_clause, extra) in _DOMAIN_FILTER_HINTS.items():
            if signal in q_lower:
                domain_where = where_clause
                domain_extra = extra
                break

        # Build WHERE clause (use token-based matching for provider)
        if domain_where and _search_token:
            # Domain filter + provider filter
            where = f"{domain_where} AND LOWER({provider_col}) LIKE '%{_search_token}%'"
        elif domain_where:
            # Domain filter only (portfolio question)
            where = domain_where
        elif _search_token:
            # Provider filter only
            where = f"WHERE LOWER({provider_col}) LIKE '%{_search_token}%'"
        else:
            # Portfolio, no domain hint — just get sample
            where = "LIMIT 100"

        if domain_mismatch:
            parts = [
                f'CORRECTION: The previous tool ({tool_used}) answered from the WRONG '
                f'domain. The question requires data from {expected_table}. '
                f'You MUST re-query using sql_query: '
                f'SELECT * FROM {fqn} {where} LIMIT 50.',
            ]
        else:
            parts = [
                f'CORRECTION: Your previous answer claimed no data exists, but '
                f'{expected_table} has confirmed rows. '
                f'Re-query using sql_query: '
                f'SELECT * FROM {fqn} {where} LIMIT 50.',
            ]

        if domain_extra:
            parts.append(domain_extra)
        parts.append('Present the actual data. Do NOT claim absence.')

        return ' '.join(parts)

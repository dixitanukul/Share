"""
P5 — QuestionRouter
====================
Native V3 replacement for V2 Cell 4 (route_question + _heuristic_route).

Classifies a user question into one of 8 routes, extracts entities
(providers, concepts), and applies six deterministic override rules
ported directly from V2:

  RE-1  rate-signal rescue  — clause_existence → rate_query when rate
        keywords dominate but no clause-existence phrasing is present.
  RE-2  unresolvable comparison detection — flags comparison intent
        when no providers are resolved.
  CE-FIX  target_concept rescue  — regex extracts concept for
        clause_existence routes when the LLM omits target_concept.
  EXTR  extraction-signal override — clause_existence / explanation →
        field_extraction when the question asks for a specific value.
  CONSTR  comparison / single-provider constraints — comparison needs
        2+ providers; single_provider needs exactly 1.
  PROF-SQL  profile shortcut  — routes offset/DOFR/IPA/is_active/LOB
        questions directly to sql_query (pre-computed profile columns).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..config.settings import LLM_REASONING

# ─── Route → V3 tool name ────────────────────────────────────────────────────

ROUTE_TO_TOOL: Dict[str, str] = {
    "clause_existence":      "clause_existence",
    "structured_extraction": "field_extraction",
    "single_provider":       "provider_deep_dive",
    "comparison":            "comparison",
    "rate_query":            "rate_query",
    "explanation":           "explanation",
    "multi_concept":         "multi_concept",
    "temporal":              "temporal_analysis",
    "sql_query":             "sql_query",
    # Phase 10B-1: Risk & Alerts
    "risk_alert":            "risk_alert",
    # Phase 10B-2: Financial Intelligence
    "financial_analysis":    "financial_analysis",
    # Phase 10B-3: Network & Geography
    "system_membership":     "system_membership",
    # Phase 10B-4: Compliance & Quality
    "compliance_query":      "compliance_query",
    # Phase 10B-5: Clause Intelligence
    "clause_text":           "clause_text",
    # Phase 10B-6: Provenance & Audit
    "provenance":            "provenance",
}

VALID_ROUTES: frozenset = frozenset(ROUTE_TO_TOOL.keys())

ROUTE_DESCRIPTIONS: Dict[str, str] = {
    "clause_existence":      "Checking contract clause coverage",
    "structured_extraction": "Extracting structured field values",
    "single_provider":       "Building provider profile",
    "comparison":            "Comparing multiple providers",
    "rate_query":            "Looking up contracted reimbursement rates",
    "explanation":           "Searching knowledge base for explanations",
    "multi_concept":         "Analyzing multiple contract concepts",
    "temporal":              "Analyzing contract timeline and history",
    "sql_query":             "Querying structured data directly",
    "risk_alert":            "Checking risk scores and active alerts",
    "financial_analysis":    "Analyzing financial exposure and spend",
    "system_membership":     "Looking up health system network membership",
    "compliance_query":      "Reviewing compliance and delegation status",
    "clause_text":           "Searching contract language and clause text",
    "provenance":            "Tracing data lineage and audit trail",
}

_DEFAULT_ROUTE = "clause_existence"


# ─── RoutingDecision ─────────────────────────────────────────────────────────

@dataclass
class RoutingDecision:
    """Structured routing result, parallel to V2's routing dict.

    Attributes
    ----------
    route       : V2-style logical route name (e.g. "clause_existence").
    tool_name   : Registered V3 tool name (mapped via ROUTE_TO_TOOL).
    confidence  : "llm" | "heuristic" — how the route was determined.
    unresolvable_comparison : RE-2 flag set when comparison intent is
                  detected but no providers could be resolved.
    """

    route: str
    tool_name: str
    providers: List[str] = field(default_factory=list)
    concepts: List[str] = field(default_factory=list)
    target_concept: Optional[str] = None
    search_keywords: List[str] = field(default_factory=list)
    semantic_query: str = ""
    is_negative: bool = False
    scope_filter: Optional[Dict] = None
    analysis_type: str = ""
    confidence: str = "heuristic"
    unresolvable_comparison: bool = False

    def to_tool_input(self) -> Dict[str, Any]:
        """Convert to a kwargs dict suitable for a V3 tool's _run() method."""
        return {
            "providers": self.providers,
            "concept": self.target_concept,
            "concepts": self.concepts,
            "search_keywords": self.search_keywords,
            "is_negative": self.is_negative,
        }


# ─── QuestionRouter ──────────────────────────────────────────────────────────

class QuestionRouter:
    """Classify a natural-language question into a V3 tool dispatch decision.

    Parameters
    ----------
    provider_service : V3 ProviderService — used for provider detection.
    llm_client       : Optional LLM client for intent classification.
                       When None, heuristic routing is used throughout.
    """

    def __init__(
        self,
        provider_service: Any,
        llm_client: Any = None,
    ) -> None:
        self._provider_service = provider_service
        self._llm_client = llm_client

    # ── Public API ────────────────────────────────────────────────────────

    def route(self, question: str) -> RoutingDecision:
        """Classify *question* and return a fully resolved RoutingDecision."""
        detected_providers = self._detect_providers(question)

        if self._llm_client:
            raw = self._llm_route(question, detected_providers)
            confidence = "llm"
        else:
            raw = self._heuristic_route(question, detected_providers)
            confidence = "heuristic"

        raw = self._apply_overrides(raw, question)

        route = raw.get("route", _DEFAULT_ROUTE)
        tool_name = ROUTE_TO_TOOL.get(route, _DEFAULT_ROUTE)

        # Remove known payer/health-plan names that should never be treated as contracted providers
        _PAYER_EXCLUSION = {
            'blue shield of california', 'blue shield', 'bsc',
            'blue cross', 'anthem', 'aetna', 'cigna', 'humana',
            'united healthcare', 'unitedhealthcare', 'kaiser permanente',
            'health net', 'molina', 'centene', 'la care',
        }
        _raw_providers = raw.get('providers') or []
        _filtered_providers = [
            p for p in _raw_providers
            if p.lower().strip() not in _PAYER_EXCLUSION
            and not any(excl in p.lower() for excl in ('blue shield', 'insurance company', 'health insurance', 'health plan of california', 'health plan of san mateo'))
        ]
        # ROUTER-HALLUCINATION-FIX: cross-validate LLM-extracted providers against
        # the deterministic, question-text-grounded `detected_providers` list.
        # The LLM prompt shows `detected_providers` only as a hint ("Detected
        # providers from database: {providers_json}") — it is NEVER constrained
        # to use only those names. In practice the LLM sometimes invents an
        # additional, unrelated-but-similarly-named facility (e.g. adding
        # "Anaheim Community Hospital" to a question that only names "Anaheim
        # Regional Medical Center" and "Loma Linda University Medical Center"),
        # or drops a legitimately-named provider. Since `detected_providers`
        # already covers exact-substring matches AND system-alias expansions
        # (e.g. "Dignity Health" -> its member facilities), it is a safe,
        # comprehensive ground truth whenever it finds anything — prefer it.
        if detected_providers:
            _detected_lower = {p.lower() for p in detected_providers}
            _grounded_providers = [p for p in _filtered_providers if p.lower() in _detected_lower]
            if _grounded_providers:
                _filtered_providers = _grounded_providers
            else:
                # Zero overlap between the LLM's provider list and what's
                # actually grounded in the question text — trust the
                # deterministic detector instead of the LLM's free-form guess.
                _filtered_providers = list(detected_providers)
            # Preserve the order providers are actually mentioned in the
            # question text, so `providers[0]` (used pervasively downstream
            # for single-provider fallback/validation logic) deterministically
            # matches the FIRST-named entity rather than an LLM- or
            # length-sort-derived ordering.
            _q_lower_order = question.lower()

            def _pos_key(_p: str) -> int:
                _idx = _q_lower_order.find(_p.lower())
                return _idx if _idx >= 0 else 10 ** 6

            _filtered_providers = sorted(_filtered_providers, key=_pos_key)
        return RoutingDecision(
            route=route,
            tool_name=tool_name,
            providers=_filtered_providers,
            concepts=raw.get("concepts") or [],
            target_concept=raw.get("target_concept") or None,
            search_keywords=raw.get("search_keywords") or [],
            semantic_query=raw.get("semantic_query") or question,
            is_negative=bool(raw.get("is_negative", False)),
            scope_filter=raw.get("scope_filter"),
            analysis_type=raw.get("analysis_type") or "",
            confidence=confidence,
            unresolvable_comparison=bool(raw.get("_unresolvable_comparison", False)),
        )

    # ── Provider detection ────────────────────────────────────────────────

    # Common health-system alias → resolvable token mapping.
    # These umbrella names never appear as canonical facility names but
    # resolve correctly via ProviderService.resolve() token matching.
    _SYSTEM_ALIASES: List[str] = [
        "Sharp HealthCare", "Sharp Health", "Dignity Health", "CommonSpirit",
        "Adventist Health", "Adventist", "Providence Health", "Providence St",
        "Sutter Health", "Scripps Health", "Scripps", "Stanford Health",
        "Cedars Sinai", "UCSD", "UCSF", "UCI Medical", "UCLA Medical",
        "Kaiser Permanente", "Providence", "Keck Medicine",
        "Palomar Health", "PIH Health",
    ]
    # Map umbrella system names to shorter tokens that resolve to ALL facilities.
    # "Sharp HealthCare" via token matching only returns Sharp Coronado (has "healthcare").
    # "Sharp" via canonical_contains returns all 3 Sharp facilities.
    _ALIAS_TOKEN_OVERRIDES: dict = {
        "sharp healthcare": "Sharp",
        "sharp health": "Sharp",
        "dignity health": "CHW",          # returns CHW Mercy family
        "scripps health": "Scripps",       # returns all Scripps facilities
        "scripps": "Scripps Memorial",     # bare alias → avoids "Scripps Health Plan Services"
        "adventist health": "Adventist",   # returns all Adventist facilities
        "sutter health": "Sutter",         # returns all Sutter facilities
        "providence health": "Providence",
        "stanford health": "Stanford",
        "commonspirit": "CHW",
        # Standalone short names (no "Health" suffix)
        "adventist": "Adventist",
        "sharp": "Sharp",
        "cedars": "Cedars",
        "cedars-sinai": "Cedars",
        "dignity": "CHW",
        "sutter": "Sutter",
        "providence": "Providence",
        "stanford": "Stanford",
    }

    def _detect_providers(self, question: str) -> List[str]:
        """Longest-match provider detection against canonical name list.

        Step 1 (exact substring): canonical name appears verbatim in question.
        Step 2 (alias resolution): extract capitalized 1-4 word sequences and
          try ProviderService.resolve() — handles "Sharp HealthCare", "Dignity
          Health", "Cedars-Sinai", etc. that aren't exact canonical names.
        """
        import re as _re
        q_lower = question.lower()
        # Period-normalized version for matching "St. Mary" → "st mary"
        q_normalized = _re.sub(r'(?<!\d)\.(?!\d)', '', q_lower).strip()
        q_normalized = _re.sub(r'\s{2,}', ' ', q_normalized)
        found: List[str] = []
        _mt_question_hint = '[prior turn was:' in q_lower  # MT enriched question
        # Step 1: Exact canonical substring matching (longest first)
        for name in sorted(self._provider_service.all_names(), key=len, reverse=True):
            if len(name) >= 4:
                name_lower = name.lower()
                if name_lower in q_lower or name_lower in q_normalized:
                    found.append(name)

        # Step 2: Health-system alias + capitalized-sequence resolution
        # For MT-enriched questions, always run Step 2 to find providers in the
        # bracketed prior-turn context (not just the main question fragment).
        if not found or _mt_question_hint:
            _SKIP_WORDS = frozenset({
                "what", "show", "does", "give", "list", "tell", "how",
                "which", "when", "that", "this", "have", "will", "please",
                "can", "could", "would", "are", "get", "find", "does",
                "make", "about", "from", "with", "into", "like", "any",
                "some", "all", "now", "here", "there", "its", "our",
                "their", "your", "the", "and", "for", "not", "but",
                "inpatient", "outpatient", "contract", "provider",
                "rate", "rates", "clause", "compliance", "query",
            })
            candidates = set()
            # a) Known system aliases that appear in the question
            for alias in self._SYSTEM_ALIASES:
                if alias.lower() in q_lower:
                    candidates.add(alias)
            # b) Extract 1-4 consecutive title/upper-case words from question
            _cap_re = _re.compile(r'\b([A-Z][a-zA-Z]+(?:[\s\-][A-Z][a-zA-Z]+){0,3})\b')
            # Sentence-start words that are not provider names but get captured
            # because they start with uppercase at the beginning of a sentence.
            _SENTENCE_START_STRIP = frozenset({
                'is', 'does', 'do', 'are', 'has', 'have', 'was', 'were',
                'show', 'give', 'tell', 'what', 'which', 'how', 'can',
                'could', 'would', 'should', 'will', 'may', 'compare',
            })
            for m in _cap_re.finditer(question):
                token = m.group(1).strip()
                # Strip leading sentence-start words from multi-word sequences
                # e.g. "Is Sharp HealthCare" → "Sharp HealthCare"
                _words = token.split()
                while _words and _words[0].lower() in _SENTENCE_START_STRIP:
                    _words.pop(0)
                token = ' '.join(_words).strip() if _words else token
                if len(token) >= 4 and token.lower() not in _SKIP_WORDS:
                    candidates.add(token)
            # Try longest candidates first; stop when we have a match
            for cand in sorted(candidates, key=len, reverse=True):
                # Use token override if available (gets multi-facility results)
                resolve_token = self._ALIAS_TOKEN_OVERRIDES.get(cand.lower(), cand)
                names, method, ids = self._provider_service.resolve(resolve_token)
                if ids:
                    for n in names:
                        if n not in found:
                            found.append(n)
                    # For comparison questions (or MT-enriched), keep resolving all candidates
                    _is_comp = any(w in q_lower for w in (" vs ", " versus ", "compare", "between"))
                    if found and not _is_comp and not _mt_question_hint:
                        break

        return found[:5]

    # ── LLM classification ────────────────────────────────────────────────

    _LLM_SYSTEM = (
        "You are a routing classifier for a contract intelligence system. "
        "Return only valid JSON."
    )

    _LLM_PROMPT_TEMPLATE = (
        "Analyze this contract intelligence question and determine how to answer it.\n\n"
        "Question: \"{question}\"\n\n"
        "Detected providers from database: {providers_json}\n\n"
        "Return ONLY valid JSON with these fields:\n"
        '{{\n'
        '  "route": "clause_existence|structured_extraction|single_provider|comparison|'
        'rate_query|explanation|multi_concept|temporal|sql_query|'
        'compliance_query|risk_alert|financial_analysis|system_membership|clause_text|provenance",\n'
        '  "providers": ["Provider Name", ...],\n'
        '  "concepts": ["concept1", ...],\n'
        '  "search_keywords": ["kw1", ...],\n'
        '  "semantic_query": "...",\n'
        '  "is_negative": true/false,\n'
        '  "target_concept": "...",\n'
        '  "analysis_type": "...",\n'
        '  "scope_filter": null\n'
        "}}\n\n"
        "Routing rules:\n"
        "- sql_query: PREFER THIS for offset/DOFR/IPA clause status, auto_renewal status, is_active checks, "
        "LOB filtering, provider counts, amendment counts, and any question answerable "
        "from tbl_genie_provider_profile pre-computed columns\n"
        "- clause_existence: which providers have/don't have a specific clause/provision "
        "(ONLY when clause is NOT offset/DOFR/IPA — those go to sql_query)\n"
        "- structured_extraction: asking for a SPECIFIC VALUE (days, amounts, dates, limits)\n"
        "- single_provider: ONE specific provider's contract details\n"
        "- comparison: COMPARE two or more named providers\n"
        "- rate_query: rates, costs, PMPM, per diem, reimbursement, financial amounts\n"
        "- explanation: EXPLAIN, DESCRIBE, or SUMMARIZE a provision or process\n"
        "- multi_concept: TWO OR MORE concepts with AND/OR/BUT logic\n"
        "- temporal: CHANGES over time, amendment history\n"
        "- passage_search (via single_provider): specific contract clause TEXT, payment"
        " timing obligations (e.g. 'within 30 days'), late payment penalties,"
        " prompt pay requirements, or any question asking what the contract"
        " SAYS or REQUIRES — use passage_search NOT field_extraction.\n\n"
        "If one provider + concept: prefer single_provider over clause_existence.\n"
        "If two providers: prefer comparison.\n"
        "If rate/cost is central: prefer rate_query.\n"
        "If asking about offset/DOFR/IPA status, active/inactive, or LOB: prefer sql_query.\n"
        "- compliance_query: regulatory compliance (Knox-Keene, DMHC, CMS, AB 72, AB 352, SB 137, AB 1455), quality programs (HEDIS, P4P, withhold, star rating, value-based), notice day requirements.\n"
        "- risk_alert: contract risk scores, alerts, deadlines, priority tiers, alert queue items. "
        "IMPORTANT: Do NOT use risk_alert for 'which contracts expire in the next N months' or "
        "'contracts expiring soon/by date' — those are TIME-BOUNDED EXPIRATION QUERIES that "
        "must go to sql_query (answered from tbl_contract_documents_master.expiration_date). "
        "Only use risk_alert for literal alert-queue lookups or risk-score inquiries.\n"
        "- financial_analysis: contracted spend, financial exposure, repricing scenarios, rate escalators.\n"
        "- system_membership: health system membership, service areas, regional networks, which system a provider belongs to.\n"
        "- clause_text: verbatim clause text retrieval, full clause language, network norms/deviations, clause comparisons.\n"
        "- provenance: data extraction sources, audit trails, how data was extracted, confidence scores, document supersession/lineage.\n"
        "IMPORTANT: Use compliance_query ONLY for DATA RETRIEVAL about compliance status, records, quality scores, notification days. "
        "Do NOT use compliance_query for pure definition questions — 'What is Knox-Keene?', 'Explain AB 72', 'What does DMHC mean?' should route to 'explanation' instead."
    )

    def _llm_route(self, question: str, detected_providers: List[str]) -> dict:
        """Use LLM to classify intent. Falls back to heuristic on failure."""
        prompt = self._LLM_PROMPT_TEMPLATE.format(
            question=question,
            providers_json=json.dumps(detected_providers[:5]),
        )
        try:
            raw = self._llm_client.chat(
                model=LLM_REASONING,
                system=self._LLM_SYSTEM,
                user=prompt,
                max_tokens=600,
            )
            raw = raw.strip()
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0]
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError("LLM returned non-dict")
            return result
        except Exception:
            return self._heuristic_route(question, detected_providers)

    # ── Heuristic route ───────────────────────────────────────────────────

    _TEMPORAL_WORDS = (
        "changed", "amendment", "history", "superseded",
        "latest version", "what was added", "what was removed",
    )
    _RATE_WORDS = (
        "rate", "per diem", "pmpm", "capitation", "reimbursement",
        "cost", "payment amount", "how much",
        # Payment structure questions are rate questions
        "payment structure", "payment type", "payment model",
        "drg", "diagnosis-related group", "bundled payment",
        "fee schedule", "fee for service structure",
        # Stop-loss and carve-out questions → rate_query has dedicated handlers
        "stop-loss", "stop loss", "attachment level",
        "carve-out", "carve out", "carved out",
    )
    _COMPARISON_WORDS = (" vs ", " versus ", "compare", "comparison", "difference between")
    _MULTI_CONCEPT_WORDS = (" and ", " but ", " or ", "both")
    # Patterns that ask for a general summary/overview of a single provider.
    # Routed to single_provider (provider_deep_dive) when a provider is in scope.
    _PROVIDER_OVERVIEW_WORDS = (
        "tell about", "tell me about", "tell me everything",
        "everything about", "everything you got", "everything you know",
        "give me all", "give me everything", "all about", "all information",
        "full profile", "complete profile", "provider profile", "provider overview",
        "what can you tell", "what do you know",
    )
    _EXPLANATION_WORDS = (
        "explain", "describe", "summarize", "what does", "how does",
    )
    _HEURISTIC_CONCEPT_RE = re.compile(
        r"\b(?:offset|termination|auto.?renewal|stop.?loss|dispute|arbitration|"
        r"capitation|indemnif|notification|force\s+majeure|assignment|confidential|"
        r"non.?compete|dofr|ipa\s+delegation)\b",
        re.IGNORECASE,
    )

    # Phase 10B-1: Risk & Alerts keywords
    _RISK_ALERT_KEYWORDS = (
        "risk", "alert", "deadline", "tier",
        "critical", "overdue", "upcoming", "priority",
        "contract risk", "risk score", "risk tier",
        "days until", "action needed", "alert queue",
        # "expir" was too broad — matched "expired contracts" (status query).
        # Use specific phrases that indicate alert/deadline context:
        "expiring soon", "about to expire", "expiry alert",
        "expiration warning", "expiration date alert",
    )
    # Phase 10B-2: Financial Intelligence keywords
    _FINANCIAL_KEYWORDS = (
        "spend", "spending", "exposure", "financial",
        "repricing", "reprice", "what if", "what-if", "scenario",
        "escalat", "escalator", "cpi", "annual increase",
        # NOTE: "supersed*", "supersession", "replaced" moved to _PROVENANCE_KEYWORDS
        # (they are audit/lineage terms, not financial analysis terms)
        "which rate replaced", "rate history", "version history",
    )

    # Phase 10B-3: Network & Geography keywords
    _NETWORK_KEYWORDS = (
        # Health-system / geography specific phrases — NOT generic "network"
        # (generic "network" is intentionally excluded: too noisy; caught by _CLAUSE_TEXT_KEYWORDS)
        "health system", "system membership", "hospital system",
        "service area", "geography", "county",
        "northern ca", "southern ca", "bay area", "central valley",
        "inland empire", "central coast",
        "affiliated", "owned by", "part of", "belongs to",
        "which system", "system affiliation",
        # NOTE: provider names (adventist, sharp, scripps, etc.) intentionally removed —
        # they appear in clause/compliance/financial questions and create false positives.
        # Provider name alone is NOT sufficient signal for network/geography routing.
    )

    # Phase 10B-4: Compliance & Quality keywords
    _COMPLIANCE_KEYWORDS = (
        "compliance", "regulation", "regulatory",
        "knox-keene", "knox keene", "dmhc", "cms", "cms_ma",
        "ab 352", "ab352", "ab 72", "ab72", "sb 137", "sb137",
        "ab 1455", "ab1455",
        "quality", "hedis", "p4p", "withhold", "star rating",
        "value based", "value-based", "performance program",
        "notice days", "days notice",
        "termination notice", "rate change notice",
        "audit notice", "audit",
        "credentialing notice",
        "notification requirement", "notice requirement",
    )

    # Phase 10B-5: Clause Intelligence keywords (verbatim text retrieval)
    _CLAUSE_TEXT_KEYWORDS = (
        "clause text", "full clause", "verbatim", "clause language",
        "actual language", "contract language", "show me the clause",
        "what does the contract say", "full text of", "clause wording",
        "provision text", "exact language", "text of the",
        "how does the contract define", "full provision",
        "network norm", "network deviation", "network baseline",
        "compared to network", "deviation from network",
    )

    # Phase 10B-6: Provenance & Audit keywords
    _PROVENANCE_KEYWORDS = (
        # Core provenance terms
        "provenance", "audit trail", "extraction audit",
        "where did this come from", "come from",
        "how was this extracted", "was extracted", "how was it extracted",
        "who extracted", "extraction method", "extraction confidence",
        "how reliable", "reliable extract",
        "human verified", "human corrected",
        # Supersession / document lineage (moved from _FINANCIAL_KEYWORDS)
        "supersession", "superseded", "superseding",
        "document supersession", "superseded by", "contract chain",
        "document lineage", "contract history", "replaced by", "replaces",
        "supersession history", "contract replacement",
        # Single-word high-confidence anchors
        "extraction",   # "show me the extraction records"
        "extract",      # matches "extracted", "extractions", "extracting"
        "replaced",     # "what replaced the old contract" → document lineage
    )



    def _heuristic_route(self, question: str, detected_providers: List[str]) -> dict:
        """Pure keyword heuristic — used when LLM is unavailable or fails."""
        q = question.lower()

        # RISK-ALERT fast-path: risk/alert/deadline keywords → risk_alert
        # GUARD: "expired contracts" / "contract status" → sql_query (tbl_contract_documents_master)
        _risk_alert_excluded = (
            "expired contract", "contract status", "how many expired",
            "list of expired", "what expired", "show expired",
            "contracts that expired", "contracts have expired",
            # EXPIRY-ROUTE-FIX: time-bounded expiration queries → sql_query
            "expire in the next", "expiring in the next",
            "expire within", "expiring within",
            "expire in the coming", "expiring in the coming",
            "expire by", "expiring by",
            "contracts expire", "contracts expiring",
        )
        if (any(w in q for w in self._RISK_ALERT_KEYWORDS)
                and not any(exc in q for exc in _risk_alert_excluded)):
            route = "risk_alert"
        # FINANCIAL fast-path: spend/exposure/repricing keywords → financial_analysis
        # DOFR GUARD: party-assignment terms ("financial responsibility", "hospital responsible",
        #   etc.) describe DOFR content — NOT spend/exposure topics. Keep as sql_query.
        # NOTE: "rate escalat*" previously guarded here → sql_query, but financial_analysis
        #   now has a two-tier extraction_quality-filtered query for tbl_rate_escalators.
        elif (any(w in q for w in self._FINANCIAL_KEYWORDS)
              and not any(t in q for t in (
                  "financial responsibility", "hospital responsible", "group responsible",
                  "health plan responsible", "hospital's financial", "responsible for services",
                  "who is responsible", "party responsible", "dofr", "division of financial",
              ))):
            route = "financial_analysis"
        # NETWORK fast-path: health system/geography keywords → system_membership
        elif any(w in q for w in self._NETWORK_KEYWORDS):
            route = "system_membership"
        # PROVENANCE fast-path: audit/lineage/supersession → provenance
        # NOTE: placed BEFORE compliance so "how was this compliance data extracted?" 
        # hits "extracted" in _PROVENANCE_KEYWORDS before "compliance" in _COMPLIANCE_KEYWORDS
        elif any(w in q for w in self._PROVENANCE_KEYWORDS):
            route = "provenance"
        # COMPLIANCE fast-path: regulatory/quality keywords → compliance_query
        # EXCLUDE pure definition/explanation questions ("what is Knox-Keene", "explain AB 72")
        elif (any(w in q for w in self._COMPLIANCE_KEYWORDS)
              and not any(exp in q for exp in ("what is ", "what are ", "explain ",
                                               "define ", "describe ", "what does"))):
            route = "compliance_query"
        # CLAUSE-TEXT fast-path: verbatim clause retrieval → clause_text
        elif any(w in q for w in self._CLAUSE_TEXT_KEYWORDS):
            route = "clause_text"
        # PROF-SQL fast-path: offset/DOFR/IPA/active/LOB → sql_query
        elif self._is_profile_sql_question(q):
            route = "sql_query"
        # Q12 FIX: "how many amendments does X have" + "when was the most recent"
        # patterns must use sql_query (COUNT+MAX), NOT temporal_analysis.
        # The word "amendment" is in _TEMPORAL_WORDS which is too broad — it routes
        # ALL amendment questions to temporal_analysis. We intercept COUNT+DATE
        # questions first so a single sql_query handles them in <5s vs 50s.
        elif re.search(
            r'\bhow\s+many\s+amendment|\bamendment\s+count\b|'
            r'\bwhen\s+was\s+the\s+most\s+recent\s+amendment\b|'
            r'\bmost\s+recent\s+amendment\s+date\b|'
            r'\blatest\s+amendment\s+date\b|'
            r'\bhow\s+many\s+(?:contracts?|documents?|versions?)\s+does\b',
            q,
        ):
            route = "sql_query"
        elif any(w in q for w in self._TEMPORAL_WORDS):
            route = "temporal"
        # RATE-ESCALATOR CLAUSE fast-path: questions specifically about escalation
        # PROVISIONS in tbl_rate_escalators (not rate schedules in tbl_contract_rates_all).
        # Must come BEFORE _RATE_WORDS so "rate escalation clauses" → financial_analysis,
        # not rate_query (which only queries the rate schedule table).
        # financial_analysis now uses a two-tier extraction_quality-filtered query (2026-07-20).
        elif any(t in q for t in ("rate escalat", "escalation clause", "escalator clause",
                                   "escalator provision", "rate adjustment clause")):
            route = "financial_analysis"
        elif any(w in q for w in self._RATE_WORDS):
            route = "rate_query"
        elif any(w in q for w in self._COMPARISON_WORDS) and len(detected_providers) >= 2:
            route = "comparison"
        elif (
            any(w in q for w in self._MULTI_CONCEPT_WORDS)
            and q.count("clause") + q.count("provision") + q.count("term") >= 2
        ):
            route = "multi_concept"
        elif any(w in q for w in self._PROVIDER_OVERVIEW_WORDS):
            # Generic "tell me about" / "everything you got" queries — route to
            # provider_deep_dive (single_provider) so the scope fallback can inject
            # the provider from provider_hint. This avoids the 8-tool ReAct loop.
            route = "single_provider"
        elif any(w in q for w in self._EXPLANATION_WORDS):
            route = "explanation"
        elif len(detected_providers) == 1:
            route = "single_provider"
        else:
            route = "clause_existence"

        concept_words = self._HEURISTIC_CONCEPT_RE.findall(q)
        return {
            "route": route,
            "providers": detected_providers,
            "concepts": concept_words if concept_words else ["contract terms"],
            "search_keywords": concept_words[:8],
            "semantic_query": question,
            "is_negative": any(w in q for w in ("don't", "dont", "without", "lack", "no ")),
            "target_concept": concept_words[0] if concept_words else None,
            "analysis_type": route.replace("_query", "").replace("single_", ""),
            "scope_filter": None,
        }

    # ── PROF-SQL: Profile-based SQL shortcut detection ─────────────────────
    # These questions are answerable via pre-computed columns in
    # tbl_genie_provider_profile (offset_clause_status, dofr_status,
    # ipa_delegation_status, is_active, lob_normalized). Much faster and
    # more accurate than corpus passage search.

    _PROFILE_CLAUSE_CONCEPTS = re.compile(
        r"\b(?:"
        r"offset(?:\s+clause)?(?:\s+status)?"
        r"|dofr"
        r"|division\s+of\s+financial\s+responsibility"
        r"|financial\s+responsibility"      # DOFR party-assignment concept
        r"|hospital\s+responsible"          # DOFR column: hospital_responsible
        r"|group\s+responsible"             # DOFR column: group_responsible
        r"|health\s+plan\s+responsible"     # DOFR column: health_plan_responsible
        r"|ipa\s+delegation"
        r"|delegation\s+(?:of\s+)?authority"
        r"|auto[- ]?renew\w*"
        r"|stop[- ]?loss(?:\s+(?:provision|clause|protection|threshold|coverage))?"
        r")\b",
        re.IGNORECASE,
    )

    _PROFILE_STATUS_SIGNALS = re.compile(
        r"\b(?:"
        r"(?:is|are)\s+.{1,60}?(?:active|inactive)\b"
        r"|active\s+providers?"
        r"|inactive\s+providers?"
        r"|currently\s+active"
        r"|is_active"
        r")",
        re.IGNORECASE,
    )

    _PROFILE_LOB_SIGNALS = re.compile(
        r"\b(?:"
        r"how\s+many\s+(?:commercial|medi.?cal|medicare|multi.?lob)\s+providers?"
        r"|(?:commercial|medi.?cal|medicare)\s+(?:providers?|contracts?)\s+(?:in|across)"
        r"|line\s+of\s+business\s+(?:breakdown|distribution|count)"
        r"|lob\s+(?:breakdown|distribution|filter)"
        r")",
        re.IGNORECASE,
    )

    _PROFILE_CLAUSE_QUESTION_SIGNALS = re.compile(
        r"\b(?:"
        r"(?:does|do|is|has|have)\s+.{0,50}(?:offset|dofr|ipa|stop[- ]?loss|auto[- ]?renew)"
        r"|(?:does|do|is|has|have)\s+.{0,80}(?:division\s+of\s+financial|financial\s+responsibility)"
        r"|(?:does|do|is|has|have)\s+.{0,80}(?:ipa\s+delegation|delegation\s+clause|delegation\s+of\s+authority)"
        r"|(?:which|how\s+many)\s+(?:provider|active)"
        r"|(?:offset|dofr|ipa|stop[- ]?loss)\s+(?:status|clause|provision|protection)"
        r")\b",
        re.IGNORECASE,
    )

    # Financial value signals — questions asking for monetary values/thresholds
    # should go to rate_query, not be treated as clause existence questions.
    _FINANCIAL_VALUE_SIGNALS = re.compile(
        r"\b(?:threshold|amount|level|dollar|how much|what.*(?:cost|price|value|rate))"
        r"|\b(?:attachment\s+level|stop.?loss\s+(?:threshold|amount|limit|level|cap))"
        r"|\bwhat\s+(?:is|are)\s+the\s+(?:stop|attachment)",
        re.IGNORECASE,
    )

    def _is_profile_sql_question(self, q: str) -> bool:
        """Return True if this question should be routed to sql_query for
        a direct profile table lookup instead of corpus search.

        Triggers on:
        - Offset/DOFR/IPA clause status questions (has/doesn't have/how many)
        - Provider active/inactive status questions
        - LOB filtering/counting questions
        """
        # 1. Active/inactive status → always SQL
        if self._PROFILE_STATUS_SIGNALS.search(q):
            return True

        # 2. LOB counting/filtering → always SQL
        if self._PROFILE_LOB_SIGNALS.search(q):
            return True

        # 3. Offset/DOFR/IPA clause + existence-type question → SQL
        #    BUT NOT if asking for a financial VALUE (threshold, amount, level)
        if self._PROFILE_CLAUSE_CONCEPTS.search(q):
            # Guard: if asking for a specific value, this is a rate question
            if self._FINANCIAL_VALUE_SIGNALS.search(q):
                return False
            # Only if asking about status/existence (not asking for full text)
            if self._PROFILE_CLAUSE_QUESTION_SIGNALS.search(q):
                return True
            # Also route if asking "which providers" + clause concept
            if re.search(r"\b(?:which|how many|list|all|show|matrix|responsible)\b", q):
                return True

        # FIX-DELEG: IPA delegation FUNCTION queries → sql_query (queries tbl_delegation_matrix)
        # "Which functions does X delegate?" is a tbl_delegation_matrix query, not clause_existence.
        if re.search(
            r'\b(?:which|what|list|show)\s+(?:\w+\s+){0,5}(?:functions?|activities?|responsibilities?)'
            r'\s+(?:does|do|are)?\s*(?:\w+\s+){0,5}delegat',
            q, re.IGNORECASE,
        ) or re.search(
            r'delegated?\s+(?:functions?|activities?|responsibilities?)|'
            r'ipa\s+(?:delegation\s+)?(?:functions?|activities?)\b',
            q, re.IGNORECASE,
        ):
            return True

        return False

    # ── Override rules (ported from V2 Cell 4) ────────────────────────────

    _RATE_SIGNALS = (
        "rate", "rates", "per diem", "pmpm", "reimbursement",
        "cost per", "payment amount", "fee schedule",
        "rate schedule", "rate distribution",
    )
    _CLAUSE_PHRASES = (
        "which providers have", "which providers don't",
        "which contracts have", "which contracts don't",
        "does it have", "is there a", "do they have",
    )
    _EXTRACTION_SIGNALS = (
        "what is the", "what are the", "extract the", "show me the",
        "how many days", "how long", "notice period", "notice days",
        "what amount", "liability limit", "cure period", "retention period",
        "contract length", "term length", "effective date", "expiration date",
        "renewal length", "insurance required",
    )
    _VALUE_WORDS = (
        "days", "months", "years", "amount", "period", "date",
        "limit", "length", "how long", "how many",
    )
    _COMPARISON_CUE_WORDS = (
        "compare", " vs ", " versus ", "difference between", "how do", "how does",
    )

    _CE_RESCUE_RE = re.compile(
        r"\b("
        r"offset(?:\s+clause)?"
        r"|termination(?:\s+clause)?"
        r"|auto[\s-]?renewal"
        r"|stop[\s-]?loss"
        r"|indemnif\w+"
        r"|arbitration"
        r"|dofr"
        r"|division\s+of\s+financial\s+responsibility"
        r"|ipa\s+delegation"
        r"|delegation\s+of\s+authority"
        r"|confidential\w*"
        r"|non[\s-]?compete"
        r"|force\s+majeure"
        r"|assignment"
        r"|notification"
        r"|capitation"
        r"|withhold\w*"
        r"|recoup\w+"
        r"|audit(?:\s+right)?"
        r"|dispute"
        r"|grievance"
        r"|credentialing"
        r"|coordination\s+of\s+benefits"
        r"|subrogation"
        r"|reinsurance"
        r"|auto[\s-]?assignment"
        r"|hold\s+harmless"
        r")\b",
        re.IGNORECASE,
    )

    def _apply_overrides(self, routing: dict, question: str) -> dict:
        """Apply deterministic override rules (order-sensitive, V2-faithful).

        Override order:
        1. Validate route value.
        2. PROF-SQL — profile shortcut: clause_existence for offset/DOFR/IPA → sql_query.
        3. EXTR  — extraction-signal: clause_existence/explanation → field_extraction.
        4. Provider fill-in from detected list.
        5. CONSTR — comparison needs 2+ providers; single_provider needs ≥1.
        6. RE-1  — rate-signal rescue: clause_existence → rate_query.
        7. RE-2  — unresolvable comparison flag.
        8. CE-FIX — target_concept rescue for clause_existence.
        """
        q = question.lower()
        route = routing.get("route", _DEFAULT_ROUTE)

        # RATE-ESCALATOR GUARD: previously forced escalator questions → sql_query.
        # Removed 2026-07-20: financial_analysis now has a two-tier query for
        # tbl_rate_escalators (extraction_quality IN HIGH/MEDIUM, adj_pct IS NOT NULL,
        # sorted desc by adj_pct). Route financial_analysis OR rate_query through unchanged.
        # (sql_query SELECT * returned unfiltered formula_text dumps — PARTIAL result)

        # EXPIRY-ROUTE-FIX: Deterministic override — "contracts expiring in [timeframe]"
        # MUST route to sql_query (tbl_contract_documents_master has expiration_date).
        # The alert_queue only has notification entries ABOUT expirations, not the
        # canonical expiration data itself. This fires BEFORE Phase 10B overrides
        # because the LLM frequently misroutes these to risk_alert.
        _has_expiry_term = bool(re.search(r'\bexpir\w*\b', q))
        _has_timeframe = bool(re.search(
            r'\b(?:next|within|in|coming|this|over the next)\s+'
            r'(?:the\s+)?(?:next\s+|coming\s+)?(?:\d+\s*)?'
            r'(?:day|week|month|year|quarter)',
            q, re.IGNORECASE,
        )) or bool(re.search(
            r'\b(?:before|by)\s+(?:20\d{2}|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)',
            q, re.IGNORECASE,
        ))
        _is_alert_context = any(w in q for w in (
            "alert", "warning", "notification", "risk score", "alert queue",
        ))
        if _has_expiry_term and _has_timeframe and not _is_alert_context:
            routing["route"] = "sql_query"
            route = "sql_query"
            routing["_expiry_override"] = True

        # 0. Phase 10B deterministic keyword overrides — BEFORE LLM route validation.
        # These fire regardless of what the LLM returned, ensuring Phase 10B tools
        # are reached even when the LLM prompt lists only legacy routes.
        _OVERRIDE_EXCLUSIONS = (
            "rate", "per diem", "reimburs", "stop-loss", "carve-out",
            "offset clause", "dofr", "ipa delegation", "auto-renew",
        )  # Rate/profile questions should not override to compliance/network/etc.

        if route not in ("compliance_query", "risk_alert", "financial_analysis",
                         "system_membership", "clause_text", "provenance"):
            # Provenance first (most specific)
            if any(w in q for w in self._PROVENANCE_KEYWORDS):
                routing["route"] = "provenance"
                route = "provenance"
            # Compliance (regulatory regulations + quality programs)
            # EXCLUDE pure explanation questions ("what is", "explain", "describe")
            # that ask for a DEFINITION, not data retrieval
            elif any(w in q for w in self._COMPLIANCE_KEYWORDS) and not any(e in q for e in _OVERRIDE_EXCLUSIONS) and not any(exp in q for exp in ("what is ", "what are ", "explain ", "define ", "tell me what", "describe ", "what does")):
                routing["route"] = "compliance_query"
                route = "compliance_query"
            # Risk/alerts
            elif any(w in q for w in self._RISK_ALERT_KEYWORDS) and route not in ("rate_query", "sql_query", "financial_analysis"):
                routing["route"] = "risk_alert"
                route = "risk_alert"
            # Financial (spend/exposure/repricing) — not already rate_query.
            # DOFR guard: 'financial responsibility', 'hospital responsible', etc. are
            # DOFR party-assignment terms, NOT spend/exposure topics — keep as sql_query.
            elif (any(w in q for w in self._FINANCIAL_KEYWORDS)
                  and route != "rate_query"
                  and not any(t in q for t in (
                      "financial responsibility", "hospital responsible", "group responsible",
                      "health plan responsible", "hospital's financial", "responsible for services",
                      "who is responsible", "party responsible", "dofr", "division of financial",
                      # ESCALATOR GUARD: rate escalation clause questions → sql_query, not financial
                      "rate escalat", "escalation clause", "escalator clause", "escalator provision",
                  ))):
                routing["route"] = "financial_analysis"
                route = "financial_analysis"
            # System membership / geography
            elif any(w in q for w in self._NETWORK_KEYWORDS):
                routing["route"] = "system_membership"
                route = "system_membership"
            # Clause text (verbatim retrieval)
            elif any(w in q for w in self._CLAUSE_TEXT_KEYWORDS):
                routing["route"] = "clause_text"
                route = "clause_text"
        # ── End Phase 10B overrides ──────────────────────────────────────────

        # 1. Validate
        if route not in VALID_ROUTES:
            routing["route"] = _DEFAULT_ROUTE
            route = _DEFAULT_ROUTE

        # 2. PROF-SQL — redirect offset/DOFR/IPA/active/LOB to sql_query
        # A3-FIX: Also override system_membership when LLM misroutes "is X active?" questions
        if route in (_DEFAULT_ROUTE, "clause_existence", "single_provider", "system_membership"):
            if self._is_profile_sql_question(q):
                routing["route"] = "sql_query"
                route = "sql_query"
                # Inject is_active default: filter inactive providers unless
                # the question explicitly asks about them
                _asks_inactive = bool(re.search(
                    r"\b(?:inactive|not\s+active|historically|retired)\b", q
                ))
                routing["profile_active_filter"] = not _asks_inactive

        # 2b. A4-FIX: Multi-concept detection — when question asks about 2+ clause concepts
        # (e.g., "does X have offset, DOFR, and IPA?"), force sql_query and tag all concepts.
        # Without this, the router picks ONE concept and the tool only answers that one.
        _CLAUSE_CONCEPT_TOKENS = {
            "offset": "offset_clause_status",
            "dofr": "dofr_status",
            "division of financial": "dofr_status",
            "ipa": "ipa_delegation_status",
            "ipa delegation": "ipa_delegation_status",
            "auto.?renew": "auto_renewal",
        }
        _detected_concepts = []
        for _token, _col in _CLAUSE_CONCEPT_TOKENS.items():
            if re.search(r'\b' + _token + r'\b', q, re.IGNORECASE):
                if _col not in _detected_concepts:
                    _detected_concepts.append(_col)
        if len(_detected_concepts) >= 2:
            routing["route"] = "sql_query"
            route = "sql_query"
            routing["multi_concepts"] = _detected_concepts
            routing["target_concept"] = "multi_clause_status"

        # 3. EXTR — extraction-signal override
        if route in ("clause_existence", "explanation"):
            if any(sig in q for sig in self._EXTRACTION_SIGNALS):
                if any(w in q for w in self._VALUE_WORDS):
                    routing["route"] = "structured_extraction"
                    route = "structured_extraction"

        # 4. Provider fill-in — always prefer resolved canonical names from DB.
        # The LLM may return raw aliases like "Sharp HealthCare" which only
        # resolve to one facility; _detect_providers returns all matching
        # canonical names via ProviderService.resolve(). Only fall back to
        # the LLM's provider list when _detect_providers finds nothing.
        _detected = self._detect_providers(question)
        if _detected:
            routing["providers"] = _detected   # canonical names take precedence
        elif not routing.get("providers"):
            pass   # leave empty — no canonical match and LLM found nothing

        # 5. CONSTR
        if route == "comparison" and len(routing.get("providers") or []) < 2:
            routing["route"] = (
                "single_provider" if routing.get("providers") else _DEFAULT_ROUTE
            )
            route = routing["route"]

        if route == "single_provider" and not routing.get("providers"):
            routing["route"] = _DEFAULT_ROUTE
            route = _DEFAULT_ROUTE

        # 5b. RATE-SPECIFIC RESCUE — Force rate_query for stop-loss/carve-out/capitation
        # regardless of what route the LLM returned. These keywords are highly specific
        # and MUST reach rate_query's dedicated handlers (not provider_deep_dive/sql_query).
        if route not in ("rate_query", "sql_query") and any(kw in q for kw in (
            "stop-loss", "stop loss", "carve-out", "carve out", "carved out",
            "attachment level", "capitation", "pmpm", "per member per month",
        )):
            routing["route"] = "rate_query"
            route = "rate_query"

        # 5b. RATE-SPECIFIC RESCUE — Force rate_query when strong rate keywords present
        # regardless of what route the LLM returned (commonly "single_provider").
        # Exception: rate escalation already handled above (→ sql_query).
        _RATE_RESCUE_KW = (
            "stop-loss", "stop loss", "carve-out", "carve out", "carved out",
            "attachment level", "capitation", "pmpm", "per member per month",
            "per diem", "drg", "case rate", "fee schedule", "rate schedule",
            "reimbursement rate", "inpatient rate", "outpatient rate",
            "behavioral health rate", "rate for",
        )
        if route not in ("rate_query", "sql_query") and any(kw in q for kw in _RATE_RESCUE_KW):
            routing["route"] = "rate_query"
            route = "rate_query"

        # 6. RE-1 — rate-signal rescue (from _DEFAULT_ROUTE only)
        if route == _DEFAULT_ROUTE:
            if any(sig in q for sig in self._RATE_SIGNALS):
                if not any(cp in q for cp in self._CLAUSE_PHRASES):
                    routing["route"] = "rate_query"
                    route = "rate_query"

        # 7. RE-2 — unresolvable comparison
        if route == _DEFAULT_ROUTE:
            if any(cw in q for cw in self._COMPARISON_CUE_WORDS):
                if not routing.get("providers"):
                    routing["_unresolvable_comparison"] = True

        # 8. CE-FIX — target_concept rescue
        if route == _DEFAULT_ROUTE and not routing.get("target_concept"):
            m = self._CE_RESCUE_RE.search(question)
            if m:
                routing["target_concept"] = m.group(0).strip()
            if not routing.get("concepts") and routing.get("target_concept"):
                routing["concepts"] = [routing["target_concept"]]

        return routing

"""
ContextManager v2 — session context, entity resolution, and coreference.

Responsibilities:
  - Create a SessionContext from an AgentRequest
  - Resolve provider names against dim_provider_canonical
  - Resolve concept terms against known taxonomies
  - W9-21: Coreference resolution (pronouns/aliases → canonical provider names)
  - W9-21: Sliding window for multi-turn conversations
  - BUG-012: Multi-turn context tolerant of non-alternating messages

V2 enhancements over V1:
  - resolve_coreferences() maps pronouns/anaphora to the most recent
    canonical provider from conversation history
  - update_from_response() records completed turns into sliding window
  - Configurable window size (default 5 turns)
  - build_conversation_context() normalizes raw messages (BUG-012)
"""
from __future__ import annotations

import re
from typing import Any

from platform.v4.contracts.agent_types import AgentRequest
from platform.v4.contracts.context_types import (
    SessionContext, ResolvedEntity, WorkingData, ConversationTurn, SessionFact,
)
from platform.v4.config.settings import TBL_DIM_PROVIDER_CANONICAL, CATALOG, SCHEMA

# Known concept terms that map to contract clause categories.
# This list is a bootstrap set; v2 will load from dim_table_schema.
_KNOWN_CONCEPTS: dict[str, str] = {
    # Offset
    "offset": "offset_clause",
    "offset clause": "offset_clause",
    "overpayment": "offset_clause",
    "recoupment": "offset_clause",
    # DOFR
    "dofr": "dofr",
    "division of financial responsibility": "dofr",
    # IPA
    "ipa": "ipa_delegation",
    "ipa delegation": "ipa_delegation",
    "utilization management": "ipa_delegation",
    # Stop loss
    "stop loss": "stop_loss",
    "stop-loss": "stop_loss",
    # Auto renewal
    "auto renewal": "auto_renewal",
    "automatic renewal": "auto_renewal",
    "evergreen": "auto_renewal",
    # Capitation
    "capitation": "capitation",
    "pmpm": "capitation",
    # Termination
    "termination without cause": "termination_without_cause",
    "termination for convenience": "termination_without_cause",
    # Encounters
    "encounters": "encounters_reconciliation",
    "encounter reconciliation": "encounters_reconciliation",
}

# ---------------------------------------------------------------------------
# W9-21: Coreference patterns
# ---------------------------------------------------------------------------

_PROVIDER_COREFERENCE_PATTERNS: list[re.Pattern] = [
    re.compile(r"\b(?:that|this|the)\s+(?:provider|hospital|facility|group|health\s*system)\b", re.I),
    re.compile(r"\b(?:they|them|their|its)\b", re.I),
    re.compile(r"\bsame\s+(?:provider|hospital|facility)\b", re.I),
    # W9-22 fix: "those/these" referring to results from a prior turn
    # e.g. "those amendments", "those filenames", "those contracts"
    re.compile(r"\b(?:those|these)\s+(?:amendments?|contracts?|documents?|rates?|clauses?|files?|filenames?|providers?|records?|items?)\b", re.I),
    # MT-COREF-FIX: bare comparison pronouns — "compare those to X", "those vs X"
    re.compile(r"\bcompare\s+(?:those|them|it|these)\b|\b(?:those|them)\s+(?:to|vs\.?|versus|with|against)\b", re.I),
]

_CONCEPT_CONTINUATION_PATTERNS: list[re.Pattern] = [
    re.compile(r"\b(?:what about|how about|and)\s+(?:the|their|its)\s+", re.I),
]

DEFAULT_WINDOW_SIZE: int = 15  # P1-8 fix (2026-07-05): extended from 5 to 15 for multi-turn coherence

# Roles that are filtered from conversation context (non-conversational)
_NON_CONVERSATIONAL_ROLES: frozenset[str] = frozenset({
    "system", "status", "tool", "function", "internal", "heartbeat",
})


# ---------------------------------------------------------------------------
# BUG-012: Multi-turn context normalization utility
# ---------------------------------------------------------------------------

def build_conversation_context(messages: list[dict], max_turns: int = 10) -> list[dict]:
    """
    Build LLM-ready conversation context tolerant of non-alternating messages.

    Handles the following real-world issues:
      - System/status/tool messages interspersed (filtered out)
      - Duplicate messages from retries (deduplicated)
      - Consecutive same-role messages (merged with newline separator)
      - Empty content messages (skipped)

    Parameters
    ----------
    messages : Raw message list from API/frontend. Each dict must have
               'role' and 'content' keys.
    max_turns : Maximum number of turns to retain (default 10, keeps last N).

    Returns
    -------
    Normalized list of alternating user/assistant messages, ready for LLM.
    """
    if not messages:
        return []

    context: list[dict] = []
    seen_content: set[str] = set()  # Track (role, content) for dedup

    for msg in messages:
        role = msg.get("role", "user")
        content = (msg.get("content") or "").strip()

        # Skip non-conversational roles
        if role in _NON_CONVERSATIONAL_ROLES:
            continue

        # Skip empty content
        if not content:
            continue

        # Normalize role: anything not "assistant" becomes "user"
        normalized_role = "assistant" if role == "assistant" else "user"

        # Deduplicate exact (role, content) pairs (retries / duplicate POSTs)
        dedup_key = f"{normalized_role}:{content}"
        if dedup_key in seen_content:
            continue
        seen_content.add(dedup_key)

        # Merge consecutive same-role messages instead of breaking alternation
        if context and context[-1]["role"] == normalized_role:
            context[-1]["content"] += "\n" + content
        else:
            context.append({"role": normalized_role, "content": content})

    # Keep only the most recent turns
    if max_turns <= 0:
        return []
    return context[-max_turns:]


def deduplicate_session_rows(rows: list[dict]) -> list[dict]:
    """
    Deduplicate session rows by (question, answer) key.

    When the front-end retries or timeout causes duplicate POSTs,
    the same question may appear multiple times in tbl_agent_sessions.
    This keeps only the LAST occurrence of each (question, answer) pair
    (most complete/recent response).

    Parameters
    ----------
    rows : Session rows ordered by created_at ASC.

    Returns
    -------
    Deduplicated rows, preserving chronological order.
    """
    if not rows:
        return []

    # Walk backwards to prefer the latest version of each turn
    seen_keys: set[str] = set()
    unique_reversed: list[dict] = []

    for row in reversed(rows):
        question = (row.get("question") or "").strip()
        # Use question as the dedup key — same question in same session = retry
        key = question.lower()
        if key and key not in seen_keys:
            seen_keys.add(key)
            unique_reversed.append(row)
        elif not key:
            # Keep rows with empty questions (edge case: system-generated)
            unique_reversed.append(row)

    # Restore chronological order
    return list(reversed(unique_reversed))


class ContextManager:
    """
    Creates and updates SessionContext objects.

    Injected with a Spark session at construction time so it can query
    dim_provider_canonical. Falls back to empty resolution if no Spark
    session is available (testing mode).
    """

    def __init__(self, spark: Any = None, window_size: int = DEFAULT_WINDOW_SIZE, llm_client: Any = None):
        self._spark = spark
        self._provider_cache: dict[str, list[dict]] | None = None
        self._window_size = window_size
        self._llm_client = llm_client  # Optional: for LLM-enhanced coreference (W9-21)

    # ── Public convenience API (aliases used in tests and notebooks) ──────────

    def resolve(self, provider_name: str):
        """
        Resolve a provider name string.

        Checks _canonical_cache first (set via set_provider_cache or direct assignment),
        then falls back to _resolve_provider (which queries dim_provider_canonical).

        Returns the matched CanonicalProvider / ResolvedEntity, or None.
        """
        key = provider_name.strip().lower()
        cache = getattr(self, "_canonical_cache", {})
        if key in cache:
            return cache[key]
        # partial match in cache
        for cached_key, cached_val in cache.items():
            if key in cached_key or cached_key in key:
                return cached_val
        return self._resolve_provider(provider_name)

    def set_provider_cache(self, cache: dict) -> None:
        """
        Set the canonical provider lookup cache.
        Keys are lowercased provider name strings; values are CanonicalProvider objects.
        """
        self._canonical_cache = {k.lower(): v for k, v in cache.items()}
        # Also sync to the row-based cache so _resolve_provider isn't queried
        rows = []
        for key, cp in cache.items():
            # CanonicalProvider repr leak fix: CanonicalProvider (adapters/provider_adapter.py)
            # exposes `.provider_name`, NOT `.canonical_name`. The old check only looked for
            # `.canonical_name` and fell back to str(cp), which for a dataclass produces its
            # default repr (e.g. "CanonicalProvider(provider_id='...', provider_name='...',
            # is_active='', line_of_business='')"). That corrupted string then propagated as
            # `canonical_form` through _resolve_provider() into request.provider_hint,
            # contaminating downstream SQL generation. Check both attribute names before
            # falling back to str().
            if hasattr(cp, "canonical_name"):
                cn = cp.canonical_name
            elif hasattr(cp, "provider_name"):
                cn = cp.provider_name
            else:
                cn = str(cp)
            pid  = cp.provider_id    if hasattr(cp, "provider_id")    else ""
            rows.append({"canonical_name": cn, "provider_ids": [pid], "all_names_used": [key]})
        self._provider_cache = rows

    def resolve_concept(self, mention: str):
        """
        Resolve a concept mention to its canonical category string.
        Returns the canonical form string, or None if not recognised.
        """
        entity = self._resolve_concept(mention)
        return entity.canonical_form if entity else None

    def create_session(self, request: AgentRequest) -> SessionContext:
        """
        Build a fresh SessionContext from an AgentRequest.
        Performs entity resolution synchronously.
        """
        ctx = SessionContext(
            session_id=request.session_id,
            question=request.question,
            working_data=WorkingData(),
            flags=request.feature_flags.copy(),
        )

        # Provider hint from caller
        if request.provider_hint:
            entity = self._resolve_provider(request.provider_hint)
            if entity:
                ctx.add_entity(entity)

        # Concept hint from caller
        if request.concept_hint:
            concept = self._resolve_concept(request.concept_hint)
            if concept:
                ctx.add_entity(concept)

        # Auto-extract entities from the question text
        for entity in self._extract_from_question(request.question):
            ctx.add_entity(entity)

        return ctx

    def continue_session(
        self,
        ctx: SessionContext,
        new_question: str,
        prev_answer: str = "",
    ) -> SessionContext:
        """
        W9-21: Continue an existing session with a new follow-up question.

        Records the previous turn, applies coreference resolution for
        the new question, and returns the updated context.
        """
        # Record completed turn into sliding window
        self._record_turn(ctx, prev_answer)

        # Reset for new turn
        ctx.question = new_question
        ctx.working_data = WorkingData()
        ctx.resolved_entities = []
        ctx.turn_count += 1

        # Resolve coreferences from conversation history
        coref_entities = self._resolve_coreferences(new_question, ctx)
        for entity in coref_entities:
            ctx.add_entity(entity)

        # Standard entity extraction on the new question
        for entity in self._extract_from_question(new_question):
            ctx.add_entity(entity)

        return ctx

    # ── W9-21: Coreference Resolution ─────────────────────────────────────────

    def _resolve_coreferences(self, question: str, ctx: SessionContext) -> list[ResolvedEntity]:
        """Resolve pronouns/anaphora to the most recent provider from history."""
        entities: list[ResolvedEntity] = []

        has_provider_coref = any(
            pattern.search(question) for pattern in _PROVIDER_COREFERENCE_PATTERNS
        )
        if has_provider_coref:
            recent_providers = ctx.last_providers(n_turns=3)
            if recent_providers:
                entity = self._resolve_provider(recent_providers[0])
                if entity:
                    entity.resolution_method = "coreference"
                    entity.confidence = 0.85
                    entity.raw_mention = question.strip()
                    entities.append(entity)

        has_concept_coref = any(
            pattern.search(question) for pattern in _CONCEPT_CONTINUATION_PATTERNS
        )
        if has_concept_coref and not ctx.get_concepts():
            recent_concepts = ctx.last_concepts(n_turns=2)
            if recent_concepts:
                entities.append(ResolvedEntity(
                    raw_mention=question.strip(),
                    canonical_form=recent_concepts[0],
                    entity_type="concept",
                    confidence=0.80,
                    resolution_method="coreference",
                ))

        # Implicit carryforward: no pronouns, no explicit provider, short follow-up
        if not has_provider_coref and not entities:
            explicit_providers = self._extract_provider_mentions(question)
            if not explicit_providers:
                recent = ctx.last_providers(n_turns=1)
                if recent and self._is_follow_up_question(question):
                    entity = self._resolve_provider(recent[0])
                    if entity:
                        entity.resolution_method = "implicit_carryforward"
                        entity.confidence = 0.70
                        entities.append(entity)
                    elif recent[0]:
                        # Prior turn had an unresolved provider (e.g. payer
                        # "Kaiser Permanente" — not in canonical table). Carry the raw
                        # mention forward so the routing can apply payer-refusal.
                        from platform.v4.contracts.context_types import ResolvedEntity as _RE
                        entity = _RE(
                            raw_mention=recent[0],
                            canonical_form=recent[0],
                            entity_type="provider",
                            provider_ids=[],   # empty → VPE unresolved path
                            confidence=0.60,
                            resolution_method="implicit_carryforward_unresolved",
                        )
                        entities.append(entity)

        # W9-21: LLM fallback for ambiguous references
        if not entities:
            llm_entities = self._resolve_coreference_llm(question, ctx)
            entities.extend(llm_entities)

        return entities

    def _is_follow_up_question(self, question: str) -> bool:
        """Heuristic: is this question likely a follow-up?"""
        q = question.strip().lower()
        follow_up_starters = (
            "what about", "how about", "and ", "also ", "additionally",
            "what's", "what is", "what are", "show me", "tell me",
            "can you", "do they", "does it", "is there",
        )
        return any(q.startswith(s) for s in follow_up_starters) or len(q.split()) <= 6

    def _resolve_coreference_llm(self, question: str, ctx: SessionContext) -> list[ResolvedEntity]:
        """
        W9-21: LLM-enhanced coreference for ambiguous references.

        Uses a fast/cheap model (Haiku-class) to resolve references that
        regex patterns miss. Examples:
          - "the one we discussed earlier" → last discussed provider
          - "that contract" → provider from prior turn
          - "compared to the first one" → earlier provider in conversation

        Only called when:
          1. llm_client is available
          2. Regex coreference found nothing
          3. Question appears to reference prior context
        """
        if not self._llm_client:
            return []

        # Only invoke LLM for ambiguous referential questions
        referential_signals = (
            "the one", "that one", "the first", "the second", "earlier",
            "the previous", "we discussed", "you mentioned", "compared to",
        )
        q_lower = question.lower()
        if not any(signal in q_lower for signal in referential_signals):
            return []

        # Build conversation context for the LLM
        history_lines = []
        for turn in ctx.conversation_history[-3:]:
            providers = turn.get_providers()
            concepts = turn.get_concepts()
            history_lines.append(
                f"Turn: \"{turn.question}\" → providers: {providers}, concepts: {concepts}"
            )
        if not history_lines:
            return []

        system_prompt = (
            "You resolve coreferences in healthcare contract questions. "
            "Given conversation history and a new question, identify which "
            "provider or concept the user is referring to. "
            "Respond with ONLY the canonical provider name, or NONE if unclear."
        )
        _history_text = '\n'.join(history_lines)
        user_prompt = (
            f"History:\n{_history_text}\n\n"
            f"New question: \"{question}\"\n\n"
            f"Which provider is the user referring to?"
        )

        try:
            response = self._llm_client.chat(
                model="databricks-claude-haiku",
                system=system_prompt,
                user=user_prompt,
                max_tokens=50,
            )
            resolved_name = response.strip().strip('"').strip("'")
            if resolved_name and resolved_name.upper() != "NONE":
                entity = self._resolve_provider(resolved_name)
                if entity:
                    entity.resolution_method = "llm_coreference"
                    entity.confidence = 0.80
                    entity.raw_mention = question.strip()
                    return [entity]
        except Exception:
            pass  # LLM failure is non-fatal; fall through to empty

        return []

    def _extract_provider_mentions(self, question: str) -> list[str]:
        """Check if question contains an explicit known provider name.

        Enhanced matching (SESSION-COREF-FIX):
          1. Exact canonical name in question (original)
          2. Any alias from all_names_used in question
          3. Reverse match: short provider token (>=6 chars) in canonical name
             e.g. "stanford" in q matches "Stanford Health Care" canonical
        """
        q_lower = question.lower()
        rows = self._get_provider_rows()
        found = []
        found_lower = set()
        for row in rows:
            cn = row["canonical_name"].lower()
            # 1. Exact canonical name in question
            if cn in q_lower:
                if cn not in found_lower:
                    found.append(row["canonical_name"])
                    found_lower.add(cn)
                continue
            # 2. Alias match (all_names_used)
            aliases = [a.lower() for a in (row.get("all_names_used") or [])]
            for alias in aliases:
                if alias in q_lower and alias not in found_lower:
                    found.append(row["canonical_name"])
                    found_lower.add(cn)
                    break
            if cn in found_lower:
                continue
            # 3. Reverse match: question word appears as start of canonical name
            #    (min 6 chars to avoid false positives like "st", "mercy")
            import re as _re_extract
            for token in _re_extract.findall(r'\b[a-z]{6,}\b', q_lower):
                if cn.startswith(token) and token not in (
                    'hospital', 'medical', 'center', 'health', 'community',
                    'regional', 'memorial', 'general', 'national', 'southern',
                    'northern', 'western', 'eastern', 'pacific', 'valley',
                ):
                    found.append(row["canonical_name"])
                    found_lower.add(cn)
                    break
        return found

    # ── W9-21: Sliding Window Management ──────────────────────────────────────

    def _record_turn(self, ctx: SessionContext, answer: str) -> None:
        """Record a completed turn into sliding window; evict oldest if over limit."""
        # Extract session facts from the answer
        facts = self._extract_session_facts(answer, ctx)

        turn = ConversationTurn(
            question=ctx.question,
            answer_preview=answer[:2000] if answer else "",  # P0-4: 2000 chars to preserve numbered option lists
            resolved_entities=list(ctx.resolved_entities),
            cost=ctx.cumulative_cost,
            facts=facts,
        )
        ctx.conversation_history.append(turn)

        # Add facts to session-level working memory
        for fact in facts:
            ctx.add_fact(fact)

        # Evict + summarize if over window size
        if len(ctx.conversation_history) > self._window_size:
            evicted = ctx.conversation_history[:-self._window_size]
            ctx.history_summary = self._summarize_evicted_turns(evicted, ctx.history_summary)
            ctx.conversation_history = ctx.conversation_history[-self._window_size:]

    # ── W9-21: Session Fact Extraction ─────────────────────────────────────────

    def _extract_session_facts(self, answer: str, ctx: SessionContext) -> list[SessionFact]:
        """Extract key facts from an answer for working memory."""
        if not answer:
            return []

        facts: list[SessionFact] = []
        providers = ctx.get_providers()
        concepts = ctx.get_concepts()
        provider = providers[0] if providers else ""
        concept = concepts[0] if concepts else ""
        turn_num = ctx.turn_count

        # Extract rate/dollar amounts
        import re
        rate_matches = re.findall(
            r'\$([\d,]+(?:\.\d+)?)\s*(?:per\s+diem|per\s+day|pmpm|per\s+month)?',
            answer, re.IGNORECASE
        )
        for rate in rate_matches[:3]:  # Max 3 rates per turn
            facts.append(SessionFact(
                fact_type="rate",
                content=f"Rate: ${rate}",
                provider=provider,
                concept=concept,
                turn_number=turn_num,
            ))

        # Extract counts/quantities
        count_matches = re.findall(
            r'(\d+)\s+(?:providers?|contracts?|amendments?|documents?|clauses?)',
            answer, re.IGNORECASE
        )
        for count in count_matches[:2]:
            facts.append(SessionFact(
                fact_type="count",
                content=f"Count: {count}",
                provider=provider,
                turn_number=turn_num,
            ))

        # Extract clause status claims — check negation FIRST
        no_match = re.search(
            r"(?:does not|doesn't|do not|don't)\s+have\s+(?:an?\s+)?(\w+\s+clause)",
            answer, re.IGNORECASE
        )
        if no_match:
            facts.append(SessionFact(
                fact_type="clause_status",
                content=f"NO {no_match.group(1)}",
                provider=provider,
                concept=concept,
                turn_number=turn_num,
            ))
        else:
            # Only check for positive HAS if no negation found
            has_match = re.search(
                r'(?:has|have|contains?|includes?)\s+(?:an?\s+)?(\w+\s+clause)',
                answer, re.IGNORECASE
            )
            if has_match:
                facts.append(SessionFact(
                    fact_type="clause_status",
                    content=f"HAS {has_match.group(1)}",
                    provider=provider,
                    concept=concept,
                    turn_number=turn_num,
                ))

        # Extract date facts
        date_matches = re.findall(
            r'(?:effective|amended|expires?|terminat\w+)\s+(?:on\s+|date\s+)?(\w+\s+\d{1,2},?\s+\d{4}|\d{4}-\d{2}-\d{2})',
            answer, re.IGNORECASE
        )
        for date_str in date_matches[:2]:
            facts.append(SessionFact(
                fact_type="date",
                content=f"Date: {date_str}",
                provider=provider,
                turn_number=turn_num,
            ))

        return facts

    # ── W9-21: Turn Summarization ──────────────────────────────────────────────

    @staticmethod
    def _summarize_evicted_turns(evicted: list[ConversationTurn], existing_summary: str) -> str:
        """Compress evicted turns into a summary string for context retention."""
        if not evicted:
            return existing_summary

        # Build compact summary from evicted turns
        new_parts = []
        for turn in evicted:
            providers = turn.get_providers()
            concepts = turn.get_concepts()
            q_preview = turn.question[:60]
            parts = [f"Q: {q_preview}"]
            if providers:
                parts.append(f"(providers: {', '.join(providers[:2])})")
            if concepts:
                parts.append(f"(topics: {', '.join(concepts[:2])})")
            new_parts.append(" ".join(parts))

        new_summary = "; ".join(new_parts)

        # Append to existing summary, cap at 500 chars
        if existing_summary:
            combined = f"{existing_summary}; {new_summary}"
        else:
            combined = new_summary

        if len(combined) > 500:
            combined = combined[-500:]
            # Clean up: start from first complete segment
            first_semi = combined.find(";")
            if first_semi > 0:
                combined = combined[first_semi + 2:]

        return combined

    # ── Provider resolution ───────────────────────────────────────────────────

    def _resolve_provider(self, mention: str) -> ResolvedEntity | None:
        """
        Attempt to resolve a provider name string against dim_provider_canonical.
        Returns None if no match is found.
        """
        mention_clean = mention.strip().lower()
        rows = self._get_provider_rows()

        # 1. Exact canonical name match
        for row in rows:
            if row["canonical_name"].lower() == mention_clean:
                return ResolvedEntity(
                    raw_mention=mention,
                    canonical_form=row["canonical_name"],
                    entity_type="provider",
                    provider_ids=row["provider_ids"],
                    confidence=1.0,
                    resolution_method="exact",
                )

        # 2. Alias match (all_names_used column)
        for row in rows:
            aliases = [a.lower() for a in (row.get("all_names_used") or [])]
            if mention_clean in aliases:
                return ResolvedEntity(
                    raw_mention=mention,
                    canonical_form=row["canonical_name"],
                    entity_type="provider",
                    provider_ids=row["provider_ids"],
                    confidence=0.95,
                    resolution_method="alias",
                )

        # 3. Substring fuzzy match
        for row in rows:
            if mention_clean in row["canonical_name"].lower() or \
               row["canonical_name"].lower() in mention_clean:
                return ResolvedEntity(
                    raw_mention=mention,
                    canonical_form=row["canonical_name"],
                    entity_type="provider",
                    provider_ids=row["provider_ids"],
                    confidence=0.75,
                    resolution_method="fuzzy",
                )

        return None

    def _resolve_concept(self, mention: str) -> ResolvedEntity | None:
        """Resolve a concept term to its canonical category."""
        key = mention.strip().lower()
        canonical = _KNOWN_CONCEPTS.get(key)
        if not canonical:
            # Partial match
            for k, v in _KNOWN_CONCEPTS.items():
                if k in key or key in k:
                    canonical = v
                    break
        if canonical:
            return ResolvedEntity(
                raw_mention=mention,
                canonical_form=canonical,
                entity_type="concept",
                confidence=1.0 if mention.strip().lower() in _KNOWN_CONCEPTS else 0.80,
                resolution_method="taxonomy_lookup",
            )
        return None

    def _extract_from_question(self, question: str) -> list[ResolvedEntity]:
        """
        Heuristically extract provider and concept mentions from free text.
        This is a lightweight bootstrap; v2 will use LLM entity extraction.
        """
        entities = []
        q_lower = question.lower()

        # Provider extraction — scan question for known canonical names / aliases
        found_provider_names = self._extract_provider_mentions(question)
        for pname in found_provider_names[:3]:  # cap at 3 per question
            entity = self._resolve_provider(pname)
            if entity:
                entities.append(entity)

        # Concept extraction — check all known concepts
        for term, canonical in _KNOWN_CONCEPTS.items():
            if term in q_lower:
                entities.append(ResolvedEntity(
                    raw_mention=term,
                    canonical_form=canonical,
                    entity_type="concept",
                    confidence=0.90,
                    resolution_method="keyword_scan",
                ))
                break  # One concept per extraction pass (v2 will handle multi-concept)

        return entities

    def _get_provider_rows(self) -> list[dict]:
        """
        Load provider canonical rows. Cached in-memory for the session.
        Returns empty list if Spark is not available.
        """
        if self._provider_cache is not None:
            return self._provider_cache

        if self._spark is None:
            self._provider_cache = []
            return self._provider_cache

        try:
            df = self._spark.sql(
                f"SELECT provider_id, canonical_name, all_names_used "
                f"FROM {TBL_DIM_PROVIDER_CANONICAL}"
            )
            # Group by canonical_name to collect all provider_ids
            from collections import defaultdict
            grouped: dict[str, dict] = defaultdict(lambda: {"provider_ids": [], "all_names_used": []})
            for row in df.collect():
                cn = row["canonical_name"]
                grouped[cn]["canonical_name"] = cn
                grouped[cn]["provider_ids"].append(str(row["provider_id"]))
                names = row["all_names_used"]
                if isinstance(names, (list, tuple)):
                    grouped[cn]["all_names_used"].extend(names)
                elif isinstance(names, str) and names:
                    grouped[cn]["all_names_used"].append(names)
            self._provider_cache = list(grouped.values())
        except Exception:
            self._provider_cache = []

        return self._provider_cache

    # ── W9-22: Session Persistence Bridge ─────────────────────────────────────

    def resume_session(
        self,
        session_id: str,
        new_question: str,
        rows: list[dict],
    ) -> SessionContext:
        """
        Resume an existing session from stored rows (loaded via SessionRepo).

        Reconstructs ConversationTurn history from prior rows, then applies
        coreference resolution for the new question.

        BUG-012 fix: Deduplicates rows by question key before rebuilding
        history, preventing corrupted context from duplicate POSTs or retries.

        Parameters
        ----------
        session_id : The existing session identifier.
        new_question : The new user question to process.
        rows : Rows from tbl_agent_sessions for this session_id, ordered by
               created_at ASC.

        Returns
        -------
        SessionContext with history populated and new question resolved.
        """
        # BUG-012: Deduplicate rows before rebuilding history
        clean_rows = deduplicate_session_rows(rows)

        ctx = SessionContext(
            session_id=session_id,
            question=new_question,
            turn_count=len(clean_rows) + 1,
        )

        # Rebuild conversation history from stored rows
        for row in clean_rows:
            entities = self._deserialize_entities(row.get("resolved_entities_json"))

            # W9-22 fix: production _persist_turn never sets resolved_entities_json
            # (field defaults to None). Recover provider context from the stored
            # question text so last_providers() and implicit carryforward work.
            if not entities:
                q_text = row.get("question", "")
                mentions = self._extract_provider_mentions(q_text) if q_text else []
                for mention in mentions[:1]:  # at most 1 provider per turn
                    recovered = self._resolve_provider(mention)
                    if recovered:
                        recovered.resolution_method = "question_text_recovery"
                        recovered.confidence = 0.75
                        entities = [recovered]
                        break
                    # Unresolved mention (e.g. payer "Kaiser Permanente")
                    # Store as passthrough entity so last_providers() returns it
                    # and the next turn can carry the payer context forward.
                    from platform.v4.contracts.context_types import ResolvedEntity as _RE
                    entities = [_RE(
                        raw_mention=mention,
                        canonical_form=mention,
                        entity_type="provider",
                        provider_ids=[],   # empty → VPE will flag as unresolved/payer
                        confidence=0.55,
                        resolution_method="question_text_recovery_passthrough",
                    )]
                    break  # only first mention

            turn = ConversationTurn(
                question=row.get("question", ""),
                answer_preview=(row.get("answer") or "")[:1200],  # BUG-6-FIX: 1200 chars preserves agent suggestions like "If you'd like to compare X vs Y, I can run that"
                resolved_entities=entities,
                cost=row.get("total_cost", 0.0) or 0.0,
            )
            ctx.conversation_history.append(turn)

        # Apply sliding window (only keep recent turns)
        if len(ctx.conversation_history) > self._window_size:
            evicted = ctx.conversation_history[:-self._window_size]
            ctx.history_summary = self._summarize_evicted_turns(evicted, ctx.history_summary)
            ctx.conversation_history = ctx.conversation_history[-self._window_size:]

        # Resolve coreferences for the new question using history
        coref_entities = self._resolve_coreferences(new_question, ctx)
        for entity in coref_entities:
            ctx.add_entity(entity)

        # Standard entity extraction
        for entity in self._extract_from_question(new_question):
            ctx.add_entity(entity)

        return ctx

    def serialize_entities(self, entities: list[ResolvedEntity]) -> str:
        """Serialize resolved entities to JSON for storage."""
        import json
        return json.dumps([
            {
                "raw_mention": e.raw_mention,
                "canonical_form": e.canonical_form,
                "entity_type": e.entity_type,
                "provider_ids": e.provider_ids,
                "confidence": e.confidence,
                "resolution_method": e.resolution_method,
            }
            for e in entities
        ])

    @staticmethod
    def _deserialize_entities(json_str: str | None) -> list[ResolvedEntity]:
        """Deserialize resolved entities from stored JSON."""
        if not json_str:
            return []
        import json
        try:
            items = json.loads(json_str)
            return [
                ResolvedEntity(
                    raw_mention=item.get("raw_mention", ""),
                    canonical_form=item.get("canonical_form", ""),
                    entity_type=item.get("entity_type", "provider"),
                    provider_ids=item.get("provider_ids", []),
                    confidence=item.get("confidence", 0.0),
                    resolution_method=item.get("resolution_method", "stored"),
                )
                for item in items
            ]
        except (json.JSONDecodeError, TypeError):
            return []

"""
platform/v4/core/hallucination_guard.py

Hallucination detection and mitigation for V3 agent responses.

Checks applied (in order)
--------------------------
1. Numeric consistency — does the answer reference numbers that appear
   in the cited source passages?
2. Provider identity — does the answer name providers that were resolved
   in the session context?
3. Date plausibility — are dates in the answer within a reasonable range?
4. Ungrounded assertion detection — sentences with high specificity but
   zero citation support are flagged.
5. Confidence floor — if citations are empty or all UNVERIFIED, cap
   confidence to MODERATE regardless of what the LLM claimed.

Design notes
------------
- This guard operates on the final answer string + supporting tool results.
- It does NOT call the LLM (cost = 0).
- It is permissive by default: flag and warn rather than block, because
  false positives on valid answers are worse than allowing some hallucinations
  through (which are caught by the citation verification layer).
- Results are attached to the AgentResponse as metadata, not surfaced to users
  directly (unless the UI layer chooses to display them).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional

from ..contracts.tool_types import Confidence, ToolResult


# ---------------------------------------------------------------------------
# Number extraction helpers
# ---------------------------------------------------------------------------

_NUMBER_RE   = re.compile(r"\$?\d+(?:[,.]\d+)*%?")
_YEAR_RE     = re.compile(r"\b(?:1[89]|20)\d{2}\b")
_DATE_RE     = re.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b")


def _extract_numbers(text: str) -> set[str]:
    """Return the set of all numeric tokens in text (normalised, no $/%/)."""
    raw = _NUMBER_RE.findall(text)
    return {re.sub(r"[^\d.]", "", n) for n in raw if re.sub(r"[^\d.]", "", n)}


def _extract_years(text: str) -> set[int]:
    return {int(y) for y in _YEAR_RE.findall(text)}


# ---------------------------------------------------------------------------
# Finding dataclass
# ---------------------------------------------------------------------------

@dataclass
class GuardFinding:
    """One hallucination-risk finding."""
    check:    str           # e.g. "numeric_mismatch", "ungrounded_provider"
    severity: str           # WARN | BLOCK
    detail:   str
    flagged_text: str = ""


@dataclass
class GuardResult:
    """Result of running all hallucination checks."""
    passed:       bool
    findings:     list[GuardFinding] = field(default_factory=list)
    adjusted_confidence: Optional[str] = None   # if lowered by a finding
    notes:        str = ""

    @property
    def has_blocks(self) -> bool:
        return any(f.severity == "BLOCK" for f in self.findings)

    @property
    def has_warnings(self) -> bool:
        return any(f.severity == "WARN" for f in self.findings)

    def summary(self) -> str:
        if not self.findings:
            return "All hallucination checks passed"
        parts = [f"[{f.severity}] {f.check}: {f.detail}" for f in self.findings]
        return "; ".join(parts)


# ---------------------------------------------------------------------------
# HallucinationGuard
# ---------------------------------------------------------------------------

# Known non-BSC providers that should NEVER appear as having BSC contract data
_NON_BSC_PROVIDER_BLOCKLIST = {
    "kaiser permanente", "kaiser", "aetna", "unitedhealth", "united healthcare",
    "cigna", "humana", "anthem", "molina", "centene", "wellcare",
    "oscar health", "ambetter", "tricare", "veterans affairs",
}


class HallucinationGuard:
    """
    Runs a battery of lightweight hallucination-risk checks on agent output.

    Usage
    -----
    guard  = HallucinationGuard()
    result = guard.check(
        answer=response.answer,
        citations=response.citations,
        tool_results=tool_results,
        context=session_context,
    )
    if result.adjusted_confidence:
        response.confidence = result.adjusted_confidence
    """

    def __init__(self, strict: bool = False) -> None:
        """
        Parameters
        ----------
        strict : If True, upgrade WARN findings to BLOCK severity.
        """
        self._strict = strict

    def check(
        self,
        answer:       str,
        citations:    list[dict],
        tool_results: Optional[list[ToolResult]] = None,
        context:      Optional[Any]              = None,   # SessionContext
        known_providers: Optional[set[str]]      = None,
    ) -> GuardResult:
        """
        Run all checks.

        Parameters
        ----------
        answer          : The assembled answer text.
        citations       : Citation dicts from the response.
        tool_results    : All ToolResult objects from the agent steps.
        context         : Session context (optional, for provider validation).
        known_providers : Set of canonical provider names in scope (optional).
        """
        findings: list[GuardFinding] = []

        # Check 1: Confidence floor (no citations = can't be HIGH)
        findings.extend(self._check_confidence_floor(answer, citations, tool_results))

        # Check 2: Numeric consistency
        findings.extend(self._check_numeric_grounding(answer, citations, tool_results))

        # Check 3: Provider name grounding
        if known_providers:
            findings.extend(self._check_provider_names(answer, known_providers))

        # Check 4: Date plausibility
        findings.extend(self._check_date_plausibility(answer))

        # Check 5: Non-BSC provider blocklist (fires even without known_providers)
        findings.extend(self._check_non_bsc_providers(answer))

        # Check 6: Universality-claim guard (GQ-ADV-08 fix)
        # Catches "all N providers have X" / "every provider has X" when the
        # claim is not supported by a SQL COUNT result in the tool data.
        # The numeric grounding check misses 3-digit provider counts (≤4 chars).
        findings.extend(self._check_universality_claim(answer, tool_results))

        # Check 7: Same-provider cross-dimensional claim guard (GQ-MH-05 fix)
        # Catches "same provider [verb] both/also" assertions in multi-hop
        # ranking answers where no single provider is proven to top all dims.
        findings.extend(self._check_same_provider_claim(answer, tool_results))

        # Derive adjusted confidence
        adjusted = self._adjust_confidence(findings, citations)
        passed   = not any(f.severity == "BLOCK" for f in findings)

        return GuardResult(
            passed=passed,
            findings=findings,
            adjusted_confidence=adjusted,
        )

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    def _check_confidence_floor(
        self,
        answer:       str,
        citations:    list[dict],
        tool_results: Optional[list[ToolResult]],
    ) -> list[GuardFinding]:
        """If no citations at all, flag a warning."""
        if not citations and not self._has_sql_data(tool_results):
            return [GuardFinding(
                check    = "no_citations",
                severity = "WARN",
                detail   = "Answer has no grounding citations or SQL data",
            )]
        return []

    def _check_numeric_grounding(
        self,
        answer:       str,
        citations:    list[dict],
        tool_results: Optional[list[ToolResult]],
    ) -> list[GuardFinding]:
        """
        Numbers in the answer should appear in either citation text
        or SQL result data.  Highly specific numbers (>4 digits) that
        appear nowhere in the results are flagged.
        """
        answer_nums = _extract_numbers(answer)
        if not answer_nums:
            return []

        # Collect all numbers from source data
        source_nums: set[str] = set()
        for cit in citations:
            for v in cit.values():
                source_nums.update(_extract_numbers(str(v)))

        if tool_results:
            for r in tool_results:
                if isinstance(r.data, list):
                    for row in r.data[:20]:
                        if isinstance(row, dict):
                            for v in row.values():
                                source_nums.update(_extract_numbers(str(v)))
                elif r.data is not None:
                    source_nums.update(_extract_numbers(str(r.data)))

        # Flag large specific numbers not found in source
        unsupported = [
            n for n in answer_nums
            if len(n.replace(".", "")) > 4 and n not in source_nums
        ]

        if unsupported:
            return [GuardFinding(
                check        = "numeric_mismatch",
                severity     = "WARN",
                detail       = f"Numbers in answer not found in source data: {unsupported[:3]}",
                flagged_text = ", ".join(unsupported[:3]),
            )]
        return []

    def _check_provider_names(
        self,
        answer:          str,
        known_providers: set[str],
    ) -> list[GuardFinding]:
        """
        Check that provider names mentioned in the answer are in the
        known-providers set.  Unknown provider names in the answer are flagged
        as BLOCK severity (prevents hallucinated provider data from reaching users).
        """
        if not known_providers:
            return []

        # Build a normalised lookup
        known_lower = {p.lower() for p in known_providers}

        # Simple heuristic: look for Title Case words following common patterns
        candidate_re = re.compile(
            r"(?:for|by|with|provider|facility)\s+([A-Z][a-zA-Z\s\-&']{3,40}?)(?:\s+(?:has|is|at|the|a|an|\.))",
            re.IGNORECASE,
        )
        candidates = candidate_re.findall(answer)
        unrecognised = [
            c.strip() for c in candidates
            if c.strip().lower() not in known_lower
            and len(c.strip()) > 4
        ][:3]

        if unrecognised:
            return [GuardFinding(
                check        = "ungrounded_provider",
                severity     = "BLOCK",  # Was WARN — upgraded to prevent hallucinated provider data
                detail       = f"Provider name(s) in answer not in resolved context: {unrecognised}",
                flagged_text = str(unrecognised),
            )]
        return []

    @staticmethod
    def _check_date_plausibility(answer: str) -> list[GuardFinding]:
        """Flag years outside the plausible contract range (2000–2035)."""
        years = _extract_years(answer)
        implausible = [y for y in years if y < 2000 or y > 2035]
        if implausible:
            return [GuardFinding(
                check    = "implausible_date",
                severity = "WARN",
                detail   = f"Year(s) outside expected contract range: {implausible}",
            )]
        return []

    @staticmethod
    def _check_non_bsc_providers(answer: str) -> list[GuardFinding]:
        """Block answers that claim specific data for known non-BSC providers.

        These providers are NOT in the Blue Shield of California contracted network.
        If the answer attributes rates, contract terms, or other specific data to them,
        it's a hallucination.
        """
        answer_lower = answer.lower()
        # Only flag if the answer attributes specific data (rates, amendments, terms)
        # to the non-BSC provider — mere mention in context is OK
        _DATA_INDICATORS = [
            "rate", "$", "per diem", "case rate", "contract", "amendment",
            "capitation", "pmpm", "term", "effective", "agreement",
        ]
        found_non_bsc = []
        for provider in _NON_BSC_PROVIDER_BLOCKLIST:
            if provider in answer_lower:
                # Check if it's in a data-attribution context (not just "unlike Kaiser...")
                # Find position and check surrounding text for data indicators
                idx = answer_lower.find(provider)
                context_window = answer_lower[max(0, idx-50):idx+len(provider)+100]
                if any(ind in context_window for ind in _DATA_INDICATORS):
                    found_non_bsc.append(provider.title())

        if found_non_bsc:
            return [GuardFinding(
                check        = "non_bsc_provider",
                severity     = "BLOCK",
                detail       = f"Answer attributes BSC contract data to non-BSC provider(s): {found_non_bsc}",
                flagged_text = str(found_non_bsc),
            )]
        return []

    @staticmethod
    def _check_universality_claim_OLD(
        answer: str,
        tool_results: Optional[list[ToolResult]],
    ) -> list[GuardFinding]:
        """Block universality claims not backed by a SQL COUNT result.

        Patterns caught:
          - "all 326 providers have offset"
          - "all providers have"
          - "every provider has"
          - "Yes, all providers"

        A claim is allowed through only when a successful sql_query result
        explicitly contains a total-count row that matches or exceeds the
        number stated in the answer.  When no SQL data exists the claim is
        BLOCKED rather than silently passed.

        Design note: severity=BLOCK because universality claims that are wrong
        are worse than a hedged answer.  The numeric grounding check only fires
        for numbers with >4 digits; provider counts (300-500) slip through.
        """
        # Positive universality patterns — require affirmative context.
        # Strategy: find "all N providers have" then check the 25-char window
        # BEFORE the match for negation words. This avoids false positives on
        # correct answers like "No, not all 326 providers have offset clauses."
        _UNIVERSALITY_RE = re.compile(
            r'(?:'
            r'all\s+\d+\s+providers?\s+(?:have|has|had)'
            r'|all\s+(?:the\s+)?providers?\s+(?:have|has|had)'
            r'|every\s+provider\s+(?:have|has|had)'
            r'|yes,?\s+all\s+(?:\d+\s+)?providers?'
            r'|(?:all|every)\s+(?:\d+\s+)?providers?\s+(?:have|has)\s+(?:an?\s+)?offset'
            r'|(?:all|every)\s+(?:\d+\s+)?providers?\s+(?:have|has)\s+(?:a\s+)?dofr'
            r'|(?:all|every)\s+(?:\d+\s+)?providers?\s+(?:have|has)\s+(?:a\s+)?ipa'
            r')',
            re.IGNORECASE,
        )
        _NEGATION_WORDS = frozenset(['not', 'no', 'neither', 'never', 'without', 'lack'])

        # Allow if backed by a sql_query result containing explicit "NO_MENTION"
        # or a non-zero count for the negative case (proves non-universality was checked)
        if tool_results:
            for r in tool_results:
                if r.success and isinstance(r.data, list):
                    data_str = str(r.data).lower()
                    if 'no_mention' in data_str or 'no mention' in data_str:
                        # SQL result shows both HAS and NO_MENTION — model should NOT
                        # assert universality. Still block.
                        pass
                    elif 'has' in data_str and len(r.data) == 1:
                        # Only one category returned — could be all-HAS; allow.
                        return []

        match = _UNIVERSALITY_RE.search(answer_lower)
        flagged = answer[match.start():match.start() + 60] if match else ""
        return [GuardFinding(
            check        = "universality_claim",
            severity     = "BLOCK",
            detail       = (
                "Answer asserts universal clause coverage ('all N providers have X') "
                "without a verified SQL count backing the claim. "
                "Always use sql_query with tbl_genie_provider_profile to verify counts."
            ),
            flagged_text = flagged,
        )]

    @staticmethod
    def _has_sql_data(tool_results: Optional[list[ToolResult]]) -> bool:
        """Return True if any tool result contains SQL row data."""
        if not tool_results:
            return False
        for r in tool_results:
            if r.success and isinstance(r.data, list) and r.data:
                return True
        return False

    @staticmethod
    def _adjust_confidence(
        findings: list[GuardFinding],
        citations: list[dict],
    ) -> Optional[str]:
        """
        Lower the claimed confidence based on findings.
        Returns the adjusted confidence string, or None if no adjustment needed.
        """
        if not findings:
            return None
        if any(f.severity == "BLOCK" for f in findings):
            return Confidence.LOW
        if not citations:
            return Confidence.MODERATE  # Cap: no citations can't be HIGH
        if any(f.severity == "WARN" for f in findings):
            return Confidence.MODERATE
        return None


    @staticmethod
    def _check_universality_claim(
        answer: str,
        tool_results: Optional[list[ToolResult]],
    ) -> list[GuardFinding]:
        """Block universality claims (GQ-ADV-08 fix).

        Catches patterns like 'all N providers have offset' or 'every provider has'
        when the claim is NOT backed by a SQL COUNT in the tool results.

        Negation-aware: 'No, not all 326 providers have offset' does NOT trigger
        this check (the 30-char pre-window before the match is scanned for
        negation words before firing).
        """
        _UNIVERSALITY_RE = re.compile(
            "("
            "all\\s+\\d+\\s+providers?\\s+(?:have|has|had)"
            "|all\\s+(?:the\\s+)?providers?\\s+(?:have|has|had)"
            "|every\\s+provider\\s+(?:have|has|had)"
            "|yes,?\\s+all\\s+(?:\\d+\\s+)?providers?"
            "|(?:all|every)\\s+(?:\\d+\\s+)?providers?\\s+(?:have|has)\\s+(?:an?\\s+)?offset"
            "|(?:all|every)\\s+(?:\\d+\\s+)?providers?\\s+(?:have|has)\\s+(?:a\\s+)?dofr"
            "|(?:all|every)\\s+(?:\\d+\\s+)?providers?\\s+(?:have|has)\\s+(?:a\\s+)?ipa"
            ")",
            re.IGNORECASE,
        )
        _NEGATION_WORDS = frozenset(['not', 'no', 'neither', 'never', 'without', 'lack'])

        answer_lower = answer.lower()
        match = _UNIVERSALITY_RE.search(answer_lower)
        if not match:
            return []

        # Check 35-char pre-window for negation — skip if negated
        # e.g. "No, not all 326 providers have offset clauses." → allowed
        pre_window = answer_lower[max(0, match.start() - 35):match.start()]
        pre_words = set(pre_window.split())
        if pre_words & _NEGATION_WORDS:
            return []

        # Allow if backed by a sql_query result containing explicit NO_MENTION
        # (proves the model has seen the non-universal breakdown)
        if tool_results:
            for r in tool_results:
                if r.success and isinstance(r.data, list) and r.data:
                    data_str = str(r.data).lower()
                    if 'no_mention' in data_str or 'no mention' in data_str:
                        # SQL shows both HAS and NO_MENTION — universality IS wrong
                        # but the model correctly reported non-universal. Block anyway
                        # if the PHRASING still asserts universality.
                        pass
                    elif 'has' in data_str and len(r.data) == 1:
                        # Single-category result (all HAS) — allow.
                        return []

        flagged = answer[match.start():match.start() + 70]
        return [GuardFinding(
            check        = "universality_claim",
            severity     = "BLOCK",
            detail       = (
                "Answer asserts universal clause coverage without SQL verification. "
                "Always sql_query tbl_genie_provider_profile for exact counts."
            ),
            flagged_text = flagged,
        )]

    @staticmethod
    def _check_same_provider_claim(
        answer: str,
        tool_results: Optional[list[ToolResult]],
    ) -> list[GuardFinding]:
        """Block cross-dimensional 'same provider' claims (GQ-MH-05 fix).

        Catches assertions that a single provider simultaneously tops two
        independent ranking dimensions — e.g. "the same provider has the
        highest rates AND the deepest amendments" — when the SQL data does
        not explicitly confirm rank #1 on both axes for that provider.

        Negation-aware: pre-window checked for 'no', 'not', 'none' before
        firing to allow correct statements like "no same provider tops both".
        """
        _SAME_PROVIDER_RE = re.compile(
            r"(?:"
            r"same\s+provider\s+(?:\w+\s+){0,4}(?:both|also\s+has|also\s+have|leads\s+both|tops\s+both|highest.{0,20}(?:and|as\s+well))"
            r"|the\s+same\s+provider\s+(?:has|have|had)\s+(?:both|the\s+(?:highest|deepest|most))"
            r"|(?:highest|deepest|most)\s+(?:\w+\s+){0,6}(?:is|are)\s+(?:also|the\s+same)\s+provider"
            r")",
            re.IGNORECASE,
        )
        _NEGATION_WORDS = frozenset(['no', 'not', 'none', 'neither', 'never', 'without', 'doesn', 'don'])

        answer_lower = answer.lower()
        match = _SAME_PROVIDER_RE.search(answer_lower)
        if not match:
            return []

        # Check 40-char pre-window for negation
        pre_window = answer_lower[max(0, match.start() - 40):match.start()]
        pre_words  = set(pre_window.split())
        if pre_words & _NEGATION_WORDS:
            return []

        flagged = answer[match.start():match.start() + 80]
        return [GuardFinding(
            check        = "same_provider_cross_dim",
            severity     = "BLOCK",
            detail       = (
                "Answer asserts one provider tops multiple independent ranking "
                "dimensions without explicit SQL confirmation. Present separate "
                "ranked lists for each dimension instead."
            ),
            flagged_text = flagged,
        )]

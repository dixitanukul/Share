"""
platform/v4/core/provenance.py

W9-17: Source provenance chain.

Provides end-to-end traceability from a claim in the agent's answer
back to the physical source document:

    claim → passage_text → page_number → source_filename → pdf_path
          → contract_id → effective_date → doc_role → amendment_order

Components
----------
  ProvenanceChain : Structured dataclass holding the full chain for one citation.
  ProvenanceResolver : Resolves source_filename → metadata + PDF path.
      Uses tbl_contract_documents_master for metadata lookup and builds
      PDF volume paths from the source_filename.

Usage
-----
  resolver = ProvenanceResolver(spark=spark)
  chain = resolver.resolve(citation_dict)
  # chain.pdf_path = '/Volumes/dev_adb/raw/files/129097205_Desert_...pdf'
  # chain.contract_id = '355258177'
  # chain.doc_role = 'amendment'
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class ProvenanceChain:
    """Full provenance chain for a single cited passage.

    Fields are ordered from claim-level down to physical source.
    All fields are optional — partial chains are valid when metadata
    is unavailable (graceful degradation).
    """
    # --- Claim level ---
    claim_text: str = ""           # What the answer asserts

    # --- Passage level ---
    passage_text: str = ""         # Literal evidence text from corpus
    passage_preview: str = ""      # First 200 chars for display
    retrieval_score: float = 0.0   # Similarity score from VS

    # --- Document location ---
    page_number: Optional[int] = None
    chunk_index: Optional[int] = None
    total_pages: Optional[int] = None

    # --- Source document identity ---
    source_filename: str = ""      # PDF filename (e.g. 129075504_..._Base_v1.pdf)
    source_doc_id: str = ""        # chunk_id or doc_id from corpus
    pdf_path: str = ""             # Full volume path to the physical PDF

    # --- Contract metadata ---
    contract_id: str = ""          # Parsed from filename or document master
    provider_name: str = ""
    provider_id: str = ""
    document_type: str = ""        # base_agreement, FirstAmend, etc.
    doc_role: str = ""             # base_agreement | amendment | settlement | other
    amendment_order: Optional[int] = None
    effective_date: Optional[str] = None
    expiration_date: Optional[str] = None
    agreement_title: str = ""
    is_current_effective: bool = True

    # --- Verification ---
    verification_status: str = "PENDING"  # VERIFIED | SUPERSEDED | etc.
    confidence: float = 1.0

    @property
    def is_complete(self) -> bool:
        """True if we have the full chain from passage to physical file."""
        return bool(
            self.passage_text
            and self.source_filename
            and self.pdf_path
            and self.contract_id
        )

    @property
    def is_partial(self) -> bool:
        """True if we have passage + filename but missing deeper metadata."""
        return bool(self.passage_text and self.source_filename) and not self.is_complete

    def to_dict(self) -> dict:
        """Serialize for JSON / AgentResponse metadata."""
        return {
            "claim_text": self.claim_text,
            "passage_preview": self.passage_preview or self.passage_text[:200],
            "page_number": self.page_number,
            "source_filename": self.source_filename,
            "pdf_path": self.pdf_path,
            "contract_id": self.contract_id,
            "provider_name": self.provider_name,
            "doc_role": self.doc_role,
            "document_type": self.document_type,
            "amendment_order": self.amendment_order,
            "effective_date": self.effective_date,
            "is_current_effective": self.is_current_effective,
            "verification_status": self.verification_status,
            "is_complete": self.is_complete,
        }

    def to_display_str(self) -> str:
        """Human-readable provenance for notebook display."""
        parts = []
        if self.provider_name:
            parts.append(f"Provider: {self.provider_name}")
        if self.source_filename:
            parts.append(f"File: {self.source_filename}")
        if self.page_number is not None:
            parts.append(f"Page {self.page_number}")
            if self.total_pages:
                parts[-1] += f"/{self.total_pages}"
        if self.doc_role:
            parts.append(f"Role: {self.doc_role}")
        if self.effective_date:
            parts.append(f"Effective: {self.effective_date}")
        if self.contract_id:
            parts.append(f"Contract: {self.contract_id}")
        return " → ".join(parts) if parts else "[no provenance]"


# ---------------------------------------------------------------------------
# ProvenanceResolver
# ---------------------------------------------------------------------------

# Default PDF volume path template
_PDF_VOLUME_ROOT = "/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts"

# Metadata table
_DOCUMENTS_MASTER = "dev_adb.raw.tbl_contract_documents_master"


class ProvenanceResolver:
    """
    Resolves citation dicts into full ProvenanceChain objects.

    Requires a Spark session for metadata lookup. If Spark is unavailable,
    builds partial chains from the citation dict alone (no metadata enrichment).

    Parameters
    ----------
    spark : PySpark SparkSession (optional).
    pdf_volume_root : Override the default PDF volume path.
    cache_metadata : If True (default), caches document master lookups.
    """

    def __init__(
        self,
        spark: Optional[Any] = None,
        pdf_volume_root: str = _PDF_VOLUME_ROOT,
        cache_metadata: bool = True,
    ) -> None:
        self._spark = spark
        self._pdf_root = pdf_volume_root.rstrip("/")
        self._cache_enabled = cache_metadata
        self._metadata_cache: dict[str, dict] = {}  # source_filename → metadata row

    @property
    def is_ready(self) -> bool:
        return self._spark is not None

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def resolve(self, citation: dict, claim_text: str = "") -> ProvenanceChain:
        """
        Build a ProvenanceChain from a citation dict.

        Parameters
        ----------
        citation : dict with fields from passage retrieval / citation adapter.
            Expected keys: passage_text/unit_text/text, source_filename,
            page_number, provider_name, source_doc_id/doc_id, score, etc.
        claim_text : The claim this citation supports (optional).

        Returns
        -------
        ProvenanceChain — always returns a valid object (partial if metadata
        lookup fails).
        """
        # Extract passage-level fields
        passage = (
            citation.get("passage_text")
            or citation.get("unit_text")
            or citation.get("text")
            or citation.get("chunk_text")
            or ""
        )
        source_filename = citation.get("source_filename", "")
        page_num = citation.get("page_number")
        if page_num is None:
            page_num = citation.get("page")
        chunk_idx = citation.get("chunk_index")
        total_pages = citation.get("total_pages")
        doc_id = (
            citation.get("source_doc_id")
            or citation.get("doc_id")
            or citation.get("chunk_id")
            or ""
        )
        provider = citation.get("provider_name") or citation.get("provider", "")
        score = float(citation.get("score") or citation.get("retrieval_score", 0.0))
        is_current = bool(citation.get("is_current_effective", True))
        verification = citation.get("verification_status") or citation.get("status", "PENDING")
        confidence = float(citation.get("confidence", 1.0))

        # Build PDF path from filename
        pdf_path = self._resolve_pdf_path(source_filename)

        # Parse contract_id from filename if not provided
        contract_id = citation.get("contract_id", "")
        if not contract_id and source_filename:
            contract_id = self._parse_contract_id(source_filename)

        # Look up metadata from document master
        metadata = self._lookup_metadata(source_filename)

        return ProvenanceChain(
            claim_text=claim_text,
            passage_text=passage,
            passage_preview=passage[:200] if passage else "",
            retrieval_score=score,
            page_number=int(page_num) if page_num is not None else None,
            chunk_index=int(chunk_idx) if chunk_idx is not None else None,
            total_pages=int(total_pages) if total_pages is not None else None,
            source_filename=source_filename,
            source_doc_id=str(doc_id),
            pdf_path=pdf_path,
            contract_id=contract_id or metadata.get("contract_id", ""),
            provider_name=provider or metadata.get("provider_name", ""),
            provider_id=metadata.get("provider_id", ""),
            document_type=metadata.get("document_type", ""),
            doc_role=citation.get("doc_role") or metadata.get("doc_role", ""),
            amendment_order=(
                citation.get("amendment_order")
                or metadata.get("amendment_order")
            ),
            effective_date=(
                citation.get("effective_date")
                or metadata.get("effective_date")
            ),
            expiration_date=metadata.get("expiration_date"),
            agreement_title=metadata.get("agreement_title", ""),
            is_current_effective=is_current,
            verification_status=str(verification),
            confidence=confidence,
        )

    def resolve_batch(self, citations: list[dict], claim_text: str = "") -> list[ProvenanceChain]:
        """Resolve multiple citations. Pre-fetches metadata for efficiency."""
        if not citations:
            return []

        # Pre-warm cache with all source_filenames
        filenames = [
            c.get("source_filename", "")
            for c in citations
            if c.get("source_filename")
        ]
        if filenames:
            self._prefetch_metadata(filenames)

        return [self.resolve(c, claim_text=claim_text) for c in citations]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _resolve_pdf_path(self, source_filename: str) -> str:
        """Build the full volume path for a source PDF."""
        if not source_filename:
            return ""
        return f"{self._pdf_root}/{source_filename}"

    @staticmethod
    def _parse_contract_id(filename: str) -> str:
        """Extract contract_id from BSC filename convention.

        Pattern: {provider_id}_{ProviderName}_{contract_id}_{DocType}_v{N}.pdf
        Example: 129097205_Desert_Regional_Medical_Center_355258177_NineteenthAmend_v2.PDF
                 → contract_id = 355258177
        """
        import re
        # Look for a 9+ digit number that's NOT the first segment (provider_id)
        parts = filename.replace(".pdf", "").replace(".PDF", "").split("_")
        # Skip first part (provider_id), find the contract_id (usually the numeric
        # segment before the document type like 'Base', 'FirstAmend', etc.)
        candidates = []
        for i, part in enumerate(parts):
            if i == 0:
                continue  # skip provider_id
            if re.match(r"^\d{6,}$", part):
                candidates.append(part)
        # Contract ID is typically the LAST large numeric in the filename
        # (after provider_id, before doc_type)
        return candidates[-1] if candidates else ""

    def _lookup_metadata(self, source_filename: str) -> dict:
        """Look up contract metadata from tbl_contract_documents_master."""
        if not source_filename:
            return {}

        # Check cache
        if self._cache_enabled and source_filename in self._metadata_cache:
            return self._metadata_cache[source_filename]

        if self._spark is None:
            return {}

        try:
            safe_fn = source_filename.replace("'", "''")
            row = self._spark.sql(f"""
                SELECT provider_id, provider_name, contract_id, document_type,
                       doc_role, amendment_order, effective_date, expiration_date,
                       agreement_title
                FROM {_DOCUMENTS_MASTER}
                WHERE source_filename = '{safe_fn}'
                LIMIT 1
            """).collect()

            if row:
                metadata = row[0].asDict()
            else:
                metadata = {}

            if self._cache_enabled:
                self._metadata_cache[source_filename] = metadata
            return metadata

        except Exception:  # noqa: BLE001
            return {}

    def _prefetch_metadata(self, filenames: list[str]) -> None:
        """Batch-load metadata for multiple filenames into cache."""
        if self._spark is None:
            return

        # Only fetch uncached filenames
        uncached = [
            fn for fn in filenames
            if fn and fn not in self._metadata_cache
        ]
        if not uncached:
            return

        try:
            # Build IN clause (max 200 at a time to avoid SQL limits)
            for i in range(0, len(uncached), 200):
                batch = uncached[i:i + 200]
                in_clause = ", ".join(f"'{fn.replace(chr(39), chr(39)*2)}'" for fn in batch)
                rows = self._spark.sql(f"""
                    SELECT source_filename, provider_id, provider_name, contract_id,
                           document_type, doc_role, amendment_order, effective_date,
                           expiration_date, agreement_title
                    FROM {_DOCUMENTS_MASTER}
                    WHERE source_filename IN ({in_clause})
                """).collect()

                for row in rows:
                    d = row.asDict()
                    fn = d.pop("source_filename", "")
                    if fn:
                        self._metadata_cache[fn] = d

                # Mark not-found filenames to avoid re-querying
                found = {self._metadata_cache.get(fn) is not None for fn in batch}
                for fn in batch:
                    if fn not in self._metadata_cache:
                        self._metadata_cache[fn] = {}

        except Exception:  # noqa: BLE001
            pass  # non-fatal — chains will be partial

    def clear_cache(self) -> None:
        """Clear the metadata cache (e.g., after table updates)."""
        self._metadata_cache.clear()

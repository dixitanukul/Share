"""
W9-26: Streaming response types for progressive result delivery.

Defines the event protocol that AgentController uses to emit partial
results as each ReAct step completes. Consumers (notebook UI, REST API,
Genie integration) implement StreamCallback to receive events.

Event flow for a typical 3-step question:
  STARTED → THINKING → TOOL_START → TOOL_RESULT → THINKING →
  TOOL_START → TOOL_RESULT → SYNTHESIZING → FINAL_ANSWER

Event flow for decomposed questions:
  STARTED → DECOMPOSING → SUB_QUESTION_START → TOOL_START → TOOL_RESULT →
  SUB_QUESTION_RESULT → SUB_QUESTION_START → ... → SYNTHESIZING → FINAL_ANSWER
"""
from __future__ import annotations

import queue
import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterator, Protocol, runtime_checkable


class StreamEvent(str, Enum):
    """Events emitted during agent execution."""
    STARTED = "started"              # Agent begins processing
    THINKING = "thinking"            # LLM reasoning step (no tool call)
    TOOL_START = "tool_start"        # About to call a tool
    TOOL_RESULT = "tool_result"      # Tool returned a result
    SYNTHESIZING = "synthesizing"    # Building final answer from evidence
    FINAL_ANSWER = "final_answer"    # Complete answer ready
    ERROR = "error"                  # Tool failure or budget exhaustion
    DECOMPOSING = "decomposing"      # Complex question being decomposed
    SUB_QUESTION_START = "sub_question_start"    # Starting a sub-question
    SUB_QUESTION_RESULT = "sub_question_result"  # Sub-question answered
    ABORTED = "aborted"              # Agent decided question is out of scope
    ROUTE_DETECTED = "route_detected"  # Route/tool selected for this question


@dataclass
class StreamMessage:
    """
    A single streaming event emitted by the agent.

    Consumers can use this to:
      - Display progress indicators (THINKING, TOOL_START)
      - Show partial results as they arrive (TOOL_RESULT, SUB_QUESTION_RESULT)
      - Render the final answer (FINAL_ANSWER)
      - Handle errors gracefully (ERROR, ABORTED)
    """
    event: StreamEvent
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    # Convenience fields populated for specific events
    step_number: int = 0
    tool_name: str = ""
    partial_answer: str = ""       # For TOOL_RESULT / SUB_QUESTION_RESULT
    progress_pct: float = 0.0      # 0.0 to 1.0 estimate
    elapsed_s: float = 0.0         # Time since STARTED

    def to_sse(self) -> str:
        """Format as a Server-Sent Event (SSE) string for REST API streaming."""
        import json
        payload = {
            "event": self.event.value,
            "step": self.step_number,
            "tool": self.tool_name or None,
            "partial_answer": self.partial_answer or None,
            "progress": round(self.progress_pct, 2),
            "elapsed_s": round(self.elapsed_s, 2),
            "data": self.data or None,
        }
        # Remove None values for compact SSE
        payload = {k: v for k, v in payload.items() if v is not None}
        return f"event: {self.event.value}\ndata: {json.dumps(payload)}\n\n"

    def to_display_text(self) -> str:
        """Human-readable progress text for notebook/UI display."""
        if self.event == StreamEvent.STARTED:
            return "🔄 Processing your question..."
        elif self.event == StreamEvent.THINKING:
            thought = self.data.get("thought", "")[:100]
            return f"💭 Reasoning: {thought}..." if thought else "💭 Thinking..."
        elif self.event == StreamEvent.TOOL_START:
            return f"🔧 Calling {self.tool_name}..."
        elif self.event == StreamEvent.TOOL_RESULT:
            return f"✅ {self.tool_name}: {self.partial_answer[:150]}"
        elif self.event == StreamEvent.SYNTHESIZING:
            return "📝 Assembling final answer..."
        elif self.event == StreamEvent.FINAL_ANSWER:
            return self.partial_answer
        elif self.event == StreamEvent.ERROR:
            return f"⚠️ {self.data.get('message', 'Error occurred')}"
        elif self.event == StreamEvent.DECOMPOSING:
            n = self.data.get("sub_question_count", 0)
            return f"🔀 Complex question → decomposing into {n} sub-questions..."
        elif self.event == StreamEvent.SUB_QUESTION_START:
            q = self.data.get("question", "")[:80]
            return f"  📋 Sub-question: {q}"
        elif self.event == StreamEvent.SUB_QUESTION_RESULT:
            return f"  ✓ Sub-question {self.step_number} answered"
        elif self.event == StreamEvent.ABORTED:
            return f"🚫 {self.data.get('reason', 'Question out of scope')}"
        return f"[{self.event.value}]"


@runtime_checkable
class StreamCallback(Protocol):
    """
    Protocol for streaming event consumers.

    Implement this to receive real-time progress from the agent.
    The callback is called synchronously from the agent's execution thread.

    Example implementations:
      - NotebookStreamHandler: updates displayHTML in real-time
      - SSEStreamHandler: writes to an HTTP response stream
      - BufferStreamHandler: collects all events for testing
    """

    def on_event(self, message: StreamMessage) -> None:
        """Called for each streaming event. Must not raise."""
        ...


class BufferStreamCallback:
    """
    Test/debug implementation that collects all events in a list.

    Usage:
        buffer = BufferStreamCallback()
        response = controller.run(request, stream_callback=buffer)
        assert buffer.events[0].event == StreamEvent.STARTED
    """

    def __init__(self):
        self.events: list[StreamMessage] = []

    def on_event(self, message: StreamMessage) -> None:
        self.events.append(message)

    @property
    def event_types(self) -> list[StreamEvent]:
        """Return list of event types in order."""
        return [e.event for e in self.events]

    @property
    def tool_events(self) -> list[StreamMessage]:
        """Return only TOOL_START and TOOL_RESULT events."""
        return [e for e in self.events if e.event in (StreamEvent.TOOL_START, StreamEvent.TOOL_RESULT)]

    def get_final_answer(self) -> str:
        """Return the final answer text, or empty string."""
        for e in reversed(self.events):
            if e.event == StreamEvent.FINAL_ANSWER:
                return e.partial_answer
        return ""

    def has_event(self, event_type: StreamEvent) -> bool:
        return event_type in self.event_types


class ThreadSafeStreamBuffer:
    """
    Thread-safe bridge for real-time streaming: the agent thread pushes
    StreamMessage events via on_event(), and the API thread pulls them
    via iter_events(). Satisfies the StreamCallback protocol.

    Usage:
        buffer = ThreadSafeStreamBuffer()
        # Agent thread:
        controller.run(request, stream_callback=buffer)
        buffer.mark_done()
        # API thread:
        for msg in buffer.iter_events():
            yield msg_to_json(msg)
    """

    def __init__(self) -> None:
        self._queue: queue.Queue[StreamMessage | None] = queue.Queue()
        self._done = threading.Event()

    def on_event(self, message: StreamMessage) -> None:
        """Called by the agent thread. Must not raise."""
        self._queue.put(message)

    def mark_done(self) -> None:
        """Signal that no more events will arrive."""
        self._queue.put(None)  # Sentinel
        self._done.set()

    def iter_events(self, timeout: float = 0.15) -> Iterator[StreamMessage]:
        """Yields events as they arrive. Returns when sentinel received."""
        while True:
            try:
                msg = self._queue.get(timeout=timeout)
                if msg is None:
                    return
                yield msg
            except queue.Empty:
                if self._done.is_set():
                    # Drain any remaining items
                    while not self._queue.empty():
                        msg = self._queue.get_nowait()
                        if msg is None:
                            return
                        yield msg
                    return

"""
Citation and verification result types for V3.

These types flow through passage_search → citation_verify → response_assembler.
The citation_adapter maps legacy platform/07_citation_verification.py output
into these canonical types before V3 code ever sees them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class VerificationStatus(str, Enum):
    VERIFIED = "VERIFIED"           # Grounded + current-effective + no supersession risk
    SUPERSEDED = "SUPERSEDED"       # Source document has been superseded by an amendment
    UNVERIFIABLE = "UNVERIFIABLE"   # Cannot confirm grounding (passage not found in corpus)
    HALLUCINATED = "HALLUCINATED"   # Key claim not found in cited source text
    PENDING = "PENDING"             # Not yet verified (trust layer disabled)


@dataclass
class Citation:
    """
    A single cited passage with full provenance metadata.

    source_doc_id matches tbl_contract_documents_master.document_id.
    page_number matches tbl_vs_unified_ready.page_number.
    """
    source_doc_id: str
    provider_name: str
    passage_text: str
    page_number: int | None = None
    clause_type: str = ""
    effective_date: str | None = None
    is_current_effective: bool = True
    doc_role: str = ""             # base_agreement | amendment | settlement | other
    amendment_order: int | None = None
    confidence: float = 1.0
    retrieval_score: float = 0.0
    # W9-17: Source provenance fields
    source_filename: str = ""      # Original PDF filename (e.g. 129075504_Hospital_A_12345_Base_v1.pdf)
    contract_id: str = ""          # Contract ID parsed from source_filename or metadata
    pdf_path: str = ""             # Full volume path to source PDF
    document_type: str = ""        # base_agreement, FirstAmend, etc.
    provider_id: str = ""          # Canonical provider_id for cross-references

    def to_dict(self) -> dict:
        return {
            "source_doc_id": self.source_doc_id,
            "provider": self.provider_name,
            "page": self.page_number,
            "clause_type": self.clause_type,
            "effective_date": self.effective_date,
            "is_current": self.is_current_effective,
            "doc_role": self.doc_role,
            "confidence": self.confidence,
            "passage_preview": self.passage_text[:200],
            # W9-17: Source provenance chain
            "source_filename": self.source_filename,
            "contract_id": self.contract_id,
            "pdf_path": self.pdf_path,
            "document_type": self.document_type,
            "provider_id": self.provider_id,
            "amendment_order": self.amendment_order,
        }


@dataclass
class VerificationResult:
    """
    Result of citation verification for one logical claim.

    Produced by platform/v4/adapters/citation_adapter.py after calling
    platform/07_citation_verification.py.
    """
    claim_text: str
    status: VerificationStatus
    supporting_citations: list[Citation] = field(default_factory=list)
    risk_flags: list[str] = field(default_factory=list)
    numerical_check_passed: bool | None = None
    temporal_check_passed: bool | None = None
    supersession_risk: bool = False
    notes: str = ""

    @property
    def is_trustworthy(self) -> bool:
        """True if the claim passed verification and has no risk flags."""
        return (
            self.status == VerificationStatus.VERIFIED
            and not self.risk_flags
            and not self.supersession_risk
        )

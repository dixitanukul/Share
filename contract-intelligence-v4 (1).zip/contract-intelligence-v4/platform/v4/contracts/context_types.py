"""
Session context and working data types for V3 ContextManager.

SessionContext is the single mutable state object threaded through
the entire ReAct loop. ContextManager creates and updates it; the
agent controller reads from it to build LLM prompts.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class ResolvedEntity:
    """
    A provider, concept, date, or rate-type entity resolved from
    raw user input to its canonical form.

    Resolution happens in ContextManager.resolve_entities() using
    dim_provider_canonical + known taxonomy terms.
    """
    raw_mention: str
    canonical_form: str
    entity_type: str              # "provider" | "concept" | "date" | "rate_type"
    provider_ids: list[str] = field(default_factory=list)  # Matching IDs from dim_provider_canonical
    confidence: float = 1.0
    resolution_method: str = ""   # "exact" | "fuzzy" | "alias" | "llm"


@dataclass
class WorkingData:
    """
    Mutable accumulator for results gathered during one ReAct loop.

    Each tool call appends to the relevant list. The response assembler
    draws from these lists to build the final answer.
    """
    sql_results: list[dict] = field(default_factory=list)
    passages: list[dict] = field(default_factory=list)
    citations: list[dict] = field(default_factory=list)
    calculations: list[dict] = field(default_factory=list)
    provider_contexts: dict[str, Any] = field(default_factory=dict)
    chart_html: str | None = None
    export_path: str | None = None

    def has_data(self) -> bool:
        return any([
            self.sql_results,
            self.passages,
            self.citations,
            self.calculations,
            self.provider_contexts,
        ])


@dataclass
class SessionFact:
    """
    W9-21: A key fact extracted from a completed turn.

    Facts are accumulated across the session and injected into prompts
    so the agent has "working memory" of prior findings.
    """
    fact_type: str           # "rate", "clause_status", "count", "date", "claim"
    content: str             # Human-readable fact text
    provider: str = ""       # Provider it relates to (if any)
    concept: str = ""        # Concept/clause type (if any)
    turn_number: int = 0     # Which turn produced this fact
    confidence: float = 1.0  # How reliable this fact is

    def to_prompt_line(self) -> str:
        prefix = f"[{self.provider}]" if self.provider else ""
        return f"{prefix} {self.content}".strip()


@dataclass
class ConversationTurn:
    """
    W9-21: One completed conversation turn for multi-turn history.

    Stored in the sliding window so coreference resolution can
    refer back to providers/concepts from prior turns.
    """
    question: str
    answer_preview: str = ""                              # First 200 chars of answer
    resolved_entities: list[ResolvedEntity] = field(default_factory=list)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    cost: float = 0.0
    facts: list[SessionFact] = field(default_factory=list)  # W9-21: facts from this turn

    def get_providers(self) -> list[str]:
        return [e.canonical_form for e in self.resolved_entities if e.entity_type == "provider"]

    def get_concepts(self) -> list[str]:
        return [e.canonical_form for e in self.resolved_entities if e.entity_type == "concept"]


@dataclass
class SessionContext:
    """
    Per-session state maintained by ContextManager throughout a ReAct loop.

    Created at the start of AgentController.run() and passed into every
    reasoning step. Never stored in notebook globals.
    """
    session_id: str
    question: str
    resolved_entities: list[ResolvedEntity] = field(default_factory=list)
    working_data: WorkingData = field(default_factory=WorkingData)
    turn_count: int = 0
    cumulative_cost: float = 0.0
    flags: dict = field(default_factory=dict)
    # W9-21: Multi-turn conversation history (sliding window)
    conversation_history: list[ConversationTurn] = field(default_factory=list)
    # W9-21: Accumulated session facts (working memory)
    session_facts: list[SessionFact] = field(default_factory=list)
    # W9-21: Summary of evicted turns (beyond sliding window)
    history_summary: str = ""

    # ── Entity helpers ────────────────────────────────────────────────────────

    def get_providers(self) -> list[str]:
        """Return canonical provider names."""
        return [e.canonical_form for e in self.resolved_entities if e.entity_type == "provider"]

    def get_provider_ids(self) -> list[str]:
        """Return all matching provider IDs across all resolved provider entities."""
        ids = []
        for e in self.resolved_entities:
            if e.entity_type == "provider":
                ids.extend(e.provider_ids)
        return list(dict.fromkeys(ids))  # dedup preserving order

    def get_concepts(self) -> list[str]:
        return [e.canonical_form for e in self.resolved_entities if e.entity_type == "concept"]

    def add_entity(self, entity: ResolvedEntity) -> None:
        # Avoid exact duplicates
        existing = {(e.raw_mention, e.entity_type) for e in self.resolved_entities}
        if (entity.raw_mention, entity.entity_type) not in existing:
            self.resolved_entities.append(entity)

    def to_prompt_summary(self) -> str:
        """
        BUG-012 fix: Compact string for injecting session context into LLM prompts.

        Now includes actual Q/A content from conversation history so the LLM
        can maintain multi-turn context (previously only said "Turn N of conversation"
        which gave the LLM zero information about prior exchanges).
        """
        providers = self.get_providers()
        concepts = self.get_concepts()
        parts = []
        if providers:
            parts.append(f"Providers: {', '.join(providers)}")
        if concepts:
            parts.append(f"Concepts: {', '.join(concepts)}")
        parts.append(f"Cost so far: ${self.cumulative_cost:.3f}")

        # BUG-012: Include actual conversation content (not just "Turn N")
        if self.conversation_history:
            history_parts = []
            # Show last 3 turns with actual content (compact)
            for turn in self.conversation_history[-3:]:
                q_short = turn.question[:80]
                a_short = turn.answer_preview[:300] if turn.answer_preview else "(no answer)"  # 300 chars captures rate comparison tables (prior-turn rate rows start after ~268-char header)
                turn_providers = turn.get_providers()
                provider_tag = f" [{turn_providers[0]}]" if turn_providers else ""
                history_parts.append(f"Q{provider_tag}: {q_short} → A: {a_short}")
            parts.append(f"Conversation ({self.turn_count} turns): " + " // ".join(history_parts))

        if self.history_summary:
            parts.append(f"Prior context: {self.history_summary[:150]}")
        if self.session_facts:
            fact_lines = [f.to_prompt_line() for f in self.session_facts[-5:]]
            parts.append(f"Known facts: {'; '.join(fact_lines)}")
        return " | ".join(parts) if parts else "No entities resolved yet."

    def add_fact(self, fact: SessionFact) -> None:
        """Add a session fact, deduplicating by content."""
        existing_content = {f.content for f in self.session_facts}
        if fact.content not in existing_content:
            self.session_facts.append(fact)

    def get_facts_for_provider(self, provider: str) -> list[SessionFact]:
        """Get all facts related to a specific provider."""
        return [f for f in self.session_facts if f.provider.lower() == provider.lower()]

    # W9-21: History helpers
    def last_providers(self, n_turns: int = 2) -> list[str]:
        """Get providers mentioned in the last N turns."""
        providers: list[str] = []
        for turn in reversed(self.conversation_history[-n_turns:]):
            providers.extend(turn.get_providers())
        return list(dict.fromkeys(providers))  # dedup preserving order

    def last_concepts(self, n_turns: int = 2) -> list[str]:
        """Get concepts mentioned in the last N turns."""
        concepts: list[str] = []
        for turn in reversed(self.conversation_history[-n_turns:]):
            concepts.extend(turn.get_concepts())
        return list(dict.fromkeys(concepts))

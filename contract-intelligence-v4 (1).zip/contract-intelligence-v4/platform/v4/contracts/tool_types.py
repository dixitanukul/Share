"""
Canonical type definitions for V3 tool interfaces.

All V3 code that produces or consumes tool results uses these types.
No external dependencies from legacy modules — this file must be
importable without Spark, Delta, or Databricks SDK.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Confidence(str, Enum):
    HIGH = "HIGH"            # Directly grounded in source text or deterministic SQL result
    MODERATE = "MODERATE"    # Inferred from multiple grounded results
    LOW = "LOW"              # Weak or partial evidence
    GENERATED = "GENERATED"  # AI-drafted text — never treated as sourced


class ToolStatus(str, Enum):
    SUCCESS = "SUCCESS"
    PARTIAL = "PARTIAL"   # Result returned but with caveats
    EMPTY = "EMPTY"       # No results found (not an error)
    ERROR = "ERROR"       # Tool failed
    SKIPPED = "SKIPPED"   # Tool was not invoked (budget/policy/flag)


@dataclass
class ToolResult:
    """
    Standard result envelope returned by every V3 tool.

    All tools — native and adapter-backed — return this type.
    The agent controller and response assembler only ever see ToolResult.
    """
    success: bool
    data: Any
    summary: str
    citations: list[dict] = field(default_factory=list)
    confidence: Confidence = Confidence.MODERATE
    cost_estimate: float = 0.0
    execution_time_s: float = 0.0
    error_message: str | None = None
    metadata: dict = field(default_factory=dict)
    status: ToolStatus = ToolStatus.SUCCESS
    tool_name: str = ""

    @classmethod
    def error(cls, message: str, tool_name: str = "") -> "ToolResult":
        """Factory for error results."""
        return cls(
            success=False,
            data=None,
            summary=f"[{tool_name}] Error: {message}" if tool_name else f"Error: {message}",
            error_message=message,
            confidence=Confidence.LOW,
            status=ToolStatus.ERROR,
        )

    @classmethod
    def empty(cls, summary: str) -> "ToolResult":
        """Factory for empty / no-results results."""
        return cls(
            success=True,
            data=None,
            summary=summary,
            confidence=Confidence.LOW,
            status=ToolStatus.EMPTY,
        )

    @classmethod
    def skipped(cls, reason: str) -> "ToolResult":
        """Factory for skipped-by-policy results."""
        return cls(
            success=False,
            data=None,
            summary=reason,
            confidence=Confidence.LOW,
            status=ToolStatus.SKIPPED,
        )

    def is_usable(self) -> bool:
        """True if the result has data an agent can act on."""
        return self.success and self.data is not None and self.status not in (
            ToolStatus.ERROR, ToolStatus.SKIPPED
        )

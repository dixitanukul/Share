"""
Type definitions for agent-level request / response / step objects.

No Spark or Databricks SDK dependencies — importable anywhere.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional,  Any

from platform.v4.contracts.tool_types import ToolResult, Confidence


class StepAction(str, Enum):
    THINK = "THINK"           # Internal reasoning (no tool call)
    CALL_TOOL = "CALL_TOOL"   # Execute a registered tool
    SYNTHESIZE = "SYNTHESIZE" # Assemble final answer from accumulated results
    ABORT = "ABORT"           # Stop — budget exhausted, unresolvable, or out of scope


@dataclass
class AgentStep:
    """One ReAct reasoning + action step."""
    step_number: int
    thought: str
    action: StepAction
    tool_name: str | None = None
    tool_input: dict = field(default_factory=dict)
    tool_result: ToolResult | None = None
    cost_this_step: float = 0.0
    elapsed_s: float = 0.0

    def to_log_dict(self) -> dict:
        return {
            "step": self.step_number,
            "action": self.action.value,
            "tool": self.tool_name,
            "cost": self.cost_this_step,
            "elapsed_s": round(self.elapsed_s, 2),
            "thought_preview": self.thought[:120],
        }


@dataclass
class AgentRequest:
    """
    Inbound request to the V3 AgentController.

    Callers (notebook, API, Genie) build this object and pass it to
    AgentController.run(). The controller never reads from notebook globals.
    """
    question: str
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str = ""
    max_steps: int = 10
    budget_usd: Optional[float] = None
    # Optional overrides for entity resolution
    provider_hint: str | None = None
    concept_hint: str | None = None
    # Feature-flag overrides for this request (merged with global flags)
    feature_flags: dict = field(default_factory=dict)
    # Arbitrary context passed by callers (e.g. prior conversation turns)
    context_hints: dict = field(default_factory=dict)


@dataclass
class AgentResponse:
    """
    Output from the V3 AgentController.run().

    Callers receive this and render it for their surface (notebook cell,
    REST response, Genie answer, etc.).
    """
    session_id: str
    answer: str
    confidence: str          # Confidence enum value as string
    citations: list[dict] = field(default_factory=list)
    steps: list[AgentStep] = field(default_factory=list)
    total_cost: float = 0.0
    total_time_s: float = 0.0
    tool_calls: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict = field(default_factory=dict)

    @property
    def step_count(self) -> int:
        return len(self.steps)

    @property
    def is_complete(self) -> bool:
        """True if the agent reached a SYNTHESIZE or ABORT action."""
        if not self.steps:
            return False
        return self.steps[-1].action in (StepAction.SYNTHESIZE, StepAction.ABORT)

    def to_summary_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "answer_preview": self.answer[:200],
            "confidence": self.confidence,
            "steps": self.step_count,
            "tools_called": self.tool_calls,
            "cost_usd": round(self.total_cost, 4),
            "time_s": round(self.total_time_s, 2),
            "warnings": self.warnings,
        }

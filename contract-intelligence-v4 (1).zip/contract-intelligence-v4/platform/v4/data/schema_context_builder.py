"""
platform/v4/data/schema_context_builder.py

Builds the schema context string used by the SQL generation tool.

Two modes:
  1. dim_table_schema mode (preferred, W9-14): reads from dim_table_schema (configured catalog.schema)
     which contains pre-computed column metadata + sample_values + is_filterable/is_joinable
     hints populated by the schema builder script.  Gives the LLM richer context
     (e.g. real sample values) so it writes better JOINs and WHERE predicates.

  2. DESCRIBE TABLE fallback: used when Spark is not available or dim_table_schema
     has no rows for the requested table.

The result is cached in-memory after the first build; call rebuild() to
refresh if schema changes are made.
"""
from __future__ import annotations

import json
import time
from typing import Any, Optional

from ..config.table_whitelist import CONTRACT_TABLES_FOR_SQL
from ..config.settings import CATALOG, SCHEMA

DIM_TBL      = f"{CATALOG}.{SCHEMA}.dim_table_schema"

_SCHEMA_CACHE: Optional[str] = None


def build_schema_context(spark: Any, force_rebuild: bool = False) -> str:
    """
    Build (or return cached) schema context for SQL generation.

    Prefers dim_table_schema data (sample values + filterable/joinable hints).
    Falls back to DESCRIBE TABLE when dim_table_schema has no rows for a table.

    Parameters
    ----------
    spark         : Active Spark session.
    force_rebuild : If True, ignore the cache and rebuild.

    Returns
    -------
    str : Formatted schema context for LLM prompt injection.
    """
    global _SCHEMA_CACHE
    if _SCHEMA_CACHE and not force_rebuild:
        return _SCHEMA_CACHE

    # Try dim_table_schema first (richer context)
    dim_data = _load_dim_table_schema(spark)

    lines: list[str] = ["Available tables for SQL generation:"]

    for table_name, description in CONTRACT_TABLES_FOR_SQL.items():
        full_name = f"{CATALOG}.{SCHEMA}.{table_name}"
        lines.append(f"\n### {full_name}")
        lines.append(f"# {description}")

        if table_name in dim_data and dim_data[table_name]:
            # Rich path — use dim_table_schema data
            for col in dim_data[table_name]:
                hints = []
                if col.get("is_filterable"):
                    hints.append("filter")
                if col.get("is_joinable"):
                    hints.append("join-key")
                hint_str = f" [{', '.join(hints)}]" if hints else ""
                comment = f"  -- {col['comment']}" if col.get("comment") else ""
                samples = col.get("sample_values") or []
                sample_str = ""
                if samples:
                    clean = [s for s in samples if s and s not in ("None", "null")][:3]
                    if clean:
                        sample_str = f"  e.g. {', '.join(repr(v) for v in clean)}"
                lines.append(
                    f"  {col['column_name']}  {col['data_type']}{hint_str}{comment}{sample_str}"
                )
        else:
            # Fallback — DESCRIBE TABLE
            columns = _get_columns_describe(spark, full_name)
            if columns:
                for col in columns:
                    comment = f"  -- {col['comment']}" if col.get("comment") else ""
                    lines.append(f"  {col['name']}  {col['data_type']}{comment}")
            else:
                lines.append("  (columns unavailable)")

    _SCHEMA_CACHE = "\n".join(lines)
    return _SCHEMA_CACHE


def rebuild_schema_context(spark: Any) -> str:
    """Force a cache rebuild. Call after schema migrations or dim_table_schema refresh."""
    return build_schema_context(spark, force_rebuild=True)


def _load_dim_table_schema(spark: Any) -> dict[str, list[dict]]:
    """
    Load all rows from dim_table_schema and return as dict[table_name -> [col_rows]].
    Returns empty dict on any failure (triggers DESCRIBE TABLE fallback per table).
    """
    if spark is None:
        return {}
    try:
        df   = spark.sql(f"""
            SELECT table_name, column_name, data_type, comment,
                   is_filterable, is_joinable, sample_values
            FROM {DIM_TBL}
            ORDER BY table_name, column_name
        """)
        result: dict[str, list[dict]] = {}
        for row in df.collect():
            tbl  = row["table_name"]
            col  = {
                "column_name":   row["column_name"],
                "data_type":     row["data_type"] or "",
                "comment":       row["comment"] or "",
                "is_filterable": bool(row["is_filterable"]),
                "is_joinable":   bool(row["is_joinable"]),
                "sample_values": _parse_json_list(row["sample_values"]),
            }
            result.setdefault(tbl, []).append(col)
        return result
    except Exception:  # noqa: BLE001
        return {}


def _parse_json_list(raw: Any) -> list[str]:
    if not raw:
        return []
    try:
        return json.loads(raw) if isinstance(raw, str) else list(raw)
    except Exception:  # noqa: BLE001
        return []


def _get_columns_describe(spark: Any, full_table_name: str) -> list[dict]:
    """Fallback: DESCRIBE TABLE -> list of {name, data_type, comment}."""
    try:
        df   = spark.sql(f"DESCRIBE TABLE {full_table_name}")
        rows = df.collect()
        cols = []
        for r in rows:
            name    = r["col_name"] if "col_name" in r else r[0]
            dtype   = r["data_type"] if "data_type" in r else r[1]
            comment = r["comment"]   if "comment"   in r else (r[2] if len(r) > 2 else "")
            if not name or name.startswith("#"):
                continue
            cols.append({"name": name, "data_type": dtype, "comment": comment or ""})
        return cols
    except Exception:  # noqa: BLE001
        return []


# ---------------------------------------------------------------------------
# SchemaContextBuilder class — injectable into SqlQueryTool (W9-14)
# ---------------------------------------------------------------------------

class SchemaContextBuilder:
    """
    Object-oriented wrapper for schema context building.

    Prefers dim_table_schema (sample values, filterable/joinable hints).
    Falls back to DESCRIBE TABLE per table when dim data unavailable.

    Parameters
    ----------
    spark : Active Spark session.
    """

    def __init__(self, spark: Any) -> None:
        self._spark    = spark
        self._context: Optional[str] = None
        self._built_at: float        = 0.0

    def build(self, force: bool = False) -> str:
        """Build and cache the schema context (W9-14: uses dim_table_schema)."""
        if self._context and not force:
            return self._context
        t0             = time.time()
        self._context  = build_schema_context(self._spark, force_rebuild=True)
        self._built_at = time.time() - t0
        return self._context

    def get(self) -> str:
        """Return cached context, building if not yet available."""
        return self._context or self.build()

    def rebuild(self) -> str:
        """Force a full rebuild from dim_table_schema / DESCRIBE TABLE."""
        return self.build(force=True)

    @property
    def is_built(self) -> bool:
        return self._context is not None

    def summary(self) -> dict:
        ctx = self._context or ""
        return {
            "tables":       len(CONTRACT_TABLES_FOR_SQL),
            "context_len":  len(ctx),
            "built":        self._context is not None,
            "build_time_s": round(self._built_at, 2),
            "source":       "dim_table_schema (with sample values)",
        }

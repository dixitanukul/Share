"""
platform/v4/services/sql_helpers.py

P2-SQL-1: Shared SQL building utilities.

Extracted from V2 Cell 3 (provider_sql_filter) and common patterns
across branches. ProviderService.sql_filter() handles provider-specific
logic; this module handles general SQL construction.

Usage
-----
    from platform.v4.services.sql_helpers import (
        escape_sql, build_in_clause, build_like_clause,
        build_where, qualified_table,
    )
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

from ..config.settings import CATALOG, SCHEMA


def escape_sql(value: str) -> str:
    """Escape single quotes for safe SQL string interpolation."""
    return value.replace("'", "''")


def escape_like_pattern(pattern: str) -> str:
    """
    Escape LIKE metacharacters so user-supplied text is treated as a literal
    search term rather than a wildcard pattern.

    Step 3.8 — prevents LIKE wildcard injection in app-facing SQL paths.

    Escaped characters:
      \\   → \\\\   (backslash must be escaped first to avoid double-escaping)
      %    → \\%    (would otherwise match any sequence of characters)
      _    → \\_    (would otherwise match any single character)

    The companion ``build_like_clause`` appends `` ESCAPE '\\\\' `` automatically
    when this function has been applied, but callers may also call
    ``escape_like_pattern`` independently before building custom LIKE clauses.
    """
    return (
        pattern
        .replace("\\", "\\\\")   # must be first
        .replace("%",  "\\%")
        .replace("_",  "\\_")
    )


def build_in_clause(column: str, values: Sequence[str]) -> str:
    """Build a SQL IN clause from a list of values.

    Returns: "column IN ('v1', 'v2', ...)"
    If values is empty, returns 'FALSE' (no match).
    """
    if not values:
        return "FALSE"
    safe = ", ".join(f"'{escape_sql(v)}'" for v in values)
    return f"{column} IN ({safe})"


def build_like_clause(
    column: str,
    pattern: str,
    case_insensitive: bool = True,
    escape_wildcards: bool = True,
) -> str:
    """Build a LIKE clause.

    Args:
        column:           Column name.
        pattern:          Search term (will be wrapped in %).
        case_insensitive: If True, uses LOWER() on both sides.
        escape_wildcards: If True (default), escape % and _ in *pattern* so
                          user-supplied text is treated as a literal string.
                          Set to False only when the caller intentionally passes
                          a wildcard pattern (e.g. from a validated allow-list).

    Step 3.8: escape_wildcards=True is the default to prevent LIKE wildcard
    injection when user input flows through this function.
    """
    if escape_wildcards:
        pattern = escape_like_pattern(pattern)
        safe = escape_sql(pattern.lower() if case_insensitive else pattern)
        if case_insensitive:
            return f"LOWER({column}) LIKE '%{safe}%' ESCAPE '\\\\'"
        return f"{column} LIKE '%{safe}%' ESCAPE '\\\\'"
    # escape_wildcards=False: caller manages the pattern; still quote-escape
    safe = escape_sql(pattern.lower() if case_insensitive else pattern)
    if case_insensitive:
        return f"LOWER({column}) LIKE '%{safe}%'"
    return f"{column} LIKE '%{safe}%'"


def build_where(conditions: List[str], operator: str = "AND") -> str:
    """Combine multiple conditions into a WHERE clause.

    Args:
        conditions: List of SQL condition strings (without WHERE keyword).
        operator: 'AND' or 'OR'
    Returns: Combined string without 'WHERE' prefix. Empty string if no conditions.
    """
    non_empty = [c.strip() for c in conditions if c and c.strip()]
    if not non_empty:
        return ""
    joiner = f" {operator} "
    return joiner.join(f"({c})" for c in non_empty)


def qualified_table(table_name: str, catalog: str = CATALOG, schema: str = SCHEMA) -> str:
    """Return fully-qualified 3-part table name.

    Safety rules:
    - If already 3-part (2+ dots) → return as-is.
    - If 2-part (1 dot) → prepend catalog only.
    - If bare name (0 dots) → prepend catalog.schema.
    """
    dot_count = table_name.count('.')
    if dot_count >= 2:
        return table_name
    if dot_count == 1:
        # schema.table → catalog.schema.table
        return f"{catalog}.{table_name}"
    return f"{catalog}.{schema}.{table_name}"


def build_provider_id_filter(
    provider_ids: List[str], column: str = "provider_id"
) -> str:
    """Build provider ID filter from a list of resolved IDs.

    Optimizes: single ID uses =, multiple uses IN.
    """
    if not provider_ids:
        return ""
    if len(provider_ids) == 1:
        return f"{column} = '{escape_sql(provider_ids[0])}'"
    return build_in_clause(column, provider_ids)


def safe_limit(limit: Optional[int], max_allowed: int = 1000) -> int:
    """Clamp a user-provided limit to safe bounds."""
    if limit is None or limit <= 0:
        return max_allowed
    return min(limit, max_allowed)


def rewrite_superseded_by_join(sql: str) -> str:
    """
    Post-process LLM-generated SQL to fix direct equality joins on superseded_by.

    superseded_by stores a composite key: 'eff:YYYY-MM-DD|src:<source_filename>'.
    Any query joining superseded_by = source_filename always returns 0 rows because
    the composite string never equals a plain filename.

    This function rewrites all such patterns to use REGEXP_EXTRACT to extract the
    filename component before comparing.

    Patterns handled (both join orders, with or without table alias):
      alias.superseded_by = alias.source_filename
      alias.source_filename = alias.superseded_by
    """
    import re as _re

    # superseded_by = source_filename  (either alias order)
    sql = _re.sub(
        r'(\w+\.)?superseded_by\s*=\s*(\w+\.)?source_filename',
        lambda m: (
            f"REGEXP_EXTRACT({m.group(1) or ''}superseded_by, 'src:(.+)'"
            f", 1) = {m.group(2) or ''}source_filename"
        ),
        sql,
        flags=_re.IGNORECASE,
    )
    # source_filename = superseded_by  (reverse order)
    sql = _re.sub(
        r'(\w+\.)?source_filename\s*=\s*(\w+\.)?superseded_by',
        lambda m: (
            f"{m.group(1) or ''}source_filename"
            f" = REGEXP_EXTRACT({m.group(2) or ''}superseded_by, 'src:(.+)'"
            f", 1)"
        ),
        sql,
        flags=_re.IGNORECASE,
    )
    return sql


def build_temporal_filter(
    effective_col: str = "effective_date",
    current_only: bool = True,
    is_current_col: Optional[str] = "is_current_effective",
) -> str:
    """Build temporal filter for current-effective data.

    Uses the is_current_effective column when available (preferred),
    otherwise falls back to effective_date IS NOT NULL.
    """
    if not current_only:
        return f"{effective_col} IS NOT NULL"
    if is_current_col:
        return f"{is_current_col} = true"
    return f"{effective_col} IS NOT NULL"


# ---------------------------------------------------------------------------
# C-04 FIX: Canonical join enforcement for rates → profile
# ---------------------------------------------------------------------------

def rewrite_canonical_join(sql: str) -> tuple[str, bool]:
    """Rewrite prohibited rates→profile joins to use canonical_provider_id.

    The LLM often generates:
        tbl_contract_rates_all r JOIN tbl_genie_provider_profile p
        ON r.provider_id = p.provider_id

    This loses 31% of rows (52,429 orphans). The correct join is:
        ON r.canonical_provider_id = p.provider_id

    Returns (rewritten_sql, was_rewritten).
    """
    import re as _re

    _RATES_TABLE = 'tbl_contract_rates_all'
    _PROFILE_TABLE = 'tbl_genie_provider_profile'

    sql_lower = sql.lower()

    # Only apply if BOTH tables are referenced
    if _RATES_TABLE not in sql_lower or _PROFILE_TABLE not in sql_lower:
        return sql, False

    # Extract alias mappings: table_name alias or table_name AS alias
    _alias_pattern = _re.compile(
        r'(?:FROM|JOIN)\s+(?:dev_adb\.raw\.)?'
        r'(tbl_contract_rates_all|tbl_genie_provider_profile)'
        r'(?:\s+(?:AS\s+)?(\w+))?',
        _re.IGNORECASE,
    )
    rates_aliases = set()
    profile_aliases = set()
    for m in _alias_pattern.finditer(sql):
        tbl = m.group(1).lower()
        alias = m.group(2)
        if tbl == _RATES_TABLE:
            rates_aliases.add(alias.lower() if alias else _RATES_TABLE)
        elif tbl == _PROFILE_TABLE:
            profile_aliases.add(alias.lower() if alias else _PROFILE_TABLE)

    if not rates_aliases or not profile_aliases:
        return sql, False

    rewritten = False

    # Pattern: <rates_alias>.provider_id = <profile_alias>.provider_id
    # We need to rewrite <rates_alias>.provider_id → <rates_alias>.canonical_provider_id
    for r_alias in rates_aliases:
        for p_alias in profile_aliases:
            # Both orders: r.provider_id = p.provider_id OR p.provider_id = r.provider_id
            # Order 1: rates.provider_id = profile.provider_id
            pattern1 = _re.compile(
                rf'\b({_re.escape(r_alias)})\.provider_id'
                rf'(\s*=\s*)'
                rf'\b({_re.escape(p_alias)})\.provider_id\b',
                _re.IGNORECASE,
            )
            if pattern1.search(sql):
                sql = pattern1.sub(
                    lambda m: f'{m.group(1)}.canonical_provider_id{m.group(2)}{m.group(3)}.provider_id',
                    sql,
                )
                rewritten = True

            # Order 2: profile.provider_id = rates.provider_id
            pattern2 = _re.compile(
                rf'\b({_re.escape(p_alias)})\.provider_id'
                rf'(\s*=\s*)'
                rf'\b({_re.escape(r_alias)})\.provider_id\b',
                _re.IGNORECASE,
            )
            if pattern2.search(sql):
                sql = pattern2.sub(
                    lambda m: f'{m.group(1)}.provider_id{m.group(2)}{m.group(3)}.canonical_provider_id',
                    sql,
                )
                rewritten = True

    return sql, rewritten

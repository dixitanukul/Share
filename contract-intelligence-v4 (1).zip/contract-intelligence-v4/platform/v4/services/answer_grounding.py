"""platform/v4/services/answer_grounding.py

Step 1.6: Answer grounding enforcement (BUG-009 fix).

Prevents the agent from returning ungrounded answers when:
  1. Max iterations are reached without sufficient grounded evidence
  2. Zero retrieved passages score above the relevance threshold (0.5)
  3. The agent's "best-effort" synthesis has no evidentiary basis

This module replaces the old iteration-12 escape hatch that would force
ungrounded answers with a WARNING prefix. Instead, it returns a clear
refusal message when grounding cannot be established.

Architecture
------------
    AnswerGroundingEnforcer
      +-- EvidenceGate (passage sufficiency checks)
      +-- score_passage (keyword relevance scoring)
      +-- ToolResult inspection (structured data grounding)

    Called by AgentController at two points:
      1. Before _best_effort_synthesis (max-steps boundary)
      2. In _build_response when warning indicates incomplete evidence

Usage
-----
    from platform.v4.services.answer_grounding import AnswerGroundingEnforcer

    enforcer = AnswerGroundingEnforcer()
    decision = enforcer.evaluate(
        tool_results=tool_results,
        passages=retrieved_passages,
        query="What is the offset clause for Sutter?",
    )
    if not decision.is_grounded:
        return decision.refusal_message
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, List, Optional, Sequence

from .text_utils import extract_keywords, score_passage

logger = logging.getLogger(__name__)

# ============================================================
# CONSTANTS
# ============================================================

# The standard refusal message returned when grounding cannot be established.
# This replaces the old WARNING-prefixed guess behavior (BUG-009).
REFUSAL_MESSAGE = (
    "I could not find verified evidence for this question in the contract corpus. "
    "The available documents do not contain sufficient information to provide "
    "a confident, source-backed answer. Please try rephrasing with more specific "
    "provider names or contract terms, or verify that the relevant contract "
    "documents have been ingested."
)

# Refusal message for open-ended / exemplar questions where a specific provider
# was not named. Instead of a hard block, we suggest naming a provider.
EXEMPLAR_REFUSAL_MESSAGE = (
    "I have contract data for many providers, but your question didn't specify which one. "
    "Could you name a specific provider? For example, try asking:\n"
    "  \u2022 \"Show amendment history for Queen of the Valley Medical Center\"\n"
    "  \u2022 \"Show amendment history for Kindred Hospital San Diego\"\n"
    "  \u2022 \"Show amendment history for Mercy General Hospital\"\n"
    "Or ask: \"Which provider has the most amendment history?\" to see a ranked list."
)

# Regex patterns that indicate an open-ended / exemplar provider question
# (user wants 'any' provider rather than a specific one).
_EXEMPLAR_INTENT_PATTERNS = [
    re.compile(r"\bany\s+(?:one\s+)?provider\b", re.IGNORECASE),
    re.compile(r"\bany\s+(?:provider|contract|agreement)\b", re.IGNORECASE),
    re.compile(r"\ban?\s+(?:example|sample)\s+(?:provider|contract|agreement)", re.IGNORECASE),
    re.compile(r"\bfor\s+example\b", re.IGNORECASE),
    re.compile(r"\bpick\s+(?:any|one)\b", re.IGNORECASE),
    re.compile(r"\bshow\s+me\s+a\b", re.IGNORECASE),
    re.compile(r"\bgive\s+me\s+a\b", re.IGNORECASE),
    re.compile(r"\bone\s+provider\b", re.IGNORECASE),
    re.compile(r"\bsome\s+provider\b", re.IGNORECASE),
]


def _is_exemplar_intent(query: str) -> bool:
    """Return True if the query uses open-ended 'any/example/pick one' language."""
    return any(p.search(query) for p in _EXEMPLAR_INTENT_PATTERNS)

# Minimum passage relevance score (0-1) for a passage to count as "grounded".
# Below this threshold, the passage is too off-topic to support an answer.
# Set per development plan: "explicit refusal for questions where zero passages
# score > 0.5"
RELEVANCE_SCORE_THRESHOLD = 0.5

# Minimum number of passages that must exceed the relevance threshold
# for the answer to be considered grounded via passage evidence.
MIN_GROUNDED_PASSAGES = 1

# Minimum number of usable SQL/structured tool results that can substitute
# for passage-based grounding (e.g., rate queries returning exact numbers).
MIN_STRUCTURED_RESULTS = 1


# ============================================================
# TYPES
# ============================================================


@dataclass(frozen=True)
class GroundingDecision:
    """Result of evaluating whether sufficient grounding exists for an answer.

    Attributes
    ----------
    is_grounded : bool
        True if sufficient evidence exists to produce a trustworthy answer.
    reason : str
        Human-readable explanation of the grounding decision.
    refusal_message : str
        The message to return to the user when is_grounded=False.
        When is_grounded=True, this is empty string.
    grounded_passage_count : int
        Number of passages that scored above the relevance threshold.
    max_passage_score : float
        The highest relevance score among all passages (0.0 if no passages).
    has_structured_data : bool
        True if at least one tool returned usable structured data (SQL rows, etc.).
    evidence_sources : list[str]
        Summary of where grounding evidence was found (for diagnostics).
    """
    is_grounded: bool
    reason: str
    refusal_message: str = ""
    grounded_passage_count: int = 0
    max_passage_score: float = 0.0
    has_structured_data: bool = False
    evidence_sources: list = field(default_factory=list)


# ============================================================
# ANSWER GROUNDING ENFORCER
# ============================================================


class AnswerGroundingEnforcer:
    """Enforces that agent answers are backed by verifiable evidence.

    This is the anti-hallucination enforcement layer (BUG-009 fix) that
    ensures:
      - No answer is produced from the max-iteration escape hatch without
        evidence
      - Questions where zero passages score > threshold get an explicit refusal
      - Structured data (SQL results) can satisfy grounding independently
        of passage retrieval

    Parameters
    ----------
    relevance_threshold : float
        Minimum score_passage score for a passage to count as grounded.
        Default: 0.5 (per development plan specification).
    min_grounded_passages : int
        Minimum passages above threshold required for passage-based grounding.
        Default: 1.
    min_structured_results : int
        Minimum usable structured tool results that can substitute for
        passage grounding. Default: 1.
    refusal_message : str
        Custom refusal message. Defaults to REFUSAL_MESSAGE constant.
    """

    def __init__(
        self,
        relevance_threshold: float = RELEVANCE_SCORE_THRESHOLD,
        min_grounded_passages: int = MIN_GROUNDED_PASSAGES,
        min_structured_results: int = MIN_STRUCTURED_RESULTS,
        refusal_message: str = REFUSAL_MESSAGE,
    ) -> None:
        self._threshold = relevance_threshold
        self._min_passages = min_grounded_passages
        self._min_structured = min_structured_results
        self._refusal = refusal_message

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(
        self,
        tool_results: Sequence[Any],
        query: str = "",
        passages: Optional[List[Any]] = None,
    ) -> GroundingDecision:
        """Evaluate whether sufficient grounding evidence exists.

        Parameters
        ----------
        tool_results : sequence of ToolResult
            All tool results accumulated during the agent's ReAct loop.
        query : str
            The original user query (used for keyword relevance scoring
            of passages).
        passages : list, optional
            Explicitly provided passages (dicts or RetrievedPassage objects).
            If None, passages are extracted from tool_results metadata.

        Returns
        -------
        GroundingDecision
            Contains is_grounded, reason, and refusal_message.
        """
        evidence_sources: list[str] = []

        # ── Check 1: Structured data grounding ─────────────────────────
        # SQL results, rate data, profile data — these are deterministic
        # and don't need passage verification.
        has_structured = self._check_structured_data(tool_results)
        if has_structured:
            evidence_sources.append("structured_data")

        # ── Check 2: Passage-based grounding ───────────────────────────
        # Score passages against the query keywords. If at least one passage
        # scores above threshold, the answer has passage grounding.
        all_passages = passages if passages is not None else self._extract_passages(tool_results)
        grounded_count, max_score = self._score_passages(all_passages, query)

        if grounded_count >= self._min_passages:
            evidence_sources.append(f"passages({grounded_count})")

        # ── Decision logic ─────────────────────────────────────────────
        # Grounded if EITHER structured data OR passage evidence is sufficient
        is_grounded = (
            has_structured
            or grounded_count >= self._min_passages
        )

        if is_grounded:
            reason = self._build_grounded_reason(
                has_structured, grounded_count, max_score, evidence_sources
            )
            return GroundingDecision(
                is_grounded=True,
                reason=reason,
                refusal_message="",
                grounded_passage_count=grounded_count,
                max_passage_score=max_score,
                has_structured_data=has_structured,
                evidence_sources=evidence_sources,
            )
        else:
            reason = self._build_ungrounded_reason(
                grounded_count, max_score, all_passages, tool_results
            )
            # Choose refusal message based on query intent:
            # If the user asked for "any" or "an example" provider (open-ended
            # exemplar intent), return a helpful suggestion with provider names
            # instead of the generic hard-block message.
            refusal = (
                EXEMPLAR_REFUSAL_MESSAGE
                if _is_exemplar_intent(query)
                else self._refusal
            )
            logger.info(
                "Grounding enforcement: REFUSING answer. reason=%s "
                "passages=%d grounded=%d max_score=%.3f structured=%s exemplar=%s",
                reason, len(all_passages), grounded_count, max_score, has_structured,
                _is_exemplar_intent(query),
            )
            return GroundingDecision(
                is_grounded=False,
                reason=reason,
                refusal_message=refusal,
                grounded_passage_count=grounded_count,
                max_passage_score=max_score,
                has_structured_data=False,
                evidence_sources=[],
            )

    def should_refuse_at_max_steps(
        self,
        tool_results: Sequence[Any],
        query: str = "",
        passages: Optional[List[Any]] = None,
    ) -> tuple[bool, str]:
        """Convenience: check whether to refuse at the max-steps boundary.

        Returns
        -------
        (should_refuse, message)
            If should_refuse is True, message is the refusal text.
            If False, message is empty (answer can proceed).
        """
        decision = self.evaluate(
            tool_results=tool_results,
            query=query,
            passages=passages,
        )
        if decision.is_grounded:
            return False, ""
        return True, decision.refusal_message

    # ------------------------------------------------------------------
    # Private: structured data check
    # ------------------------------------------------------------------

    def _check_structured_data(self, tool_results: Sequence[Any]) -> bool:
        """Return True if any tool result contains usable structured data.

        Structured data includes SQL row results, rate lookups, provider
        profile data, etc. These are deterministic and don't require
        passage-based grounding verification.
        """
        usable_count = 0
        for result in tool_results:
            if not getattr(result, "success", False):
                continue
            data = getattr(result, "data", None)
            if data is None:
                continue
            # List of dicts = SQL row results
            if isinstance(data, list) and data:
                if isinstance(data[0], dict):
                    usable_count += 1
                    continue
            # Non-empty dict = structured lookup result
            if isinstance(data, dict) and data:
                usable_count += 1
                continue
        return usable_count >= self._min_structured

    # ------------------------------------------------------------------
    # Private: passage scoring
    # ------------------------------------------------------------------

    def _score_passages(
        self, passages: List[Any], query: str
    ) -> tuple[int, float]:
        """Score all passages against query keywords.

        Returns (grounded_count, max_score).
        """
        if not passages or not query:
            return 0, 0.0

        keywords = extract_keywords(query)
        if not keywords:
            return 0, 0.0

        max_score = 0.0
        grounded_count = 0

        for passage in passages:
            text = self._get_text(passage)
            if not text:
                continue
            score = score_passage(text, keywords)
            max_score = max(max_score, score)
            if score >= self._threshold:
                grounded_count += 1

        return grounded_count, round(max_score, 4)

    def _extract_passages(self, tool_results: Sequence[Any]) -> List[Any]:
        """Extract passages from tool results metadata or data.

        Tools that retrieve passages typically store them in:
          - result.metadata["passages"]
          - result.data (when data is a list of passage-like dicts)
          - result.citations (citation dicts with text)
        """
        passages: List[Any] = []
        for result in tool_results:
            # Check metadata.passages
            metadata = getattr(result, "metadata", {}) or {}
            if isinstance(metadata, dict) and "passages" in metadata:
                meta_passages = metadata["passages"]
                if isinstance(meta_passages, list):
                    passages.extend(meta_passages)
                    continue

            # Check citations (they contain passage text)
            citations = getattr(result, "citations", []) or []
            for cit in citations:
                if isinstance(cit, dict) and any(
                    k in cit for k in ("text", "unit_text", "chunk_text", "passage_text")
                ):
                    passages.append(cit)

            # Check if data itself is a list of passage-like dicts
            data = getattr(result, "data", None)
            if isinstance(data, list):
                for item in data[:50]:  # Cap to avoid processing huge result sets
                    if isinstance(item, dict) and any(
                        k in item for k in ("text", "unit_text", "chunk_text", "passage_text")
                    ):
                        passages.append(item)

        return passages

    # ------------------------------------------------------------------
    # Private: text extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _get_text(passage: Any) -> str:
        """Extract text from a passage (dict or object)."""
        if isinstance(passage, dict):
            return (
                passage.get("unit_text")
                or passage.get("text")
                or passage.get("chunk_text")
                or passage.get("passage_text")
                or ""
            )
        return (
            getattr(passage, "unit_text", "")
            or getattr(passage, "text", "")
            or getattr(passage, "chunk_text", "")
            or ""
        )

    # ------------------------------------------------------------------
    # Private: reason formatting
    # ------------------------------------------------------------------

    @staticmethod
    def _build_grounded_reason(
        has_structured: bool,
        grounded_count: int,
        max_score: float,
        evidence_sources: list[str],
    ) -> str:
        parts = []
        if has_structured:
            parts.append("structured data available")
        if grounded_count > 0:
            parts.append(
                f"{grounded_count} passage(s) scored above threshold "
                f"(max={max_score:.3f})"
            )
        return "Evidence sufficient: " + "; ".join(parts)

    @staticmethod
    def _build_ungrounded_reason(
        grounded_count: int,
        max_score: float,
        passages: List[Any],
        tool_results: Sequence[Any],
    ) -> str:
        total_passages = len(passages)
        total_results = len(tool_results)
        usable_results = sum(
            1 for r in tool_results
            if getattr(r, "success", False) and getattr(r, "data", None) is not None
        )

        if total_passages == 0 and usable_results == 0:
            return (
                "No evidence gathered: zero passages retrieved and "
                f"no usable tool results ({total_results} total attempts)."
            )
        if total_passages == 0:
            return (
                f"No passage-based evidence: {usable_results} tool result(s) "
                "returned data but none contained passage text for grounding."
            )
        return (
            f"Insufficient relevance: {total_passages} passage(s) retrieved "
            f"but {grounded_count} scored above threshold "
            f"(max_score={max_score:.3f}, threshold={RELEVANCE_SCORE_THRESHOLD})."
        )

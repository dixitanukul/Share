"""
platform/v4/services/telemetry_writer.py

Non-blocking query telemetry writer for the API layer.

Step 3.7 — logs every /api/v1/query request to
``dev_adb.raw.app_query_telemetry`` (or the environment-configured
catalog/schema equivalent) for operations, QA, and Phase 4 feedback loops.

Design constraints
------------------
* Fire-and-forget: telemetry write MUST NOT block or break a user response.
* Fault-tolerant: ALL exceptions are swallowed silently.
* Lazy table creation: table is created (IF NOT EXISTS) on first write.
* Thread-safe: uses a daemon thread per write; no shared mutable state.

Table schema
------------
    app_query_telemetry
    -------------------
    query_id          STRING      -- UUID, generated per request
    event_ts          TIMESTAMP   -- wall-clock time of the query
    app_version       STRING      -- e.g. "4.0.0-dev"
    question          STRING      -- raw user question (truncated at 2000 chars)
    provider_scope    STRING      -- provider_name filter (empty if portfolio)
    route_type        STRING      -- "stream" | "sync"
    tools_called      STRING      -- JSON array of tool names used
    total_latency_ms  LONG        -- end-to-end wall time in milliseconds
    agent_latency_ms  LONG        -- runtime.ask() duration in milliseconds
    confidence_label  STRING      -- HIGH / MODERATE / LOW / UNCERTAIN
    confidence_score  DOUBLE      -- numeric 0–1
    citations_count   INT         -- number of citations returned
    answer_length     INT         -- character length of the answer
    cost_estimate_usd DOUBLE      -- estimated LLM cost
    tool_calls_count  INT         -- number of tool calls made
    error_class       STRING      -- exception class name on failure, else NULL
    session_id        STRING      -- multi-turn session ID
"""
from __future__ import annotations

import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, List, Optional

logger = logging.getLogger(__name__)

_TABLE_DDL = """
CREATE TABLE IF NOT EXISTS {table} (
    query_id          STRING,
    event_ts          TIMESTAMP,
    app_version       STRING,
    question          STRING,
    provider_scope    STRING,
    route_type        STRING,
    tools_called      STRING,
    total_latency_ms  LONG,
    agent_latency_ms  LONG,
    confidence_label  STRING,
    confidence_score  DOUBLE,
    citations_count   INT,
    answer_length     INT,
    cost_estimate_usd DOUBLE,
    tool_calls_count  INT,
    error_class       STRING,
    session_id        STRING
)
USING DELTA
COMMENT 'API query telemetry — logged by /api/v1/query (Phase 3, Step 3.7)'
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true')
"""


class TelemetryWriter:
    """
    Non-blocking query telemetry writer.

    Parameters
    ----------
    spark : Active SparkSession (from Databricks Connect or notebook context).
    table : Fully-qualified table name, e.g. ``"dev_adb.raw.app_query_telemetry"``.
    """

    def __init__(self, spark: Any, table: str, app_version: str = "4.0.0-dev") -> None:
        self._spark       = spark
        self._table       = table
        self._app_version = app_version
        self._table_ready = False
        self._init_lock   = threading.Lock()

    # ── Public API ──────────────────────────────────────────────────────────

    def log(
        self,
        *,
        question:          str,
        provider_scope:    str            = "",
        route_type:        str            = "sync",
        tools_called:      List[str]      = (),
        total_latency_ms:  int            = 0,
        agent_latency_ms:  int            = 0,
        confidence_label:  str            = "",
        confidence_score:  float          = 0.0,
        citations_count:   int            = 0,
        answer_length:     int            = 0,
        cost_estimate_usd: float          = 0.0,
        tool_calls_count:  int            = 0,
        error_class:       Optional[str]  = None,
        session_id:        str            = "",
    ) -> None:
        """
        Fire-and-forget telemetry log. Returns immediately; write happens in a
        daemon thread. All exceptions from the write are silently swallowed.
        """
        row = {
            "query_id":          str(uuid.uuid4()),
            "event_ts":          datetime.now(tz=timezone.utc).isoformat(),
            "app_version":       self._app_version,
            "question":          question[:2000],
            "provider_scope":    provider_scope,
            "route_type":        route_type,
            "tools_called":      json.dumps(list(tools_called)),
            "total_latency_ms":  total_latency_ms,
            "agent_latency_ms":  agent_latency_ms,
            "confidence_label":  confidence_label,
            "confidence_score":  confidence_score,
            "citations_count":   citations_count,
            "answer_length":     answer_length,
            "cost_estimate_usd": cost_estimate_usd,
            "tool_calls_count":  tool_calls_count,
            "error_class":       error_class,
            "session_id":        session_id,
        }
        threading.Thread(target=self._write, args=(row,), daemon=True).start()

    # ── Private helpers ────────────────────────────────────────────────────

    def _ensure_table(self) -> None:
        """Create the telemetry table if it does not yet exist (idempotent)."""
        if self._table_ready:
            return
        with self._init_lock:
            if self._table_ready:
                return
            try:
                self._spark.sql(_TABLE_DDL.format(table=self._table))
                self._table_ready = True
            except Exception as exc:  # noqa: BLE001
                logger.warning("TelemetryWriter: table creation skipped: %s", exc)

    def _write(self, row: dict) -> None:
        """Synchronous write executed in a daemon thread.

        Uses SQL INSERT INTO (compatible with WarehouseSpark which lacks
        createDataFrame). Falls back gracefully on any error.
        """
        try:
            self._ensure_table()

            def _esc(v) -> str:
                if v is None:
                    return "NULL"
                if isinstance(v, bool):
                    return "true" if v else "false"
                if isinstance(v, (int, float)):
                    return str(v)
                safe = str(v).replace("\\", "\\\\").replace("'", "''")[:4000]
                return f"'{safe}'"

            cols = list(row.keys())
            vals = [_esc(row[c]) for c in cols]
            sql = (
                f"INSERT INTO {self._table} ({', '.join(cols)}) "
                f"VALUES ({', '.join(vals)})"
            )
            self._spark.sql(sql)
        except Exception as exc:  # noqa: BLE001
            logger.warning("TelemetryWriter: write failed (non-fatal): %s", exc)

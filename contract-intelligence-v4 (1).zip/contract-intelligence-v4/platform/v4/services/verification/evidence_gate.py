"""
platform/v4/services/verification/evidence_gate.py

P3-VER-2: Evidence sufficiency gate.

Decides whether retrieved passages are sufficient to answer a query,
replacing the ``should_refuse`` logic from V2 HybridRetriever.

Design
------
Four sequential checks (any failure -> should_refuse=True):

  1. Presence  -- at least ``min_passages`` passages returned.
  2. Relevance -- at least ``min_scored`` passages score above
                 ``relevance_threshold`` against query keywords.
  3. Provider  -- if ``provider_name`` given, at least one passage
                 must mention that provider (fail-open for empty corpora).
  4. Content   -- passages are not all very short (stub/noise guard).

Fail-open behaviour: if ``query`` is empty or no keywords are extracted,
relevance check is skipped (all passages pass).

Usage
-----
    from platform.v4.services.verification.evidence_gate import EvidenceGate

    gate    = EvidenceGate()
    result  = gate.check(passages, query="offset clause",
                         provider_name="Sutter Roseville")
    if result.should_refuse:
        return ToolResult(success=False, summary=result.reason)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, List, Optional

from ..text_utils import extract_keywords, score_passage

logger = logging.getLogger(__name__)

# Minimum characters for a passage to be treated as substantive content
_MIN_CONTENT_LENGTH = 40


@dataclass
class SufficiencyResult:
    """Result of an evidence sufficiency check."""
    sufficient:     bool
    reason:         str
    confidence:     float       # 0.0-1.0  (useful when sufficient=True)
    passage_count:  int
    scored_count:   int         # passages above relevance threshold
    provider_hit:   bool        # True if provider filter was satisfied (or not checked)

    @property
    def should_refuse(self) -> bool:
        """Convenience alias: True when the agent should decline to answer."""
        return not self.sufficient


class EvidenceGate:
    """
    Evidence sufficiency gate.

    Runs four sequential checks on a list of retrieved passages and
    returns a ``SufficiencyResult`` indicating whether the agent has
    enough evidence to generate a trustworthy answer.

    Parameters
    ----------
    min_passages : int
        Minimum total passages required (default 1).
    min_scored : int
        Minimum passages that must score above ``relevance_threshold``
        (default 1).  Only checked when query keywords are extractable.
    relevance_threshold : float
        Minimum ``score_passage`` score for a passage to count as
        relevant.  Default 0.05 (low bar -- intentionally permissive).
    min_content_length : int
        Passages shorter than this are treated as noise (default 40 chars).
    """

    def __init__(
        self,
        min_passages:        int   = 1,
        min_scored:          int   = 1,
        relevance_threshold: float = 0.05,
        min_content_length:  int   = _MIN_CONTENT_LENGTH,
    ) -> None:
        self._min_passages   = min_passages
        self._min_scored     = min_scored
        self._rel_threshold  = relevance_threshold
        self._min_len        = min_content_length

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check(
        self,
        passages:      List[Any],
        query:         str = "",
        provider_name: Optional[str] = None,
    ) -> SufficiencyResult:
        """
        Check whether passages are sufficient to answer the query.

        Parameters
        ----------
        passages : list
            Passage dicts from ``RetrievalService`` (keys: unit_text,
            provider_name, source_filename ...) **or** ``RetrievedPassage``
            objects from ``RetrievalAdapter``.  Both shapes are supported.
        query : str
            Original query string.  Used for keyword relevance scoring.
        provider_name : str, optional
            If given, at least one passage must mention this provider
            (case-insensitive substring match).
        """
        # -- Check 1: presence ----------------------------------------
        if not passages:
            return SufficiencyResult(
                sufficient=False,
                reason="No passages retrieved -- concept may not appear in the indexed corpus.",
                confidence=0.0,
                passage_count=0,
                scored_count=0,
                provider_hit=(provider_name is None),
            )

        # Filter out stub/noise passages
        substantive = [p for p in passages if len(self._text(p)) >= self._min_len]
        total     = len(passages)
        sub_count = len(substantive)

        if sub_count < self._min_passages:
            return SufficiencyResult(
                sufficient=False,
                reason=(
                    f"Only {sub_count} substantive passage(s) retrieved "
                    f"({total - sub_count} too short). "
                    "Query may be too specific or concept absent from corpus."
                ),
                confidence=0.1,
                passage_count=total,
                scored_count=0,
                provider_hit=(provider_name is None),
            )

        # -- Check 2: relevance ----------------------------------------
        kws = extract_keywords(query) if query else []
        if kws:
            scored_count = sum(
                1 for p in substantive
                if score_passage(self._text(p), kws) >= self._rel_threshold
            )
        else:
            scored_count = sub_count  # no keywords -- skip relevance gate

        if scored_count < self._min_scored:
            return SufficiencyResult(
                sufficient=False,
                reason=(
                    f"Retrieved {sub_count} passage(s) but none scored above the "
                    f"relevance threshold ({self._rel_threshold:.2f}) for query keywords "
                    f"{kws[:4]}.  Passages may be off-topic."
                ),
                confidence=0.15,
                passage_count=total,
                scored_count=scored_count,
                provider_hit=(provider_name is None),
            )

        # -- Check 3: provider match -----------------------------------
        provider_hit = True
        if provider_name:
            prov_lower = provider_name.lower()
            provider_hit = any(
                prov_lower in self._provider(p).lower()
                for p in substantive
            )
            if not provider_hit:
                return SufficiencyResult(
                    sufficient=False,
                    reason=(
                        f"No passages matched provider '{provider_name}'. "
                        "Provider may not be in the indexed corpus or name "
                        "may need alias resolution."
                    ),
                    confidence=0.0,
                    passage_count=total,
                    scored_count=scored_count,
                    provider_hit=False,
                )

        # -- Sufficient -- compute confidence from coverage -----------
        coverage    = scored_count / max(sub_count, 1)
        depth_bonus = min(sub_count / 10.0, 0.3)   # more passages -> higher confidence
        confidence  = round(min(coverage + depth_bonus, 1.0), 3)

        logger.debug(
            "EvidenceGate.check: sufficient  passages=%d scored=%d confidence=%.3f",
            total, scored_count, confidence,
        )

        return SufficiencyResult(
            sufficient=True,
            reason=f"{total} passage(s) retrieved, {scored_count} relevant to query.",
            confidence=confidence,
            passage_count=total,
            scored_count=scored_count,
            provider_hit=provider_hit,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _text(passage: Any) -> str:
        """Extract text from a passage dict or RetrievedPassage."""
        if isinstance(passage, dict):
            return passage.get("unit_text", passage.get("text", ""))
        return getattr(passage, "text", "") or getattr(passage, "unit_text", "")

    @staticmethod
    def _provider(passage: Any) -> str:
        """Extract provider_name from a passage dict or RetrievedPassage."""
        if isinstance(passage, dict):
            return passage.get("provider_name", "")
        return getattr(passage, "provider_name", "")

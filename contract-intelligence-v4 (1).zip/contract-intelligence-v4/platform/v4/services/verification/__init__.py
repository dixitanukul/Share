"""V3 verification services — evidence gate and citation verification."""
from platform.v4.services.verification.evidence_gate import EvidenceGate, SufficiencyResult
from platform.v4.services.verification.citation_verifier import (
    CitationVerifier, VerificationResult, CitationVerdict,
    CheckResult, CheckStatus,
)

__all__ = [
    "EvidenceGate",
    "SufficiencyResult",
    "CitationVerifier",
    "VerificationResult",
    "CitationVerdict",
    "CheckResult",
    "CheckStatus",
]

"""
platform/v4/services/polling.py

Adaptive polling utility for REST API polling loops.

Step 3.2 — replaces fixed-interval time.sleep() with exponential backoff
to reduce latency on fast queries without hammering slow APIs.

Behavior
--------
  initial_s      : First sleep interval (default 200 ms).
  backoff_factor : Multiplier applied to each successive interval (default 1.5x).
  max_interval_s : Hard cap on any single sleep (default 2.0 s).
  timeout_s      : Overall wall-clock deadline; raises PollTimeout when exceeded.

Example intervals (initial=0.2, factor=1.5, cap=2.0):
  0.2 → 0.3 → 0.45 → 0.68 → 1.01 → 1.52 → 2.0 → 2.0 → ...

Usage
-----
    from platform.v4.services.polling import poll_sync, poll_async, PollTimeout

    # Synchronous (notebook / tool path):
    result = poll_sync(
        fn=lambda: requests.get(url).json(),
        terminal_states=frozenset({"COMPLETED", "FAILED", "ERROR"}),
        timeout_s=120,
    )

    # Async (FastAPI endpoint path):
    result = await poll_async(
        fn=lambda: requests.get(url).json(),
        terminal_states=frozenset({"COMPLETED", "FAILED", "ERROR"}),
        timeout_s=120,
    )
"""
from __future__ import annotations

import time
from typing import Any, Callable, FrozenSet


class PollTimeout(TimeoutError):
    """Raised by poll_sync / poll_async when the timeout_s deadline is exceeded."""


def poll_sync(
    fn: Callable[[], dict],
    terminal_states: FrozenSet[str],
    status_key: str = "status",
    *,
    initial_s: float = 0.2,
    backoff_factor: float = 1.5,
    max_interval_s: float = 2.0,
    timeout_s: float = 30.0,
) -> dict:
    """
    Poll ``fn()`` with exponential backoff until a terminal status is reached.

    Parameters
    ----------
    fn              : Zero-argument callable returning a dict.
    terminal_states : Status strings that signal completion (success or failure).
    status_key      : Key in the returned dict that holds the status string.
    initial_s       : First sleep duration in seconds.
    backoff_factor  : Multiplier applied to the sleep interval after each poll.
    max_interval_s  : Hard upper bound on any single sleep.
    timeout_s       : Total allowed wall-clock time before raising PollTimeout.

    Returns
    -------
    dict
        The last dict returned by ``fn()`` whose status was terminal.

    Raises
    ------
    PollTimeout
        If ``timeout_s`` elapses before a terminal status is observed.
    """
    deadline = time.perf_counter() + timeout_s
    interval = initial_s
    result: dict = {}

    while time.perf_counter() < deadline:
        result = fn()
        if result.get(status_key, "") in terminal_states:
            return result

        remaining = deadline - time.perf_counter()
        sleep_time = min(interval, max_interval_s, max(remaining, 0.0))
        if sleep_time <= 0:
            break
        time.sleep(sleep_time)
        interval = min(interval * backoff_factor, max_interval_s)

    # One final attempt before raising
    result = fn()
    if result.get(status_key, "") in terminal_states:
        return result

    raise PollTimeout(
        f"poll_sync: timed out after {timeout_s:.0f}s. "
        f"Last status: {result.get(status_key, 'UNKNOWN')!r}"
    )


async def poll_async(
    fn: Callable[[], dict],
    terminal_states: FrozenSet[str],
    status_key: str = "status",
    *,
    initial_s: float = 0.2,
    backoff_factor: float = 1.5,
    max_interval_s: float = 2.0,
    timeout_s: float = 30.0,
) -> dict:
    """
    Async variant of ``poll_sync``. Uses ``asyncio.sleep`` so the FastAPI
    event loop is not blocked during polling.

    Parameters and return value are identical to ``poll_sync``.
    """
    import asyncio

    deadline = time.perf_counter() + timeout_s
    interval = initial_s
    result: dict = {}

    while time.perf_counter() < deadline:
        result = fn()
        if result.get(status_key, "") in terminal_states:
            return result

        remaining = deadline - time.perf_counter()
        sleep_time = min(interval, max_interval_s, max(remaining, 0.0))
        if sleep_time <= 0:
            break
        await asyncio.sleep(sleep_time)
        interval = min(interval * backoff_factor, max_interval_s)

    # One final attempt before raising
    result = fn()
    if result.get(status_key, "") in terminal_states:
        return result

    raise PollTimeout(
        f"poll_async: timed out after {timeout_s:.0f}s. "
        f"Last status: {result.get(status_key, 'UNKNOWN')!r}"
    )

"""
platform/v4/services/vector_search_service.py

V4 vector search service — uses single unified index (idx_unified_v4).

Replaces V3 multi-index architecture. The unified index contains:
  - Layer 1: 670,728 raw OCR passages (chunk_type=PASSAGE)
  - Layer 2: 57,147 structured legal units (chunk_type=CLAUSE/DEFINITION/RATE_TABLE/etc.)
  - Total: 727,875 chunks with GTE-1024d embeddings

Usage
-----
    from platform.v4.services.vector_search_service import VectorSearchService

    vs = VectorSearchService()
    results = vs.search("offset clause in healthcare contract", top_k=20)
    passages = vs.retrieve("stop loss", provider_name="Cedarssinai Medical Center")
    legal = vs.search_legal("termination clause", provider_name="Sutter Health")
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..config.settings import VS_ENDPOINT, VS_INDEX_UNIFIED

logger = logging.getLogger(__name__)


@dataclass
class DegradationState:
    """Tracks VS health state."""
    is_degraded: bool = False
    reason: str = ""


class VectorSearchService:
    """
    Vector search service wrapping Databricks Vector Search SDK.

    V4 — Uses single unified index (idx_unified_v4) containing both
    raw OCR passages (Layer 1, chunk_type=PASSAGE) and structured
    legal units (Layer 2, chunk_type=CLAUSE/DEFINITION/RATE_TABLE/etc.).

    Features:
      - Single-index architecture (no fallback needed)
      - Degradation state tracking
      - Filter support: provider_name, is_current, chunk_type
      - Unified search interface for both raw SDK results and structured dicts
      - Real cosine similarity scores from VS SDK (Step 1.1 fix, 2026-06-18)
    """

    # Columns synced to idx_unified_v4 (available for retrieval)
    _DEFAULT_COLUMNS = [
        "chunk_id", "chunk_text", "provider_name", "provider_id",
        "source_filename", "chunk_type", "page_number_est",
        "section_header", "content_length", "quality_score",
        "doc_role", "is_current", "context_prefix",
    ]

    # Minimal columns for lightweight retrieval
    _RETRIEVE_COLUMNS = [
        "chunk_id", "provider_name", "source_filename",
        "chunk_text", "chunk_type", "page_number_est",
        "is_current", "content_length",
    ]

    # Legal unit chunk types (Layer 2 of unified index)
    _LEGAL_CHUNK_TYPES = ["CLAUSE", "SECTION", "DEFINITION", "RATE_TABLE", "CONDITION"]

    # Columns for legal unit retrieval
    _LEGAL_COLUMNS = ["unit_text", "provider_name", "source_filename", "section_type"]

    def __init__(
        self,
        endpoint: str = VS_ENDPOINT,
        index_name: str = VS_INDEX_UNIFIED,
        index_fulltext: str = VS_INDEX_UNIFIED,
        index_legal: str = VS_INDEX_UNIFIED,
        workspace_url: Optional[str] = None,
        personal_access_token: Optional[str] = None,
    ) -> None:
        self._endpoint = endpoint
        self._index_name = index_name
        self._index_fulltext = index_fulltext
        self._index_legal = index_legal
        self._workspace_url = workspace_url
        self._personal_access_token = personal_access_token
        self._degradation = DegradationState()
        self._client: Optional[Any] = None

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_degraded(self) -> bool:
        return self._degradation.is_degraded

    @property
    def degradation_reason(self) -> str:
        return self._degradation.reason

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        provider_filter: Optional[str] = None,
        top_k: int = 20,
        columns: Optional[List[str]] = None,
        current_only: bool = True,
        chunk_types: Optional[List[str]] = None,
        index_name: Optional[str] = None,
    ) -> List[List]:
        """
        Search contract passages via the unified VS index.

        Returns raw data_array (list of lists).
        NOTE: The last element of each row is the cosine similarity score
        appended by the VS SDK (not part of the requested columns).

        Args:
            query: Natural language search query.
            provider_filter: Filter to a single provider name.
            top_k: Number of results to return (default 20).
            columns: Override columns returned (default: _DEFAULT_COLUMNS).
            current_only: If True, only return is_current=True passages.
            chunk_types: Filter to specific chunk types (e.g., ["PASSAGE", "CLAUSE"]).
            index_name: Override index name (default: self._index_name).
        """
        client = self._get_client()
        cols = columns or self._DEFAULT_COLUMNS
        idx = index_name or self._index_name

        filters = {}
        if provider_filter and provider_filter not in ("All Providers", None, ""):
            filters["provider_name"] = provider_filter
        if current_only:
            filters["is_current"] = True
        if chunk_types and len(chunk_types) == 1:
            filters["chunk_type"] = chunk_types[0]

        try:
            index = client.get_index(endpoint_name=self._endpoint, index_name=idx)
            results = index.similarity_search(
                query_text=query, columns=cols,
                num_results=top_k, filters=filters or None,
            )
            self._degradation = DegradationState(is_degraded=False)
            return results.get("result", {}).get("data_array", [])

        except Exception as e:
            # H9: Reset client on 401/auth errors so next call rebuilds with fresh OAuth token.
            # In Databricks Apps, SP OAuth tokens rotate automatically; a stale cached
            # client would otherwise keep returning 401 until the process restarts.
            if self._is_auth_error(e):
                logger.warning("VS 401/auth error — resetting client for OAuth token refresh")
                self._client = None
            self._degradation = DegradationState(
                is_degraded=True,
                reason=f"VS index unavailable: {str(e)[:150]}",
            )
            logger.error("VS DEGRADED: index unavailable (%s)", str(e)[:80])
            return []

    def retrieve(
        self,
        query: str,
        top_k: int = 20,
        provider_name: Optional[str] = None,
        current_only: bool = True,
        chunk_types: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """
        Retrieve passages as structured dicts (replaces _live_retrieve_fn).

        Returns list of dicts with keys:
          chunk_id, provider_name, source_filename, page_number_est,
          chunk_text, chunk_type, is_current, content_length, score, channel

        Step 1.1 fix (2026-06-18): score is now actual cosine similarity from
        the VS SDK (r[-1]), not synthetic rank-decay. Range: ~0.50-0.80 for
        GTE-1024d embeddings on contract text.
        """
        client = self._get_client()

        filters = {}
        if provider_name:
            filters["provider_name"] = provider_name
        if current_only:
            filters["is_current"] = True
        if chunk_types and len(chunk_types) == 1:
            filters["chunk_type"] = chunk_types[0]

        def _rows_to_dicts(rows):
            return [
                {
                    "chunk_id": r[0],
                    "provider_name": r[1],
                    "source_filename": r[2],
                    "chunk_text": r[3],
                    "chunk_type": r[4],
                    "page_number_est": r[5],
                    "is_current": r[6],
                    "content_length": r[7],
                    "score": float(r[-1]) if len(r) > len(self._RETRIEVE_COLUMNS) else 1.0 - (i * 0.02),
                    "channel": "semantic",
                }
                for i, r in enumerate(rows)
            ]

        try:
            index = client.get_index(
                endpoint_name=self._endpoint, index_name=self._index_name
            )
            vs_r = index.similarity_search(
                query_text=query,
                columns=self._RETRIEVE_COLUMNS,
                num_results=top_k,
                filters=filters or None,
            )
            rows = vs_r.get("result", {}).get("data_array", [])
            self._degradation = DegradationState(is_degraded=False)

            # P1-5: Fuzzy provider filter fallback.
            # VS uses exact-match filters; if the canonical provider name stored in
            # the index differs even slightly from the filter value (extra punctuation,
            # different casing, legal suffix), the result set is empty. When we get 0
            # results WITH a provider filter, retry WITHOUT the filter and post-filter
            # by substring match — catches "Alvarado Hospital" vs "Alvarado Hospital LP".
            if not rows and provider_name:
                logger.info(
                    "P1-5: VS exact-match returned 0 for provider=%r, retrying without filter",
                    provider_name,
                )
                _fallback_filters = {}
                if current_only:
                    _fallback_filters["is_current"] = True
                if chunk_types and len(chunk_types) == 1:
                    _fallback_filters["chunk_type"] = chunk_types[0]
                vs_r2 = index.similarity_search(
                    query_text=query,
                    columns=self._RETRIEVE_COLUMNS,
                    num_results=top_k * 2,  # Fetch more; will post-filter
                    filters=_fallback_filters or None,
                )
                rows2 = vs_r2.get("result", {}).get("data_array", [])
                # Post-filter: keep rows whose provider_name contains a key word
                # from the requested provider name (case-insensitive substring)
                _pn_lower = provider_name.lower()
                # Key words: skip stop-words; at least one significant word must match
                _stop = {"of", "the", "and", "at", "for", "a", "an", "in", "is", "medical", "health"}
                _key_words = [
                    w for w in _pn_lower.replace(",", "").split()
                    if w not in _stop and len(w) > 3
                ]
                if _key_words:
                    rows = [
                        r for r in rows2
                        if any(kw in (r[1] or "").lower() for kw in _key_words)
                    ]
                    # Fall back to unfiltered if still 0 (last resort)
                    if not rows:
                        rows = rows2[:top_k]
                        logger.info(
                            "P1-5: Keyword post-filter also empty for %r — using unfiltered results",
                            provider_name,
                        )
                    else:
                        logger.info(
                            "P1-5: Fuzzy fallback found %d results for %r",
                            len(rows), provider_name,
                        )
                        rows = rows[:top_k]

            # Map positional results to structured dicts
            # _RETRIEVE_COLUMNS order: chunk_id, provider_name, source_filename,
            #   chunk_text, chunk_type, page_number_est, is_current, content_length
            # VS SDK appends cosine similarity as the LAST element (r[-1])
            return _rows_to_dicts(rows)

        except Exception as e:
            # H9: Reset client on 401/auth errors (same as search())
            if self._is_auth_error(e):
                logger.warning("VS 401/auth error in retrieve — resetting client")
                self._client = None
            logger.warning("VectorSearchService.retrieve failed: %s", e)
            self._degradation = DegradationState(
                is_degraded=True, reason=str(e)[:200]
            )
            return []

    def search_legal(
        self,
        query: str,
        provider_name: Optional[str] = None,
        top_k: int = 10,
        unit_types: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search structured legal units (Layer 2) specifically.

        Convenience wrapper that filters to non-PASSAGE chunk types.
        Uses the unified index with chunk_type post-filtering.
        """
        types = unit_types or self._LEGAL_CHUNK_TYPES
        # VS only supports single-value filter; search without type filter and post-filter
        results = self.retrieve(
            query=query,
            provider_name=provider_name,
            top_k=top_k * 3,  # Over-fetch to compensate for post-filter
            current_only=True,
        )
        filtered = [r for r in results if r.get("chunk_type") in types]
        return filtered[:top_k]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _is_auth_error(exc: Exception) -> bool:
        """Return True if the exception indicates a 401 / expired-token error.

        Checks for HTTP 401 codes and common auth-related error strings across
        both AISearchClient and VectorSearchClient exception representations.
        """
        msg = str(exc).lower()
        return (
            "401" in msg
            or "unauthorized" in msg
            or "unauthenticated" in msg
            or ("token" in msg and ("expired" in msg or "invalid" in msg))
            or "authentication" in msg
        )

    def _get_client(self) -> Any:
        """Lazy-initialize the VectorSearchClient.

        If workspace_url + personal_access_token were provided at construction
        (e.g. in Databricks Apps where JVM notebook auth is unavailable), they
        are passed explicitly so the VS SDK does not rely on auto-discovery.

        Self-healing: If the databricks-vectorsearch package is not installed,
        this method will attempt to install it automatically via pip and retry
        the import. This ensures the service never enters degraded state due to
        a missing package.
        """
        if self._client is None:
            url   = self._workspace_url
            token = self._personal_access_token
            self._client = self._try_init_client(url, token)
            if self._client is None:
                # Package missing — attempt auto-install and retry
                self._auto_install_vectorsearch()
                self._client = self._try_init_client(url, token)
                if self._client is None:
                    raise ImportError(
                        "databricks-vectorsearch could not be installed or imported. "
                        "Install manually: pip install databricks-vectorsearch>=0.40"
                    )
        return self._client

    @staticmethod
    def _try_init_client(
        url: Optional[str], token: Optional[str]
    ) -> Optional[Any]:
        """Attempt to create a VS client, returning None if imports fail."""
        # Try newer AISearchClient first
        try:
            from databricks.ai_search.client import AISearchClient
            if url and token:
                return AISearchClient(
                    workspace_url=url,
                    personal_access_token=token,
                )
            return AISearchClient()
        except (ImportError, TypeError):
            pass

        # Fallback: VectorSearchClient (older SDK)
        try:
            from databricks.vector_search.client import VectorSearchClient
            if url and token:
                return VectorSearchClient(
                    workspace_url=url,
                    personal_access_token=token,
                    disable_notice=True,
                )
            return VectorSearchClient(disable_notice=True)
        except ImportError:
            return None

    @staticmethod
    def _auto_install_vectorsearch() -> None:
        """Auto-install databricks-vectorsearch if missing.

        Uses subprocess to avoid kernel restarts. Logs outcome for
        observability. This ensures VS never stays degraded due to a
        missing package in notebooks or app containers.
        """
        import subprocess
        import sys

        logger.warning(
            "VS-AUTO-INSTALL: databricks-vectorsearch not found — "
            "attempting automatic installation..."
        )
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install",
                 "databricks-vectorsearch>=0.40", "--quiet", "--disable-pip-version-check"],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0:
                logger.info(
                    "VS-AUTO-INSTALL: Successfully installed databricks-vectorsearch"
                )
                # Clear failed-import entries from sys.modules
                _stale = [
                    k for k in list(sys.modules.keys())
                    if k.startswith("databricks.vector_search")
                    or k.startswith("databricks.ai_search")
                ]
                for k in _stale:
                    del sys.modules[k]
                # Extend databricks namespace __path__ to include the
                # site-packages dir where VS was just installed. On
                # Databricks clusters the pre-loaded 'databricks' module
                # only has __path__ pointing to /databricks/spark/python/
                # which doesn't include ephemeral pip install locations.
                import os, importlib
                importlib.invalidate_caches()
                if "databricks" in sys.modules:
                    db_mod = sys.modules["databricks"]
                    if hasattr(db_mod, "__path__"):
                        _existing = list(db_mod.__path__)
                        for _sp in sys.path:
                            _cand = os.path.join(_sp, "databricks")
                            if (
                                os.path.isdir(
                                    os.path.join(_cand, "vector_search")
                                )
                                and _cand not in _existing
                            ):
                                db_mod.__path__.insert(0, _cand)
                                logger.info(
                                    "VS-AUTO-INSTALL: Extended "
                                    "databricks.__path__ with %s",
                                    _cand,
                                )
                                break
            else:
                logger.error(
                    "VS-AUTO-INSTALL: pip install failed (rc=%d): %s",
                    result.returncode, (result.stderr or result.stdout)[:300],
                )
        except Exception as exc:
            logger.error(
                "VS-AUTO-INSTALL: Installation attempt raised: %s", exc
            )

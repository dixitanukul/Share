"""
platform/v4/services/retrieval_service.py

P3-RET-1: Native V3 retrieval service.

Composes VectorSearchService + CurrentEffectiveFilter + text_utils scoring
to replace the _live_retrieve_fn closure from V2 Cell 15 / Cell 23.

Methods
-------
retrieve(query, provider_name, top_k, current_only) -> list[dict]
    Semantic search on the page-level fulltext index with current-effective
    filtering and relevance scoring.

retrieve_legal(query, top_k) -> list[dict]
    Semantic search on the unified index filtered to legal unit chunk types.

Usage
-----
    from platform.v4.services.retrieval_service import build_retrieval_service

    svc = build_retrieval_service(spark=spark)
    results = svc.retrieve("offset clause", provider_name="Sutter Roseville", top_k=10)
    legal  = svc.retrieve_legal("overpayment recoupment", top_k=5)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from ..config.settings import TBL_VS_UNIFIED_READY  # noqa: F401 (re-exported)
from ..core.current_effective_filter import CurrentEffectiveFilter
from ..services.text_utils import extract_keywords, score_passage
from ..services.vector_search_service import VectorSearchService

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# RetrievalService
# ---------------------------------------------------------------------------

class RetrievalService:
    """
    High-level retrieval service for V3.

    Composes:
      - VectorSearchService  — Databricks Vector Search SDK wrapper
      - CurrentEffectiveFilter — removes passages from expired documents
      - text_utils — passage relevance scoring and dedup

    This replaces the ``_live_retrieve_fn`` closure wired in V2 Cell 15 / Cell 23.
    The returned dicts share the same shape as ``VectorSearchService.retrieve()``
    so they are directly compatible with ``RetrievalAdapter._normalise_chunk()``.

    Parameters
    ----------
    vs_service : VectorSearchService
        Configured VS wrapper (injected; must not be None).
    current_filter : CurrentEffectiveFilter, optional
        Current-effective document filter.  If None, no filtering is applied
        (all passages returned as-is).
    provider_service : object, optional
        ProviderService instance for alias resolution before VS queries.
        If None, provider_name is passed directly to VS.
    """

    def __init__(
        self,
        vs_service: VectorSearchService,
        current_filter: Optional[CurrentEffectiveFilter] = None,
        provider_service: Optional[Any] = None,
    ) -> None:
        self._vs              = vs_service
        self._filter          = current_filter
        self._provider_service = provider_service

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def retrieve(
        self,
        query: str,
        provider_name: Optional[str] = None,
        top_k: int = 10,
        current_only: bool = True,
        keep_minimum: int = 3,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """
        Retrieve passages from the page-level fulltext index.

        Parameters
        ----------
        query : str
            Natural language query.
        provider_name : str, optional
            Filter results to a specific provider.  Accepts aliases; resolved
            via ProviderService if available.  Also accepts ``provider_id``
            kwarg for backward-compat.
        top_k : int
            Maximum number of passages to return from VS before filtering.
        current_only : bool
            If True (default), filter out passages from expired documents.
            Set False for temporal/amendment analysis that needs history.
        keep_minimum : int
            Safety threshold: if current-effective filtering would reduce
            results below this count, return all results with
            ``is_current_effective`` flags set instead.
        """
        resolved_provider = self._resolve_provider(
            provider_name or kwargs.get("provider_id")
        )

        # 1. Vector search
        raw = self._vs.retrieve(query, top_k=top_k, provider_name=resolved_provider)

        if not raw:
            logger.debug("RetrievalService.retrieve: no VS results for %r", query[:80])
            return []

        # 2. Current-effective filter
        if current_only and self._filter is not None:
            raw = self._apply_filter(raw, keep_minimum=keep_minimum)

        # 3. Relevance scoring (keyword density vs. query)
        raw = self._score_and_sort(raw, query)

        # 4. Dedup by source_filename (keep best-scored per file)
        raw = self._dedup_by_filename(raw)

        return raw

    def retrieve_legal(
        self,
        query: str,
        top_k: int = 10,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """
        Retrieve structured legal units (clause-level) from the unified index.

        Step 1.1 fix (2026-06-18): Rewritten to use VectorSearchService.search_legal()
        on the unified index with chunk_type filtering, instead of the deleted
        idx_legal_units_v2. Scores are now actual cosine similarity from the VS SDK.

        Returns passage dicts with ``channel="legal"`` that are compatible
        with ``RetrievalAdapter._normalise_chunk()``.
        """
        # Use search_legal() which does retrieve() + chunk_type post-filter
        results = self._vs.search_legal(
            query=query,
            top_k=top_k,
        )

        # Reshape to the format expected by RetrievalAdapter._normalise_chunk()
        return [
            {
                "unit_id":         r.get("source_filename", ""),
                "provider_name":   r.get("provider_name", ""),
                "source_filename": r.get("source_filename", ""),
                "page_number":     r.get("page_number_est"),
                "unit_text":       r.get("chunk_text", ""),
                "chunk_index":     0,
                "score":           r.get("score", 0.0),
                "channel":         "legal",
                "is_current":      r.get("is_current", True),
                "is_current_effective": r.get("is_current", True),
                "section_type":    r.get("chunk_type", ""),
            }
            for r in results
        ]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _resolve_provider(self, provider_name: Optional[str]) -> Optional[str]:
        """Resolve provider alias to canonical name via ProviderService."""
        if not provider_name:
            return None
        if self._provider_service is None:
            return provider_name
        try:
            resolved = self._provider_service.resolve_name(provider_name)
            return resolved or provider_name
        except Exception:  # noqa: BLE001
            return provider_name

    def _apply_filter(
        self,
        results: List[Dict[str, Any]],
        keep_minimum: int = 3,
    ) -> List[Dict[str, Any]]:
        """
        Apply current-effective filter to plain result dicts.

        Uses ``CurrentEffectiveFilter.is_current()`` on source_filename so the
        filter works on dicts rather than RetrievedPassage objects.

        Safety: if filtering would reduce below ``keep_minimum``, return all
        results with ``is_current_effective`` flags set (same keep_minimum
        semantics as CurrentEffectiveFilter.apply()).
        """
        filtered: List[Dict[str, Any]] = []
        for r in results:
            fn = r.get("source_filename", "")
            is_current = self._filter.is_current(fn)
            r["is_current_effective"] = is_current
            if is_current:
                filtered.append(r)

        # Safety: don't starve the agent of results
        if len(filtered) < keep_minimum and len(results) >= keep_minimum:
            logger.info(
                "RetrievalService: filter would reduce %d -> %d results "
                "(below minimum=%d); returning all with flags set",
                len(results), len(filtered), keep_minimum,
            )
            return results  # is_current_effective already stamped on each

        return filtered

    def _score_and_sort(
        self,
        results: List[Dict[str, Any]],
        query: str,
    ) -> List[Dict[str, Any]]:
        """
        Score passages by query keyword relevance and sort descending.

        Uses text_utils.score_passage so scoring is consistent with V2
        Branch A Step 4 (Score & Dedup).
        """
        kws = extract_keywords(query)
        for r in results:
            text = r.get("unit_text", "") or r.get("chunk_text", "")
            r["_relevance_score"] = score_passage(text, kws)
        return sorted(results, key=lambda x: x.get("_relevance_score", 0.0), reverse=True)

    def _dedup_by_filename(
        self,
        results: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Deduplicate: keep the best-scored (first in sorted list) per source_filename.

        Files with an empty or missing source_filename are always kept.
        """
        seen: set = set()
        deduped: List[Dict[str, Any]] = []
        for r in results:
            fn = r.get("source_filename", "")
            if not fn or fn not in seen:
                if fn:
                    seen.add(fn)
                deduped.append(r)
        return deduped


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_retrieval_service(
    spark: Optional[Any] = None,
    vs_service: Optional[VectorSearchService] = None,
    current_filter: Optional[CurrentEffectiveFilter] = None,
    provider_service: Optional[Any] = None,
) -> RetrievalService:
    """
    Factory: create a ready-to-use RetrievalService.

    If ``vs_service`` is not provided, one is created with default settings.
    If ``current_filter`` is not provided and ``spark`` is given, one is
    created automatically (lazy-loads filename cache on first use).

    Parameters
    ----------
    spark : SparkSession, optional
        Required for CurrentEffectiveFilter; also passed to ProviderService.
    vs_service : VectorSearchService, optional
        Override the default VS wrapper.
    current_filter : CurrentEffectiveFilter, optional
        Override the default filter.
    provider_service : ProviderService, optional
        Override or provide a ProviderService for alias resolution.
    """
    if vs_service is None:
        vs_service = VectorSearchService()
    if current_filter is None and spark is not None:
        current_filter = CurrentEffectiveFilter(spark=spark)
    return RetrievalService(
        vs_service=vs_service,
        current_filter=current_filter,
        provider_service=provider_service,
    )

"""
platform/v4/services/rate_query_templates.py

P2-SQL-2: Parameterized SQL templates for rate/financial queries.

Extracted from V2 Cell 3 (RATES_CURRENT_SQL) and Cell 10 (Branch D).
Used by the native RateQueryTool (Phase 4).

Usage
-----
    from platform.v4.services.rate_query_templates import (
        RateQueryTemplates, RATE_DOMAIN_KEYWORDS, DOMAIN_TO_CATEGORY,
    )

    templates = RateQueryTemplates()
    sql = templates.provider_rates(provider_filter="provider_id = '129088335'")
    domain, detail = templates.normalize_category("inpatient per diem")
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from ..config.settings import CATALOG, SCHEMA, TBL_CONTRACT_RATES_ALL


# Rate domain keywords (from V2 Cell 10 _RATE_DOMAIN_KEYWORDS)
# Compound keywords FIRST so they match before their single-word components
RATE_DOMAIN_KEYWORDS: List[str] = [
    "inpatient per-diem", "inpatient per diem", "inpatient case rate",
    "outpatient surgical", "outpatient per-diem", "outpatient per diem",
    "drg", "case rate", "case-rate",  # 3D-FIX: DRG/case-rate specific keywords
    "per diem", "per-diem",           # PD-FIX: standalone "per diem" → inpatient_per_diem
    "inpatient", "outpatient", "emergency", "maternity", "cardiac",
    "radiology", "rehabilitation", "psychiatric", "skilled nursing",
    "neonatal", "transplant", "behavioral", "ambulatory",
]


# Mapping from domain keywords to exact rate_category values in tbl_contract_rates_all
DOMAIN_TO_CATEGORY: dict = {
    "drg": "inpatient_case_rate",  # 3D-FIX: DRG = case rate based payment
    "case rate": "inpatient_case_rate",
    "case-rate": "inpatient_case_rate",
    "inpatient per-diem": "inpatient_per_diem",
    "inpatient per diem": "inpatient_per_diem",
    "per diem": "inpatient_per_diem",       # PD-FIX: standalone "per diem" question
    "per-diem": "inpatient_per_diem",       # PD-FIX: standalone "per-diem" question
    "inpatient case rate": "inpatient_case_rate",
    "outpatient surgical": "outpatient_surgical_tiers",
    "outpatient per-diem": "outpatient_per_diem",
    "outpatient per diem": "outpatient_per_diem",
    "inpatient": "inpatient%",  # 3A-FIX: match ALL inpatient categories (per_diem, case_rate, other)
    "outpatient": "outpatient%",  # 3E-FIX: match ALL outpatient categories with LIKE
    "emergency": "emergency",
    "maternity": "inpatient_case_rate",  # maternity lives under inpatient_case_rate
    "cardiac": "inpatient_case_rate",    # cardiac/coronary lives under inpatient_case_rate
    "radiology": "radiology",
    "rehabilitation": "rehabilitation",
    # 3P-FIX: psychiatric/behavioral are service_categories under inpatient_per_diem,
    # NOT their own rate_categories. Setting rate_category=None lets the service_category
    # filter (from _extract_service_category) handle them correctly.
    "psychiatric": "inpatient_per_diem",
    "skilled nursing": "skilled_nursing",
    "neonatal": "neonatal",
    "transplant": "inpatient_case_rate",  # transplants live under inpatient_case_rate
    "behavioral": "inpatient_per_diem",   # 3P-FIX: behavioral health = per diem with service_category filter
    "ambulatory": "ambulatory",
}


# CRA-7 2026-06-19: Percentage-of-benchmark helper expressions.
# Rates like "90% of Hospital charges" store rate_numeric=90 which is ambiguous
# (¤90 vs 90%). These columns let downstream formatters and the LLM correctly
# label the rate as a percentage and display the full benchmark reference.
_PCT_OF_BENCHMARK_FLAG = """CASE
        WHEN rate_text RLIKE '^[0-9]+\\.?[0-9]*\\s*%\\s+of\\s+'
             OR LOWER(rate_type_detail) LIKE '%percentage of%'
        THEN TRUE ELSE FALSE
    END"""
_PCT_OF_BENCHMARK_REF = """CASE
        WHEN rate_text RLIKE '^[0-9]+\\.?[0-9]*\\s*%\\s+of\\s+'
        THEN REGEXP_EXTRACT(LOWER(rate_text),
                            '^[0-9]+\\.?[0-9]*\\s*%\\s+of\\s+(.*)', 1)
        ELSE NULL
    END"""

# Current-effective rates subquery — uses tbl_contract_rates_all WHERE status='current'
# (Fix D1: was tbl_reimb_rate_rules which missed 11+ golden query expected values)
# (Fix CRA-1 2026-06-19: added QUALIFY dedup guard to eliminate 18,055 extraction duplicates)
# (Fix CRA-7 2026-06-19: added is_pct_of_benchmark + benchmark_ref columns)
RATES_CURRENT_SQL = f"""(
    SELECT provider_name,
           canonical_provider_id AS provider_id,
           rate_category,
           service_category,
           rate_text,
           rate_numeric,
           rate_type_detail,
           effective_date_parsed,
           formula,
           revenue_codes,
           program_normalized,
           network,
           source_filename,
           {_PCT_OF_BENCHMARK_FLAG}   AS is_pct_of_benchmark,
           {_PCT_OF_BENCHMARK_REF}    AS benchmark_ref
    FROM {TBL_CONTRACT_RATES_ALL}
    WHERE status = 'current'
      AND is_valid_rate = true
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY canonical_provider_id, rate_category, service_category,
                     rate_numeric, rate_text, effective_date_parsed,
                     program_normalized, revenue_codes
        ORDER BY source_filename
    ) = 1
) AS rates_current"""


# Historical rates (no temporal filter) — also from contract_rates_all
# (Fix CRA-7 2026-06-19: added is_pct_of_benchmark + benchmark_ref columns)
# (Fix CRA-1b 2026-06-21: added QUALIFY dedup guard — same partition key as RATES_CURRENT_SQL)
RATES_HISTORICAL_SQL = f"""(
    SELECT provider_name,
           canonical_provider_id AS provider_id,
           rate_category,
           service_category,
           rate_text,
           rate_numeric,
           rate_type_detail,
           effective_date_parsed,
           formula,
           revenue_codes,
           program_normalized,
           network,
           source_filename,
           {_PCT_OF_BENCHMARK_FLAG}   AS is_pct_of_benchmark,
           {_PCT_OF_BENCHMARK_REF}    AS benchmark_ref
    FROM {TBL_CONTRACT_RATES_ALL}
    WHERE is_valid_rate = true
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY canonical_provider_id, rate_category, service_category,
                     rate_numeric, rate_text, effective_date_parsed,
                     program_normalized, revenue_codes
        ORDER BY source_filename
    ) = 1
) AS rates_historical"""


class RateQueryTemplates:
    """
    Parameterized SQL templates for rate queries.

    All methods return SQL strings ready for spark.sql().
    """

    def __init__(self, include_historical: bool = False) -> None:
        self._rate_source = RATES_HISTORICAL_SQL if include_historical else RATES_CURRENT_SQL

    # ------------------------------------------------------------------
    # Category normalization (from V2 Cell 10 _normalize_rate_category)
    # ------------------------------------------------------------------

    @staticmethod
    def normalize_category(user_query: str) -> Tuple[str, str]:
        """Split user rate intent into (domain_keyword, detail_keyword).

        Uses DOMAIN_TO_CATEGORY for mapping to exact rate_category values.
        Compound keywords are checked first (e.g. "inpatient per-diem" before "inpatient").
        """
        q = user_query.lower().strip()
        for domain in RATE_DOMAIN_KEYWORDS:
            if domain in q:
                detail = q.replace(domain, "").strip()
                return domain, detail
        return "", q

    @staticmethod
    def get_category_filter(domain: str) -> Optional[str]:
        """Return the exact rate_category value for a domain keyword, or None."""
        return DOMAIN_TO_CATEGORY.get(domain)

    # ------------------------------------------------------------------
    # Query templates
    # ------------------------------------------------------------------

    def provider_rates(self, provider_filter: str, limit: int = 200,
                       rate_category: Optional[str] = None,
                       service_category: Optional[str] = None) -> str:
        """Template: Show a specific provider's rate schedule.

        Args:
            provider_filter: SQL WHERE condition for provider (e.g. "provider_id = '...'")
            limit: Max rows to return
            rate_category: Optional exact rate_category to filter (e.g. 'inpatient_case_rate')
            service_category: Optional service keyword to filter (e.g. 'Normal Delivery')
        """
        where = provider_filter
        if rate_category:
            if '%' in rate_category:
                where += f" AND rate_category LIKE '{rate_category}'"
            else:
                where += f" AND rate_category = '{rate_category}'"
        if service_category:
            where += f" AND LOWER(service_category) LIKE '%{service_category.lower()}%'"
        return f"""
            SELECT rate_category, service_category, rate_text, rate_numeric,
                   rate_type_detail, formula, effective_date_parsed, program_normalized
            FROM {self._rate_source}
            WHERE {where}
            ORDER BY rate_category, rate_numeric DESC
            LIMIT {limit}
        """

    def point_in_time(
        self,
        provider_filter: str,
        amendment_order: Optional[int] = None,
        effective_date: Optional[str] = None,
        rate_category: Optional[str] = None,
        service_category: Optional[str] = None,
        program: Optional[str] = None,
        limit: int = 200,
    ) -> str:
        """Template: Point-in-time rate lookup using amendment_order or effective_date.

        Queries tbl_contract_rates_all DIRECTLY (not the current/historical subquery)
        because point-in-time needs access to ALL versions including superseded.

        Use cases:
        - "What was Queen of Valley's MS-DRG rate at amendment 10?"
        - "What were Hoag's inpatient rates effective 2023-01-01?"
        - "Show me rate history for Provider X's cardiac services"

        Args:
            provider_filter: SQL WHERE condition (e.g. "provider_id = '129088335'")
            amendment_order: Specific amendment version number (0=base, N=Nth amendment)
            effective_date: ISO date string for point-in-time (finds rates effective on that date)
            rate_category: Optional exact rate_category filter
            service_category: Optional service keyword filter (LIKE match)
            program: Optional program_normalized filter (e.g. 'Commercial', 'Medicare')
            limit: Max rows to return
        """
        conditions = [provider_filter, "is_valid_rate = true"]

        if amendment_order is not None:
            conditions.append(f"amendment_order = {int(amendment_order)}")

        if effective_date:
            # Find rates that were effective on the given date:
            # effective_date_parsed <= target AND (superseded_date > target OR status='current')
            conditions.append(
                f"effective_date_parsed <= '{effective_date}'"
            )
            conditions.append(
                f"(superseded_date > '{effective_date}' OR status = 'current')"
            )

        if rate_category:
            conditions.append(f"rate_category = '{rate_category}'")

        if service_category:
            conditions.append(
                f"LOWER(service_category) LIKE '%{service_category.lower()}%'"
            )

        if program:
            conditions.append(
                f"LOWER(program_normalized) LIKE '%{program.lower()}%'"
            )

        where = " AND ".join(conditions)

        return f"""
            SELECT provider_name,
                   canonical_provider_id AS provider_id,
                   rate_category,
                   service_category,
                   rate_text,
                   rate_numeric,
                   rate_type_detail,
                   effective_date_parsed,
                   amendment_order,
                   status,
                   program_normalized,
                   formula,
                   source_filename,
                   {_PCT_OF_BENCHMARK_FLAG} AS is_pct_of_benchmark,
                   {_PCT_OF_BENCHMARK_REF}  AS benchmark_ref
            FROM {TBL_CONTRACT_RATES_ALL}
            WHERE {where}
            ORDER BY amendment_order_int DESC, rate_category, rate_numeric DESC
            LIMIT {limit}
        """

    def amendment_history(
        self,
        provider_filter: str,
        rate_category: Optional[str] = None,
        service_category: Optional[str] = None,
    ) -> str:
        """Template: Full amendment history for a provider+service combination.

        Returns ALL versions (current + superseded) ordered by amendment_order,
        showing how rates evolved over time.

        Use cases:
        - "Show me rate changes for Queen of Valley's MS-DRG over time"
        - "How has Hoag's coronary rate changed across amendments?"
        """
        conditions = [provider_filter, "is_valid_rate = true"]
        if rate_category:
            conditions.append(f"rate_category = '{rate_category}'")
        if service_category:
            conditions.append(
                f"LOWER(service_category) LIKE '%{service_category.lower()}%'"
            )
        where = " AND ".join(conditions)

        return f"""
            SELECT rate_category,
                   service_category,
                   amendment_order,
                   status,
                   rate_numeric,
                   rate_text,
                   effective_date_parsed,
                   superseded_date,
                   source_filename
            FROM {TBL_CONTRACT_RATES_ALL}
            WHERE {where}
            ORDER BY service_category, amendment_order_int ASC
            LIMIT 500
        """

    def provider_rate_summary(self, provider_filter: str) -> str:
        """Template: Aggregated rate summary by category for one provider."""
        return f"""
            SELECT rate_category,
                   COUNT(*) AS entry_count,
                   ROUND(AVG(CASE WHEN rate_numeric > 0 THEN rate_numeric END), 2) AS avg_rate,
                   MAX(rate_numeric) AS max_rate,
                   MIN(CASE WHEN rate_numeric > 0 THEN rate_numeric END) AS min_rate
            FROM {self._rate_source}
            WHERE {provider_filter}
            GROUP BY rate_category
            ORDER BY avg_rate DESC
        """

    def benchmark(self, provider_filter: str) -> str:
        """Template: Provider rate vs portfolio P10-P50-P90 benchmarks."""
        return f"""
            WITH provider_avg AS (
                SELECT rate_category AS service_line,
                       ROUND(AVG(rate_numeric), 2) AS provider_rate
                FROM {self._rate_source}
                WHERE {provider_filter} AND rate_numeric > 0
                GROUP BY rate_category
            ),
            portfolio AS (
                SELECT rate_category AS service_line,
                       ROUND(PERCENTILE_CONT(0.10) WITHIN GROUP (ORDER BY rate_numeric), 2) AS p10,
                       ROUND(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY rate_numeric), 2) AS p50,
                       ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY rate_numeric), 2) AS p90,
                       COUNT(DISTINCT canonical_provider_id) AS n_providers
                FROM {self._rate_source}
                WHERE rate_numeric > 0
                GROUP BY rate_category
            )
            SELECT p.service_line, pa.provider_rate,
                   p.p10, p.p50, p.p90, p.n_providers,
                   CASE
                       WHEN pa.provider_rate <= p.p10 THEN 'Below P10'
                       WHEN pa.provider_rate <= p.p50 THEN 'P10-P50'
                       WHEN pa.provider_rate <= p.p90 THEN 'P50-P90'
                       ELSE 'Above P90'
                   END AS percentile_band
            FROM portfolio p
            LEFT JOIN provider_avg pa ON p.service_line = pa.service_line
            WHERE pa.provider_rate IS NOT NULL
            ORDER BY pa.provider_rate DESC
        """

    def aggregation(self, group_by: str = "rate_category", metric: str = "avg") -> str:
        """Template: Portfolio-level rate aggregation."""
        agg_fn = {
            "avg": "ROUND(AVG(rate_numeric), 2)",
            "max": "MAX(rate_numeric)",
            "min": "MIN(CASE WHEN rate_numeric > 0 THEN rate_numeric END)",
            "sum": "ROUND(SUM(rate_numeric), 2)",
            "count": "COUNT(*)",
        }.get(metric, "ROUND(AVG(rate_numeric), 2)")

        return f"""
            SELECT {group_by},
                   {agg_fn} AS rate_value,
                   COUNT(*) AS n_entries,
                   COUNT(DISTINCT provider_name) AS n_providers
            FROM {self._rate_source}
            WHERE rate_numeric > 0
            GROUP BY {group_by}
            ORDER BY rate_value DESC
            LIMIT 50
        """

    def distribution(self, category_filter: Optional[str] = None) -> str:
        """Template: Rate distribution (for histogram/spread analysis)."""
        where = "rate_numeric > 0"
        if category_filter:
            where += f" AND LOWER(rate_category) LIKE '%{category_filter.lower()}%'"
        return f"""
            SELECT provider_name, rate_category, rate_numeric,
                   NTILE(10) OVER (ORDER BY rate_numeric) AS decile
            FROM {self._rate_source}
            WHERE {where}
            ORDER BY rate_numeric DESC
            LIMIT 500
        """

    def top_n_providers(self, n: int = 10, category_filter: Optional[str] = None,
                        metric: str = "avg") -> str:
        """Template: Top-N providers by rate metric (avg/max/min).

        Args:
            n: Number of top providers to return
            category_filter: Optional rate_category filter (LIKE match)
            metric: Aggregation metric - 'avg', 'max', or 'min'
        """
        where = "rate_numeric > 0"
        if category_filter:
            where += f" AND LOWER(rate_category) LIKE '%{category_filter.lower()}%'"

        agg_expr = {
            "avg": "ROUND(AVG(rate_numeric), 2)",
            "max": "MAX(rate_numeric)",
            "min": "MIN(CASE WHEN rate_numeric > 0 THEN rate_numeric END)",
        }.get(metric, "ROUND(AVG(rate_numeric), 2)")

        return f"""
            SELECT provider_name,
                   {agg_expr} AS rate_value,
                   COUNT(*) AS n_rules
            FROM {self._rate_source}
            WHERE {where}
            GROUP BY provider_name
            HAVING COUNT(*) >= 3
            ORDER BY rate_value DESC
            LIMIT {n}
        """

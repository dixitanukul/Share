"""
Tests for W9-26 Streaming Response Support.

Validates that:
  - StreamEvent types and StreamMessage work correctly
  - BufferStreamCallback collects events
  - AgentController.run() emits events in correct order
  - No-callback path is unchanged (backward compatible)
  - Error events fire on tool failures
  - Decomposed questions emit SUB_QUESTION events
  - SSE serialization works
  - Display text renders for all event types
"""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

import json
import pytest
from platform.v4.contracts.streaming_types import (
    StreamEvent, StreamMessage, StreamCallback, BufferStreamCallback,
)
from platform.v4.contracts.agent_types import AgentRequest, AgentResponse
from platform.v4.tools.registry import ToolRegistry
from platform.v4.core.agent_controller import AgentController


# ═══════════════════════════════════════════════════════════════════════════════
# StreamMessage / StreamEvent basics
# ═══════════════════════════════════════════════════════════════════════════════

class TestStreamMessage:
    def test_event_enum_values(self):
        assert StreamEvent.STARTED.value == "started"
        assert StreamEvent.TOOL_START.value == "tool_start"
        assert StreamEvent.FINAL_ANSWER.value == "final_answer"
        assert StreamEvent.DECOMPOSING.value == "decomposing"

    def test_message_creation(self):
        msg = StreamMessage(
            event=StreamEvent.TOOL_RESULT,
            step_number=3,
            tool_name="sql_query",
            partial_answer="Found 42 providers with offset clause.",
            progress_pct=0.6,
            elapsed_s=2.5,
        )
        assert msg.event == StreamEvent.TOOL_RESULT
        assert msg.step_number == 3
        assert msg.tool_name == "sql_query"
        assert msg.progress_pct == 0.6

    def test_to_sse_format(self):
        msg = StreamMessage(
            event=StreamEvent.TOOL_RESULT,
            step_number=2,
            tool_name="passage_search",
            partial_answer="Retrieved 5 relevant passages.",
        )
        sse = msg.to_sse()
        assert "event: tool_result" in sse
        assert "data: " in sse
        assert "passage_search" in sse
        assert sse.endswith("\n\n")

    def test_to_display_text_all_events(self):
        events_and_expected = [
            (StreamEvent.STARTED, {}, "Processing"),
            (StreamEvent.THINKING, {"thought": "Analyzing provider"}, "Reasoning"),
            (StreamEvent.TOOL_START, {}, "Calling"),
            (StreamEvent.TOOL_RESULT, {}, ""),
            (StreamEvent.SYNTHESIZING, {}, "Assembling"),
            (StreamEvent.ERROR, {"message": "Budget exceeded"}, "Budget"),
            (StreamEvent.DECOMPOSING, {"sub_question_count": 3}, "3 sub-questions"),
            (StreamEvent.SUB_QUESTION_START, {"question": "What rate?"}, "Sub-question"),
            (StreamEvent.SUB_QUESTION_RESULT, {}, "answered"),
            (StreamEvent.ABORTED, {"reason": "Out of scope"}, "scope"),
        ]
        for event, data, expected_substr in events_and_expected:
            msg = StreamMessage(event=event, tool_name="test_tool",
                                partial_answer="result text", data=data)
            text = msg.to_display_text()
            if expected_substr:
                assert expected_substr.lower() in text.lower(), \
                    f"Expected '{expected_substr}' in display text for {event.value}: '{text}'"

    def test_sse_omits_none_values(self):
        msg = StreamMessage(event=StreamEvent.STARTED)
        sse = msg.to_sse()
        parsed_data = json.loads(sse.split("data: ")[1].strip())
        assert "tool" not in parsed_data  # None values omitted
        assert "partial_answer" not in parsed_data


# ═══════════════════════════════════════════════════════════════════════════════
# BufferStreamCallback
# ═══════════════════════════════════════════════════════════════════════════════

class TestBufferStreamCallback:
    def test_collects_events(self):
        buffer = BufferStreamCallback()
        buffer.on_event(StreamMessage(event=StreamEvent.STARTED))
        buffer.on_event(StreamMessage(event=StreamEvent.THINKING))
        buffer.on_event(StreamMessage(event=StreamEvent.FINAL_ANSWER, partial_answer="Done"))

        assert len(buffer.events) == 3
        assert buffer.event_types == [StreamEvent.STARTED, StreamEvent.THINKING, StreamEvent.FINAL_ANSWER]

    def test_get_final_answer(self):
        buffer = BufferStreamCallback()
        buffer.on_event(StreamMessage(event=StreamEvent.STARTED))
        buffer.on_event(StreamMessage(event=StreamEvent.FINAL_ANSWER, partial_answer="The rate is $1,500."))

        assert buffer.get_final_answer() == "The rate is $1,500."

    def test_get_final_answer_empty(self):
        buffer = BufferStreamCallback()
        buffer.on_event(StreamMessage(event=StreamEvent.STARTED))
        assert buffer.get_final_answer() == ""

    def test_tool_events_filter(self):
        buffer = BufferStreamCallback()
        buffer.on_event(StreamMessage(event=StreamEvent.STARTED))
        buffer.on_event(StreamMessage(event=StreamEvent.TOOL_START, tool_name="sql"))
        buffer.on_event(StreamMessage(event=StreamEvent.THINKING))
        buffer.on_event(StreamMessage(event=StreamEvent.TOOL_RESULT, tool_name="sql"))

        assert len(buffer.tool_events) == 2

    def test_has_event(self):
        buffer = BufferStreamCallback()
        buffer.on_event(StreamMessage(event=StreamEvent.ERROR, data={"message": "fail"}))
        assert buffer.has_event(StreamEvent.ERROR)
        assert not buffer.has_event(StreamEvent.FINAL_ANSWER)

    def test_implements_protocol(self):
        """BufferStreamCallback satisfies StreamCallback protocol."""
        buffer = BufferStreamCallback()
        assert isinstance(buffer, StreamCallback)


# ═══════════════════════════════════════════════════════════════════════════════
# AgentController streaming integration
# ═══════════════════════════════════════════════════════════════════════════════

class TestAgentControllerStreaming:
    """Test streaming with the agent controller using no LLM (stub mode)."""

    def setup_method(self):
        self.registry = ToolRegistry()
        self.controller = AgentController(
            registry=self.registry,
            llm_client=None,  # Stub mode — returns SYNTHESIZE immediately
        )

    def test_run_without_callback_works(self):
        """Backward compatibility: run() with no callback works as before."""
        request = AgentRequest(session_id="test-1", question="What is offset?")
        response = self.controller.run(request)
        assert response.answer is not None
        assert len(response.answer) > 0

    def test_run_with_callback_emits_started(self):
        """STARTED event is always first."""
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="test-2", question="Test question")
        self.controller.run(request, stream_callback=buffer)

        assert len(buffer.events) > 0
        assert buffer.events[0].event == StreamEvent.STARTED

    def test_run_with_callback_emits_final_answer(self):
        """FINAL_ANSWER event is always last."""
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="test-3", question="Test question")
        self.controller.run(request, stream_callback=buffer)

        assert buffer.events[-1].event == StreamEvent.FINAL_ANSWER
        assert buffer.get_final_answer() != ""

    def test_event_order_stub_mode(self):
        """In stub mode: STARTED → SYNTHESIZING → FINAL_ANSWER."""
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="test-4", question="What is the rate?")
        self.controller.run(request, stream_callback=buffer)

        types = buffer.event_types
        assert types[0] == StreamEvent.STARTED
        assert StreamEvent.FINAL_ANSWER in types
        # SYNTHESIZING should appear before FINAL_ANSWER
        if StreamEvent.SYNTHESIZING in types:
            synth_idx = types.index(StreamEvent.SYNTHESIZING)
            final_idx = types.index(StreamEvent.FINAL_ANSWER)
            assert synth_idx < final_idx

    def test_elapsed_time_increases(self):
        """elapsed_s should be monotonically non-decreasing."""
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="test-5", question="Test")
        self.controller.run(request, stream_callback=buffer)

        for i in range(1, len(buffer.events)):
            assert buffer.events[i].elapsed_s >= buffer.events[i - 1].elapsed_s

    def test_progress_pct_in_range(self):
        """All progress values should be between 0.0 and 1.0."""
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="test-6", question="Test")
        self.controller.run(request, stream_callback=buffer)

        for event in buffer.events:
            assert 0.0 <= event.progress_pct <= 1.0

    def test_callback_exception_non_fatal(self):
        """A failing callback does not crash the agent."""
        class FailingCallback:
            def on_event(self, message):
                raise RuntimeError("Callback failed!")

        request = AgentRequest(session_id="test-7", question="Test")
        response = self.controller.run(request, stream_callback=FailingCallback())
        # Should still get a valid response
        assert response.answer is not None


# ═══════════════════════════════════════════════════════════════════════════════
# Tool streaming events (with mock tool)
# ═══════════════════════════════════════════════════════════════════════════════

class TestToolStreamingEvents:
    """Test that tool calls emit TOOL_START and TOOL_RESULT events."""

    def test_tool_result_events_with_mock_llm(self):
        """When LLM returns CALL_TOOL, we get TOOL_START + TOOL_RESULT."""
        call_count = {"n": 0}

        class MockLLM:
            def chat(self, model, system, user, max_tokens):
                call_count["n"] += 1
                if call_count["n"] == 1:
                    return json.dumps({
                        "thought": "Let me query for rates",
                        "action": "CALL_TOOL",
                        "tool_name": "test_tool",
                        "tool_input": {"query": "test"},
                    })
                return json.dumps({
                    "thought": "The answer is 42.",
                    "action": "SYNTHESIZE",
                    "final_answer": "The rate is $1,500 per diem.",
                })

        from platform.v4.contracts.tool_types import ToolResult, ToolStatus, Confidence
        from platform.v4.tools.base import BaseTool

        class FakeTool(BaseTool):
            name = "test_tool"
            description = "A test tool"
            parameters = {"query": {"type": "string"}}

            def _run(self, **kwargs) -> ToolResult:
                return ToolResult(
                    tool_name="test_tool",
                    success=True,
                    data={"count": 42},
                    summary="Found 42 matching records.",
                    confidence=Confidence.HIGH,
                    cost_estimate=0.01,
                )

        registry = ToolRegistry()
        registry.register(FakeTool())

        controller = AgentController(registry=registry, llm_client=MockLLM())
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="tool-test", question="How many?")
        response = controller.run(request, stream_callback=buffer)

        types = buffer.event_types
        assert StreamEvent.TOOL_START in types
        assert StreamEvent.TOOL_RESULT in types
        assert StreamEvent.FINAL_ANSWER in types

        # TOOL_START should precede TOOL_RESULT
        start_idx = types.index(StreamEvent.TOOL_START)
        result_idx = types.index(StreamEvent.TOOL_RESULT)
        assert start_idx < result_idx

        # Tool name should be set on TOOL_START event
        start_event = buffer.events[start_idx]
        assert start_event.tool_name == "test_tool"

    def test_tool_failure_emits_tool_result_event(self):
        """When a tool fails (exception caught by BaseTool), TOOL_RESULT fires with failure info."""
        call_count = {"n": 0}

        class MockLLM:
            def chat(self, model, system, user, max_tokens):
                call_count["n"] += 1
                if call_count["n"] == 1:
                    return json.dumps({
                        "thought": "Try calling broken tool",
                        "action": "CALL_TOOL",
                        "tool_name": "broken_tool",
                        "tool_input": {},
                    })
                return json.dumps({
                    "thought": "Tool failed, providing partial answer.",
                    "action": "SYNTHESIZE",
                    "final_answer": "Unable to retrieve data.",
                })

        from platform.v4.contracts.tool_types import ToolResult, Confidence
        from platform.v4.tools.base import BaseTool

        class BrokenTool(BaseTool):
            name = "broken_tool"
            description = "Always fails"
            parameters = {}

            def _run(self, **kwargs) -> ToolResult:
                raise ValueError("Database connection lost")

        registry = ToolRegistry()
        registry.register(BrokenTool())

        controller = AgentController(registry=registry, llm_client=MockLLM())
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="error-test", question="Test error")
        response = controller.run(request, stream_callback=buffer)

        # BaseTool wraps _run() exceptions into a ToolResult(success=False)
        # So we get TOOL_RESULT event with success=False, not ERROR
        assert buffer.has_event(StreamEvent.TOOL_RESULT)
        result_events = [e for e in buffer.events if e.event == StreamEvent.TOOL_RESULT]
        assert len(result_events) >= 1
        # The tool result event should indicate failure
        result_event = result_events[0]
        assert result_event.data.get("success") is False

    def test_error_event_on_budget_exhaustion(self):
        """ERROR event fires when budget is exhausted."""
        call_count = {"n": 0}

        class ExpensiveLLM:
            def chat(self, model, system, user, max_tokens):
                call_count["n"] += 1
                # Always returns THINK (never synthesizes) to force budget exhaustion
                return json.dumps({
                    "thought": "Still thinking...",
                    "action": "THINK",
                })

        registry = ToolRegistry()
        controller = AgentController(
            registry=registry,
            llm_client=ExpensiveLLM(),
            max_steps=3,
            default_budget=0.0001,  # Extremely low budget
        )
        buffer = BufferStreamCallback()
        request = AgentRequest(session_id="budget-test", question="Test budget")
        response = controller.run(request, stream_callback=buffer)

        # Should eventually hit max steps or budget (both produce a response)
        assert buffer.has_event(StreamEvent.FINAL_ANSWER)


# ═══════════════════════════════════════════════════════════════════════════════
# Decomposed question streaming
# ═══════════════════════════════════════════════════════════════════════════════

class TestDecomposedStreaming:
    """Test streaming events for complex decomposed questions."""

    def test_decomposed_emits_sub_question_events(self):
        """Complex questions emit DECOMPOSING + SUB_QUESTION_START/RESULT events."""
        from platform.v4.core.question_decomposer import QuestionDecomposer

        class MockLLM:
            def chat(self, model, system, user, max_tokens):
                return json.dumps({
                    "thought": "Sub-question result",
                    "action": "SYNTHESIZE",
                    "final_answer": "Rate is $1,500.",
                })

        registry = ToolRegistry()
        controller = AgentController(
            registry=registry,
            llm_client=MockLLM(),
        )

        # Use a complex question that triggers decomposition
        buffer = BufferStreamCallback()
        request = AgentRequest(
            session_id="decompose-test",
            question="Compare the offset clause for Sutter Roseville and Mills Peninsula, and calculate the difference in their per diem rates",
        )
        response = controller.run(request, stream_callback=buffer)

        types = buffer.event_types
        assert StreamEvent.STARTED in types
        assert StreamEvent.FINAL_ANSWER in types
        # Complex question should trigger decomposition
        if StreamEvent.DECOMPOSING in types:
            # DECOMPOSING should appear after STARTED
            dec_idx = types.index(StreamEvent.DECOMPOSING)
            start_idx = types.index(StreamEvent.STARTED)
            assert dec_idx > start_idx
            # Sub-question events should appear
            assert (StreamEvent.SUB_QUESTION_START in types or
                    StreamEvent.SUB_QUESTION_RESULT in types), \
                f"Expected sub-question events, got: {types}"
        # Final answer should always be last
        assert types[-1] == StreamEvent.FINAL_ANSWER

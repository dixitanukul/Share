"""
platform/v4/tests/test_evidence_gate.py

P3-VER-2: Unit tests for EvidenceGate.
"""
from __future__ import annotations

import sys
import types
import unittest

_V3_BASE = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline"
if _V3_BASE not in sys.path:
    sys.path.insert(0, _V3_BASE)
if "platform.v4" not in sys.modules:
    _pkg = types.ModuleType("platform.v4")
    _pkg.__path__ = [f"{_V3_BASE}/platform/v3"]
    _pkg.__package__ = "platform.v4"
    _pkg.__spec__ = None
    sys.modules["platform.v4"] = _pkg
    sys.modules["platform"].v3 = _pkg  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _p(text="The plan has the right to offset overpayments from future payments.",
       provider="Sutter Roseville",
       source_filename="sutter_v2.pdf") -> dict:
    return {"unit_text": text, "provider_name": provider,
            "source_filename": source_filename}


def _short_p(provider="Acme") -> dict:
    return {"unit_text": "N/A", "provider_name": provider, "source_filename": "acme.pdf"}


# ---------------------------------------------------------------------------
# TestSufficiencyResultAlias
# ---------------------------------------------------------------------------

class TestSufficiencyResultAlias(unittest.TestCase):
    def setUp(self):
        from platform.v4.services.verification.evidence_gate import SufficiencyResult
        self.SR = SufficiencyResult

    def test_should_refuse_false_when_sufficient(self):
        r = self.SR(sufficient=True, reason="ok", confidence=0.9,
                    passage_count=5, scored_count=3, provider_hit=True)
        self.assertFalse(r.should_refuse)

    def test_should_refuse_true_when_not_sufficient(self):
        r = self.SR(sufficient=False, reason="no", confidence=0.0,
                    passage_count=0, scored_count=0, provider_hit=False)
        self.assertTrue(r.should_refuse)


# ---------------------------------------------------------------------------
# TestEvidenceGatePresenceCheck
# ---------------------------------------------------------------------------

class TestEvidenceGatePresenceCheck(unittest.TestCase):
    def setUp(self):
        from platform.v4.services.verification.evidence_gate import EvidenceGate
        self.EvidenceGate = EvidenceGate
        self.gate = EvidenceGate()

    def test_empty_passages_refuses(self):
        r = self.gate.check([], query="offset clause")
        self.assertTrue(r.should_refuse)
        self.assertEqual(r.passage_count, 0)

    def test_none_passages_refuses(self):
        r = self.gate.check([], query="offset")
        self.assertTrue(r.should_refuse)

    def test_single_good_passage_sufficient(self):
        r = self.gate.check([_p()], query="offset clause")
        self.assertTrue(r.sufficient)

    def test_all_stub_passages_refuses(self):
        """Passages shorter than min_content_length are filtered as noise."""
        stubs = [_short_p() for _ in range(5)]
        r = self.gate.check(stubs, query="offset")
        self.assertTrue(r.should_refuse)

    def test_min_passages_threshold_respected(self):
        gate = self.EvidenceGate(min_passages=3)
        r = gate.check([_p(), _p()], query="offset")
        self.assertTrue(r.should_refuse)
        r2 = gate.check([_p(), _p(), _p()], query="offset")
        self.assertTrue(r2.sufficient)


# ---------------------------------------------------------------------------
# TestEvidenceGateRelevanceCheck
# ---------------------------------------------------------------------------

class TestEvidenceGateRelevanceCheck(unittest.TestCase):
    def setUp(self):
        from platform.v4.services.verification.evidence_gate import EvidenceGate
        self.EvidenceGate = EvidenceGate
        self.gate = EvidenceGate(relevance_threshold=0.05)

    def test_on_topic_passage_passes_relevance(self):
        p = _p("The plan has rights to offset and recoup overpayments.")
        r = self.gate.check([p], query="offset clause recoupment")
        self.assertTrue(r.sufficient)
        self.assertGreater(r.scored_count, 0)

    def test_off_topic_passage_fails_relevance(self):
        p = _p("The amendment was signed on June 1, 2024, by both parties.")
        r = self.gate.check([p], query="capitation rate table surgery")
        self.assertTrue(r.should_refuse)

    def test_empty_query_skips_relevance_gate(self):
        """No query keywords → relevance check skipped → always passes."""
        r = self.gate.check([_p()], query="")
        self.assertTrue(r.sufficient)

    def test_min_scored_threshold_respected(self):
        gate = self.EvidenceGate(min_scored=2)
        # Only 1 passage — scored_count can be at most 1
        r = gate.check([_p("offset clause rights")], query="offset")
        self.assertTrue(r.should_refuse)


# ---------------------------------------------------------------------------
# TestEvidenceGateProviderCheck
# ---------------------------------------------------------------------------

class TestEvidenceGateProviderCheck(unittest.TestCase):
    def setUp(self):
        from platform.v4.services.verification.evidence_gate import EvidenceGate
        self.gate = EvidenceGate()

    def test_provider_match_passes(self):
        p = _p(provider="Sutter Roseville")
        r = self.gate.check([p], query="offset", provider_name="Sutter Roseville")
        self.assertTrue(r.sufficient)
        self.assertTrue(r.provider_hit)

    def test_provider_no_match_refuses(self):
        p = _p(provider="Kaiser")
        r = self.gate.check([p], query="offset", provider_name="Sutter Roseville")
        self.assertTrue(r.should_refuse)
        self.assertFalse(r.provider_hit)

    def test_provider_partial_match_passes(self):
        """'Sutter' substring matches 'Sutter Roseville'."""
        p = _p(provider="Sutter Roseville Medical Center")
        r = self.gate.check([p], query="offset", provider_name="Sutter")
        self.assertTrue(r.sufficient)

    def test_no_provider_filter_skips_check(self):
        """provider_name=None → provider check skipped, result is provider_hit=True."""
        r = self.gate.check([_p(provider="Anyone")], query="offset", provider_name=None)
        self.assertTrue(r.sufficient)
        self.assertTrue(r.provider_hit)


# ---------------------------------------------------------------------------
# TestEvidenceGateConfidence
# ---------------------------------------------------------------------------

class TestEvidenceGateConfidence(unittest.TestCase):
    def setUp(self):
        from platform.v4.services.verification.evidence_gate import EvidenceGate
        self.gate = EvidenceGate()

    def test_confidence_between_0_and_1(self):
        passages = [_p("offset recoup overpayment rights contract.")] * 5
        r = self.gate.check(passages, query="offset clause")
        self.assertGreaterEqual(r.confidence, 0.0)
        self.assertLessEqual(r.confidence, 1.0)

    def test_more_passages_higher_confidence(self):
        few   = [_p()] * 2
        many  = [_p()] * 10
        r_few  = self.gate.check(few,  query="offset")
        r_many = self.gate.check(many, query="offset")
        if r_few.sufficient and r_many.sufficient:
            self.assertGreaterEqual(r_many.confidence, r_few.confidence)

    def test_insufficient_result_has_zero_or_low_confidence(self):
        r = self.gate.check([], query="offset")
        self.assertEqual(r.confidence, 0.0)


# ---------------------------------------------------------------------------
# TestEvidenceGateRetrievedPassageShape
# ---------------------------------------------------------------------------

class TestEvidenceGateRetrievedPassageShape(unittest.TestCase):
    """Gate works on RetrievedPassage objects (not just dicts)."""

    def setUp(self):
        from platform.v4.services.verification.evidence_gate import EvidenceGate
        self.gate = EvidenceGate()

    def _make_passage_obj(self, text="Offset rights are granted per Section 4.3 of this agreement.", provider="BSC"):
        """Simulate a RetrievedPassage (dataclass-like object)."""
        from unittest.mock import MagicMock
        p = MagicMock()
        p.text = text
        p.unit_text = text
        p.provider_name = provider
        return p

    def test_passage_object_accepted(self):
        p = self._make_passage_obj("The right to offset overpayments is confirmed.")
        r = self.gate.check([p], query="offset")
        self.assertTrue(r.sufficient)

    def test_passage_object_provider_check(self):
        p = self._make_passage_obj(provider="Sutter")
        r = self.gate.check([p], query="offset", provider_name="Sutter")
        self.assertTrue(r.sufficient)
        self.assertTrue(r.provider_hit)


if __name__ == "__main__":
    unittest.main(verbosity=2)

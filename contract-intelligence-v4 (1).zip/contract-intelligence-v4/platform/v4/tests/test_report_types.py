"""Tests for platform/v4/contracts/report_types.py (P5-RPT-1)."""
import pytest

from platform.v4.contracts.report_types import (
    ProviderStatus, Polarity, ConfidenceLabel, ExtractionConfidence, ValueType,
    TaxonomyEntry, ExecutionPlan, ClassifiedPassage, ProviderFindingSummary,
    ConfidenceScore, DocumentMetadata, ProviderEnrichment, ExtractedValue,
    FieldDefinition, ProviderProfile, RateEntry, ContractTerm, AmendmentEntry,
    ClauseReport, StructuredExtractionReport, ProviderReport, RateReport,
    TemporalReport, ComparisonReport, ExplanationReport, MultiConceptReport,
    ReportConfig, AnyReport, ROUTE_TO_REPORT_TYPE,
)


# ============================================================
# ENUM TESTS
# ============================================================


class TestProviderStatus:
    def test_values(self):
        assert ProviderStatus.HAS_GRANT.value == "HAS_GRANT"
        assert ProviderStatus.HAS_DENIED.value == "HAS_DENIED"
        assert ProviderStatus.MIXED.value == "MIXED"
        assert ProviderStatus.NO_MENTION.value == "NO_MENTION"

    def test_display_label(self):
        assert ProviderStatus.HAS_GRANT.display_label == "Has Grant"
        assert ProviderStatus.NO_MENTION.display_label == "No Mention"

    def test_has_findings(self):
        assert ProviderStatus.HAS_GRANT.has_findings is True
        assert ProviderStatus.HAS_DENIED.has_findings is True
        assert ProviderStatus.MIXED.has_findings is True
        assert ProviderStatus.NO_MENTION.has_findings is False

    def test_string_comparison(self):
        # ProviderStatus inherits from str
        assert ProviderStatus.HAS_GRANT == "HAS_GRANT"


class TestPolarity:
    def test_values(self):
        assert Polarity.GRANT.value == "GRANT"
        assert Polarity.RESTRICT.value == "RESTRICT"
        assert Polarity.ABSENT.value == "ABSENT"


class TestConfidenceLabel:
    def test_values(self):
        assert ConfidenceLabel.HIGH.value == "HIGH"
        assert ConfidenceLabel.MODERATE.value == "MODERATE"
        assert "Review" in ConfidenceLabel.LOW.value


class TestExtractionConfidence:
    def test_values(self):
        assert ExtractionConfidence.HIGH.value == "high"
        assert ExtractionConfidence.MEDIUM.value == "medium"
        assert ExtractionConfidence.LOW.value == "low"


class TestValueType:
    def test_values(self):
        assert ValueType.NUMERIC.value == "numeric"
        assert ValueType.DATE.value == "date"
        assert ValueType.BOOLEAN.value == "boolean"


# ============================================================
# SUB-TYPE TESTS
# ============================================================


class TestTaxonomyEntry:
    def test_creation(self):
        entry = TaxonomyEntry(
            code="OVERPAYMENT_OFFSET",
            label="Overpayment Recovery",
            description="Plan recovers erroneous overpayments",
            polarity=Polarity.GRANT,
        )
        assert entry.code == "OVERPAYMENT_OFFSET"
        assert entry.label == "Overpayment Recovery"
        assert entry.polarity == Polarity.GRANT
        assert entry.is_denial is False
        assert entry.is_absence_code is False

    def test_frozen(self):
        entry = TaxonomyEntry(code="X", label="Y")
        with pytest.raises(Exception):  # FrozenInstanceError
            entry.code = "Z"

    def test_absence_code(self):
        entry = TaxonomyEntry(
            code="DOFR_NOT_SPECIFIED", label="No DOFR Defined",
            polarity=Polarity.ABSENT,
        )
        assert entry.is_absence_code is True

    def test_denial(self):
        entry = TaxonomyEntry(
            code="OFFSET_PROHIBITION", label="Offset Prohibited",
            polarity=Polarity.RESTRICT, is_denial=True,
        )
        assert entry.is_denial is True
        assert entry.is_absence_code is False


class TestExecutionPlan:
    def test_defaults(self):
        plan = ExecutionPlan()
        assert plan.core_keywords == []
        assert plan.extended_keywords == []
        assert plan.precision_strategy == "balanced"

    def test_with_keywords(self):
        plan = ExecutionPlan(
            core_keywords=["offset", "overpayment"],
            extended_keywords=["recovery", "deduction"],
            precision_strategy="high_recall",
        )
        assert len(plan.core_keywords) == 2
        assert plan.precision_strategy == "high_recall"


class TestClassifiedPassage:
    def test_relevant(self):
        p = ClassifiedPassage(
            provider="Kaiser", filename="doc.pdf",
            category="OVERPAYMENT_OFFSET",
        )
        assert p.is_relevant is True

    def test_not_relevant_empty(self):
        p = ClassifiedPassage(provider="X", filename="y.pdf", category="")
        assert p.is_relevant is False

    def test_not_relevant_codes(self):
        for cat in ("NOT_RELEVANT", "UNKNOWN"):
            p = ClassifiedPassage(provider="X", filename="y.pdf", category=cat)
            assert p.is_relevant is False

    def test_full_fields(self):
        p = ClassifiedPassage(
            provider="Sutter", filename="sutter_v2.pdf",
            category="BSC_UM", is_denial=False,
            text="some passage text", reasoning="contains BSC-UM language",
            key_phrase="offset recovery", page=42,
            keywords=["offset", "recovery"],
        )
        assert p.page == 42
        assert p.key_phrase == "offset recovery"


class TestProviderFindingSummary:
    def test_doc_count(self):
        f = ProviderFindingSummary(
            provider_name="Kaiser",
            status=ProviderStatus.HAS_GRANT,
            documents_found={"a.pdf", "b.pdf", "c.pdf"},
        )
        assert f.doc_count == 3

    def test_empty(self):
        f = ProviderFindingSummary(
            provider_name="Small Hospital",
            status=ProviderStatus.NO_MENTION,
        )
        assert f.doc_count == 0
        assert f.categories == {}


class TestConfidenceScore:
    def test_score_pct(self):
        cs = ConfidenceScore(score=0.85, label=ConfidenceLabel.HIGH)
        assert cs.score_pct == "85%"

    def test_moderate(self):
        cs = ConfidenceScore(score=0.55, label=ConfidenceLabel.MODERATE, tier="MEDIUM")
        assert cs.score_pct == "55%"
        assert cs.tier == "MEDIUM"


class TestDocumentMetadata:
    def test_creation(self):
        dm = DocumentMetadata(
            source_filename="123456_Provider_789012_Amendment_v3.pdf",
            provider_name="Test Provider",
            effective_date="2024-01-01",
            doc_role="amendment",
            contract_status="ACTIVE",
            version=3,
            is_latest_version=True,
        )
        assert dm.version == 3
        assert dm.is_latest_version is True


class TestProviderEnrichment:
    def test_with_confidence(self):
        pe = ProviderEnrichment(
            provider_id="12345",
            lob="Commercial, Medi-Cal",
            lob_method="rate data",
            confidence=ConfidenceScore(score=0.9, label=ConfidenceLabel.HIGH),
        )
        assert pe.confidence is not None
        assert pe.confidence.score == 0.9


class TestExtractedValue:
    def test_numeric(self):
        ev = ExtractedValue(
            provider_name="Kaiser",
            raw_value="30",
            display_value="30 days",
            normalized_value=30.0,
            confidence=ExtractionConfidence.HIGH,
            evidence="Notice period of 30 days",
            source_file="kaiser_v2.pdf",
            page=5,
        )
        assert ev.normalized_value == 30.0


class TestFieldDefinition:
    def test_creation(self):
        fd = FieldDefinition(
            field_name="offset_start_date",
            value_type=ValueType.DATE,
            unit="",
            description="Start date of offset period",
            keywords=["offset", "start", "effective"],
        )
        assert fd.value_type == ValueType.DATE
        assert len(fd.keywords) == 3


# ============================================================
# REPORT TYPE TESTS
# ============================================================


class TestClauseReport:
    @pytest.fixture
    def sample_report(self):
        report = ClauseReport(
            target_concept="offset clause",
            total_universe=326,
            question="Which providers have offset clauses?",
            llm_model="databricks-claude-sonnet-4-5",
        )
        # Add providers
        report.provider_findings["Kaiser"] = ProviderFindingSummary(
            provider_name="Kaiser", status=ProviderStatus.HAS_GRANT,
            documents_found={"k1.pdf", "k2.pdf"}, categories={"BSC_UM": 2},
        )
        report.provider_findings["Sutter"] = ProviderFindingSummary(
            provider_name="Sutter", status=ProviderStatus.HAS_GRANT,
            documents_found={"s1.pdf"}, categories={"OVERPAYMENT_OFFSET": 1},
        )
        report.provider_findings["Banner"] = ProviderFindingSummary(
            provider_name="Banner", status=ProviderStatus.MIXED,
            documents_found={"b1.pdf", "b2.pdf"}, categories={"BSC_UM": 1, "OFFSET_PROHIBITION": 1},
        )
        report.provider_findings["Denied Co"] = ProviderFindingSummary(
            provider_name="Denied Co", status=ProviderStatus.HAS_DENIED,
            documents_found={"d1.pdf"}, categories={"OFFSET_PROHIBITION": 1},
        )
        report.no_mention_providers = {"Small A", "Small B"}
        # Classified passages
        report.classified_passages = [
            ClassifiedPassage(provider="Kaiser", filename="k1.pdf", category="BSC_UM"),
            ClassifiedPassage(provider="Kaiser", filename="k2.pdf", category="BSC_UM"),
            ClassifiedPassage(provider="Sutter", filename="s1.pdf", category="OVERPAYMENT_OFFSET"),
            ClassifiedPassage(provider="Banner", filename="b1.pdf", category="BSC_UM"),
            ClassifiedPassage(provider="Banner", filename="b2.pdf", category="OFFSET_PROHIBITION", is_denial=True),
            ClassifiedPassage(provider="Denied Co", filename="d1.pdf", category="OFFSET_PROHIBITION", is_denial=True),
            ClassifiedPassage(provider="Noise", filename="n.pdf", category="NOT_RELEVANT"),
        ]
        # Taxonomy
        report.taxonomy = [
            TaxonomyEntry(code="BSC_UM", label="BSC Utilization Management", polarity=Polarity.GRANT),
            TaxonomyEntry(code="OVERPAYMENT_OFFSET", label="Overpayment Recovery", polarity=Polarity.GRANT),
            TaxonomyEntry(code="OFFSET_PROHIBITION", label="Offset Prohibited", polarity=Polarity.RESTRICT, is_denial=True),
        ]
        return report

    def test_has_count(self, sample_report):
        # HAS_GRANT + HAS_DENIED
        assert sample_report.has_count == 3

    def test_denied_count(self, sample_report):
        assert sample_report.denied_count == 1

    def test_mixed_count(self, sample_report):
        assert sample_report.mixed_count == 1

    def test_no_mention_count(self, sample_report):
        assert sample_report.no_mention_count == 2

    def test_relevant_passages(self, sample_report):
        # 7 total, 1 NOT_RELEVANT
        assert len(sample_report.relevant_passages) == 6

    def test_category_distribution(self, sample_report):
        dist = sample_report.category_distribution
        assert dist["BSC_UM"] == 3
        assert dist["OVERPAYMENT_OFFSET"] == 1
        assert dist["OFFSET_PROHIBITION"] == 2

    def test_code_to_label(self, sample_report):
        assert sample_report.code_to_label("BSC_UM") == "BSC Utilization Management"
        assert sample_report.code_to_label("UNKNOWN_CODE") == "UNKNOWN_CODE"

    def test_get_mixed_providers(self, sample_report):
        mixed = sample_report.get_mixed_providers()
        assert "Banner" in mixed
        assert len(mixed) == 1

    def test_get_denied_providers(self, sample_report):
        denied = sample_report.get_denied_providers()
        assert "Denied Co" in denied
        assert len(denied) == 1

    def test_offset_extraction_optional(self, sample_report):
        assert sample_report.offset_extraction is None


class TestStructuredExtractionReport:
    @pytest.fixture
    def sample_extraction(self):
        report = StructuredExtractionReport(
            field_definition=FieldDefinition(
                field_name="offset_start_date",
                value_type=ValueType.DATE,
                keywords=["offset", "start"],
            ),
            total_universe=100,
        )
        report.provider_values = {
            "Kaiser": ExtractedValue(provider_name="Kaiser", confidence=ExtractionConfidence.HIGH, normalized_value=30.0),
            "Sutter": ExtractedValue(provider_name="Sutter", confidence=ExtractionConfidence.MEDIUM, normalized_value=60.0),
            "Small": ExtractedValue(provider_name="Small", confidence=ExtractionConfidence.LOW, normalized_value=0.0),
        }
        report.no_data_providers = ["Hospital A", "Hospital B"]
        return report

    def test_counts(self, sample_extraction):
        assert sample_extraction.extracted_count == 3
        assert sample_extraction.no_data_count == 2

    def test_confidence_counts(self, sample_extraction):
        assert sample_extraction.high_confidence_count == 1
        assert sample_extraction.medium_confidence_count == 1
        assert sample_extraction.low_confidence_count == 1

    def test_numeric_values(self, sample_extraction):
        # Only values > 0 returned
        nums = sample_extraction.numeric_values()
        assert 30.0 in nums
        assert 60.0 in nums
        assert 0.0 not in nums  # 0 excluded (> 0 filter)


class TestProviderReport:
    def test_provider_name_property(self):
        report = ProviderReport(
            profile=ProviderProfile(provider_name="Kaiser Permanente", total_rates=120),
        )
        assert report.provider_name == "Kaiser Permanente"

    def test_with_data(self):
        report = ProviderReport(
            profile=ProviderProfile(
                provider_name="Sutter",
                agreement_type="Capitated",
                total_rates=50,
                total_amendments=3,
                avg_inpatient_per_diem=1200.0,
            ),
            rates=[RateEntry(rate_category="Inpatient", rate_numeric=1200.0)],
            terms=[ContractTerm(topic="Offset")],
            amendments=[
                AmendmentEntry(amendment_order=1),
                AmendmentEntry(amendment_order=2),
            ],
        )
        assert len(report.rates) == 1
        assert len(report.amendments) == 2


class TestRateReport:
    def test_empty(self):
        report = RateReport(query_type="rates")
        assert report.is_empty is True
        assert report.row_count == 0
        assert report.numeric_columns() == []

    def test_with_data(self):
        report = RateReport(
            query_type="benchmark",
            columns=["provider_name", "rate_numeric", "program"],
            rows=[
                {"provider_name": "Kaiser", "rate_numeric": 1500.0, "program": "Commercial"},
                {"provider_name": "Sutter", "rate_numeric": 1200.0, "program": "Medi-Cal"},
            ],
        )
        assert report.row_count == 2
        assert report.is_empty is False
        assert "rate_numeric" in report.numeric_columns()
        assert "provider_name" not in report.numeric_columns()


class TestTemporalReport:
    def test_basics(self):
        report = TemporalReport(
            provider_filter="Kaiser",
            amendments=[
                AmendmentEntry(amendment_order=1, provider_name="Kaiser"),
                AmendmentEntry(amendment_order=2, provider_name="Kaiser"),
            ],
            concept_evolution=[{"version": 1, "filename": "k_v1.pdf", "passage_count": 3}],
            llm_summary="Contract evolved significantly.",
        )
        assert report.amendment_count == 2
        assert report.has_evolution is True

    def test_no_evolution(self):
        report = TemporalReport(provider_filter="Small Hospital")
        assert report.has_evolution is False


class TestComparisonReport:
    def test_creation(self):
        report = ComparisonReport(
            providers=["Kaiser", "Sutter"],
            comparison_data={
                "Kaiser": {"profile": {"total_rates": 120}},
                "Sutter": {"profile": {"total_rates": 50}},
            },
            llm_summary="Kaiser has higher rates overall.",
            target_concept="offset clause",
        )
        assert len(report.providers) == 2


class TestExplanationReport:
    def test_citation_count(self):
        report = ExplanationReport(
            narrative="Offset clauses are...",
            evidence_passages=[{"text": "passage1"}, {"text": "passage2"}],
            target_concept="offset clause",
        )
        assert report.citation_count == 2

    def test_empty(self):
        report = ExplanationReport(narrative="")
        assert report.citation_count == 0


class TestMultiConceptReport:
    def test_match_rate(self):
        report = MultiConceptReport(
            operator="INTERSECTION",
            concepts=["offset", "DOFR"],
            result_set=["Kaiser", "Sutter"],
            concept_results={"offset": 300, "DOFR": 310},
            total_universe=326,
        )
        assert report.match_count == 2
        assert abs(report.match_rate - 2 / 326) < 1e-6

    def test_zero_universe(self):
        report = MultiConceptReport(operator="UNION", total_universe=0)
        assert report.match_rate == 0.0


# ============================================================
# REPORT CONFIG TESTS
# ============================================================


class TestReportConfig:
    def test_defaults(self):
        config = ReportConfig()
        assert config.lob_filter_mode == "all"
        assert config.max_passages_per_provider == 20
        assert config.classify_batch_size == 15
        assert config.confidence_threshold_high == 0.75

    def test_confidence_label_high(self):
        config = ReportConfig()
        assert config.confidence_label(0.80) == ConfidenceLabel.HIGH
        assert config.confidence_label(0.75) == ConfidenceLabel.HIGH

    def test_confidence_label_moderate(self):
        config = ReportConfig()
        assert config.confidence_label(0.60) == ConfidenceLabel.MODERATE
        assert config.confidence_label(0.40) == ConfidenceLabel.MODERATE

    def test_confidence_label_low(self):
        config = ReportConfig()
        assert config.confidence_label(0.39) == ConfidenceLabel.LOW
        assert config.confidence_label(0.0) == ConfidenceLabel.LOW

    def test_custom_thresholds(self):
        config = ReportConfig(
            confidence_threshold_high=0.90,
            confidence_threshold_moderate=0.50,
        )
        assert config.confidence_label(0.85) == ConfidenceLabel.MODERATE
        assert config.confidence_label(0.91) == ConfidenceLabel.HIGH


# ============================================================
# ROUTE MAP TESTS
# ============================================================


class TestRouteToReportType:
    def test_all_routes_present(self):
        expected = {
            "clause_existence", "structured_extraction", "single_provider",
            "rate_query", "temporal", "comparison", "explanation", "multi_concept",
        }
        assert set(ROUTE_TO_REPORT_TYPE.keys()) == expected

    def test_types_correct(self):
        assert ROUTE_TO_REPORT_TYPE["clause_existence"] is ClauseReport
        assert ROUTE_TO_REPORT_TYPE["structured_extraction"] is StructuredExtractionReport
        assert ROUTE_TO_REPORT_TYPE["single_provider"] is ProviderReport
        assert ROUTE_TO_REPORT_TYPE["rate_query"] is RateReport
        assert ROUTE_TO_REPORT_TYPE["temporal"] is TemporalReport
        assert ROUTE_TO_REPORT_TYPE["comparison"] is ComparisonReport
        assert ROUTE_TO_REPORT_TYPE["explanation"] is ExplanationReport
        assert ROUTE_TO_REPORT_TYPE["multi_concept"] is MultiConceptReport

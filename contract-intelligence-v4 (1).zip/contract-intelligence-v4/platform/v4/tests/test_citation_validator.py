"""Tests for platform/v4/services/citation_validator.py (Step 1.5).

Covers all 6 validation checks:
  1. Source existence (Spark SQL against documents_master)
  2. Passage integrity (Spark SQL against fulltext table)
  3. Recency / supersession (is_current_effective, doc_role)
  4. Grounding (keyword overlap + optional LLM NLI)
  5. Numerical consistency (numbers in claim vs passage)
  6. Temporal consistency (dates in claim vs passage)

Plus aggregate ValidationResult properties.

Uses importlib pattern for standalone execution (avoids platform.v4 namespace conflict).
"""
import importlib.util
import os
import sys
import types
from unittest.mock import MagicMock

import pandas as pd
import pytest

# ============================================================
# MODULE LOADING (standalone-compatible)
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..")
)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

_spec = importlib.util.spec_from_file_location(
    "citation_validator",
    os.path.join(PROJECT_ROOT, "platform", "v4", "services", "citation_validator.py"),
)
_mod = importlib.util.module_from_spec(_spec)
sys.modules["citation_validator"] = _mod
_spec.loader.exec_module(_mod)

CitationValidator = _mod.CitationValidator
CheckStatus = _mod.CheckStatus
ValidationResult = _mod.ValidationResult
CitationValidation = _mod.CitationValidation
CheckResult = _mod.CheckResult


# ============================================================
# MOCK HELPERS
# ============================================================


class MockSpark:
    """Mock Spark with configurable source/passage existence."""

    def __init__(self, existing_files=None, existing_passages=None):
        self.existing_files = existing_files or set()
        self.existing_passages = existing_passages or set()

    def sql(self, query):
        mock_df = MagicMock()
        if "SELECT DISTINCT" in query:
            found = [f for f in self.existing_files if f"\'{f}\'" in query or f in query]
            mock_df.toPandas.return_value = pd.DataFrame({"source_filename": found})
            return mock_df
        # Passage integrity queries use "chunk_text LIKE" pattern
        if "chunk_text LIKE" in query:
            for p in self.existing_passages:
                if p[:50] in query:
                    mock_df.count.return_value = 1
                    return mock_df
            mock_df.count.return_value = 0
            return mock_df
        # Source existence single-file check
        if "source_filename" in query.lower():
            for f in self.existing_files:
                if f in query:
                    mock_df.count.return_value = 1
                    return mock_df
            mock_df.count.return_value = 0
            return mock_df
        mock_df.count.return_value = 0
        return mock_df


class MockLLM:
    """Mock LLM client that returns configurable NLI verdicts."""

    def __init__(self, response="SUPPORTS"):
        self.response = response
        self.calls = []

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        return self.response


def _make_validator(files=None, passages=None, llm_response=None, **kwargs):
    spark = MockSpark(existing_files=files or set(), existing_passages=passages or set())
    llm = MockLLM(response=llm_response) if llm_response else None
    return CitationValidator(spark=spark, llm_client=llm, **kwargs), llm


# ============================================================
# CHECK 1: Source Existence
# ============================================================


class TestSourceExistence:
    def test_source_exists(self):
        v, _ = _make_validator(files={"contract.pdf"})
        cit = {"source_filename": "contract.pdf", "passage_text": "x " * 20}
        r = v.validate_single("claim text here enough", cit)
        c = [x for x in r.checks if x.check_name == "source_existence"][0]
        assert c.status == CheckStatus.PASS

    def test_source_not_found(self):
        v, _ = _make_validator(files={"other.pdf"})
        cit = {"source_filename": "missing.pdf", "passage_text": "x " * 20}
        r = v.validate_single("claim text here enough", cit)
        c = [x for x in r.checks if x.check_name == "source_existence"][0]
        assert c.status == CheckStatus.FAIL
        assert c.confidence_impact == -0.5

    def test_empty_source_filename(self):
        v, _ = _make_validator(files={"contract.pdf"})
        cit = {"source_filename": "", "passage_text": "x " * 20}
        r = v.validate_single("claim text here enough", cit)
        c = [x for x in r.checks if x.check_name == "source_existence"][0]
        assert c.status == CheckStatus.FAIL

    def test_source_cache_prevents_duplicate_queries(self):
        spark = MockSpark(existing_files={"a.pdf"})
        v = CitationValidator(spark=spark)
        cit = {"source_filename": "a.pdf", "passage_text": "y " * 20}
        v.validate_single("claim enough words here", cit)
        v.validate_single("claim enough words here", cit)
        # Cache should prevent second SQL call (first call primes cache)
        assert "a.pdf" in v._source_cache


# ============================================================
# CHECK 2: Passage Integrity
# ============================================================


class TestPassageIntegrity:
    def test_passage_found(self):
        v, _ = _make_validator(
            files={"doc.pdf"},
            passages={"The provider shall have the right to offset overpayments"},
        )
        cit = {
            "source_filename": "doc.pdf",
            "passage_text": "The provider shall have the right to offset overpayments against future claims.",
        }
        r = v.validate_single("Provider has offset rights", cit)
        c = [x for x in r.checks if x.check_name == "passage_integrity"][0]
        assert c.status == CheckStatus.PASS

    def test_passage_not_found(self):
        v, _ = _make_validator(files={"doc.pdf"}, passages=set())
        cit = {
            "source_filename": "doc.pdf",
            "passage_text": "Completely fabricated text that does not exist in the corpus anywhere.",
        }
        r = v.validate_single("Some claim here sufficient", cit)
        c = [x for x in r.checks if x.check_name == "passage_integrity"][0]
        assert c.status == CheckStatus.WARN  # WARN, not FAIL (may be truncated)

    def test_short_passage_skipped(self):
        v, _ = _make_validator(files={"doc.pdf"})
        cit = {"source_filename": "doc.pdf", "passage_text": "short"}
        r = v.validate_single("claim", cit)
        c = [x for x in r.checks if x.check_name == "passage_integrity"][0]
        assert c.status == CheckStatus.SKIP


# ============================================================
# CHECK 3: Recency
# ============================================================


class TestRecency:
    def test_current_document(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf", "passage_text": "x " * 20, "is_current_effective": True}
        r = v.validate_single("claim text sufficient", cit)
        c = [x for x in r.checks if x.check_name == "recency"][0]
        assert c.status == CheckStatus.PASS

    def test_expired_document(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf", "passage_text": "x " * 20, "is_current_effective": False}
        r = v.validate_single("claim text sufficient", cit)
        c = [x for x in r.checks if x.check_name == "recency"][0]
        assert c.status == CheckStatus.WARN
        assert c.confidence_impact == -0.3

    def test_superseded_doc_role(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf", "passage_text": "x " * 20,
               "is_current_effective": True, "doc_role": "superseded"}
        r = v.validate_single("claim text sufficient", cit)
        c = [x for x in r.checks if x.check_name == "recency"][0]
        assert c.status == CheckStatus.WARN

    def test_replaced_doc_role(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf", "passage_text": "x " * 20,
               "is_current_effective": True, "doc_role": "replaced"}
        r = v.validate_single("claim text sufficient", cit)
        c = [x for x in r.checks if x.check_name == "recency"][0]
        assert c.status == CheckStatus.WARN


# ============================================================
# CHECK 4: Grounding + NLI
# ============================================================


class TestGrounding:
    def test_high_overlap_passes(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {
            "source_filename": "f.pdf",
            "passage_text": "Provider has right to offset overpayments against future claims.",
        }
        r = v.validate_single("Provider offset overpayments against future claims", cit)
        c = [x for x in r.checks if x.check_name == "grounding"][0]
        assert c.status == CheckStatus.PASS

    def test_low_overlap_fails(self):
        v, _ = _make_validator(files={"f.pdf"}, grounding_threshold=0.5)
        cit = {
            "source_filename": "f.pdf",
            "passage_text": "The annual report was filed with the regulatory commission on time.",
        }
        r = v.validate_single("Provider has offset clause for overpayment recovery", cit)
        c = [x for x in r.checks if x.check_name == "grounding"][0]
        assert c.status == CheckStatus.FAIL

    def test_borderline_with_nli_supports(self):
        v, llm = _make_validator(
            files={"f.pdf"}, llm_response="SUPPORTS",
            grounding_threshold=0.5, nli_on_warn=True,
        )
        cit = {
            "source_filename": "f.pdf",
            "passage_text": "BSC retains all remedies available under the law including the recovery of any amounts owed.",
        }
        r = v.validate_single("BSC has offset clause allowing recovery", cit)
        c = [x for x in r.checks if x.check_name == "grounding"][0]
        assert c.status == CheckStatus.PASS
        assert len(llm.calls) == 1

    def test_borderline_with_nli_contradicts(self):
        v, llm = _make_validator(
            files={"f.pdf"}, llm_response="CONTRADICTS",
            grounding_threshold=0.5, nli_on_warn=True,
        )
        cit = {
            "source_filename": "f.pdf",
            "passage_text": "BSC retains all remedies available under the law including the recovery of any amounts owed.",
        }
        r = v.validate_single("BSC has offset clause allowing recovery", cit)
        c = [x for x in r.checks if x.check_name == "grounding"][0]
        assert c.status == CheckStatus.FAIL

    def test_no_llm_borderline_warns(self):
        v, _ = _make_validator(files={"f.pdf"}, grounding_threshold=0.5, nli_on_warn=True)
        cit = {
            "source_filename": "f.pdf",
            "passage_text": "BSC retains all remedies available under the law including the recovery of any amounts owed.",
        }
        r = v.validate_single("BSC has offset clause allowing recovery", cit)
        c = [x for x in r.checks if x.check_name == "grounding"][0]
        assert c.status == CheckStatus.WARN

    def test_empty_passage_fails(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf", "passage_text": ""}
        r = v.validate_single("Claim with sufficient words", cit)
        c = [x for x in r.checks if x.check_name == "grounding"][0]
        assert c.status == CheckStatus.FAIL


# ============================================================
# CHECK 5: Numerical
# ============================================================


class TestNumerical:
    def test_numbers_match(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf",
               "passage_text": "The cap rate is $50,000 per year."}
        r = v.validate_single("Cap of $50,000", cit)
        c = [x for x in r.checks if x.check_name == "numerical"][0]
        assert c.status == CheckStatus.PASS

    def test_numbers_missing(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf",
               "passage_text": "Standard terms apply without specific amounts."}
        r = v.validate_single("Cap of $50,000 per year", cit)
        c = [x for x in r.checks if x.check_name == "numerical"][0]
        assert c.status in (CheckStatus.WARN, CheckStatus.FAIL)

    def test_no_numbers_in_claim_skips(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf",
               "passage_text": "The rate is $50,000."}
        r = v.validate_single("Provider has offset clause", cit)
        c = [x for x in r.checks if x.check_name == "numerical"][0]
        assert c.status == CheckStatus.SKIP


# ============================================================
# CHECK 6: Temporal
# ============================================================


class TestTemporal:
    def test_dates_match(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf",
               "passage_text": "Effective January 1, 2024, provider shall comply."}
        r = v.validate_single("Terms effective January 1, 2024", cit)
        c = [x for x in r.checks if x.check_name == "temporal"][0]
        assert c.status == CheckStatus.PASS

    def test_no_dates_in_passage_warns(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf",
               "passage_text": "Standard terms apply under this agreement."}
        r = v.validate_single("Effective January 1, 2024", cit)
        c = [x for x in r.checks if x.check_name == "temporal"][0]
        assert c.status == CheckStatus.WARN

    def test_no_dates_in_claim_skips(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf",
               "passage_text": "Effective January 1, 2024."}
        r = v.validate_single("Provider has offset clause", cit)
        c = [x for x in r.checks if x.check_name == "temporal"][0]
        assert c.status == CheckStatus.SKIP

    def test_year_level_match(self):
        v, _ = _make_validator(files={"f.pdf"})
        cit = {"source_filename": "f.pdf",
               "passage_text": "This agreement was executed in 2024.",
               "effective_date": "2024-01-01"}
        r = v.validate_single("The 2024 contract provides for offset", cit)
        c = [x for x in r.checks if x.check_name == "temporal"][0]
        assert c.status == CheckStatus.PASS


# ============================================================
# AGGREGATE: ValidationResult
# ============================================================


class TestValidationResult:
    def test_all_pass(self):
        v, _ = _make_validator(files={"good.pdf"})
        cits = [{"source_filename": "good.pdf",
                 "passage_text": "Provider has right to offset overpayments against future claims payments to the provider."}]
        result = v.validate("Provider has offset clause for overpayment recovery", cits)
        assert result.all_passed
        assert result.pass_rate == 1.0

    def test_has_failures(self):
        v, _ = _make_validator(files={"good.pdf"})
        cits = [
            {"source_filename": "good.pdf",
             "passage_text": "Provider has right to offset overpayments against future claims."},
            {"source_filename": "good.pdf", "passage_text": "x"},  # grounding FAIL
        ]
        result = v.validate("Provider has offset clause for recovery", cits)
        assert result.has_failures
        assert result.n_citations == 2
        assert 0 < result.pass_rate < 1.0

    def test_empty_citations(self):
        v, _ = _make_validator(files={"f.pdf"})
        result = v.validate("Some claim", [])
        assert result.n_citations == 0
        assert result.pass_rate == 0.0
        assert result.all_passed  # vacuously true (0 failures)

    def test_failure_summary(self):
        v, _ = _make_validator(files=set())  # no files exist
        cits = [{"source_filename": "missing.pdf", "passage_text": "x " * 20}]
        result = v.validate("claim text sufficient", cits)
        assert "missing.pdf" in result.failure_summary

    def test_confidence_penalty(self):
        v, _ = _make_validator(files={"f.pdf"})
        cits = [{"source_filename": "f.pdf", "passage_text": "",
                 "is_current_effective": False}]
        result = v.validate("claim text sufficient", cits)
        assert result.overall_confidence_penalty < 0

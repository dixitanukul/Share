"""Tests for platform/v4/presentation/html_renderer.py (P5-RPT-4).

Covers:
  - HtmlRenderer utility methods (card, section_header, table, status_badge, etc.)
  - render_report() dispatch for all 8 report types
  - page_wrapper wrapping
  - Edge cases: empty data, missing fields
"""
import pytest

from platform.v4.contracts.report_types import (
    ClauseReport, StructuredExtractionReport, ProviderReport, RateReport,
    TemporalReport, ComparisonReport, ExplanationReport, MultiConceptReport,
    ProviderFindingSummary, ProviderStatus, ClassifiedPassage,
    TaxonomyEntry, Polarity, ConfidenceScore, ConfidenceLabel,
    FieldDefinition, ExtractedValue, ExtractionConfidence,
    ProviderProfile, AmendmentEntry, RateEntry, ContractTerm,
)
from platform.v4.presentation.html_renderer import HtmlRenderer


# ============================================================
# FIXTURES
# ============================================================


def _make_clause_report():
    return ClauseReport(
        target_concept="offset clause",
        total_universe=5,
        provider_findings={
            "Provider A": ProviderFindingSummary(
                provider_name="Provider A", status=ProviderStatus.HAS_GRANT,
                categories={"OFFSET_GRANT": 2}),
            "Provider B": ProviderFindingSummary(
                provider_name="Provider B", status=ProviderStatus.HAS_DENIED,
                categories={"OFFSET_DENIED": 1}),
        },
        no_mention_providers={"Provider C", "Provider D", "Provider E"},
        classified_passages=[
            ClassifiedPassage(provider="Provider A", filename="f1.pdf",
                            category="OFFSET_GRANT", reasoning="ok", key_phrase="offset"),
        ],
        taxonomy=[
            TaxonomyEntry(code="OFFSET_GRANT", label="Offset Grant", polarity=Polarity.GRANT),
            TaxonomyEntry(code="OFFSET_DENIED", label="Offset Denied", polarity=Polarity.RESTRICT),
        ],
        confidence_scores={
            "Provider A": ConfidenceScore(score=0.85, label=ConfidenceLabel.HIGH),
        },
    )


def _make_extraction_report():
    return StructuredExtractionReport(
        field_definition=FieldDefinition(field_name="offset_start_date"),
        total_universe=3,
        provider_values={
            "P1": ExtractedValue(provider_name="P1", raw_value="2024-01-01",
                                display_value="Jan 1, 2024", confidence=ExtractionConfidence.HIGH),
        },
        no_data_providers=["P2", "P3"],
    )


def _make_provider_report():
    return ProviderReport(
        profile=ProviderProfile(provider_name="Sutter Health", total_rates=5),
        rates=[RateEntry(rate_category="Inpatient", rate_text="$500/day", rate_numeric=500.0)],
        terms=[ContractTerm(topic="Termination", content_text="90 days notice")],
        amendments=[AmendmentEntry(amendment_order=1, document_type="First Amendment")],
    )


def _make_rate_report():
    return RateReport(
        query_type="rates",
        columns=["provider", "rate", "category"],
        rows=[
            {"provider": "Sutter", "rate": 500, "category": "Inpatient"},
            {"provider": "Kaiser", "rate": 450, "category": "Inpatient"},
        ],
    )


def _make_temporal_report():
    return TemporalReport(
        provider_filter="Sutter Health",
        amendments=[AmendmentEntry(amendment_order=1, summary_of_changes="Rate increase")],
        llm_summary="Contract has evolved over 3 amendments since 2020.",
    )


def _make_comparison_report():
    return ComparisonReport(
        providers=["Sutter", "Kaiser"],
        comparison_data={"Sutter": {"rates": 5}, "Kaiser": {"rates": 3}},
        llm_summary="Sutter has higher rates than Kaiser.",
    )


def _make_explanation_report():
    return ExplanationReport(
        narrative="Offset clauses allow health plans to recover overpayments by deducting "
                 "from future claims. This is common in capitated and fee-for-service contracts.",
        target_concept="offset clause",
        evidence_passages=[{"text": "passage 1", "source": "f1.pdf"}],
    )


def _make_multi_concept_report():
    return MultiConceptReport(
        operator="INTERSECTION",
        concepts=["offset clause", "dofr"],
        result_set=["Provider A", "Provider B"],
        total_universe=10,
    )


# ============================================================
# UTILITY METHOD TESTS
# ============================================================


class TestHtmlRendererUtilities:
    def setup_method(self):
        self.renderer = HtmlRenderer()

    def test_card_contains_title_and_value(self):
        html = self.renderer.card("Total Providers", "326")
        assert "Total Providers" in html
        assert "326" in html

    def test_section_header_basic(self):
        html = self.renderer.section_header("Findings")
        assert "Findings" in html
        assert "<h" in html.lower() or "header" in html.lower()

    def test_section_header_with_subtitle(self):
        html = self.renderer.section_header("Results", "Phase 1")
        assert "Results" in html
        assert "Phase 1" in html

    def test_status_badge_has_grant(self):
        html = self.renderer.status_badge("HAS_GRANT")
        assert "HAS" in html or "Grant" in html

    def test_status_badge_no_mention(self):
        html = self.renderer.status_badge("NO_MENTION")
        assert "NO" in html or "Mention" in html

    def test_progress_bar_basic(self):
        html = self.renderer.progress_bar(0.75, label="Coverage")
        assert "75" in html or "0.75" in html

    def test_progress_bar_zero(self):
        html = self.renderer.progress_bar(0.0)
        assert "0" in html

    def test_collapsible_default_closed(self):
        html = self.renderer.collapsible("Details", "<p>Content here</p>")
        assert "Details" in html
        assert "Content here" in html
        # Should not have 'open' attribute by default
        assert "open" not in html.split("Details")[0]

    def test_collapsible_open(self):
        html = self.renderer.collapsible("Details", "Content", open_default=True)
        assert "open" in html

    def test_narrative_basic(self):
        html = self.renderer.narrative("This is a long narrative about contract clauses.")
        assert "narrative" in html.lower() or "contract" in html

    def test_methodology_panel(self):
        steps = [("Step 1", "Do thing A"), ("Step 2", "Do thing B")]
        html = self.renderer.methodology_panel(steps)
        assert "Step 1" in html
        assert "Do thing A" in html
        assert "Step 2" in html

    def test_page_wrapper(self):
        html = self.renderer.page_wrapper("<p>Body content</p>", title="Report")
        assert "<html" in html.lower() or "<body" in html.lower() or "Body content" in html
        assert "Report" in html

    def test_confidence_banner(self):
        html = self.renderer.confidence_banner("high", 0.85, 8, 10, 0)
        assert "85" in html or "High" in html

    def test_card_row(self):
        cards = self.renderer.card("A", "1") + self.renderer.card("B", "2")
        html = self.renderer.card_row(cards)
        assert "A" in html and "B" in html

    def test_citation_footnotes(self):
        citations = [
            {"source_filename": "doc.pdf", "page_number": 5, "text": "excerpt"},
        ]
        html = self.renderer.citation_footnotes(citations)
        assert "doc.pdf" in html

    def test_degradation_banner(self):
        html = self.renderer.degradation_banner("VS timeout — using cached results")
        assert "timeout" in html or "degradation" in html.lower()


# ============================================================
# render_report() DISPATCH TESTS
# ============================================================


class TestRenderReport:
    def setup_method(self):
        self.renderer = HtmlRenderer()

    def test_render_clause_report(self):
        report = _make_clause_report()
        html = self.renderer.render_report(report, question="Which providers have offset?")
        assert "offset" in html.lower()
        assert "Provider A" in html
        assert len(html) > 200

    def test_render_extraction_report(self):
        report = _make_extraction_report()
        html = self.renderer.render_report(report)
        assert "offset_start_date" in html or "Jan 1, 2024" in html
        assert len(html) > 100

    def test_render_provider_report(self):
        report = _make_provider_report()
        html = self.renderer.render_report(report)
        assert "Sutter" in html
        assert len(html) > 100

    def test_render_rate_report(self):
        report = _make_rate_report()
        html = self.renderer.render_report(report)
        assert "500" in html or "rate" in html.lower()
        assert len(html) > 100

    def test_render_temporal_report(self):
        report = _make_temporal_report()
        html = self.renderer.render_report(report)
        assert "Sutter" in html or "amendment" in html.lower()
        assert len(html) > 100

    def test_render_comparison_report(self):
        report = _make_comparison_report()
        html = self.renderer.render_report(report)
        assert "Sutter" in html or "Kaiser" in html
        assert len(html) > 100

    def test_render_explanation_report(self):
        report = _make_explanation_report()
        html = self.renderer.render_report(report)
        assert "offset" in html.lower() or "Offset" in html
        assert "overpayments" in html or "narrative" in html.lower()
        assert len(html) > 100

    def test_render_multi_concept_report(self):
        report = _make_multi_concept_report()
        html = self.renderer.render_report(report)
        assert "INTERSECTION" in html or "offset" in html.lower()
        assert len(html) > 100

    def test_render_unknown_type_returns_fallback(self):
        """Unrecognized report type should not crash."""

        class FakeReport:
            pass

        html = self.renderer.render_report(FakeReport())
        # Should return something (even if just a fallback message)
        assert html is not None
        assert isinstance(html, str)

    def test_render_empty_clause_report(self):
        """ClauseReport with minimal data should not crash."""
        report = ClauseReport(target_concept="test", total_universe=0)
        html = self.renderer.render_report(report)
        assert html is not None and len(html) > 0

    def test_render_empty_rate_report(self):
        """RateReport with no rows should not crash."""
        report = RateReport(query_type="rates", columns=[], rows=[])
        html = self.renderer.render_report(report)
        assert html is not None

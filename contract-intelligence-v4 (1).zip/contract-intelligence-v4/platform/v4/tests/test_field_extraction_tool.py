"""
platform/v4/tests/test_field_extraction_tool.py

Tests for the native FieldExtractionTool (P4A-RATE-2).

Test groups:
    1. TestFieldRegistry - field definition lookup
    2. TestFieldMatching - field matching from questions
    3. TestExtraction - full extraction pipeline
    4. TestRegexFallback - extraction without LLM
    5. TestEdgeCases - validation, empty results
    6. TestGoldenExtraction - 5 golden extraction queries
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock
from typing import Dict, List

import pandas as pd

from platform.v4.tools.field_extraction import (
    FieldExtractionTool,
    FieldDefinition,
    FIELD_REGISTRY,
    find_matching_field,
    ExtractionResult,
)
from platform.v4.contracts.tool_types import Confidence, ToolResult, ToolStatus


# -- Fixtures -----------------------------------------------------------------


class MockSparkSession:
    """Mock SparkSession for field extraction tests."""

    def __init__(self, passages: pd.DataFrame = None):
        self._passages = passages if passages is not None else pd.DataFrame()

    def sql(self, query: str) -> "MockSparkResult":
        return MockSparkResult(self._passages)


class MockSparkResult:
    def __init__(self, pdf: pd.DataFrame):
        self._pdf = pdf

    def toPandas(self) -> pd.DataFrame:
        return self._pdf.copy()


class MockProviderService:
    def __init__(self):
        self._all_names = ["Kaiser Permanente", "Cedars-Sinai", "Sutter Health"]

    def resolve(self, user_input: str):
        key = user_input.lower().strip()
        if "kaiser" in key:
            return (["Kaiser Permanente"], "canonical_exact", ["129088335"])
        return ([user_input], "unresolved", [])

    def all_names(self) -> List[str]:
        return self._all_names


def _make_passages(n: int = 3) -> pd.DataFrame:
    """Sample passages containing termination notice language."""
    return pd.DataFrame({
        "chunk_id": list(range(n)),
        "chunk_text": [
            "Either party may terminate this Agreement without cause upon ninety (90) days prior written notice to the other party.",
            "Provider shall maintain professional liability insurance with minimum coverage of $1,000,000 per occurrence.",
            "Records shall be retained for a period of seven (7) years following termination of this Agreement.",
        ][:n],
        "source_filename": [f"contract_v{i+1}.pdf" for i in range(n)],
        "provider_name": ["Kaiser Permanente"] * n,
        "page_number": [5, 12, 8][:n],
        "doc_version": [2, 2, 1][:n],
    })


@pytest.fixture
def mock_spark():
    return MockSparkSession(passages=_make_passages())


@pytest.fixture
def mock_provider_service():
    return MockProviderService()


@pytest.fixture
def tool(mock_spark, mock_provider_service):
    """FieldExtractionTool with no LLM (regex fallback only)."""
    return FieldExtractionTool(
        spark=mock_spark,
        provider_service=mock_provider_service,
        retrieval_service=None,
        llm_client=None,
    )


@pytest.fixture
def tool_with_llm(mock_spark, mock_provider_service):
    """FieldExtractionTool with mock LLM."""
    mock_llm = MagicMock()
    mock_llm.chat.return_value = "90"
    return FieldExtractionTool(
        spark=mock_spark,
        provider_service=mock_provider_service,
        retrieval_service=None,
        llm_client=mock_llm,
    )


# ==========================================================================
# 1. Field Registry
# ==========================================================================


class TestFieldRegistry:
    """Test FIELD_REGISTRY contents."""

    def test_registry_has_28_fields(self):
        assert len(FIELD_REGISTRY) == 28

    def test_all_fields_have_required_attributes(self):
        for name, defn in FIELD_REGISTRY.items():
            assert defn.name == name
            assert defn.value_type in ("duration", "currency", "date",
                                       "numeric", "text", "boolean")
            assert isinstance(defn.keywords, list)
            assert len(defn.keywords) >= 2
            assert defn.description

    def test_known_fields_present(self):
        expected = [
            "termination for convenience notice",
            "audit retention period",
            "insurance required",
            "effective date",
            "delegation of financial responsibility",
            "ab 352 compliance",
        ]
        for name in expected:
            assert name in FIELD_REGISTRY, f"Missing field: {name}"


# ==========================================================================
# 2. Field Matching
# ==========================================================================


class TestFieldMatching:
    """Test field matching from natural language questions."""

    def test_exact_name_match(self):
        result = find_matching_field("What is the termination for convenience notice period?")
        assert result is not None
        assert result.name == "termination for convenience notice"

    def test_keyword_match(self):
        result = find_matching_field("How long must audit records be retained?")
        assert result is not None
        assert result.name == "audit retention period"

    def test_no_match_for_unrelated(self):
        result = find_matching_field("What is the weather today?")
        assert result is None

    def test_insurance_keywords(self):
        result = find_matching_field(
            "What is the minimum malpractice insurance coverage required?"
        )
        assert result is not None
        assert result.name == "insurance required"

    def test_dofr_keywords(self):
        result = find_matching_field("Is there delegated financial responsibility?")
        assert result is not None
        assert result.name == "delegation of financial responsibility"


# ==========================================================================
# 3. Full Extraction (with LLM)
# ==========================================================================


class TestExtraction:
    """Test full extraction pipeline with mock LLM."""

    def test_extracts_termination_notice(self, tool_with_llm):
        result = tool_with_llm(
            question="What is Kaiser's termination for convenience notice period?",
            provider_name="Kaiser",
        )
        assert result.success
        assert result.data["query_type"] == "field_extraction"
        assert result.data["field_name"] == "termination for convenience notice"
        assert result.data["extraction"]["value"] == 90.0

    def test_includes_source_citation(self, tool_with_llm):
        result = tool_with_llm(
            question="What is Kaiser's termination notice?",
            provider_name="Kaiser",
            field_name="termination for convenience notice",
        )
        assert result.citations
        assert result.citations[0]["source_filename"]

    def test_llm_null_response(self, mock_spark, mock_provider_service):
        mock_llm = MagicMock()
        mock_llm.chat.return_value = "null"
        tool = FieldExtractionTool(
            spark=mock_spark, provider_service=mock_provider_service,
            llm_client=mock_llm,
        )
        result = tool(
            question="Kaiser termination notice",
            provider_name="Kaiser",
            field_name="termination for convenience notice",
        )
        assert result.success
        assert result.data["extraction"]["value"] is None


# ==========================================================================
# 4. Regex Fallback
# ==========================================================================


class TestRegexFallback:
    """Test extraction without LLM (regex fallback)."""

    def test_regex_extracts_number_near_keyword(self, tool):
        result = tool(
            question="What is Kaiser's termination for convenience notice?",
            provider_name="Kaiser",
        )
        assert result.success
        # The passage contains "ninety (90) days" near "terminate" + "notice"
        # Regex should find 90
        extraction = result.data["extraction"]
        assert extraction["value"] == 90.0
        assert extraction["notes"] == "regex fallback (no LLM)"

    def test_regex_fallback_confidence(self, tool):
        result = tool(
            question="Kaiser termination notice",
            provider_name="Kaiser",
            field_name="termination for convenience notice",
        )
        # Regex extraction gives MODERATE confidence
        assert result.confidence in (Confidence.MODERATE, Confidence.HIGH)


# ==========================================================================
# 5. Edge Cases
# ==========================================================================


class TestEdgeCases:
    """Test validation and edge cases."""

    def test_missing_question(self, tool):
        result = tool()
        assert not result.success
        assert result.status == ToolStatus.ERROR

    def test_empty_question(self, tool):
        result = tool(question="")
        assert not result.success
        assert result.status == ToolStatus.ERROR

    def test_unrecognized_field(self, tool):
        result = tool(question="What is the meaning of life?")
        assert result.status == ToolStatus.EMPTY
        assert "Could not identify" in result.summary

    def test_no_passages_found(self, mock_provider_service):
        empty_spark = MockSparkSession(passages=pd.DataFrame())
        tool = FieldExtractionTool(
            spark=empty_spark, provider_service=mock_provider_service,
        )
        result = tool(
            question="Kaiser termination notice",
            provider_name="Kaiser",
            field_name="termination for convenience notice",
        )
        assert result.status == ToolStatus.EMPTY

    def test_tool_name_and_description(self, tool):
        assert tool.name == "field_extraction"
        assert "extract" in tool.description.lower()
        assert not tool.is_adapter_backed

    def test_explicit_field_name(self, tool):
        result = tool(
            question="What about Kaiser?",
            provider_name="Kaiser",
            field_name="audit retention period",
        )
        assert result.success
        assert result.data["field_name"] == "audit retention period"


# ==========================================================================
# 6. Golden Extraction Queries
# ==========================================================================


class TestGoldenExtraction:
    """Golden queries for extraction parity."""

    GOLDEN = [
        ("What is Kaiser's termination for convenience notice?", "Kaiser",
         "termination for convenience notice", "duration"),
        ("How long must Kaiser retain audit records?", "Kaiser",
         "audit retention period", "duration"),
        ("What insurance is required for Kaiser?", "Kaiser",
         "insurance required", "currency"),
        ("What is the effective date of Kaiser's contract?", "Kaiser",
         "effective date", "date"),
        ("Does Kaiser have AB 352 compliance?", "Kaiser",
         "ab 352 compliance", "boolean"),
    ]

    @pytest.mark.parametrize(
        "question,provider,expected_field,expected_type",
        GOLDEN,
        ids=[f"GOLDEN-{i:02d}" for i in range(1, 6)],
    )
    def test_golden_extraction(self, tool, question, provider, expected_field, expected_type):
        result = tool(question=question, provider_name=provider)
        # Must succeed (or be empty if no passages matched)
        assert result.status in (ToolStatus.SUCCESS, ToolStatus.EMPTY), (
            f"Unexpected status: {result.status} - {result.summary}"
        )
        if result.status == ToolStatus.SUCCESS:
            assert result.data["field_name"] == expected_field
            assert result.data["value_type"] == expected_type

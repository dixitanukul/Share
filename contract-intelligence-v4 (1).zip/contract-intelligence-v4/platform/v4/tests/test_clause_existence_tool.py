"""
platform/v4/tests/test_clause_existence_tool.py

P4C-CE-8: Test suite for the V3 Clause Existence Engine.

Test classes:
  TestTaxonomyBuilder         (5)  -- known concept, bypass, novel, fallback
  TestPassageRetriever        (6)  -- freq gate, score/dedup, sweep, cap
  TestClauseClassifier        (8)  -- batch LLM, lien override, polarity rollup
  TestClauseRevalidator       (5)  -- denial re-val, settlement, latest-doc
  TestFalseNegativeRescuer    (5)  -- rescue logic, post-rescue assertion
  TestClauseExistenceTool     (8)  -- validate, concept extraction, pipeline
  TestGoldenConceptExtraction (4)  -- parametrized concept regex regression

Total: 41 tests
"""
from __future__ import annotations

import json
import pandas as pd
import pytest
from unittest.mock import MagicMock
from typing import Any, Dict, List

from platform.v4.tools.clause_existence.taxonomy_builder import TaxonomyBuilder
from platform.v4.tools.clause_existence.passage_retrieval import PassageRetriever
from platform.v4.tools.clause_existence.classifier import ClauseClassifier
from platform.v4.tools.clause_existence.revalidation import ClauseRevalidator
from platform.v4.tools.clause_existence.rescue import FalseNegativeRescuer
from platform.v4.tools.clause_existence_tool import ClauseExistenceTool
from platform.v4.config.taxonomies import KNOWN_TAXONOMIES
from platform.v4.contracts.tool_types import ToolStatus, Confidence


# =============================================================================
# Test Utilities
# =============================================================================

class _MockRow:
    """Dict-like Spark Row mock."""
    def __init__(self, data: dict):
        self._d = data
    def __getitem__(self, key): return self._d[key]
    def get(self, key, default=None): return self._d.get(key, default)


class _MockDF:
    """Mock Spark DataFrame."""
    def __init__(self, df: pd.DataFrame):
        self._df = df
    def toPandas(self): return self._df
    def first(self):
        if self._df.empty:
            return None
        return _MockRow(self._df.iloc[0].to_dict())


class _MockSpark:
    """
    Mock SparkSession. Match patterns checked in insertion order (most-specific first).
    Values may be pd.DataFrame or list-of-dicts.
    """
    def __init__(self, responses: dict = None):
        self._r = responses or {}
        self.calls: List[str] = []
    def sql(self, query: str):
        self.calls.append(query)
        q = query.lower()
        for pattern, value in self._r.items():
            if pattern.lower() in q:
                df = value if isinstance(value, pd.DataFrame) else pd.DataFrame(value)
                return _MockDF(df)
        return _MockDF(pd.DataFrame())


def _make_llm(responses: dict = None):
    """Mock DatabricksLLMClient. Map prompt substrings to JSON responses."""
    llm = MagicMock()
    _r = responses or {}
    def _chat(model, system, user, max_tokens, temperature=0.0):
        for key, val in _r.items():
            if key.lower() in user.lower():
                return val
        return "[]"
    llm.chat.side_effect = _chat
    return llm


def _offset_taxonomy():
    return list(KNOWN_TAXONOMIES["offset clause"])


def _passage(provider="Sutter Health", text="overpayment recoup offset rights", score=3):
    return {
        "text": text, "provider": provider,
        "filename": f"12345_99_{provider[:10].replace(' ','_')}_v2.pdf",
        "page": 1, "score": score, "source": "keyword",
    }


def _classified(provider="Sutter Health", category="OVERPAYMENT_OFFSET"):
    return {
        **_passage(provider),
        "category": category,
        "reasoning": "offset language present",
        "key_phrase": "right to offset overpayment",
    }


# =============================================================================
# TestTaxonomyBuilder
# =============================================================================

class TestTaxonomyBuilder:

    def test_known_concept_returns_cached_taxonomy(self):
        builder = TaxonomyBuilder()
        taxonomy, plan = builder.resolve("offset clause", ["offset", "recoup"])
        codes = {c["code"] for c in taxonomy}
        assert "OVERPAYMENT_OFFSET" in codes
        assert "NO_OFFSET_RIGHTS" in codes

    def test_known_concept_bypass_frequency_gate(self):
        builder = TaxonomyBuilder()
        _, plan = builder.resolve("offset clause", ["offset"])
        assert plan["bypass_frequency_gate"] is True
        assert plan["known_concept_key"] == "offset clause"

    def test_known_concept_case_insensitive(self):
        builder = TaxonomyBuilder()
        taxonomy, plan = builder.resolve("DIVISION OF FINANCIAL RESPONSIBILITY", [])
        codes = {c["code"] for c in taxonomy}
        assert "BSC_UM_RESPONSIBLE" in codes
        assert plan["bypass_frequency_gate"] is True

    def test_novel_concept_no_llm_binary_fallback(self):
        builder = TaxonomyBuilder(llm_client=None)
        taxonomy, plan = builder.resolve("novel governance clause", ["governance"])
        codes = {c["code"] for c in taxonomy}
        assert "CONFIRMED_PRESENT" in codes
        assert "EXPLICITLY_DENIED" in codes
        assert plan["bypass_frequency_gate"] is False

    def test_novel_concept_with_llm(self):
        cats = [
            {"code": "PRESENT", "label": "Present", "description": "yes", "is_denial": False},
            {"code": "ABSENT", "label": "Absent", "description": "no", "is_denial": True},
        ]
        llm = _make_llm({"classification taxonomy": json.dumps({"categories": cats})})
        builder = TaxonomyBuilder(llm_client=llm)
        taxonomy, _ = builder.resolve("some novel clause", ["novel", "clause"])
        assert any(c["code"] == "PRESENT" for c in taxonomy)


# =============================================================================
# TestPassageRetriever
# =============================================================================

class TestPassageRetriever:

    def test_freq_gate_bypass_known_taxonomy(self):
        spark = _MockSpark()
        retriever = PassageRetriever(spark=spark)
        plan = {"bypass_frequency_gate": True, "extended_keywords": ["a", "b"]}
        result = retriever.apply_corpus_frequency_gate(plan)
        assert result["extended_strong"] == ["a", "b"]
        assert result["extended_weak"] == []
        # Should NOT call Spark
        assert spark.calls == []

    def test_freq_gate_weak_above_1pct(self):
        freq_df = pd.DataFrame([{"total": 1000, "kw_0": 20}])
        spark = _MockSpark({"tbl_vs_unified_ready": freq_df})
        retriever = PassageRetriever(spark=spark)
        plan = {
            "bypass_frequency_gate": False,
            "extended_keywords": ["broad"],
            "excluded_keywords": [],
        }
        result = retriever.apply_corpus_frequency_gate(plan)
        # 20/1000 = 2% -> weak
        assert "broad" in result["extended_weak"]
        assert "broad" not in result["extended_strong"]

    def test_score_and_dedup_per_file_cap(self):
        spark = _MockSpark()
        retriever = PassageRetriever(spark=spark)
        # 8 passages for same file -> should be capped at MAX_CHUNKS_PER_FILE=5
        semantic = [
            {"chunk_text": f"offset recoup passage {i}", "provider_name": "Sutter",
             "source_filename": "same_file.pdf", "chunk_index": i,
             "page_number": i, "total_pages": 10, "total_chunks": 8}
            for i in range(8)
        ]
        understanding = {"search_keywords": ["offset", "recoup"]}
        candidates = retriever._score_and_dedup(semantic, None, understanding)
        file_counts = {}
        for c in candidates:
            file_counts[c["filename"]] = file_counts.get(c["filename"], 0) + 1
        assert file_counts.get("same_file.pdf", 0) <= PassageRetriever.MAX_CHUNKS_PER_FILE

    def test_score_and_dedup_normalises_dict_input(self):
        """PassageRetriever normalises VS dict results to candidate dicts."""
        spark = _MockSpark()
        retriever = PassageRetriever(spark=spark)
        semantic = [{"chunk_text": "offset payment rights", "provider_name": "Kaiser",
                     "source_filename": "kaiser_v1.pdf", "chunk_index": 1,
                     "page_number": 2, "total_pages": 10, "total_chunks": 5}]
        understanding = {"search_keywords": ["offset"]}
        candidates = retriever._score_and_dedup(semantic, None, understanding)
        assert len(candidates) == 1
        assert candidates[0]["provider"] == "Kaiser"
        assert candidates[0]["score"] >= 2

    def test_per_provider_sweep_skips_when_all_covered(self):
        spark = _MockSpark()
        retriever = PassageRetriever(spark=spark)
        candidates = [_passage("Sutter Health")]
        aug, rescued, missed = retriever._per_provider_sweep(
            candidates, ["Sutter Health"], {"core_keywords": ["offset"]}, {}
        )
        assert rescued == 0
        assert missed == 0
        assert len(aug) == 1

    def test_apply_provider_cap(self):
        spark = _MockSpark()
        retriever = PassageRetriever(spark=spark)
        # 5 passages for Sutter, 2 for Kaiser, cap=2
        candidates = [_passage("Sutter Health")] * 5 + [_passage("Kaiser")] * 2
        capped = retriever._apply_provider_cap(candidates, max_per_provider=2)
        sutter_count = sum(1 for c in capped if c["provider"] == "Sutter Health")
        kaiser_count = sum(1 for c in capped if c["provider"] == "Kaiser")
        assert sutter_count == 2
        assert kaiser_count == 2


# =============================================================================
# TestClauseClassifier
# =============================================================================

class TestClauseClassifier:

    def test_classify_batch_success(self):
        batch = [_passage("Sutter Health")]
        response = json.dumps([{"passage_num": 1, "category": "OVERPAYMENT_OFFSET",
                                "reasoning": "offset language", "key_phrase": "right to offset"}])
        llm = _make_llm({"offset": response})
        classifier = ClauseClassifier(llm_client=llm)
        results = classifier.classify_batch(batch, "offset clause", ["OVERPAYMENT_OFFSET", "NO_OFFSET_RIGHTS"])
        assert len(results) == 1
        assert results[0]["category"] == "OVERPAYMENT_OFFSET"

    def test_classify_batch_lien_hard_override(self):
        """Third-party lien passages must be forced to NOT_RELEVANT."""
        batch = [_passage("Provider X", text="third party lien hospital hold harmless")]
        response = json.dumps([{"passage_num": 1, "category": "NO_OFFSET_RIGHTS",
                                "reasoning": "third party lien prohibition",
                                "key_phrase": "third party lien"}])
        llm = _make_llm({"offset": response})
        classifier = ClauseClassifier(llm_client=llm)
        results = classifier.classify_batch(batch, "offset clause", ["OVERPAYMENT_OFFSET", "NO_OFFSET_RIGHTS"])
        assert results[0]["category"] == "NOT_RELEVANT"

    def test_classify_batch_json_retry(self):
        """Second attempt succeeds when first attempt returns invalid JSON."""
        batch = [_passage("Mercy")]
        good_resp = json.dumps([{"passage_num": 1, "category": "GENERAL_OFFSET",
                                  "reasoning": "offset", "key_phrase": "offset amounts"}])
        call_count = [0]
        def _chat(model, system, user, max_tokens, temperature=0.0):
            call_count[0] += 1
            if call_count[0] == 1:
                return "NOT VALID JSON {"
            return good_resp
        llm = MagicMock()
        llm.chat.side_effect = _chat
        classifier = ClauseClassifier(llm_client=llm)
        results = classifier.classify_batch(batch, "offset clause", ["GENERAL_OFFSET"])
        assert len(results) == 1
        assert call_count[0] == 2

    def test_provider_rollup_absent_never_creates_mixed(self):
        """ABSENT polarity findings must NOT contribute to MIXED."""
        # Provider has one GRANT finding and one ABSENT finding -> should be HAS, not MIXED
        taxonomy = list(KNOWN_TAXONOMIES["offset clause"])
        # Add an artificial absent code
        taxonomy_with_absent = taxonomy + [
            {"code": "NO_OFFSET_RIGHTS", "label": "No Offset", "description": "none",
             "is_denial": True, "polarity": "RESTRICT"}
        ]
        # Use real ABSENT code from known taxonomy: NO_RECONCILIATION_REQUIREMENT for encounters
        enc_tax = list(KNOWN_TAXONOMIES["encounters reconciliation"])
        classified = [
            _classified("Provider A", "MANDATORY_RECONCILIATION"),   # GRANT
            _classified("Provider A", "NO_RECONCILIATION_REQUIREMENT"),  # ABSENT
        ]
        classifier = ClauseClassifier(llm_client=None)
        provider_data, no_mention = classifier.provider_rollup(
            classified, enc_tax, ["Provider A", "Provider B"], "encounters reconciliation"
        )
        # Provider A has GRANT + ABSENT -> HAS (not MIXED)
        assert "Provider A" in provider_data
        assert provider_data["Provider A"]["status"].startswith("HAS_")
        assert "MIXED" not in provider_data["Provider A"]["status"]

    def test_provider_rollup_grant_only_is_has(self):
        taxonomy = list(KNOWN_TAXONOMIES["offset clause"])
        classified = [_classified("Sutter", "OVERPAYMENT_OFFSET")]
        classifier = ClauseClassifier(llm_client=None)
        provider_data, no_mention = classifier.provider_rollup(
            classified, taxonomy, ["Sutter", "Kaiser"], "offset clause"
        )
        assert provider_data["Sutter"]["status"].startswith("HAS_")
        assert "Kaiser" in no_mention

    def test_provider_rollup_restrict_only_is_denied(self):
        taxonomy = list(KNOWN_TAXONOMIES["offset clause"])
        classified = [_classified("Dignity Health", "NO_OFFSET_RIGHTS")]
        classifier = ClauseClassifier(llm_client=None)
        provider_data, no_mention = classifier.provider_rollup(
            classified, taxonomy, ["Dignity Health"], "offset clause"
        )
        assert provider_data["Dignity Health"]["status"].endswith("_DENIED")

    def test_provider_rollup_grant_and_restrict_is_mixed(self):
        taxonomy = list(KNOWN_TAXONOMIES["offset clause"])
        classified = [
            _classified("Cedar", "OVERPAYMENT_OFFSET"),
            _classified("Cedar", "CONDITIONAL_OFFSET_RESTRICTION"),
        ]
        classifier = ClauseClassifier(llm_client=None)
        provider_data, _ = classifier.provider_rollup(
            classified, taxonomy, ["Cedar"], "offset clause"
        )
        assert provider_data["Cedar"]["status"] == "MIXED"

    def test_verify_key_phrases(self):
        classified = [
            {"text": "the plan shall have the right to offset overpayments",
             "key_phrase": "right to offset overpayments", "category": "OVERPAYMENT_OFFSET"},
            {"text": "short text", "key_phrase": "phrase not in source", "category": "GENERAL_OFFSET"},
        ]
        result = ClauseClassifier(llm_client=None).verify_key_phrases(classified)
        assert result[0]["kp_verified"] is True
        # Second might be False or uncertain; just check key exists
        assert "kp_verified" in result[1]


# =============================================================================
# TestClauseRevalidator
# =============================================================================

class TestClauseRevalidator:

    def test_revalidate_no_denials_skips_llm(self):
        llm = MagicMock()
        rv = ClauseRevalidator(llm_client=llm)
        taxonomy = list(KNOWN_TAXONOMIES["offset clause"])
        classified = [_classified("Sutter", "OVERPAYMENT_OFFSET")]  # no denials
        out, confirmed, reclassified = rv.revalidate_denials(classified, taxonomy, "offset clause")
        assert confirmed == 0 and reclassified == 0
        llm.chat.assert_not_called()

    def test_revalidate_false_denial_reclassified(self):
        response = json.dumps([{"passage_num": 1, "verdict": "FALSE_DENIAL",
                                "correct_category": "OVERPAYMENT_OFFSET", "reason": "conditional"}])
        llm = _make_llm({"prohibiting": response})
        rv = ClauseRevalidator(llm_client=llm)
        taxonomy = list(KNOWN_TAXONOMIES["offset clause"])
        classified = [_classified("Provider X", "NO_OFFSET_RIGHTS")]
        out, confirmed, reclassified = rv.revalidate_denials(classified, taxonomy, "offset clause")
        assert reclassified == 1
        assert out[0]["category"] == "OVERPAYMENT_OFFSET"

    def test_settlement_audit_downgrade(self):
        rv = ClauseRevalidator()
        provider_data = {
            "Vaca Valley": {
                "status": "HAS_OFFSET_CLAUSE",
                "docs": {"12_vaca_settlementagmt_v1.pdf"},
                "findings": [_classified("Vaca Valley")],
            }
        }
        no_mention = []
        pd_out, nm_out, downgraded = rv.settlement_audit(provider_data, no_mention)
        assert "Vaca Valley" in downgraded
        assert "Vaca Valley" in nm_out
        assert "Vaca Valley" not in pd_out

    def test_settlement_audit_no_downgrade_many_findings(self):
        """Providers with > 2 findings are NOT downgraded even if only settlement docs."""
        rv = ClauseRevalidator()
        provider_data = {
            "Big Provider": {
                "status": "HAS_OFFSET_CLAUSE",
                "docs": {"12_big_settlementagmt_v1.pdf"},
                "findings": [_classified("Big Provider")] * 5,  # > 2
            }
        }
        pd_out, nm_out, downgraded = rv.settlement_audit(provider_data, [])
        assert "Big Provider" not in downgraded
        assert "Big Provider" in pd_out

    def test_latest_doc_gate_marks_historical(self):
        fn_df = pd.DataFrame([{"source_filename": "12345_99_provider_v2.pdf"}])
        spark = _MockSpark({"tbl_vs_unified_ready": fn_df})
        rv = ClauseRevalidator(spark=spark)
        # Provider evidence is from v1, but v2 exists -> historical
        provider_data = {
            "Old Provider": {
                "status": "HAS_OFFSET_CLAUSE",
                "docs": {"12345_99_provider_v1.pdf"},
            }
        }
        pd_out, nm_out, historical = rv.latest_doc_gate(provider_data, [])
        assert "Old Provider" in historical
        assert "HISTORICAL" in pd_out["Old Provider"]["status"]


# =============================================================================
# TestFalseNegativeRescuer
# =============================================================================

class TestFalseNegativeRescuer:

    def test_rescue_empty_no_mention(self):
        spark = _MockSpark()
        rescuer = FalseNegativeRescuer(spark=spark)
        no_mention, classified, provider_data, rescued = rescuer.rescue(
            [], [], {}, {"target_concept": "offset clause"}, _offset_taxonomy(), "offset clause"
        )
        assert rescued == 0
        assert spark.calls == []

    def test_rescue_no_strong_phrase_hits(self):
        """Providers with keyword hits but no strong-phrase hits are NOT rescued."""
        # chunk_text has first_pass keyword ("offset") but NOT a strong phrase
        chunks_df = pd.DataFrame([{
            "provider_name": "Missing Provider",
            "source_filename": "mp_v1.pdf",
            "chunk_text": "offset is mentioned once in a weak context",
            "page_number": 1,
            "chunk_index": 1,
            "total_hits": 1,
        }])
        spark = _MockSpark({"tbl_vs_unified_ready": chunks_df})
        rescuer = FalseNegativeRescuer(spark=spark)
        no_mention, classified, provider_data, rescued = rescuer.rescue(
            ["Missing Provider"], [], {}, {"target_concept": "offset clause"},
            _offset_taxonomy(), "offset clause"
        )
        assert rescued == 0
        assert "Missing Provider" in no_mention

    def test_rescue_genuine_strong_hit(self):
        """Provider with strong-phrase hit is moved from no_mention to provider_data."""
        strong_text = "plan has the right to recoup overpayments from future payments"
        chunks_df = pd.DataFrame([{
            "provider_name": "Hidden Provider",
            "source_filename": "hidden_v1.pdf",
            "chunk_text": strong_text,
            "page_number": 3,
            "chunk_index": 5,
            "total_hits": 2,
        }])
        spark = _MockSpark({"tbl_vs_unified_ready": chunks_df})
        rescuer = FalseNegativeRescuer(spark=spark)
        no_mention, classified, provider_data, rescued = rescuer.rescue(
            ["Hidden Provider"], [], {}, {"target_concept": "offset clause"},
            _offset_taxonomy(), "offset clause"
        )
        assert rescued == 1
        assert "Hidden Provider" not in no_mention
        assert "Hidden Provider" in provider_data
        assert provider_data["Hidden Provider"]["status"].startswith("HAS_")

    def test_post_rescue_assertion_passes_when_no_hits(self):
        """Post-rescue assertion passes when no remaining NO_MENTION have >= 2 strong hits."""
        adf = pd.DataFrame()  # empty -> all good
        spark = _MockSpark({"tbl_vs_unified_ready": adf})
        rescuer = FalseNegativeRescuer(spark=spark)
        # Should not raise
        rescuer._run_post_rescue_assertion(["Clean Provider"], ["right to offset"])

    def test_post_rescue_assertion_empty_inputs(self):
        spark = _MockSpark()
        rescuer = FalseNegativeRescuer(spark=spark)
        # Empty no_mention or empty strong_signals -> no SQL call
        rescuer._run_post_rescue_assertion([], ["right to offset"])
        rescuer._run_post_rescue_assertion(["Provider"], [])
        assert spark.calls == []


# =============================================================================
# TestClauseExistenceTool
# =============================================================================

class TestClauseExistenceTool:

    def _make_tool(self, spark=None, provider_service=None):
        if spark is None:
            spark = _MockSpark()
        if provider_service is None:
            provider_service = MagicMock()
            provider_service.corpus_universe.return_value = ["Sutter Health", "Kaiser", "Providence"]
        llm = _make_llm({
            "classify": json.dumps([
                {"passage_num": 1, "category": "OVERPAYMENT_OFFSET",
                 "reasoning": "offset present", "key_phrase": "right to offset"}
            ])
        })
        return ClauseExistenceTool(
            spark=spark,
            provider_service=provider_service,
            retrieval_service=None,
            llm_client=llm,
        )

    def test_validate_inputs_empty_question(self):
        tool = self._make_tool()
        errors = tool.validate_inputs(question="")
        assert len(errors) == 1
        assert "question" in errors[0]

    def test_validate_inputs_valid(self):
        tool = self._make_tool()
        errors = tool.validate_inputs(question="Which providers have offset clause?")
        assert errors == []

    def test_extract_concept_offset(self):
        tool = self._make_tool()
        assert tool._extract_concept("which providers have offset clause") == "offset clause"

    def test_extract_concept_dofr(self):
        tool = self._make_tool()
        assert tool._extract_concept("who has division of financial responsibility") == "division of financial responsibility"

    def test_extract_concept_auto_renewal(self):
        tool = self._make_tool()
        assert tool._extract_concept("auto-renewal clause analysis") == "auto renewal"

    def test_build_understanding_routing_overrides_regex(self):
        tool = self._make_tool()
        routing = {"target_concept": "ipa delegation", "search_keywords": ["ipa"], "semantic_query": "ipa"}
        understanding = tool._build_understanding(
            "some generic question", None, None, routing
        )
        assert understanding["target_concept"] == "ipa delegation"
        assert understanding["search_keywords"] == ["ipa"]

    def test_make_vs_fn_returns_none_when_no_service(self):
        fn = ClauseExistenceTool._make_vs_fn(None)
        assert fn is None

    def test_evidence_gate_returns_empty_on_no_candidates(self):
        """When retrieval returns nothing, tool returns ToolStatus.EMPTY."""
        spark = _MockSpark()  # returns empty DataFrames for all queries
        provider_service = MagicMock()
        provider_service.corpus_universe.return_value = ["Provider A"]
        tool = ClauseExistenceTool(
            spark=spark, provider_service=provider_service, llm_client=None
        )
        result = tool(question="which providers have offset clause?")
        assert result.status == ToolStatus.EMPTY


# =============================================================================
# TestGoldenConceptExtraction  (P4C-CE-8 regression)
# =============================================================================

@pytest.mark.parametrize("question,expected_concept", [
    ("Which providers have an offset clause?", "offset clause"),
    ("Show me providers with division of financial responsibility", "division of financial responsibility"),
    ("Which contracts have IPA delegation?", "ipa delegation"),
    ("Do all providers have auto renewal?", "auto renewal"),
])
def test_golden_concept_extraction(question: str, expected_concept: str):
    """Golden queries: concept extraction must return expected value (CE-8 regression)."""
    tool = ClauseExistenceTool(
        spark=_MockSpark(),
        provider_service=MagicMock(),
        llm_client=None,
    )
    extracted = tool._extract_concept(question)
    assert extracted == expected_concept, (
        f"Concept mismatch for {question!r}: expected {expected_concept!r}, got {extracted!r}"
    )


# =============================================================================
# TestProviderFilterUniverse (GAP-006)
# =============================================================================

class TestProviderFilterUniverse:
    """GAP-006: total_universe must reflect provider_filter when specified."""

    def test_no_filter_returns_full_universe(self):
        full = ["Provider A", "Provider B", "Provider C"]
        result = ClauseExistenceTool._apply_provider_filter(full, None)
        assert result == full

    def test_empty_filter_returns_full_universe(self):
        full = ["Provider A", "Provider B", "Provider C"]
        result = ClauseExistenceTool._apply_provider_filter(full, "")
        assert result == full

    def test_single_provider_filter(self):
        full = ["Cedars-Sinai", "Kaiser Permanente", "Providence"]
        result = ClauseExistenceTool._apply_provider_filter(full, "Kaiser Permanente")
        assert result == ["Kaiser Permanente"]

    def test_single_provider_filter_case_insensitive(self):
        full = ["Cedars-Sinai", "Kaiser Permanente", "Providence"]
        result = ClauseExistenceTool._apply_provider_filter(full, "kaiser permanente")
        assert result == ["Kaiser Permanente"]

    def test_comma_separated_filter(self):
        full = ["Cedars-Sinai", "Kaiser Permanente", "Providence", "Sutter Health"]
        result = ClauseExistenceTool._apply_provider_filter(
            full, "Cedars-Sinai, Providence"
        )
        assert set(result) == {"Cedars-Sinai", "Providence"}
        assert len(result) == 2

    def test_json_list_filter(self):
        """Frontend may pass filter as JSON-style list string."""
        full = ["Cedars-Sinai", "Kaiser Permanente", "Providence"]
        result = ClauseExistenceTool._apply_provider_filter(
            full, "['Cedars-Sinai', 'Kaiser Permanente']"
        )
        assert set(result) == {"Cedars-Sinai", "Kaiser Permanente"}

    def test_filter_no_match_falls_back_to_full(self):
        """If filter matches nothing (typo), fall back to full universe."""
        full = ["Cedars-Sinai", "Kaiser Permanente"]
        result = ClauseExistenceTool._apply_provider_filter(full, "Nonexistent Hospital")
        assert result == full  # fallback

    def test_filter_preserves_order(self):
        full = ["A", "B", "C", "D", "E"]
        result = ClauseExistenceTool._apply_provider_filter(full, "D, B")
        # Should preserve the order from full_universe
        assert result == ["B", "D"]

    def test_total_universe_uses_filtered_count(self):
        """Integration: total_universe in result reflects filtered set."""
        spark = _MockSpark()
        provider_service = MagicMock()
        provider_service.corpus_universe.return_value = [
            "Cedars-Sinai", "Kaiser Permanente", "Providence",
            "Sutter Health", "Dignity Health",
        ]
        tool = ClauseExistenceTool(
            spark=spark,
            provider_service=provider_service,
            llm_client=None,
        )
        # Run with filter — should get EMPTY (no passages) but total_universe = 2
        result = tool(
            question="Which providers have offset clause?",
            provider_filter="Cedars-Sinai, Kaiser Permanente",
        )
        assert result.data["total_universe"] == 2  # NOT 5

"""
platform/v4/tests/test_multiturn_context.py

BUG-012: Tests for multi-turn conversation context fixes:
  - build_conversation_context() — non-alternating messages, dedup, filtering
  - deduplicate_session_rows() — retry/timeout duplicate handling
  - resume_session() — integrated dedup in session resumption
  - to_prompt_summary() — actual Q/A content in prompts
  - chat_multi() — multi-turn LLM method validation

No live Spark or LLM required — all mocked.

Run: python -B -m pytest platform/v4/tests/test_multiturn_context.py -v -p no:cacheprovider
"""
import sys
import os
import types
import importlib.util

# ---------------------------------------------------------------------------
# Import setup: The project uses `from platform.v4.xxx import yyy` which
# requires `platform` to resolve as a local package (not stdlib).
# We set this up here so standalone pytest execution works.
# ---------------------------------------------------------------------------
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _import_from_file(module_name: str, file_path: str):
    """Import a module directly from file path, bypassing package resolution."""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


# Bootstrap: import context_types first (no transitive deps that hit platform.v4)
_context_types = _import_from_file(
    "platform.v4.contracts.context_types",
    os.path.join(_PROJECT_ROOT, "platform/v4/contracts/context_types.py"),
)

# Stub out the platform.v4 imports that context_manager.py needs
_agent_types_mod = types.ModuleType("platform.v4.contracts.agent_types")


class _AgentRequest:
    """Stub for testing — only needs session_id, question, provider_hint, concept_hint, feature_flags."""
    def __init__(self, session_id="", question="", provider_hint="", concept_hint="",
                 max_steps=10, budget_usd=5.0, feature_flags=None):
        self.session_id = session_id
        self.question = question
        self.provider_hint = provider_hint
        self.concept_hint = concept_hint
        self.max_steps = max_steps
        self.budget_usd = budget_usd
        self.feature_flags = feature_flags or {}


_agent_types_mod.AgentRequest = _AgentRequest
sys.modules["platform.v4.contracts.agent_types"] = _agent_types_mod

# Stub the settings module
_settings_mod = types.ModuleType("platform.v4.config.settings")
_settings_mod.TBL_DIM_PROVIDER_CANONICAL = "dev_adb.raw.dim_provider_canonical"
_settings_mod.CATALOG = "dev_adb"
_settings_mod.SCHEMA = "raw"
sys.modules["platform.v4.config.settings"] = _settings_mod
sys.modules["platform.v4.config"] = types.ModuleType("platform.v4.config")
sys.modules["platform.v4.contracts"] = types.ModuleType("platform.v4.contracts")
sys.modules["platform.v4"] = types.ModuleType("platform.v4")

# Wire context_types into the platform.v4.contracts namespace (since context_manager imports from there)
sys.modules["platform.v4.contracts.context_types"] = _context_types

# Now import context_manager (which imports from platform.v4.contracts + platform.v4.config)
_context_manager = _import_from_file(
    "platform.v4.core.context_manager",
    os.path.join(_PROJECT_ROOT, "platform/v4/core/context_manager.py"),
)

# Import LLM client (no transitive platform.v4 deps)
_llm_client_mod = _import_from_file(
    "platform.v4.runtime.databricks_llm_client",
    os.path.join(_PROJECT_ROOT, "platform/v4/runtime/databricks_llm_client.py"),
)

# ---------------------------------------------------------------------------
# Bind imports
# ---------------------------------------------------------------------------
import pytest
from unittest.mock import MagicMock, patch

ContextManager = _context_manager.ContextManager
build_conversation_context = _context_manager.build_conversation_context
deduplicate_session_rows = _context_manager.deduplicate_session_rows

SessionContext = _context_types.SessionContext
ConversationTurn = _context_types.ConversationTurn
ResolvedEntity = _context_types.ResolvedEntity
WorkingData = _context_types.WorkingData

DatabricksLLMClient = _llm_client_mod.DatabricksLLMClient


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_manager(window_size: int = 5) -> ContextManager:
    """Create a ContextManager with pre-populated provider cache (no Spark)."""
    cm = ContextManager(spark=None, window_size=window_size)
    cm._provider_cache = [
        {
            "canonical_name": "Cedars-Sinai Medical Center",
            "provider_ids": ["cs001"],
            "all_names_used": ["cedars", "cedars-sinai", "cedars sinai"],
        },
        {
            "canonical_name": "Kaiser Permanente",
            "provider_ids": ["k001"],
            "all_names_used": ["kaiser"],
        },
    ]
    return cm


def _make_session_rows(questions: list[str], answers: list[str] | None = None) -> list[dict]:
    """Build mock session rows as would be loaded from tbl_agent_sessions."""
    answers = answers or ["Answer " + str(i) for i in range(len(questions))]
    rows = []
    for i, (q, a) in enumerate(zip(questions, answers)):
        rows.append({
            "session_id": "test-session-001",
            "question": q,
            "answer": a,
            "total_cost": 0.01 * (i + 1),
            "resolved_entities_json": None,
            "created_at": f"2026-06-20T10:0{i}:00Z",
        })
    return rows


# ===========================================================================
# TestBuildConversationContext
# ===========================================================================

class TestBuildConversationContext:
    """Tests for the build_conversation_context() utility function."""

    def test_empty_messages(self):
        result = build_conversation_context([])
        assert result == []

    def test_single_user_message(self):
        messages = [{"role": "user", "content": "Hello"}]
        result = build_conversation_context(messages)
        assert result == [{"role": "user", "content": "Hello"}]

    def test_normal_alternation(self):
        messages = [
            {"role": "user", "content": "What is offset?"},
            {"role": "assistant", "content": "An offset clause allows..."},
            {"role": "user", "content": "Who has one?"},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 3
        assert result[0]["role"] == "user"
        assert result[1]["role"] == "assistant"
        assert result[2]["role"] == "user"

    def test_system_messages_filtered(self):
        messages = [
            {"role": "system", "content": "You are a contract analyst."},
            {"role": "user", "content": "What is offset?"},
            {"role": "system", "content": "Processing..."},
            {"role": "assistant", "content": "An offset clause allows..."},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2
        assert result[0] == {"role": "user", "content": "What is offset?"}
        assert result[1] == {"role": "assistant", "content": "An offset clause allows..."}

    def test_status_messages_filtered(self):
        messages = [
            {"role": "user", "content": "Query rates"},
            {"role": "status", "content": "Searching vector index..."},
            {"role": "status", "content": "Running SQL query..."},
            {"role": "assistant", "content": "Found 5 rate rules."},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2
        assert all(m["role"] != "status" for m in result)

    def test_tool_messages_filtered(self):
        messages = [
            {"role": "user", "content": "Show rates for Cedars"},
            {"role": "tool", "content": '{"results": [...]}'},
            {"role": "function", "content": "tool_result"},
            {"role": "assistant", "content": "Cedars has per diem rates."},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2

    def test_consecutive_user_messages_merged(self):
        """When user sends multiple messages before assistant responds, merge them."""
        messages = [
            {"role": "user", "content": "What is the offset clause?"},
            {"role": "user", "content": "For Cedars-Sinai specifically."},
            {"role": "assistant", "content": "Cedars-Sinai has an offset clause..."},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2
        assert result[0]["role"] == "user"
        assert "What is the offset clause?" in result[0]["content"]
        assert "For Cedars-Sinai specifically." in result[0]["content"]
        assert result[1]["role"] == "assistant"

    def test_consecutive_assistant_messages_merged(self):
        """When assistant sends multiple responses (streaming chunks), merge them."""
        messages = [
            {"role": "user", "content": "Show all rates"},
            {"role": "assistant", "content": "Here are the rates:"},
            {"role": "assistant", "content": "1. Per diem: $1,500"},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2
        assert result[1]["role"] == "assistant"
        assert "Here are the rates:" in result[1]["content"]
        assert "1. Per diem: $1,500" in result[1]["content"]

    def test_duplicate_messages_deduped(self):
        """Exact duplicate (role, content) pairs from retries are removed."""
        messages = [
            {"role": "user", "content": "What is offset?"},
            {"role": "user", "content": "What is offset?"},  # duplicate retry
            {"role": "assistant", "content": "An offset clause allows..."},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2
        assert result[0]["content"] == "What is offset?"

    def test_empty_content_skipped(self):
        messages = [
            {"role": "user", "content": ""},
            {"role": "user", "content": "   "},
            {"role": "user", "content": "Actual question"},
            {"role": "assistant", "content": ""},
            {"role": "assistant", "content": "Real answer"},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2
        assert result[0]["content"] == "Actual question"
        assert result[1]["content"] == "Real answer"

    def test_max_turns_truncation(self):
        """Only keeps the last max_turns messages."""
        messages = [
            {"role": "user", "content": f"Question {i}"}
            if i % 2 == 0 else
            {"role": "assistant", "content": f"Answer {i}"}
            for i in range(20)
        ]
        result = build_conversation_context(messages, max_turns=4)
        assert len(result) == 4

    def test_unknown_roles_normalized_to_user(self):
        """Roles other than 'assistant' are treated as 'user'."""
        messages = [
            {"role": "human", "content": "Custom role question"},
            {"role": "assistant", "content": "Response"},
        ]
        result = build_conversation_context(messages)
        assert result[0]["role"] == "user"
        assert result[0]["content"] == "Custom role question"

    def test_missing_role_defaults_to_user(self):
        messages = [{"content": "No role specified"}]
        result = build_conversation_context(messages)
        assert result[0]["role"] == "user"

    def test_complex_mixed_scenario(self):
        """Real-world scenario: system + user + status + retry + assistant."""
        messages = [
            {"role": "system", "content": "System prompt"},
            {"role": "user", "content": "What are Cedars rates?"},
            {"role": "status", "content": "Searching..."},
            {"role": "user", "content": "What are Cedars rates?"},  # duplicate
            {"role": "tool", "content": "tool_result_json"},
            {"role": "assistant", "content": "Cedars has per diem rates of $1,500."},
            {"role": "status", "content": "Complete."},
            {"role": "user", "content": "What about their stop loss?"},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 3
        assert result[0] == {"role": "user", "content": "What are Cedars rates?"}
        assert result[1] == {"role": "assistant", "content": "Cedars has per diem rates of $1,500."}
        assert result[2] == {"role": "user", "content": "What about their stop loss?"}

    def test_internal_and_heartbeat_filtered(self):
        messages = [
            {"role": "user", "content": "Question"},
            {"role": "internal", "content": "routing decision"},
            {"role": "heartbeat", "content": "ping"},
            {"role": "assistant", "content": "Answer"},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 2


# ===========================================================================
# TestDeduplicateSessionRows
# ===========================================================================

class TestDeduplicateSessionRows:
    """Tests for the deduplicate_session_rows() utility function."""

    def test_empty_rows(self):
        assert deduplicate_session_rows([]) == []

    def test_no_duplicates(self):
        rows = _make_session_rows(["Q1", "Q2", "Q3"])
        result = deduplicate_session_rows(rows)
        assert len(result) == 3

    def test_exact_duplicate_question_keeps_latest(self):
        """When same question appears twice (retry), keep only the latest."""
        rows = _make_session_rows(
            ["What is offset?", "Show rates", "What is offset?"],
            ["First try answer", "Rates answer", "Retry answer (complete)"],
        )
        result = deduplicate_session_rows(rows)
        assert len(result) == 2
        # The "What is offset?" row kept should be the LAST one (most complete)
        offset_rows = [r for r in result if r["question"] == "What is offset?"]
        assert len(offset_rows) == 1
        assert offset_rows[0]["answer"] == "Retry answer (complete)"

    def test_multiple_duplicates(self):
        """Multiple retries of the same question."""
        rows = _make_session_rows(
            ["Q1", "Q1", "Q1", "Q2"],
            ["A1-v1", "A1-v2", "A1-v3", "A2"],
        )
        result = deduplicate_session_rows(rows)
        assert len(result) == 2
        q1_row = [r for r in result if r["question"] == "Q1"][0]
        assert q1_row["answer"] == "A1-v3"  # latest version

    def test_case_insensitive_dedup(self):
        """Dedup is case-insensitive (same question, different casing)."""
        rows = _make_session_rows(
            ["What is offset?", "WHAT IS OFFSET?"],
            ["Answer 1", "Answer 2"],
        )
        result = deduplicate_session_rows(rows)
        assert len(result) == 1

    def test_preserves_chronological_order(self):
        """Result maintains original chronological ordering."""
        rows = _make_session_rows(["Q1", "Q2", "Q3", "Q2"])
        result = deduplicate_session_rows(rows)
        questions = [r["question"] for r in result]
        # Q2's last occurrence is row 3 (index 3), Q1 is row 0, Q3 is row 2
        # After dedup keeping latest: Q1 (index 0), Q3 (index 2), Q2 (index 3)
        assert questions == ["Q1", "Q3", "Q2"]

    def test_empty_question_preserved(self):
        """Rows with empty questions are edge-case preserved."""
        rows = _make_session_rows(["", "Q1", ""])
        result = deduplicate_session_rows(rows)
        # Both empty-question rows kept (edge case)
        empty_rows = [r for r in result if r["question"] == ""]
        assert len(empty_rows) == 2


# ===========================================================================
# TestResumeSessionDedup
# ===========================================================================

class TestResumeSessionDedup:
    """Tests that resume_session() properly deduplicates before rebuilding."""

    def test_resume_with_duplicate_rows(self):
        cm = _make_manager()
        rows = _make_session_rows(
            ["What is offset for Cedars?", "Show rates", "What is offset for Cedars?"],
            ["First answer", "Rates: $1500", "Complete answer about offset"],
        )
        ctx = cm.resume_session("sess-001", "Follow-up question", rows)
        # Should only have 2 turns in history (deduped)
        assert len(ctx.conversation_history) == 2
        assert ctx.turn_count == 3  # 2 prior turns + 1 new

    def test_resume_without_duplicates(self):
        cm = _make_manager()
        rows = _make_session_rows(["Q1", "Q2", "Q3"])
        ctx = cm.resume_session("sess-002", "Q4", rows)
        assert len(ctx.conversation_history) == 3
        assert ctx.turn_count == 4

    def test_resume_applies_window_size(self):
        cm = _make_manager(window_size=2)
        rows = _make_session_rows(["Q1", "Q2", "Q3", "Q4", "Q5"])
        ctx = cm.resume_session("sess-003", "Q6", rows)
        # Window size=2, so only last 2 turns retained
        assert len(ctx.conversation_history) == 2
        # But history_summary should contain info about evicted turns
        assert ctx.history_summary != ""

    def test_resume_empty_rows(self):
        cm = _make_manager()
        ctx = cm.resume_session("sess-004", "First question", [])
        assert len(ctx.conversation_history) == 0
        assert ctx.turn_count == 1


# ===========================================================================
# TestToPromptSummary
# ===========================================================================

class TestToPromptSummary:
    """Tests for the improved to_prompt_summary() method."""

    def test_no_history_shows_basic_info(self):
        ctx = SessionContext(session_id="test", question="Q1")
        summary = ctx.to_prompt_summary()
        assert "Cost so far" in summary
        # No "Conversation" since no history
        assert "Conversation" not in summary

    def test_with_history_shows_qa_content(self):
        """BUG-012: prompt summary now includes actual Q/A content."""
        ctx = SessionContext(
            session_id="test",
            question="Follow-up",
            turn_count=2,
        )
        ctx.conversation_history = [
            ConversationTurn(
                question="What is the offset clause for Cedars?",
                answer_preview="Cedars-Sinai has an offset clause allowing recoupment...",
            ),
        ]
        summary = ctx.to_prompt_summary()
        assert "What is the offset clause" in summary
        assert "Cedars-Sinai has an offset clause" in summary
        assert "Conversation (2 turns)" in summary

    def test_prompt_summary_includes_provider_tags(self):
        """Provider tags are shown in history entries."""
        ctx = SessionContext(session_id="test", question="Follow-up", turn_count=2)
        ctx.conversation_history = [
            ConversationTurn(
                question="Show me Cedars rates",
                answer_preview="Per diem: $1,500",
                resolved_entities=[
                    ResolvedEntity(
                        raw_mention="Cedars",
                        canonical_form="Cedars-Sinai Medical Center",
                        entity_type="provider",
                        provider_ids=["cs001"],
                    )
                ],
            ),
        ]
        summary = ctx.to_prompt_summary()
        assert "[Cedars-Sinai Medical Center]" in summary

    def test_prompt_summary_limits_history_to_3(self):
        """Only last 3 turns are shown in prompt summary."""
        ctx = SessionContext(session_id="test", question="Q6", turn_count=6)
        ctx.conversation_history = [
            ConversationTurn(question=f"Question {i}", answer_preview=f"Answer {i}")
            for i in range(5)
        ]
        summary = ctx.to_prompt_summary()
        # Should have Q2, Q3, Q4 (last 3 turns)
        assert "Question 2" in summary
        assert "Question 3" in summary
        assert "Question 4" in summary
        assert "Question 0" not in summary
        assert "Question 1" not in summary

    def test_prompt_summary_handles_empty_answer(self):
        ctx = SessionContext(session_id="test", question="Q2", turn_count=2)
        ctx.conversation_history = [
            ConversationTurn(question="First question", answer_preview=""),
        ]
        summary = ctx.to_prompt_summary()
        assert "(no answer)" in summary


# ===========================================================================
# TestChatMulti
# ===========================================================================

class TestChatMulti:
    """Tests for the DatabricksLLMClient.chat_multi() method."""

    def test_chat_multi_empty_messages_raises(self):
        client = DatabricksLLMClient(
            workspace_url="https://test.azuredatabricks.net",
            model="test-model",
            api_token="dapi_test",
        )
        with pytest.raises(ValueError, match="messages list cannot be empty"):
            client.chat_multi(model="test-model", messages=[], max_tokens=100)

    def test_chat_multi_last_message_must_be_user(self):
        client = DatabricksLLMClient(
            workspace_url="https://test.azuredatabricks.net",
            model="test-model",
            api_token="dapi_test",
        )
        messages = [
            {"role": "user", "content": "Question"},
            {"role": "assistant", "content": "Answer"},  # last msg is assistant
        ]
        with pytest.raises(ValueError, match="last message must have role='user'"):
            client.chat_multi(model="test-model", messages=messages, max_tokens=100)

    def test_chat_multi_sends_full_message_list(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "choices": [{"message": {"content": "Multi-turn response"}}]
        }
        mock_resp.raise_for_status = MagicMock()

        client = DatabricksLLMClient(
            workspace_url="https://test.azuredatabricks.net",
            model="test-model",
            api_token="dapi_test",
        )
        messages = [
            {"role": "system", "content": "You are a contract analyst."},
            {"role": "user", "content": "What is offset?"},
            {"role": "assistant", "content": "Offset allows recoupment."},
            {"role": "user", "content": "Does Cedars have one?"},
        ]

        import requests as _requests
        with patch.object(_requests, "post", return_value=mock_resp) as mock_post:
            result = client.chat_multi(model="test-model", messages=messages, max_tokens=500)

        assert result == "Multi-turn response"
        # Verify the full message list was sent in the payload
        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["messages"] == messages
        assert payload["max_tokens"] == 500

    def test_chat_multi_handles_api_error(self):
        import requests as _requests

        client = DatabricksLLMClient(
            workspace_url="https://test.azuredatabricks.net",
            model="test-model",
            api_token="dapi_test",
        )
        messages = [{"role": "user", "content": "Test"}]

        with patch.object(_requests, "post", side_effect=_requests.exceptions.ConnectionError("timeout")):
            with pytest.raises(RuntimeError, match="chat_multi: request failed"):
                client.chat_multi(model="test-model", messages=messages, max_tokens=100)


# ===========================================================================
# TestBuildConversationContextEdgeCases
# ===========================================================================

class TestBuildConversationContextEdgeCases:
    """Additional edge cases for robustness."""

    def test_none_content_handled(self):
        messages = [
            {"role": "user", "content": None},
            {"role": "user", "content": "Real question"},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 1
        assert result[0]["content"] == "Real question"

    def test_missing_content_key(self):
        messages = [
            {"role": "user"},  # no content key
            {"role": "user", "content": "Has content"},
        ]
        result = build_conversation_context(messages)
        assert len(result) == 1

    def test_preserves_newlines_in_merged_content(self):
        messages = [
            {"role": "user", "content": "Line 1"},
            {"role": "user", "content": "Line 2"},
        ]
        result = build_conversation_context(messages)
        assert result[0]["content"] == "Line 1\nLine 2"

    def test_max_turns_zero_returns_empty(self):
        messages = [{"role": "user", "content": "Q"}]
        result = build_conversation_context(messages, max_turns=0)
        assert result == []

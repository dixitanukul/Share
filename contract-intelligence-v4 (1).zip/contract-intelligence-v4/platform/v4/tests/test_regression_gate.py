"""
platform/v4/tests/test_regression_gate.py

W9-33: Tests for RegressionGate, GateConfig, and evaluate_against_config().

All tests run without Spark or a live eval database.
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from platform.v4.evaluation.regression_gate import RegressionGate, GateResult
from platform.v4.evaluation.gate_config import (
    GateConfig, ConfigGateResult, evaluate_against_config,
)


# ============================================================================
# Helpers
# ============================================================================

def _report(
    run_id: str = "test_run",
    total: int = 10,
    success: int = 9,
    failed: int = 1,
    avg_match: float = 0.80,
    avg_cost: float = 0.50,
) -> MagicMock:
    r = MagicMock()
    r.run_id            = run_id
    r.total_queries     = total
    r.successful_queries = success
    r.failed_queries    = failed
    r.avg_match_score   = avg_match
    r.avg_cost          = avg_cost
    return r


# ============================================================================
# Category 1: RegressionGate no-Spark dry paths (4 tests)
# ============================================================================

class TestRegressionGateNoSpark:

    def test_no_spark_returns_warn(self):
        gate   = RegressionGate(spark=None, baseline_run="run_001")
        result = gate.evaluate(new_run_id="run_002")
        assert isinstance(result, GateResult)
        assert result.verdict == "WARN"
        assert "No Spark" in result.summary

    def test_no_baseline_returns_warn(self):
        gate   = RegressionGate(spark=MagicMock())
        result = gate.evaluate(new_run_id="run_002")
        assert result.verdict == "WARN"
        assert "baseline" in result.summary.lower()

    def test_has_baseline_false_when_not_set(self):
        gate = RegressionGate()
        assert gate.has_baseline() is False

    def test_set_baseline_registers_run_id(self):
        gate = RegressionGate()
        gate.set_baseline("run_baseline_001")
        assert gate.has_baseline() is True
        assert gate._baseline_run == "run_baseline_001"

    def test_gate_result_passed_property(self):
        r = GateResult(verdict="PASS", baseline_run_id="b", new_run_id="n")
        assert r.passed is True
        r2 = GateResult(verdict="FAIL", baseline_run_id="b", new_run_id="n")
        assert r2.passed is False


# ============================================================================
# Category 2: GateConfig defaults and overrides (3 tests)
# ============================================================================

class TestGateConfig:

    def test_defaults_set_correctly(self):
        cfg = GateConfig()
        assert cfg.min_success_rate    == 0.90
        assert cfg.min_avg_match_score == 0.20
        assert cfg.max_failure_rate    == 0.10
        assert cfg.max_avg_cost_per_query == 2.00

    def test_warn_thresholds_above_min(self):
        """warn thresholds are stricter than min thresholds."""
        cfg = GateConfig()
        assert cfg.warn_success_rate > cfg.min_success_rate
        assert cfg.warn_match_score  > cfg.min_avg_match_score

    def test_custom_config_overrides_defaults(self):
        cfg = GateConfig(min_success_rate=0.99, max_avg_cost_per_query=0.50)
        assert cfg.min_success_rate     == 0.99
        assert cfg.max_avg_cost_per_query == 0.50


# ============================================================================
# Category 3: evaluate_against_config verdict logic (7 tests)
# ============================================================================

class TestEvaluateAgainstConfig:

    def test_perfect_report_passes(self):
        result = evaluate_against_config(
            _report(total=10, success=10, failed=0, avg_match=0.95, avg_cost=0.10)
        )
        assert isinstance(result, ConfigGateResult)
        assert result.verdict == "PASS"
        assert result.passed is True

    def test_low_success_rate_fails(self):
        """8/10 success = 0.80 < 0.90 threshold => FAIL."""
        result = evaluate_against_config(
            _report(total=10, success=8, failed=2, avg_match=0.80)
        )
        assert result.verdict == "FAIL"

    def test_low_match_score_fails(self):
        """avg_match=0.10 < 0.20 threshold => FAIL."""
        result = evaluate_against_config(
            _report(total=10, success=10, failed=0, avg_match=0.10)
        )
        assert result.verdict == "FAIL"

    def test_high_failure_rate_fails(self):
        """20% failure > 10% threshold => FAIL."""
        result = evaluate_against_config(
            _report(total=10, success=8, failed=2, avg_match=0.80)
        )
        assert result.verdict == "FAIL"

    def test_warn_when_below_warn_threshold(self):
        """success_rate=0.91 passes min(0.90) but below warn(0.95) => WARN."""
        result = evaluate_against_config(
            _report(total=100, success=91, failed=9, avg_match=0.85)
        )
        assert result.verdict in ("WARN", "PASS")  # depends on failure_rate check too
        # success_rate check specifically should be WARN
        sr_check = next(c for c in result.checks if c["name"] == "success_rate")
        assert sr_check["status"] == "WARN"

    def test_high_cost_fails(self):
        """avg_cost=$3.00 > $2.00 threshold => FAIL."""
        result = evaluate_against_config(
            _report(total=10, success=10, failed=0, avg_match=0.90, avg_cost=3.00)
        )
        assert result.verdict == "FAIL"
        cost_check = next(c for c in result.checks if c["name"] == "avg_cost_per_query")
        assert cost_check["status"] == "FAIL"

    def test_result_checks_contain_all_four_dimensions(self):
        result = evaluate_against_config(_report())
        check_names = {c["name"] for c in result.checks}
        assert check_names == {
            "success_rate", "avg_match_score", "failure_rate", "avg_cost_per_query"
        }

    def test_to_markdown_contains_verdict(self):
        result = evaluate_against_config(_report())
        md = result.to_markdown()
        assert result.verdict in md
        assert result.run_id  in md

    def test_zero_total_queries_does_not_raise(self):
        """Edge case: empty report should not raise."""
        result = evaluate_against_config(_report(total=0, success=0, failed=0))
        assert result.verdict in ("PASS", "WARN", "FAIL")

    def test_custom_config_applied(self):
        """Stricter config: min_success_rate=0.99 => FAIL on 90%."""
        cfg    = GateConfig(min_success_rate=0.99)
        result = evaluate_against_config(
            _report(total=10, success=9, failed=1, avg_match=0.90),
            config=cfg,
        )
        assert result.verdict == "FAIL"

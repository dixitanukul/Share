"""Tests for QuestionDecomposer (W9-25).

Covers:
  - Complexity scoring heuristics
  - Simple question passthrough
  - Heuristic decomposition (comparison, conditional, calculation)
  - LLM decomposition with mock client
  - Execution group ordering (topological sort)
  - Edge cases (empty, very long, malformed LLM output)
  - Integration with AgentController._maybe_decompose()
"""
import json
import pytest
from unittest.mock import MagicMock

from platform.v4.core.question_decomposer import QuestionDecomposer
from platform.v4.contracts.decomposition_types import (
    ComplexityLevel,
    DecompositionPlan,
    SubQuestion,
    SubQuestionType,
)


# ── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def decomposer_no_llm():
    """Decomposer without LLM — heuristic only."""
    return QuestionDecomposer(llm_client=None)


@pytest.fixture
def mock_llm():
    """Mock LLM client that returns structured decomposition."""
    client = MagicMock()
    return client


@pytest.fixture
def decomposer_with_llm(mock_llm):
    """Decomposer with mock LLM."""
    return QuestionDecomposer(llm_client=mock_llm)


# ── Complexity Scoring ──────────────────────────────────────────────────────

class TestComplexityScoring:
    """Test the heuristic complexity scoring."""

    def test_simple_question_scores_low(self, decomposer_no_llm):
        score, signals = decomposer_no_llm._complexity_score(
            "What is the inpatient rate for Sutter Roseville?"
        )
        assert score < 3
        assert decomposer_no_llm.is_complex(
            "What is the inpatient rate for Sutter Roseville?"
        ) is False

    def test_comparison_scores_high(self, decomposer_no_llm):
        score, signals = decomposer_no_llm._complexity_score(
            "Compare the termination provisions between Providence Health and Dignity Health."
        )
        assert score >= 3
        assert any("multi_provider" in s for s in signals)

    def test_conditional_scores_high(self, decomposer_no_llm):
        score, signals = decomposer_no_llm._complexity_score(
            "For providers that have capitation arrangements, what is the average offset rate?"
        )
        assert score >= 3
        assert any("conditional" in s for s in signals)

    def test_calculation_scores_high(self, decomposer_no_llm):
        score, signals = decomposer_no_llm._complexity_score(
            "What is the percentage difference between inpatient rates across all providers?"
        )
        assert score >= 3
        assert any("calculation" in s for s in signals)

    def test_multi_provider_detection(self, decomposer_no_llm):
        score, signals = decomposer_no_llm._complexity_score(
            "Compare Sharp Memorial and Stanford Health Care termination clauses."
        )
        assert any("multi_provider" in s for s in signals)

    def test_keywords_contribute_to_score(self, decomposer_no_llm):
        score, signals = decomposer_no_llm._complexity_score(
            "Calculate the ratio and compare the difference across all network providers."
        )
        assert any("keywords" in s for s in signals)

    def test_long_question_bonus(self, decomposer_no_llm):
        long_q = " ".join(["word"] * 30)
        score, signals = decomposer_no_llm._complexity_score(long_q)
        assert any("long" in s for s in signals)

    def test_empty_question_scores_zero(self, decomposer_no_llm):
        score, signals = decomposer_no_llm._complexity_score("")
        assert score == 0
        assert signals == []


# ── Simple Question Passthrough ────────────────────────────────────────────

class TestSimplePassthrough:
    """Simple questions should return is_simple=True, no sub-questions."""

    def test_simple_rate_question(self, decomposer_no_llm):
        plan = decomposer_no_llm.analyze(
            "What is the inpatient per diem rate for Chinese Hospital?"
        )
        assert plan.is_simple is True
        assert plan.complexity == ComplexityLevel.SIMPLE
        assert plan.sub_questions == []
        assert plan.execution_groups == []

    def test_simple_clause_question(self, decomposer_no_llm):
        plan = decomposer_no_llm.analyze(
            "Does Palomar Health have an offset clause?"
        )
        assert plan.is_simple is True

    def test_simple_count_question(self, decomposer_no_llm):
        plan = decomposer_no_llm.analyze(
            "How many providers are in the network?"
        )
        assert plan.is_simple is True


# ── Heuristic Decomposition ────────────────────────────────────────────────

class TestHeuristicDecomposition:
    """Decomposition without LLM (heuristic patterns)."""

    def test_comparison_decomposition(self, decomposer_no_llm):
        plan = decomposer_no_llm.analyze(
            "Compare the termination provisions between Sharp Memorial and Stanford Health Care."
        )
        assert plan.is_simple is False
        assert plan.complexity in (ComplexityLevel.MODERATE, ComplexityLevel.COMPLEX)
        assert len(plan.sub_questions) >= 2
        # Should have parallel group for the two providers
        assert len(plan.execution_groups) >= 2
        # First group should have independent lookups
        assert len(plan.execution_groups[0]) >= 1

    def test_conditional_decomposition(self, decomposer_no_llm):
        plan = decomposer_no_llm.analyze(
            "For providers that have more than 10 amendments, what is the average inpatient rate?"
        )
        assert plan.is_simple is False
        assert len(plan.sub_questions) >= 2
        # Should have sequential dependency
        has_dep = any(sq.depends_on for sq in plan.sub_questions)
        assert has_dep

    def test_calculation_decomposition(self, decomposer_no_llm):
        plan = decomposer_no_llm.analyze(
            "What is the rate difference between inpatient and outpatient per diem for Sutter Roseville?"
        )
        assert plan.is_simple is False
        # Should have retrieval steps + calculation step
        types = {sq.sub_type for sq in plan.sub_questions}
        assert SubQuestionType.CALCULATION in types or SubQuestionType.SQL_QUERY in types

    def test_decomposition_has_execution_groups(self, decomposer_no_llm):
        plan = decomposer_no_llm.analyze(
            "Compare rates for Sharp Memorial and also check their offset clause status."
        )
        assert plan.is_simple is False
        assert len(plan.execution_groups) >= 1
        # All sub-question IDs appear in exactly one group
        all_ids = {sq.id for sq in plan.sub_questions}
        grouped_ids = set()
        for g in plan.execution_groups:
            for id_ in g:
                assert id_ not in grouped_ids, f"ID {id_} in multiple groups"
                grouped_ids.add(id_)
        assert grouped_ids == all_ids


# ── LLM Decomposition ──────────────────────────────────────────────────────

class TestLLMDecomposition:
    """Decomposition with mock LLM client."""

    def test_valid_llm_response(self, decomposer_with_llm, mock_llm):
        mock_llm.chat.return_value = json.dumps({
            "complexity": "MODERATE",
            "reasoning": "This requires comparing two providers.",
            "sub_questions": [
                {
                    "id": 1,
                    "question": "Get Sharp Memorial rates",
                    "type": "SQL_QUERY",
                    "depends_on": [],
                    "suggested_tools": ["sql_query"],
                    "provider_hint": "Sharp Memorial",
                },
                {
                    "id": 2,
                    "question": "Get Stanford rates",
                    "type": "SQL_QUERY",
                    "depends_on": [],
                    "suggested_tools": ["sql_query"],
                    "provider_hint": "Stanford Health Care",
                },
                {
                    "id": 3,
                    "question": "Compare results",
                    "type": "SYNTHESIS",
                    "depends_on": [1, 2],
                    "suggested_tools": ["summarize"],
                    "provider_hint": None,
                },
            ],
            "synthesis_prompt": "Compare rates side by side.",
        })

        plan = decomposer_with_llm.analyze(
            "Compare the inpatient rates between Sharp Memorial and Stanford Health Care."
        )
        assert plan.is_simple is False
        assert plan.complexity == ComplexityLevel.MODERATE
        assert len(plan.sub_questions) == 3
        assert plan.execution_groups == [[1, 2], [3]]
        assert plan.sub_questions[0].provider_hint == "Sharp Memorial"
        assert plan.sub_questions[2].depends_on == [1, 2]

    def test_llm_returns_malformed_json_fallback(self, decomposer_with_llm, mock_llm):
        mock_llm.chat.return_value = "This is not valid JSON at all."

        plan = decomposer_with_llm.analyze(
            "Compare the rates for Sharp Memorial and Stanford Health Care."
        )
        # Should fall back to heuristic
        assert plan.is_simple is False  # Still complex by heuristic
        assert len(plan.sub_questions) >= 2

    def test_llm_raises_exception_fallback(self, decomposer_with_llm, mock_llm):
        mock_llm.chat.side_effect = RuntimeError("LLM timeout")

        plan = decomposer_with_llm.analyze(
            "Compare the termination between Sharp Memorial and Stanford Health Care."
        )
        # Should fall back to heuristic
        assert plan.is_simple is False
        assert len(plan.sub_questions) >= 2

    def test_llm_returns_too_many_subquestions_fallback(self, decomposer_with_llm, mock_llm):
        mock_llm.chat.return_value = json.dumps({
            "complexity": "COMPLEX",
            "reasoning": "Very complex",
            "sub_questions": [
                {"id": i, "question": f"Q{i}", "type": "RETRIEVAL", "depends_on": [], "suggested_tools": []}
                for i in range(1, 10)  # 9 sub-questions > 6 limit
            ],
            "synthesis_prompt": "Merge.",
        })

        plan = decomposer_with_llm.analyze(
            "Compare the rates between Sharp Memorial and Stanford Health Care."
        )
        # Should fall back to heuristic due to > 6 sub-questions
        assert len(plan.sub_questions) <= 6


# ── Execution Groups (Topological Sort) ───────────────────────────────────

class TestExecutionGroups:
    """Test topological sort into parallel execution groups."""

    def test_all_independent(self):
        subs = [
            SubQuestion(id=1, question="Q1", sub_type=SubQuestionType.RETRIEVAL),
            SubQuestion(id=2, question="Q2", sub_type=SubQuestionType.RETRIEVAL),
            SubQuestion(id=3, question="Q3", sub_type=SubQuestionType.RETRIEVAL),
        ]
        groups = QuestionDecomposer._build_execution_groups(subs)
        # All independent → single group
        assert groups == [[1, 2, 3]]

    def test_linear_chain(self):
        subs = [
            SubQuestion(id=1, question="Q1", sub_type=SubQuestionType.SQL_QUERY),
            SubQuestion(id=2, question="Q2", sub_type=SubQuestionType.CALCULATION, depends_on=[1]),
            SubQuestion(id=3, question="Q3", sub_type=SubQuestionType.SYNTHESIS, depends_on=[2]),
        ]
        groups = QuestionDecomposer._build_execution_groups(subs)
        assert groups == [[1], [2], [3]]

    def test_diamond_dependency(self):
        subs = [
            SubQuestion(id=1, question="Q1", sub_type=SubQuestionType.RETRIEVAL),
            SubQuestion(id=2, question="Q2", sub_type=SubQuestionType.RETRIEVAL),
            SubQuestion(id=3, question="Q3", sub_type=SubQuestionType.COMPARISON, depends_on=[1, 2]),
            SubQuestion(id=4, question="Q4", sub_type=SubQuestionType.SYNTHESIS, depends_on=[3]),
        ]
        groups = QuestionDecomposer._build_execution_groups(subs)
        assert groups == [[1, 2], [3], [4]]

    def test_partial_parallelism(self):
        subs = [
            SubQuestion(id=1, question="Q1", sub_type=SubQuestionType.LOOKUP),
            SubQuestion(id=2, question="Q2", sub_type=SubQuestionType.SQL_QUERY, depends_on=[1]),
            SubQuestion(id=3, question="Q3", sub_type=SubQuestionType.RETRIEVAL),
            SubQuestion(id=4, question="Q4", sub_type=SubQuestionType.SYNTHESIS, depends_on=[2, 3]),
        ]
        groups = QuestionDecomposer._build_execution_groups(subs)
        assert groups == [[1, 3], [2], [4]]

    def test_empty_list(self):
        groups = QuestionDecomposer._build_execution_groups([])
        assert groups == []

    def test_single_item(self):
        subs = [SubQuestion(id=1, question="Q1", sub_type=SubQuestionType.RETRIEVAL)]
        groups = QuestionDecomposer._build_execution_groups(subs)
        assert groups == [[1]]


# ── DecompositionPlan Properties ───────────────────────────────────────────

class TestDecompositionPlan:
    """Test DecompositionPlan dataclass methods."""

    def test_to_log_dict(self):
        plan = DecompositionPlan(
            is_simple=False,
            complexity=ComplexityLevel.MODERATE,
            original_question="Compare X and Y",
            sub_questions=[
                SubQuestion(id=1, question="Q1", sub_type=SubQuestionType.RETRIEVAL),
                SubQuestion(id=2, question="Q2", sub_type=SubQuestionType.RETRIEVAL),
                SubQuestion(id=3, question="Q3", sub_type=SubQuestionType.SYNTHESIS, depends_on=[1, 2]),
            ],
            execution_groups=[[1, 2], [3]],
            reasoning="Test reasoning",
        )
        log = plan.to_log_dict()
        assert log["is_simple"] is False
        assert log["complexity"] == "MODERATE"
        assert log["sub_questions"] == 3
        assert log["execution_groups"] == 2
        assert log["max_parallelism"] == 2

    def test_get_group(self):
        subs = [
            SubQuestion(id=1, question="Q1", sub_type=SubQuestionType.RETRIEVAL),
            SubQuestion(id=2, question="Q2", sub_type=SubQuestionType.RETRIEVAL),
            SubQuestion(id=3, question="Q3", sub_type=SubQuestionType.SYNTHESIS, depends_on=[1, 2]),
        ]
        plan = DecompositionPlan(
            is_simple=False,
            sub_questions=subs,
            execution_groups=[[1, 2], [3]],
        )
        group_0 = plan.get_group(0)
        assert len(group_0) == 2
        assert group_0[0].id == 1
        assert group_0[1].id == 2

        group_1 = plan.get_group(1)
        assert len(group_1) == 1
        assert group_1[0].id == 3

        # Out of bounds
        assert plan.get_group(5) == []

    def test_simple_plan_properties(self):
        plan = DecompositionPlan(is_simple=True)
        assert plan.total_sub_questions == 0
        assert plan.max_parallelism == 0


# ── Integration with AgentController ───────────────────────────────────────

class TestAgentControllerIntegration:
    """Test that AgentController properly uses the decomposer."""

    def test_simple_question_uses_normal_react(self):
        from platform.v4.core.agent_controller import AgentController
        from platform.v4.tools.registry import ToolRegistry
        from platform.v4.contracts.agent_types import AgentRequest

        registry = ToolRegistry()
        controller = AgentController(registry=registry, llm_client=None)

        # Simple question → should use normal ReAct (stub SYNTHESIZE)
        response = controller.run(
            AgentRequest(question="What is the rate for Chinese Hospital?")
        )
        assert response.answer  # Got an answer (stub)
        assert response.is_complete

    def test_complex_question_triggers_decomposition(self):
        from platform.v4.core.agent_controller import AgentController
        from platform.v4.tools.registry import ToolRegistry
        from platform.v4.contracts.agent_types import AgentRequest

        registry = ToolRegistry()
        controller = AgentController(registry=registry, llm_client=None)

        # Complex question → should trigger decomposition
        response = controller.run(
            AgentRequest(
                question="Compare the termination provisions between Sharp Memorial and Stanford Health Care and also calculate the rate difference."
            )
        )
        assert response.answer  # Got an answer
        # With no LLM, it uses heuristic decomposition then stub sub-runs

    def test_decomposer_exception_is_non_fatal(self):
        from platform.v4.core.agent_controller import AgentController
        from platform.v4.tools.registry import ToolRegistry
        from platform.v4.contracts.agent_types import AgentRequest

        # Inject a decomposer that always raises
        broken_decomposer = MagicMock()
        broken_decomposer.analyze.side_effect = RuntimeError("Decomposer crash")

        registry = ToolRegistry()
        controller = AgentController(
            registry=registry,
            llm_client=None,
            decomposer=broken_decomposer,
        )

        # Should fall back to normal ReAct, not crash
        response = controller.run(
            AgentRequest(question="Compare X and Y.")
        )
        assert response.answer
        assert response.is_complete

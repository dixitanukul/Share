"""
Tests for W9-22: Session persistence (SessionRepo + ContextManager.resume_session).

Covers:
  - SessionRecord serialization (as_row with resolved_entities_json)
  - SessionRepo.load_session / session_exists / purge_expired
  - ContextManager.resume_session (history reconstruction + coreference)
  - serialize_entities / _deserialize_entities roundtrip
"""
import json
import time
import sys

import pytest

sys.path.insert(0, "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline")

from platform.v4.data.session_repo import SessionRepo, SessionRecord, SESSION_TTL_DAYS
from platform.v4.core.context_manager import ContextManager, DEFAULT_WINDOW_SIZE
from platform.v4.contracts.context_types import (
    SessionContext, ResolvedEntity, ConversationTurn,
)


# ─── Fixtures ────────────────────────────────────────────────────────────────

def _make_record(**overrides) -> SessionRecord:
    defaults = dict(
        session_id="sess-001",
        question="What is the offset clause for Cedars-Sinai?",
        answer="Cedars-Sinai has a standard offset clause.",
        confidence="HIGH",
        total_cost=1.50,
        execution_time_s=4.2,
        step_count=3,
        tool_calls=["sql_query", "passage_search"],
        citation_count=2,
        user_id="adixit01@blueshieldca.com",
        question_type="RETRIEVAL",
        resolved_entities_json=json.dumps([
            {
                "raw_mention": "Cedars-Sinai",
                "canonical_form": "Cedars-Sinai Medical Center",
                "entity_type": "provider",
                "provider_ids": ["cs001"],
                "confidence": 1.0,
                "resolution_method": "exact",
            }
        ]),
    )
    defaults.update(overrides)
    return SessionRecord(**defaults)


def _make_stored_rows(n: int = 3) -> list[dict]:
    """Simulate rows loaded from tbl_agent_sessions."""
    rows = []
    providers = [
        ("Cedars-Sinai Medical Center", "cs001"),
        ("Kaweah Delta", "kd002"),
        ("Lompoc Valley", "lv003"),
    ]
    for i in range(n):
        pname, pid = providers[i % len(providers)]
        rows.append({
            "session_id": "sess-resume-01",
            "question": f"Question {i+1} about {pname}",
            "answer": f"Answer about {pname} turn {i+1}",
            "confidence": "HIGH",
            "total_cost": 1.0 + i * 0.5,
            "execution_time_s": 3.0,
            "step_count": 2,
            "tool_calls": json.dumps(["passage_search"]),
            "citation_count": 1,
            "question_type": "RETRIEVAL",
            "error": None,
            "user_id": "test_user",
            "created_at": int((time.time() - (n - i) * 60) * 1000),
            "resolved_entities_json": json.dumps([{
                "raw_mention": pname,
                "canonical_form": pname,
                "entity_type": "provider",
                "provider_ids": [pid],
                "confidence": 1.0,
                "resolution_method": "exact",
            }]),
        })
    return rows


# ─── SessionRecord Tests ─────────────────────────────────────────────────────


class TestSessionRecord:
    def test_as_row_includes_resolved_entities_json(self):
        rec = _make_record()
        row = rec.as_row()
        assert "resolved_entities_json" in row
        parsed = json.loads(row["resolved_entities_json"])
        assert parsed[0]["canonical_form"] == "Cedars-Sinai Medical Center"

    def test_as_row_tool_calls_is_json_string(self):
        rec = _make_record()
        row = rec.as_row()
        assert isinstance(row["tool_calls"], str)
        assert json.loads(row["tool_calls"]) == ["sql_query", "passage_search"]

    def test_as_row_created_at_is_milliseconds(self):
        rec = _make_record(created_at=1000.0)
        row = rec.as_row()
        assert row["created_at"] == 1_000_000

    def test_as_row_none_entities(self):
        rec = _make_record(resolved_entities_json=None)
        row = rec.as_row()
        assert row["resolved_entities_json"] is None


# ─── SessionRepo Tests (in-memory mode) ──────────────────────────────────────


class TestSessionRepoInMemory:
    def test_save_without_spark_buffers(self):
        repo = SessionRepo(spark=None)
        rec = _make_record()
        assert repo.save(rec) is True
        assert len(repo._buffer) == 1

    def test_load_session_from_buffer(self):
        repo = SessionRepo(spark=None)
        repo.save(_make_record(session_id="a", question="Q1"))
        repo.save(_make_record(session_id="a", question="Q2"))
        repo.save(_make_record(session_id="b", question="Q3"))
        rows = repo.load_session("a")
        assert len(rows) == 2
        assert all(r["session_id"] == "a" for r in rows)

    def test_session_exists_true(self):
        repo = SessionRepo(spark=None)
        repo.save(_make_record(session_id="x"))
        assert repo.session_exists("x") is True

    def test_session_exists_false(self):
        repo = SessionRepo(spark=None)
        assert repo.session_exists("nonexistent") is False

    def test_purge_expired_no_spark_returns_zero(self):
        repo = SessionRepo(spark=None)
        repo.save(_make_record())
        assert repo.purge_expired() == 0

    def test_make_id_is_uuid(self):
        id1 = SessionRepo.make_id()
        id2 = SessionRepo.make_id()
        assert id1 != id2
        assert len(id1) == 36  # UUID format


# ─── ContextManager.resume_session Tests ─────────────────────────────────────


class TestResumeSession:
    def _make_manager(self) -> ContextManager:
        cm = ContextManager(spark=None, window_size=5)
        cm._provider_cache = [
            {"canonical_name": "Cedars-Sinai Medical Center", "provider_ids": ["cs001"], "all_names_used": ["cedars", "cedars-sinai"]},
            {"canonical_name": "Kaweah Delta", "provider_ids": ["kd002"], "all_names_used": ["kaweah"]},
            {"canonical_name": "Lompoc Valley", "provider_ids": ["lv003"], "all_names_used": ["lompoc"]},
        ]
        return cm

    def test_resume_rebuilds_history(self):
        cm = self._make_manager()
        rows = _make_stored_rows(3)
        ctx = cm.resume_session("sess-resume-01", "What about their rates?", rows)
        assert len(ctx.conversation_history) == 3
        assert ctx.turn_count == 4  # 3 prior + 1 new

    def test_resume_applies_window(self):
        cm = ContextManager(spark=None, window_size=2)
        cm._provider_cache = []
        rows = _make_stored_rows(3)
        ctx = cm.resume_session("s", "new q", rows)
        assert len(ctx.conversation_history) == 2  # window=2, trimmed from 3

    def test_resume_resolves_coreferences(self):
        cm = self._make_manager()
        # Last row has Lompoc Valley
        rows = _make_stored_rows(3)
        ctx = cm.resume_session("s", "What about their stop loss?", rows)
        # "their" should trigger coreference to last provider (Lompoc Valley)
        providers = ctx.get_providers()
        assert "Lompoc Valley" in providers

    def test_resume_empty_rows_creates_fresh_context(self):
        cm = self._make_manager()
        ctx = cm.resume_session("s", "Tell me about offset", [])
        assert len(ctx.conversation_history) == 0
        assert ctx.turn_count == 1
        # Should still extract concept from question
        assert "offset_clause" in ctx.get_concepts()

    def test_resume_extracts_concepts_from_new_question(self):
        cm = self._make_manager()
        rows = _make_stored_rows(1)
        ctx = cm.resume_session("s", "What is the capitation rate?", rows)
        assert "capitation" in ctx.get_concepts()

    def test_resume_deserialized_entities_have_correct_types(self):
        cm = self._make_manager()
        rows = _make_stored_rows(1)
        ctx = cm.resume_session("s", "new question", rows)
        turn = ctx.conversation_history[0]
        assert len(turn.resolved_entities) == 1
        entity = turn.resolved_entities[0]
        assert isinstance(entity, ResolvedEntity)
        assert entity.entity_type == "provider"


# ─── Serialize / Deserialize Roundtrip ────────────────────────────────────────


class TestEntitySerialization:
    def test_roundtrip(self):
        cm = ContextManager(spark=None)
        entities = [
            ResolvedEntity("Cedars", "Cedars-Sinai Medical Center", "provider", ["cs001"], 1.0, "exact"),
            ResolvedEntity("offset", "offset_clause", "concept", [], 0.9, "keyword_scan"),
        ]
        json_str = cm.serialize_entities(entities)
        restored = cm._deserialize_entities(json_str)
        assert len(restored) == 2
        assert restored[0].canonical_form == "Cedars-Sinai Medical Center"
        assert restored[1].entity_type == "concept"

    def test_deserialize_none_returns_empty(self):
        result = ContextManager._deserialize_entities(None)
        assert result == []

    def test_deserialize_empty_string_returns_empty(self):
        result = ContextManager._deserialize_entities("")
        assert result == []

    def test_deserialize_invalid_json_returns_empty(self):
        result = ContextManager._deserialize_entities("not json")
        assert result == []

    def test_serialize_empty_list(self):
        cm = ContextManager(spark=None)
        assert cm.serialize_entities([]) == "[]"

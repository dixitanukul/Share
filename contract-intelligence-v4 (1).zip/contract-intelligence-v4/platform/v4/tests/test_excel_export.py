"""Tests for platform/v4/presentation/excel_export.py (P5-RPT-3).

Covers:
  - ExcelExportService.export() produces .xlsx files for ClauseReport
  - ExcelExportService.export() produces .xlsx for StructuredExtractionReport
  - Shared utilities (_truncate, _split_paragraphs)
  - Route handler dispatch (all 8 routes are callable)
  - Error handling for missing/empty data
"""
import os
import tempfile
import pytest

from platform.v4.contracts.report_types import (
    ClauseReport, StructuredExtractionReport, ProviderReport, RateReport,
    TemporalReport, ComparisonReport, ExplanationReport, MultiConceptReport,
    ProviderFindingSummary, ProviderStatus, ClassifiedPassage,
    TaxonomyEntry, Polarity, ConfidenceScore, ConfidenceLabel,
    FieldDefinition, ExtractedValue, ExtractionConfidence,
    ProviderProfile, AmendmentEntry, RateEntry, ContractTerm,
)
from platform.v4.presentation.excel_export import ExcelExportService


# ============================================================
# FIXTURES
# ============================================================


def _make_clause_report():
    return ClauseReport(
        target_concept="offset clause",
        total_universe=4,
        provider_findings={
            "Provider A": ProviderFindingSummary(
                provider_name="Provider A", status=ProviderStatus.HAS_GRANT,
                categories={"OFFSET_GRANT": 2}),
            "Provider B": ProviderFindingSummary(
                provider_name="Provider B", status=ProviderStatus.HAS_DENIED,
                categories={"OFFSET_DENIED": 1}),
        },
        no_mention_providers={"Provider C", "Provider D"},
        classified_passages=[
            ClassifiedPassage(provider="Provider A", filename="f1.pdf",
                            category="OFFSET_GRANT", reasoning="Passage grants offset",
                            key_phrase="offset clause applies"),
            ClassifiedPassage(provider="Provider A", filename="f2.pdf",
                            category="OFFSET_GRANT", reasoning="Another grant",
                            key_phrase="recovery permitted"),
            ClassifiedPassage(provider="Provider B", filename="f3.pdf",
                            category="OFFSET_DENIED", is_denial=True,
                            reasoning="Denied", key_phrase="no offset"),
        ],
        taxonomy=[
            TaxonomyEntry(code="OFFSET_GRANT", label="Offset Grant", polarity=Polarity.GRANT),
            TaxonomyEntry(code="OFFSET_DENIED", label="Offset Denied",
                         polarity=Polarity.RESTRICT, is_denial=True),
        ],
        confidence_scores={
            "Provider A": ConfidenceScore(score=0.9, label=ConfidenceLabel.HIGH, doc_count=2),
            "Provider B": ConfidenceScore(score=0.5, label=ConfidenceLabel.MODERATE, doc_count=1),
        },
    )


def _make_extraction_report():
    return StructuredExtractionReport(
        field_definition=FieldDefinition(field_name="offset_start_date"),
        total_universe=3,
        provider_values={
            "P1": ExtractedValue(provider_name="P1", raw_value="2024-01-01",
                                display_value="Jan 1, 2024", confidence=ExtractionConfidence.HIGH),
            "P2": ExtractedValue(provider_name="P2", raw_value="2023-07-15",
                                display_value="Jul 15, 2023", confidence=ExtractionConfidence.MEDIUM),
        },
        no_data_providers=["P3"],
    )


def _make_provider_report():
    return ProviderReport(
        profile=ProviderProfile(provider_name="Sutter Health", total_rates=3),
        rates=[RateEntry(rate_category="Inpatient", rate_text="$500/day", rate_numeric=500.0)],
        terms=[ContractTerm(topic="Termination", content_text="90 days notice")],
        amendments=[AmendmentEntry(amendment_order=1, document_type="First Amendment",
                                  summary_of_changes="Rate increase 5%")],
    )


def _make_rate_report():
    return RateReport(
        query_type="rates",
        columns=["provider", "rate", "category"],
        rows=[{"provider": "Sutter", "rate": 500, "category": "Inpatient"}],
    )


def _make_temporal_report():
    return TemporalReport(
        provider_filter="Sutter Health",
        amendments=[AmendmentEntry(amendment_order=1, summary_of_changes="Rate increase")],
        llm_summary="Contract evolved over time.",
    )


def _make_comparison_report():
    return ComparisonReport(
        providers=["Sutter", "Kaiser"],
        comparison_data={"Sutter": {"rates": 5}, "Kaiser": {"rates": 3}},
        llm_summary="Sutter has higher rates.",
    )


def _make_explanation_report():
    return ExplanationReport(
        narrative="Offset clauses allow recovery of overpayments from future claims.",
        target_concept="offset clause",
        evidence_passages=[{"text": "passage 1", "source": "f1.pdf", "page": 5}],
    )


def _make_multi_concept_report():
    return MultiConceptReport(
        operator="INTERSECTION",
        concepts=["offset clause", "dofr"],
        result_set=["Provider A", "Provider B"],
        total_universe=10,
    )


# ============================================================
# EXPORT INTEGRATION TESTS
# ============================================================


class TestExcelExportClause:
    """Test ExcelExportService with ClauseReport."""

    def setup_method(self):
        self.service = ExcelExportService()
        self.tmpdir = tempfile.mkdtemp()

    def test_export_produces_xlsx(self):
        report = _make_clause_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Which providers have offset?",
            route="clause_existence",
            concept_label="offset clause",
        )
        assert path.endswith(".xlsx")
        assert os.path.exists(path)
        assert os.path.getsize(path) > 5000  # non-trivial size

    def test_export_filename_contains_concept(self):
        report = _make_clause_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Offset analysis",
            route="clause_existence",
            concept_label="offset clause",
        )
        fname = os.path.basename(path).lower()
        assert "offset" in fname

    def test_export_with_empty_findings(self):
        """Empty ClauseReport should still produce a valid xlsx."""
        report = ClauseReport(target_concept="test", total_universe=0)
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Test", route="clause_existence",
            concept_label="test",
        )
        assert os.path.exists(path)
        assert os.path.getsize(path) > 1000


class TestExcelExportExtraction:
    """Test ExcelExportService with StructuredExtractionReport."""

    def setup_method(self):
        self.service = ExcelExportService()
        self.tmpdir = tempfile.mkdtemp()

    def test_export_produces_xlsx(self):
        report = _make_extraction_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="What are the offset start dates?",
            route="structured_extraction",
            concept_label="offset_start_date",
        )
        assert path.endswith(".xlsx")
        assert os.path.exists(path)
        assert os.path.getsize(path) > 3000


class TestExcelExportOtherRoutes:
    """Test that all route handlers are callable without crashing."""

    def setup_method(self):
        self.service = ExcelExportService()
        self.tmpdir = tempfile.mkdtemp()

    def test_export_provider_report(self):
        report = _make_provider_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Sutter details", route="single_provider",
            concept_label="provider",
        )
        assert os.path.exists(path)

    def test_export_rate_report(self):
        report = _make_rate_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Rate query", route="rate_query",
            concept_label="rates",
        )
        assert os.path.exists(path)

    def test_export_temporal_report(self):
        report = _make_temporal_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="How has Sutter changed?", route="temporal",
            concept_label="temporal",
        )
        assert os.path.exists(path)

    def test_export_comparison_report(self):
        report = _make_comparison_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Compare Sutter vs Kaiser", route="comparison",
            concept_label="comparison",
        )
        assert os.path.exists(path)

    def test_export_explanation_report(self):
        report = _make_explanation_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Explain offset", route="explanation",
            concept_label="offset clause",
        )
        assert os.path.exists(path)

    def test_export_multi_concept_report(self):
        report = _make_multi_concept_report()
        path = self.service.export(
            report, output_dir=self.tmpdir,
            question="Which have both?", route="multi_concept",
            concept_label="multi_concept",
        )
        assert os.path.exists(path)

"""Tests for ExplanationTool (P4E)."""
from __future__ import annotations

from collections import OrderedDict
from unittest.mock import MagicMock
import pandas as pd
import pytest

from platform.v4.tools.explanation import ExplanationTool
from platform.v4.contracts.tool_types import Confidence, ToolStatus


# ── Mock helpers ─────────────────────────────────────────────────────────────

class MockDF:
    def __init__(self, pdf):
        self._pdf = pdf
    def toPandas(self):
        return self._pdf


class MockSpark:
    """Pattern: ordered-dict with most-specific SQL pattern first."""
    def __init__(self, patterns: "OrderedDict"):
        self._patterns = patterns

    def sql(self, query: str) -> MockDF:
        for pattern, pdf in self._patterns.items():
            if pattern in query:
                return MockDF(pdf)
        return MockDF(pd.DataFrame())


class MockProviderService:
    def __init__(self, names=None, resolution=None):
        self._names = names or ["Sutter Health", "Kaiser Permanente", "Providence Health"]
        self._resolution = resolution or {}

    def all_names(self):
        return self._names

    def resolve(self, name: str):
        if name in self._resolution:
            return self._resolution[name]
        return ([name], "unresolved", [])


class MockRetrievalService:
    def __init__(self, passages=None):
        self._passages = passages or []

    def retrieve(self, query, provider_name=None, top_k=30, current_only=True):
        return self._passages


class MockLLMClient:
    def __init__(self, response="Mock narrative about the provision."):
        self._response = response
        self.calls = []

    def chat(self, model, system, user, max_tokens, temperature=0.0):
        self.calls.append({"system": system, "user": user[:100]})
        return self._response


# ── Fixtures ─────────────────────────────────────────────────────────────────

def make_tool(patterns=None, passages=None, resolution=None, llm_response=None):
    spark = MockSpark(OrderedDict(patterns or {}))
    ps = MockProviderService(resolution=resolution or {})
    rs = MockRetrievalService(passages=passages or [])
    llm = MockLLMClient(response=llm_response or "Narrative text.") if llm_response is not None else None
    return ExplanationTool(spark=spark, provider_service=ps, retrieval_service=rs, llm_client=llm)


TERM_ROWS = pd.DataFrame({
    "provider_name": ["Sutter Health"] * 3,
    "title": ["Dispute Resolution", "Arbitration", "Mediation"],
    "topic": ["dispute"] * 3,
    "content_text": [
        "The parties shall submit disputes to binding arbitration under AAA rules.",
        "Arbitration shall occur in Sacramento County within 60 days of notice.",
        "Mediation is a prerequisite to arbitration for claims under $50,000.",
    ],
    "source_filename": ["sutter_v1.pdf", "sutter_v2.pdf", "sutter_v3.pdf"],
})


# ── Init ─────────────────────────────────────────────────────────────────────

class TestExplanationToolInit:
    def test_name(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        assert t.name == "explanation"

    def test_not_adapter_backed(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        assert t.is_adapter_backed is False

    def test_optional_deps_default_none(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        assert t._retrieval_service is None
        assert t._llm_client is None

    def test_stores_all_deps(self):
        rs = MockRetrievalService()
        llm = MockLLMClient()
        t = ExplanationTool(spark="sp", provider_service="ps", retrieval_service=rs, llm_client=llm)
        assert t._spark == "sp"
        assert t._provider_service == "ps"
        assert t._retrieval_service is rs
        assert t._llm_client is llm


# ── Validation ───────────────────────────────────────────────────────────────

class TestExplanationToolValidation:
    def test_requires_question(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        errors = t.validate_inputs()
        assert errors  # question missing

    def test_passes_with_question(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        errors = t.validate_inputs(question="Explain dispute resolution")
        assert errors == []


# ── Concept extraction ────────────────────────────────────────────────────────

class TestConceptExtraction:
    def setup_method(self):
        self.tool = ExplanationTool(spark=None, provider_service=MockProviderService())

    def test_explain_pattern(self):
        c = self.tool._extract_concept("Explain dispute resolution")
        assert c == "dispute resolution"

    def test_describe_pattern(self):
        # regex strips trailing 'clause' suffix so concept = core term
        c = self.tool._extract_concept("Describe the offset clause")
        assert c is not None and len(c) >= 3

    def test_how_does_pattern(self):
        c = self.tool._extract_concept("How does auto-renewal work")
        assert c == "auto-renewal"

    def test_what_is_pattern(self):
        c = self.tool._extract_concept("What is a termination for cause clause")
        assert "termination" in c

    def test_returns_none_for_unrecognised(self):
        c = self.tool._extract_concept("Which providers have offset clause?")
        assert c is None


# ── Provider extraction ───────────────────────────────────────────────────────

class TestProviderExtraction:
    def test_longest_match_wins(self):
        t = ExplanationTool(
            spark=None,
            provider_service=MockProviderService(names=["Sutter", "Sutter Health"]),
        )
        p = t._extract_provider("Explain Sutter Health's dispute resolution")
        assert p == "Sutter Health"

    def test_no_match_returns_none(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        p = t._extract_provider("Explain dispute resolution processes")
        assert p is None


# ── Fetch structured ──────────────────────────────────────────────────────────

class TestFetchStructured:
    def test_returns_passages(self):
        patterns = OrderedDict({"vw_genie_contract_terms": TERM_ROWS})
        t = ExplanationTool(spark=MockSpark(patterns), provider_service=MockProviderService())
        results = t._fetch_structured("arbitration", None, None, 10)
        assert len(results) == 3
        assert all(r["origin"] == "structured" for r in results)

    def test_uses_prov_filter_when_provided(self):
        captured = []

        class CaptureSpark:
            def sql(self, q):
                captured.append(q)
                return MockDF(TERM_ROWS)

        t = ExplanationTool(spark=CaptureSpark(), provider_service=MockProviderService())
        t._fetch_structured("dispute", "provider_id IN ('p1')", None, 10)
        assert "provider_id IN" in captured[0]

    def test_falls_back_to_name_like(self):
        captured = []

        class CaptureSpark:
            def sql(self, q):
                captured.append(q)
                return MockDF(TERM_ROWS)

        t = ExplanationTool(spark=CaptureSpark(), provider_service=MockProviderService())
        t._fetch_structured("dispute", None, "Sutter Health", 10)
        assert "LIKE" in captured[0]

    def test_exception_returns_empty(self):
        class BrokenSpark:
            def sql(self, q):
                raise RuntimeError("DB error")

        t = ExplanationTool(spark=BrokenSpark(), provider_service=MockProviderService())
        results = t._fetch_structured("dispute", None, None, 10)
        assert results == []


# ── Fetch semantic ────────────────────────────────────────────────────────────

class TestFetchSemantic:
    def test_returns_passages_from_retrieval_service(self):
        passages = [
            {"chunk_text": "Disputes are resolved via arbitration.", "provider_name": "Sutter Health", "source_filename": "s1.pdf"},
            {"chunk_text": "Arbitration rules apply per AAA standards.", "provider_name": "Sutter Health", "source_filename": "s2.pdf"},
        ]
        t = ExplanationTool(
            spark=None, provider_service=MockProviderService(),
            retrieval_service=MockRetrievalService(passages=passages)
        )
        results = t._fetch_semantic("dispute resolution", None, 10)
        assert len(results) == 2
        assert all(r["origin"] == "semantic" for r in results)

    def test_no_retrieval_service_returns_empty(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        results = t._fetch_semantic("dispute", None, 10)
        assert results == []

    def test_short_passages_filtered(self):
        passages = [{"chunk_text": "Short", "provider_name": "X", "source_filename": "x.pdf"}]
        t = ExplanationTool(
            spark=None, provider_service=MockProviderService(),
            retrieval_service=MockRetrievalService(passages=passages)
        )
        results = t._fetch_semantic("short", None, 10)
        assert results == []


# ── Merge ─────────────────────────────────────────────────────────────────────

class TestMerge:
    def setup_method(self):
        self.tool = ExplanationTool(spark=None, provider_service=MockProviderService())

    def test_deduplicates_by_source(self):
        a = [{"source": "s1.pdf", "text": "A"}, {"source": "s2.pdf", "text": "B"}]
        b = [{"source": "s1.pdf", "text": "A2"}, {"source": "s3.pdf", "text": "C"}]
        merged = self.tool._merge(a, b, 10)
        sources = [p["source"] for p in merged]
        assert sources == ["s1.pdf", "s2.pdf", "s3.pdf"]

    def test_respects_max_passages(self):
        passages = [{"source": f"f{i}.pdf", "text": "x"} for i in range(20)]
        merged = self.tool._merge(passages, [], 5)
        assert len(merged) == 5

    def test_empty_inputs(self):
        assert self.tool._merge([], [], 10) == []


# ── Synthesize ────────────────────────────────────────────────────────────────

class TestSynthesize:
    def test_calls_llm(self):
        llm = MockLLMClient("Comprehensive explanation text.")
        t = ExplanationTool(spark=None, provider_service=MockProviderService(), llm_client=llm)
        passages = [{"text": "Arbitration text", "source": "s.pdf", "provider": "Sutter Health"}]
        result = t._synthesize("dispute resolution", "Sutter Health", passages)
        assert result == "Comprehensive explanation text."
        assert len(llm.calls) == 1

    def test_no_llm_returns_empty(self):
        t = ExplanationTool(spark=None, provider_service=MockProviderService())
        result = t._synthesize("concept", None, [{"text": "x", "source": "s", "provider": "P"}])
        assert result == ""

    def test_prompt_includes_concept(self):
        llm = MockLLMClient("ok")
        t = ExplanationTool(spark=None, provider_service=MockProviderService(), llm_client=llm)
        t._synthesize("auto-renewal", None, [{"text": "x" * 50, "source": "s.pdf", "provider": "P"}])
        assert "auto-renewal" in llm.calls[0]["user"]


# ── Full _run ─────────────────────────────────────────────────────────────────

class TestExplanationToolRun:
    def test_no_evidence_returns_empty_status(self):
        t = make_tool(llm_response="")
        result = t._run("Explain dispute resolution", concept="dispute resolution")
        assert result.status == ToolStatus.EMPTY
        assert result.data["evidence_count"] == 0

    def test_with_passages_returns_success(self):
        passages = [
            {"chunk_text": "Disputes resolved via arbitration under AAA rules.",
             "provider_name": "Sutter Health", "source_filename": f"s{i}.pdf"}
            for i in range(12)
        ]
        t = make_tool(passages=passages, llm_response="High confidence narrative.")
        result = t._run("Explain dispute resolution", concept="dispute resolution")
        assert result.success
        assert result.status == ToolStatus.SUCCESS
        assert result.data["evidence_count"] == 12
        assert result.data["confidence_level"] == "high"
        assert result.confidence == Confidence.HIGH

    def test_moderate_confidence_5_to_9_passages(self):
        passages = [
            {"chunk_text": "Arbitration under AAA rules applies.",
             "provider_name": "Sutter", "source_filename": f"s{i}.pdf"}
            for i in range(7)
        ]
        t = make_tool(passages=passages, llm_response="Moderate text.")
        result = t._run("Explain arbitration", concept="arbitration")
        assert result.data["confidence_level"] == "moderate"
        assert result.confidence == Confidence.LOW  # Confidence enum has only HIGH/LOW

    def test_provider_resolution_uses_canonical(self):
        resolution = {"Sutter": (["Sutter Health System"], "canonical_exact", ["p001"])}
        patterns = OrderedDict({"vw_genie_contract_terms": TERM_ROWS})
        spark = MockSpark(patterns)
        ps = MockProviderService(names=["Sutter", "Sutter Health System"], resolution=resolution)
        t = ExplanationTool(spark=spark, provider_service=ps, llm_client=MockLLMClient("ok"))
        result = t._run("Explain Sutter dispute resolution", concept="dispute resolution")
        assert result.data["provider_filter"] == "Sutter Health System"

    def test_default_concept_fallback(self):
        t = make_tool(llm_response="")
        result = t._run("Tell me about provider contracts")
        assert result.data["concept"] == "contract provision"

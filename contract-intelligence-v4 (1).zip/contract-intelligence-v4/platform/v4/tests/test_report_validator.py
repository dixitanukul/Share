"""Tests for platform/v4/presentation/report_validator.py (P5-RPT-5).

Covers:
  - ReportValidator.validate() for all 8 report types
  - Severity escalation (PASS → WARN → BLOCK)
  - ValidationResult properties and formatting
  - assert_pass() exception behavior
  - Edge cases: empty reports, missing fields, boundary conditions
"""
import pytest

from platform.v4.contracts.report_types import (
    ClauseReport, StructuredExtractionReport, ProviderReport, RateReport,
    TemporalReport, ComparisonReport, ExplanationReport, MultiConceptReport,
    ProviderFindingSummary, ProviderStatus, ClassifiedPassage,
    TaxonomyEntry, Polarity, ConfidenceScore, ConfidenceLabel,
    FieldDefinition, ExtractedValue, ExtractionConfidence,
    ProviderProfile, AmendmentEntry,
)
from platform.v4.presentation.report_validator import (
    ReportValidator, ValidationResult, Finding, Severity,
)


# ============================================================
# FIXTURES / HELPERS
# ============================================================


def _make_valid_clause_report(total_universe=5, n_has=2, n_denied=1, n_no_mention=2):
    """Build a minimal valid ClauseReport that passes all checks."""
    findings_map = {}
    passages = []
    taxonomy = [
        TaxonomyEntry(code="CODE_A", label="Grant A", polarity=Polarity.GRANT),
        TaxonomyEntry(code="CODE_B", label="Grant B", polarity=Polarity.GRANT),
        TaxonomyEntry(code="CODE_DENY", label="Restriction", polarity=Polarity.RESTRICT, is_denial=True),
    ]

    for i in range(n_has):
        name = f"Provider_HAS_{i}"
        findings_map[name] = ProviderFindingSummary(
            provider_name=name, status=ProviderStatus.HAS_GRANT,
            categories={"CODE_A": 1}, findings=[],
        )
        passages.append(ClassifiedPassage(
            provider=name, filename=f"f{i}.pdf", category="CODE_A",
            reasoning="found it", key_phrase="clause text",
        ))

    for i in range(n_denied):
        name = f"Provider_DENIED_{i}"
        findings_map[name] = ProviderFindingSummary(
            provider_name=name, status=ProviderStatus.HAS_DENIED,
            categories={"CODE_DENY": 1}, findings=[],
        )
        passages.append(ClassifiedPassage(
            provider=name, filename=f"d{i}.pdf", category="CODE_DENY",
            is_denial=True, reasoning="denied", key_phrase="no clause",
        ))

    no_mention = {f"Provider_NM_{i}" for i in range(n_no_mention)}

    confidence = {
        name: ConfidenceScore(score=0.8, label=ConfidenceLabel.HIGH, doc_count=2)
        for name in findings_map
    }

    return ClauseReport(
        target_concept="test concept",
        total_universe=total_universe,
        provider_findings=findings_map,
        no_mention_providers=no_mention,
        classified_passages=passages,
        taxonomy=taxonomy,
        confidence_scores=confidence,
    )


def _make_valid_extraction_report(total=4, extracted=2, no_data=2):
    """Build a minimal valid StructuredExtractionReport."""
    values = {}
    for i in range(extracted):
        name = f"Provider_{i}"
        values[name] = ExtractedValue(
            provider_name=name, raw_value=f"val_{i}",
            display_value=f"Value {i}", confidence=ExtractionConfidence.HIGH,
        )
    return StructuredExtractionReport(
        field_definition=FieldDefinition(field_name="test_field"),
        total_universe=total,
        provider_values=values,
        no_data_providers=[f"NoData_{i}" for i in range(no_data)],
    )


# ============================================================
# ValidationResult TESTS
# ============================================================


class TestValidationResult:
    def test_empty_findings_is_pass(self):
        vr = ValidationResult(report_type="Test", findings=[])
        assert vr.verdict == "PASS"
        assert vr.passed is True
        assert vr.blocking is False
        assert vr.n_block == 0
        assert vr.n_warn == 0
        assert vr.n_pass == 0

    def test_warn_verdict(self):
        vr = ValidationResult(report_type="Test", findings=[
            Finding(Severity.PASS, "check1", "ok"),
            Finding(Severity.WARN, "check2", "maybe"),
        ])
        assert vr.verdict == "WARN"
        assert vr.passed is False
        assert vr.blocking is False

    def test_block_verdict(self):
        vr = ValidationResult(report_type="Test", findings=[
            Finding(Severity.PASS, "check1", "ok"),
            Finding(Severity.BLOCK, "check2", "bad"),
            Finding(Severity.WARN, "check3", "meh"),
        ])
        assert vr.verdict == "BLOCK"
        assert vr.blocking is True
        assert vr.n_block == 1
        assert vr.n_warn == 1
        assert vr.n_pass == 1

    def test_summary_line(self):
        vr = ValidationResult(report_type="Test", findings=[
            Finding(Severity.BLOCK, "c1", "d1"),
            Finding(Severity.WARN, "c2", "d2"),
            Finding(Severity.PASS, "c3", "d3"),
        ])
        assert "1 block" in vr.summary_line()
        assert "1 warn" in vr.summary_line()
        assert "1 pass" in vr.summary_line()

    def test_format_text_contains_all_findings(self):
        vr = ValidationResult(report_type="ClauseReport", findings=[
            Finding(Severity.PASS, "Check A", "detail A"),
            Finding(Severity.WARN, "Check B", "detail B"),
        ])
        text = vr.format_text()
        assert "ClauseReport" in text
        assert "Check A" in text
        assert "Check B" in text


class TestFinding:
    def test_icon_pass(self):
        f = Finding(Severity.PASS, "test", "ok")
        assert "\u2705" in f.icon or "✅" in f.icon

    def test_icon_block(self):
        f = Finding(Severity.BLOCK, "test", "bad")
        assert "\u26d4" in f.icon or "⛔" in f.icon


# ============================================================
# ClauseReport VALIDATION
# ============================================================


class TestValidateClauseReport:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = _make_valid_clause_report()
        result = self.validator.validate(report)
        assert result.passed, f"Expected PASS: {result.format_text()}"
        assert result.n_block == 0

    def test_universe_mismatch_blocks(self):
        report = _make_valid_clause_report(total_universe=100)
        result = self.validator.validate(report)
        assert result.blocking
        block_findings = [f for f in result.findings if f.severity == Severity.BLOCK]
        assert any("Universe count parity" in f.check for f in block_findings)

    def test_universe_zero_warns(self):
        report = _make_valid_clause_report(total_universe=0)
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Universe count parity" in f.check for f in warn_findings)

    def test_missing_target_concept_blocks(self):
        report = _make_valid_clause_report()
        report.target_concept = ""
        result = self.validator.validate(report)
        assert result.blocking
        assert any("Required fields" in f.check for f in result.findings
                   if f.severity == Severity.BLOCK)

    def test_empty_findings_and_no_mention_blocks(self):
        report = ClauseReport(
            target_concept="test",
            total_universe=0,
            provider_findings={},
            no_mention_providers=set(),
        )
        result = self.validator.validate(report)
        assert result.blocking

    def test_unknown_category_warns(self):
        report = _make_valid_clause_report()
        # Add passage with unknown category
        report.classified_passages.append(ClassifiedPassage(
            provider="Provider_HAS_0", filename="x.pdf",
            category="TOTALLY_UNKNOWN", reasoning="hmm", key_phrase="what",
        ))
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Category completeness" in f.check for f in warn_findings)

    def test_no_taxonomy_warns(self):
        report = _make_valid_clause_report()
        report.taxonomy = []
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Category completeness" in f.check for f in warn_findings)

    def test_all_low_confidence_warns(self):
        report = _make_valid_clause_report()
        report.confidence_scores = {
            name: ConfidenceScore(score=0.2, label=ConfidenceLabel.LOW)
            for name in report.provider_findings
        }
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Confidence distribution" in f.check for f in warn_findings)

    def test_no_confidence_scores_warns(self):
        report = _make_valid_clause_report()
        report.confidence_scores = {}
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Confidence distribution" in f.check for f in warn_findings)

    def test_orphan_passage_provider_warns(self):
        report = _make_valid_clause_report()
        # Add passage for unknown provider
        report.classified_passages.append(ClassifiedPassage(
            provider="GHOST_PROVIDER", filename="ghost.pdf",
            category="CODE_A", reasoning="phantom", key_phrase="boo",
        ))
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Cross-sheet consistency" in f.check for f in warn_findings)

    def test_false_mixed_blocks(self):
        """MIXED provider with only ABSENT-category denials should BLOCK."""
        report = ClauseReport(
            target_concept="dofr",
            total_universe=2,
            provider_findings={
                "Good": ProviderFindingSummary(
                    provider_name="Good", status=ProviderStatus.HAS_GRANT),
                "FalseMixed": ProviderFindingSummary(
                    provider_name="FalseMixed", status=ProviderStatus.MIXED),
            },
            no_mention_providers=set(),
            classified_passages=[
                ClassifiedPassage(provider="Good", filename="g.pdf",
                                  category="REAL_GRANT", reasoning="r", key_phrase="k"),
                ClassifiedPassage(provider="FalseMixed", filename="f.pdf",
                                  category="REAL_GRANT", reasoning="r", key_phrase="k"),
                ClassifiedPassage(provider="FalseMixed", filename="f2.pdf",
                                  category="ABSENCE_CODE", is_denial=True,
                                  reasoning="r", key_phrase="k"),
            ],
            taxonomy=[
                TaxonomyEntry(code="REAL_GRANT", label="Grant", polarity=Polarity.GRANT),
                TaxonomyEntry(code="ABSENCE_CODE", label="Absent", polarity=Polarity.ABSENT),
            ],
        )
        result = self.validator.validate(report)
        assert result.blocking
        block_findings = [f for f in result.findings if f.severity == Severity.BLOCK]
        assert any("Polarity sanity" in f.check for f in block_findings)

    def test_genuine_mixed_passes(self):
        """MIXED with genuine RESTRICT denial should pass polarity check."""
        report = ClauseReport(
            target_concept="offset",
            total_universe=2,
            provider_findings={
                "Good": ProviderFindingSummary(
                    provider_name="Good", status=ProviderStatus.HAS_GRANT),
                "TrueMixed": ProviderFindingSummary(
                    provider_name="TrueMixed", status=ProviderStatus.MIXED),
            },
            no_mention_providers=set(),
            classified_passages=[
                ClassifiedPassage(provider="Good", filename="g.pdf",
                                  category="OFFSET_GRANT", reasoning="r", key_phrase="k"),
                ClassifiedPassage(provider="TrueMixed", filename="m1.pdf",
                                  category="OFFSET_GRANT", reasoning="r", key_phrase="k"),
                ClassifiedPassage(provider="TrueMixed", filename="m2.pdf",
                                  category="OFFSET_RESTRICT", is_denial=True,
                                  reasoning="r", key_phrase="k"),
            ],
            taxonomy=[
                TaxonomyEntry(code="OFFSET_GRANT", label="Grant", polarity=Polarity.GRANT),
                TaxonomyEntry(code="OFFSET_RESTRICT", label="Restrict",
                              polarity=Polarity.RESTRICT, is_denial=True),
            ],
            confidence_scores={
                "Good": ConfidenceScore(score=0.8, label=ConfidenceLabel.HIGH),
                "TrueMixed": ConfidenceScore(score=0.6, label=ConfidenceLabel.MODERATE),
            },
        )
        result = self.validator.validate(report)
        polarity_findings = [f for f in result.findings if "Polarity" in f.check]
        assert all(f.severity == Severity.PASS for f in polarity_findings)

    def test_template_hygiene_offset_in_non_offset_warns(self):
        report = _make_valid_clause_report()
        report.target_concept = "auto renewal"  # NOT offset
        report.offset_extraction = _make_valid_extraction_report()
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Template hygiene" in f.check for f in warn_findings)

    def test_template_hygiene_offset_in_offset_passes(self):
        report = _make_valid_clause_report()
        report.target_concept = "offset clause"
        report.offset_extraction = _make_valid_extraction_report()
        result = self.validator.validate(report)
        hygiene = [f for f in result.findings if "Template hygiene" in f.check]
        assert all(f.severity == Severity.PASS for f in hygiene)

    def test_blank_reasoning_warns(self):
        report = _make_valid_clause_report()
        # Clear reasoning on a relevant passage
        report.classified_passages[0].reasoning = ""
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Findings completeness" in f.check for f in warn_findings)


# ============================================================
# StructuredExtractionReport VALIDATION
# ============================================================


class TestValidateStructuredExtraction:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = _make_valid_extraction_report()
        result = self.validator.validate(report)
        assert result.passed

    def test_universe_mismatch_blocks(self):
        report = _make_valid_extraction_report(total=10, extracted=2, no_data=2)
        result = self.validator.validate(report)
        assert result.blocking
        assert any("Universe parity" in f.check for f in result.findings
                   if f.severity == Severity.BLOCK)

    def test_empty_field_name_blocks(self):
        report = _make_valid_extraction_report()
        report.field_definition = FieldDefinition(field_name="")
        result = self.validator.validate(report)
        assert result.blocking

    def test_all_low_confidence_warns(self):
        report = _make_valid_extraction_report()
        for v in report.provider_values.values():
            v.confidence = ExtractionConfidence.LOW
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Confidence" in f.check for f in warn_findings)

    def test_null_values_warns(self):
        report = _make_valid_extraction_report()
        for v in report.provider_values.values():
            v.raw_value = ""
            v.display_value = ""
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Value consistency" in f.check for f in warn_findings)

    def test_zero_universe_warns(self):
        report = _make_valid_extraction_report(total=0, extracted=2, no_data=2)
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Universe parity" in f.check for f in warn_findings)


# ============================================================
# ProviderReport VALIDATION
# ============================================================


class TestValidateProviderReport:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = ProviderReport(
            profile=ProviderProfile(provider_name="Sutter Health", total_rates=5),
            rates=[],
            terms=[],
            amendments=[AmendmentEntry(amendment_order=1, document_type="amendment")],
        )
        result = self.validator.validate(report)
        assert result.passed

    def test_empty_provider_name_blocks(self):
        report = ProviderReport(
            profile=ProviderProfile(provider_name=""),
        )
        result = self.validator.validate(report)
        assert result.blocking

    def test_empty_data_warns(self):
        report = ProviderReport(
            profile=ProviderProfile(provider_name="Sutter"),
            rates=[], terms=[], amendments=[],
        )
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert any("Structural integrity" in f.check for f in warn_findings)


# ============================================================
# RateReport VALIDATION
# ============================================================


class TestValidateRateReport:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = RateReport(
            query_type="rates",
            columns=["provider", "rate"],
            rows=[{"provider": "P1", "rate": 500}],
        )
        result = self.validator.validate(report)
        assert result.passed

    def test_empty_query_type_blocks(self):
        report = RateReport(query_type="", columns=[], rows=[])
        result = self.validator.validate(report)
        assert result.blocking

    def test_empty_rows_warns(self):
        report = RateReport(query_type="rates", columns=["x"], rows=[])
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert len(warn_findings) > 0


# ============================================================
# TemporalReport VALIDATION
# ============================================================


class TestValidateTemporalReport:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = TemporalReport(
            provider_filter="Sutter Health",
            amendments=[AmendmentEntry(amendment_order=1)],
            llm_summary="Changes over time...",
        )
        result = self.validator.validate(report)
        assert result.passed

    def test_empty_provider_filter_blocks(self):
        report = TemporalReport(provider_filter="", amendments=[])
        result = self.validator.validate(report)
        assert result.blocking

    def test_empty_amendments_and_summary_warns(self):
        report = TemporalReport(provider_filter="Kaiser", amendments=[], llm_summary="")
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert len(warn_findings) > 0


# ============================================================
# ComparisonReport VALIDATION
# ============================================================


class TestValidateComparisonReport:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = ComparisonReport(
            providers=["Sutter", "Kaiser"],
            comparison_data={"Sutter": {"rates": 5}, "Kaiser": {"rates": 3}},
            llm_summary="Comparison results...",
        )
        result = self.validator.validate(report)
        assert result.passed

    def test_single_provider_blocks(self):
        report = ComparisonReport(providers=["Only One"])
        result = self.validator.validate(report)
        assert result.blocking

    def test_empty_providers_blocks(self):
        report = ComparisonReport(providers=[])
        result = self.validator.validate(report)
        assert result.blocking

    def test_no_data_warns(self):
        report = ComparisonReport(
            providers=["A", "B"],
            comparison_data={},
            llm_summary="",
        )
        result = self.validator.validate(report)
        warn_findings = [f for f in result.findings if f.severity == Severity.WARN]
        assert len(warn_findings) > 0


# ============================================================
# ExplanationReport VALIDATION
# ============================================================


class TestValidateExplanationReport:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = ExplanationReport(
            narrative="This is a comprehensive explanation of offset clause patterns across providers. " * 3,
            target_concept="offset clause",
            evidence_passages=[{"text": "...", "source": "f.pdf"}],
        )
        result = self.validator.validate(report)
        assert result.passed

    def test_empty_narrative_blocks(self):
        report = ExplanationReport(narrative="", target_concept="test")
        result = self.validator.validate(report)
        assert result.blocking

    def test_trivially_short_narrative_blocks(self):
        report = ExplanationReport(narrative="Too short.", target_concept="test")
        result = self.validator.validate(report)
        assert result.blocking

    def test_whitespace_only_narrative_blocks(self):
        report = ExplanationReport(narrative="     \n\t  ", target_concept="test")
        result = self.validator.validate(report)
        assert result.blocking


# ============================================================
# MultiConceptReport VALIDATION
# ============================================================


class TestValidateMultiConceptReport:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_valid_report_passes(self):
        report = MultiConceptReport(
            operator="INTERSECTION",
            concepts=["offset clause", "dofr"],
            result_set=["Provider A", "Provider B"],
            total_universe=10,
        )
        result = self.validator.validate(report)
        assert result.passed

    def test_empty_concepts_blocks(self):
        report = MultiConceptReport(operator="INTERSECTION", concepts=[])
        result = self.validator.validate(report)
        assert result.blocking

    def test_empty_operator_blocks(self):
        report = MultiConceptReport(operator="", concepts=["a", "b"])
        result = self.validator.validate(report)
        assert result.blocking

    def test_match_exceeds_universe_blocks(self):
        report = MultiConceptReport(
            operator="UNION",
            concepts=["a", "b"],
            result_set=["P1", "P2", "P3", "P4", "P5"],
            total_universe=3,
        )
        result = self.validator.validate(report)
        assert result.blocking


# ============================================================
# ReportValidator API TESTS
# ============================================================


class TestReportValidatorAPI:
    def setup_method(self):
        self.validator = ReportValidator()

    def test_validate_returns_correct_type_name(self):
        report = _make_valid_clause_report()
        result = self.validator.validate(report)
        assert result.report_type == "ClauseReport"

    def test_validate_extraction_type_name(self):
        report = _make_valid_extraction_report()
        result = self.validator.validate(report)
        assert result.report_type == "StructuredExtractionReport"

    def test_unknown_type_warns(self):
        """Passing an unregistered type should produce a WARN, not crash."""

        class FakeReport:
            pass

        result = self.validator.validate(FakeReport())
        assert result.verdict == "WARN"
        assert "Unknown report type" in result.findings[0].check

    def test_assert_pass_succeeds_for_valid(self):
        report = _make_valid_clause_report()
        result = self.validator.assert_pass(report)
        assert result.passed

    def test_assert_pass_raises_for_block(self):
        report = _make_valid_clause_report(total_universe=999)
        with pytest.raises(ValueError, match="BLOCKED"):
            self.validator.assert_pass(report)

    def test_assert_pass_strict_raises_for_warn(self):
        report = _make_valid_clause_report()
        report.confidence_scores = {}  # triggers WARN
        with pytest.raises(ValueError, match="warnings"):
            self.validator.assert_pass(report, allow_warn=False)

    def test_assert_pass_lenient_allows_warn(self):
        report = _make_valid_clause_report()
        report.confidence_scores = {}  # triggers WARN
        result = self.validator.assert_pass(report, allow_warn=True)
        assert result.verdict == "WARN"  # returned, not raised


# ============================================================
# SEVERITY ENUM
# ============================================================


class TestSeverity:
    def test_values(self):
        assert Severity.PASS.value == "PASS"
        assert Severity.WARN.value == "WARN"
        assert Severity.BLOCK.value == "BLOCK"

    def test_is_str_enum(self):
        assert Severity.PASS == "PASS"
        assert Severity.BLOCK == "BLOCK"

"""
platform/v4/tests/test_sql_query_tool.py

Unit tests for SqlQueryTool.

Tests use a stub Spark session and stub LLM to avoid real SQL execution.
"""
import pytest
from unittest.mock import MagicMock

from ..contracts.tool_types import Confidence, ToolResult
from ..tools.sql_query import SqlQueryTool, _extract_sql, _validate_sql


# ---------------------------------------------------------------------------
# _extract_sql unit tests
# ---------------------------------------------------------------------------

class TestExtractSql:

    def test_extracts_from_fenced_block(self):
        raw = "Here is your query:\n```sql\nSELECT * FROM dev_adb.raw.tbl_v2_contract_registry\n```"
        sql = _extract_sql(raw)
        assert "SELECT" in sql.upper()
        assert "```" not in sql

    def test_extracts_bare_select(self):
        raw = "SELECT provider_name FROM dev_adb.raw.tbl_v2_contract_registry LIMIT 10"
        sql = _extract_sql(raw)
        assert sql.strip().upper().startswith("SELECT")

    def test_handles_explanation_prefix(self):
        raw = "I'll write a query to answer this.\nSELECT * FROM dev_adb.raw.tbl_genie_rates_current LIMIT 5"
        sql = _extract_sql(raw)
        assert "SELECT" in sql.upper()


# ---------------------------------------------------------------------------
# _validate_sql unit tests
# ---------------------------------------------------------------------------

class TestValidateSql:

    def test_valid_select_passes(self):
        sql = "SELECT * FROM dev_adb.raw.tbl_v2_contract_registry LIMIT 10"
        assert _validate_sql(sql) is None

    def test_create_blocked(self):
        sql = "CREATE TABLE foo AS SELECT * FROM dev_adb.raw.tbl_v2_contract_registry"
        err = _validate_sql(sql)
        assert err is not None
        assert "DDL" in err or "keyword" in err.lower()

    def test_drop_blocked(self):
        err = _validate_sql("DROP TABLE dev_adb.raw.tbl_v2_contract_registry")
        assert err is not None

    def test_delete_blocked(self):
        err = _validate_sql("DELETE FROM dev_adb.raw.tbl_v2_contract_registry")
        assert err is not None

    def test_non_whitelisted_table_blocked(self):
        sql = "SELECT * FROM dev_adb.raw.some_random_table LIMIT 10"
        err = _validate_sql(sql)
        assert err is not None
        assert "whitelist" in err.lower() or "not in" in err.lower()

    def test_whitelisted_table_passes(self):
        sql = "SELECT provider_name, rate_amount FROM dev_adb.raw.tbl_genie_rates_current WHERE is_current_effective = true LIMIT 50"
        assert _validate_sql(sql) is None


# ---------------------------------------------------------------------------
# SqlQueryTool integration tests (with stub Spark)
# ---------------------------------------------------------------------------

class TestSqlQueryTool:

    def _make_spark_stub(self, rows=None):
        """Create a minimal Spark stub that returns given rows."""
        spark = MagicMock()
        df    = MagicMock()
        df.collect.return_value = [MagicMock(asDict=lambda: r) for r in (rows or [])]
        spark.sql.return_value = df
        return spark

    def _make_llm_stub(self, sql_output: str):
        llm = MagicMock()
        llm.chat.return_value = sql_output
        return llm

    def test_returns_tool_result(self):
        tool  = SqlQueryTool(
            spark=self._make_spark_stub([{"provider_name": "Cedars-Sinai", "rate_amount": 100.0}]),
            llm_client=self._make_llm_stub(
                "SELECT provider_name, rate_amount FROM dev_adb.raw.tbl_genie_rates_current LIMIT 10"
            ),
        )
        result = tool._run(question="What is the rate for Cedars-Sinai?")
        assert isinstance(result, ToolResult)
        assert result.success is True

    def test_no_spark_returns_stub(self):
        tool   = SqlQueryTool(spark=None)
        result = tool._run(question="Any question")
        assert result.success is False
        assert "STUB" in result.summary or result.error_message is not None

    def test_ddl_sql_blocked(self):
        tool = SqlQueryTool(
            spark=self._make_spark_stub(),
            llm_client=self._make_llm_stub("DROP TABLE dev_adb.raw.tbl_genie_rates_current"),
        )
        result = tool._run(question="Drop the rates table")
        assert result.success is False
        assert "validation" in result.summary.lower() or "forbidden" in result.summary.lower()

    def test_execute_raw_valid(self):
        tool = SqlQueryTool(
            spark=self._make_spark_stub([{"count": 51109}]),
        )
        result = tool.execute_raw("SELECT COUNT(*) AS count FROM dev_adb.raw.tbl_genie_rates_current")
        assert result.success is True
        assert result.data[0]["count"] == 51109

"""Tests for platform/v4/services/verification/citation_verifier.py (P3-VER-1).

Covers:
  - Supersession check (current/expired/superseded doc roles)
  - Grounding check (keyword overlap between claim and passage)
  - Numerical check (numbers in claim match passage)
  - Temporal check (dates in claim match passage/metadata)
  - VerificationResult aggregates
  - CitationVerdict properties
  - Dict and dataclass citation inputs
"""
import pytest
from dataclasses import dataclass

from platform.v4.services.verification.citation_verifier import (
    CitationVerifier, VerificationResult, CitationVerdict,
    CheckResult, CheckStatus, _extract_numbers, _extract_dates,
    _keyword_overlap,
)


# ============================================================
# HELPERS
# ============================================================


@dataclass
class MockCitation:
    """Lightweight mock matching Citation shape."""
    passage_text: str = ""
    source_filename: str = "test.pdf"
    is_current_effective: bool = True
    doc_role: str = ""
    effective_date: str = ""


def _make_citation(**kwargs) -> MockCitation:
    return MockCitation(**kwargs)


def _make_citation_dict(**kwargs) -> dict:
    base = {
        "passage_text": "",
        "source_filename": "test.pdf",
        "is_current_effective": True,
        "doc_role": "",
        "effective_date": "",
    }
    base.update(kwargs)
    return base


# ============================================================
# UTILITY FUNCTION TESTS
# ============================================================


class TestExtractNumbers:
    def test_dollar_amounts(self):
        nums = _extract_numbers("The cap is $50,000 per year")
        assert "50000" in nums

    def test_percentages(self):
        nums = _extract_numbers("Rate increased by 12.5%")
        assert "12.5%" in nums

    def test_plain_integers(self):
        nums = _extract_numbers("Found 326 providers in the universe")
        assert "326" in nums

    def test_comma_separated(self):
        nums = _extract_numbers("Total was 1,234,567 units")
        assert "1234567" in nums

    def test_decimals(self):
        nums = _extract_numbers("Score of 0.85")
        assert "0.85" in nums

    def test_single_digits_skipped(self):
        nums = _extract_numbers("Found 5 items")
        # Single digit "5" is below the 2+ digit threshold
        assert "5" not in nums

    def test_empty_string(self):
        assert _extract_numbers("") == set()
        assert _extract_numbers(None) == set()


class TestExtractDates:
    def test_month_day_year(self):
        dates = _extract_dates("Effective January 1, 2024")
        assert any("january" in d and "2024" in d for d in dates)

    def test_iso_format(self):
        dates = _extract_dates("Date: 2024-01-15")
        assert "2024-01-15" in dates

    def test_slash_format(self):
        dates = _extract_dates("Signed on 01/15/2024")
        assert "01/15/2024" in dates

    def test_standalone_year(self):
        dates = _extract_dates("Contract from 2023")
        assert "2023" in dates

    def test_empty_string(self):
        assert _extract_dates("") == set()
        assert _extract_dates(None) == set()


class TestKeywordOverlap:
    def test_full_overlap(self):
        assert _keyword_overlap("offset clause provider", "The offset clause for this provider") == 1.0

    def test_no_overlap(self):
        assert _keyword_overlap("offset clause", "banana smoothie recipe") == 0.0

    def test_partial_overlap(self):
        score = _keyword_overlap(
            "offset clause cap amount",
            "The offset clause specifies a maximum deduction",
        )
        # "offset" and "clause" match (2/4 significant words with len>=4)
        assert 0.3 <= score <= 0.7

    def test_empty_text_a(self):
        assert _keyword_overlap("", "something") == 0.0

    def test_empty_text_b(self):
        assert _keyword_overlap("something", "") == 0.0

    def test_short_words_ignored(self):
        # Words <4 chars ignored
        assert _keyword_overlap("the is a", "the is a for") == 1.0  # all filtered out -> returns 1.0


# ============================================================
# SUPERSESSION CHECK
# ============================================================


class TestSupersessionCheck:
    def setup_method(self):
        self.verifier = CitationVerifier()

    def test_current_document_passes(self):
        cit = _make_citation(is_current_effective=True, doc_role="base_agreement")
        result = self.verifier.verify_single("test claim", cit)
        supersession = next(c for c in result.checks if c.check_name == "supersession")
        assert supersession.status == CheckStatus.PASS

    def test_expired_document_warns(self):
        cit = _make_citation(is_current_effective=False)
        result = self.verifier.verify_single("test claim", cit)
        supersession = next(c for c in result.checks if c.check_name == "supersession")
        assert supersession.status == CheckStatus.WARN
        assert supersession.confidence_impact < 0

    def test_superseded_role_warns(self):
        cit = _make_citation(is_current_effective=True, doc_role="superseded")
        result = self.verifier.verify_single("test claim", cit)
        supersession = next(c for c in result.checks if c.check_name == "supersession")
        assert supersession.status == CheckStatus.WARN

    def test_replaced_role_warns(self):
        cit = _make_citation(is_current_effective=True, doc_role="replaced")
        result = self.verifier.verify_single("test claim", cit)
        supersession = next(c for c in result.checks if c.check_name == "supersession")
        assert supersession.status == CheckStatus.WARN


# ============================================================
# GROUNDING CHECK
# ============================================================


class TestGroundingCheck:
    def setup_method(self):
        self.verifier = CitationVerifier(grounding_threshold=0.25)

    def test_well_grounded_passes(self):
        cit = _make_citation(
            passage_text="The provider shall offset overpayments against future claims "
                        "with a maximum cap of fifty thousand dollars per calendar year."
        )
        result = self.verifier.verify_single(
            "Provider has offset clause with cap for overpayments", cit
        )
        grounding = next(c for c in result.checks if c.check_name == "grounding")
        assert grounding.status == CheckStatus.PASS

    def test_ungrounded_fails(self):
        cit = _make_citation(
            passage_text="This agreement covers parking lot maintenance and landscaping services."
        )
        result = self.verifier.verify_single(
            "Provider has offset clause with cap for overpayments", cit
        )
        grounding = next(c for c in result.checks if c.check_name == "grounding")
        assert grounding.status == CheckStatus.FAIL

    def test_empty_passage_fails(self):
        cit = _make_citation(passage_text="")
        result = self.verifier.verify_single("Some claim", cit)
        grounding = next(c for c in result.checks if c.check_name == "grounding")
        assert grounding.status == CheckStatus.FAIL

    def test_short_claim_skips(self):
        cit = _make_citation(passage_text="Long passage text here with many words")
        result = self.verifier.verify_single("Yes", cit)
        grounding = next(c for c in result.checks if c.check_name == "grounding")
        assert grounding.status == CheckStatus.SKIP

    def test_weak_grounding_warns(self):
        cit = _make_citation(
            passage_text="The agreement establishes offset provisions for this facility "
                        "and outlines quarterly reconciliation procedures."
        )
        # "offset" and "provisions" overlap, but "overpayment cap" words don't
        result = self.verifier.verify_single(
            "offset overpayment cap maximum deduction provider claims future", cit
        )
        grounding = next(c for c in result.checks if c.check_name == "grounding")
        assert grounding.status in (CheckStatus.WARN, CheckStatus.FAIL)


# ============================================================
# NUMERICAL CHECK
# ============================================================


class TestNumericalCheck:
    def setup_method(self):
        self.verifier = CitationVerifier(strict_numerical=False)

    def test_numbers_match_passes(self):
        cit = _make_citation(
            passage_text="Maximum offset amount shall not exceed $50,000 per calendar year"
        )
        result = self.verifier.verify_single(
            "The offset cap is $50,000 annually", cit
        )
        numerical = next(c for c in result.checks if c.check_name == "numerical")
        assert numerical.status == CheckStatus.PASS

    def test_no_numbers_in_claim_skips(self):
        cit = _make_citation(passage_text="Some text with 12345")
        result = self.verifier.verify_single("No numbers here", cit)
        numerical = next(c for c in result.checks if c.check_name == "numerical")
        assert numerical.status == CheckStatus.SKIP

    def test_numbers_missing_from_passage_warns(self):
        cit = _make_citation(
            passage_text="The agreement establishes an offset provision."
        )
        result = self.verifier.verify_single(
            "The offset cap is $50,000 per year", cit
        )
        numerical = next(c for c in result.checks if c.check_name == "numerical")
        assert numerical.status == CheckStatus.WARN

    def test_strict_mode_fails(self):
        verifier = CitationVerifier(strict_numerical=True)
        cit = _make_citation(
            passage_text="The agreement establishes an offset provision."
        )
        result = verifier.verify_single(
            "The offset cap is $50,000 per year", cit
        )
        numerical = next(c for c in result.checks if c.check_name == "numerical")
        assert numerical.status == CheckStatus.FAIL

    def test_partial_number_match(self):
        cit = _make_citation(
            passage_text="Rate is $500 per diem with maximum of 30 days"
        )
        result = self.verifier.verify_single(
            "Rate is $500 per diem for 90 days maximum", cit
        )
        numerical = next(c for c in result.checks if c.check_name == "numerical")
        # $500 matches but 90 doesn't
        assert numerical.status in (CheckStatus.WARN, CheckStatus.PASS)


# ============================================================
# TEMPORAL CHECK
# ============================================================


class TestTemporalCheck:
    def setup_method(self):
        self.verifier = CitationVerifier()

    def test_date_match_passes(self):
        cit = _make_citation(
            passage_text="Effective January 1, 2024, the offset provision applies.",
            effective_date="2024-01-01",
        )
        result = self.verifier.verify_single(
            "Starting January 1, 2024, the offset clause takes effect", cit
        )
        temporal = next(c for c in result.checks if c.check_name == "temporal")
        assert temporal.status == CheckStatus.PASS

    def test_no_dates_in_claim_skips(self):
        cit = _make_citation(passage_text="Date is 2024-01-01")
        result = self.verifier.verify_single("No dates in this claim", cit)
        temporal = next(c for c in result.checks if c.check_name == "temporal")
        assert temporal.status == CheckStatus.SKIP

    def test_date_mismatch_warns(self):
        cit = _make_citation(
            passage_text="Signed on March 15, 2022.",
            effective_date="2022-03-15",
        )
        result = self.verifier.verify_single(
            "The agreement from 2025 establishes the offset", cit
        )
        temporal = next(c for c in result.checks if c.check_name == "temporal")
        assert temporal.status == CheckStatus.WARN

    def test_year_level_match_passes(self):
        cit = _make_citation(
            passage_text="This 2024 amendment modifies the offset terms.",
            effective_date="2024-06-01",
        )
        result = self.verifier.verify_single(
            "In 2024, the offset terms were changed", cit
        )
        temporal = next(c for c in result.checks if c.check_name == "temporal")
        assert temporal.status == CheckStatus.PASS

    def test_effective_date_metadata_used(self):
        cit = _make_citation(
            passage_text="No dates in the text itself.",
            effective_date="2024-01-15",
        )
        result = self.verifier.verify_single(
            "Effective 2024-01-15, these terms apply", cit
        )
        temporal = next(c for c in result.checks if c.check_name == "temporal")
        assert temporal.status == CheckStatus.PASS


# ============================================================
# AGGREGATE / INTEGRATION TESTS
# ============================================================


class TestVerificationResult:
    def setup_method(self):
        self.verifier = CitationVerifier()

    def test_all_pass(self):
        cit = _make_citation(
            passage_text="The provider offset clause permits recovery of overpayments "
                        "not exceeding $50,000 per calendar year effective January 2024.",
            is_current_effective=True,
            effective_date="2024-01-01",
        )
        result = self.verifier.verify(
            claim="Provider has offset clause with $50,000 cap starting January 2024",
            citations=[cit],
        )
        assert result.all_passed
        assert result.n_citations == 1
        assert result.pass_rate == 1.0

    def test_mixed_results(self):
        good = _make_citation(
            passage_text="Offset clause with $50,000 annual cap effective 2024",
            is_current_effective=True,
        )
        bad = _make_citation(
            passage_text="Parking lot maintenance agreement section 4.2",
            is_current_effective=False,
        )
        result = self.verifier.verify(
            claim="Provider has offset clause with $50,000 cap",
            citations=[good, bad],
        )
        assert result.n_citations == 2
        assert result.has_failures
        assert 0.0 < result.pass_rate < 1.0

    def test_failure_summary(self):
        bad = _make_citation(
            passage_text="Unrelated text about parking",
            source_filename="parking_lot_agreement.pdf",
        )
        result = self.verifier.verify(
            claim="Provider has offset clause provisions",
            citations=[bad],
        )
        assert result.has_failures
        assert "parking_lot_agreement.pdf" in result.failure_summary

    def test_empty_citations(self):
        result = self.verifier.verify(claim="test", citations=[])
        assert result.n_citations == 0
        assert result.all_passed  # vacuously true

    def test_dict_citations_supported(self):
        cit_dict = _make_citation_dict(
            passage_text="The offset clause provides for recovery of overpayments "
                        "against future claims up to $25,000 per year.",
            is_current_effective=True,
            effective_date="2023-07-01",
        )
        result = self.verifier.verify(
            claim="Offset allows recovery up to $25,000 annually from 2023",
            citations=[cit_dict],
        )
        assert result.all_passed


class TestCitationVerdict:
    def test_passed_property(self):
        v = CitationVerdict(citation_index=0, source_filename="test.pdf", checks=[
            CheckResult("supersession", CheckStatus.PASS, "ok"),
            CheckResult("grounding", CheckStatus.PASS, "ok"),
        ])
        assert v.passed is True

    def test_failed_property(self):
        v = CitationVerdict(citation_index=0, source_filename="test.pdf", checks=[
            CheckResult("supersession", CheckStatus.PASS, "ok"),
            CheckResult("grounding", CheckStatus.FAIL, "bad", confidence_impact=-0.5),
        ])
        assert v.passed is False
        assert v.failure_reasons == ["bad"]

    def test_confidence_penalty(self):
        v = CitationVerdict(citation_index=0, source_filename="test.pdf", checks=[
            CheckResult("supersession", CheckStatus.WARN, "old", confidence_impact=-0.3),
            CheckResult("grounding", CheckStatus.PASS, "ok", confidence_impact=0.0),
        ])
        assert v.confidence_penalty == pytest.approx(-0.3)
        assert v.has_warnings is True

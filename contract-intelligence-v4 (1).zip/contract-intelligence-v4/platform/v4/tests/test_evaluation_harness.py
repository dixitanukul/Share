"""Tests for W9-31 evaluation infrastructure.

Covers:
  - GroundednessScorer: claim detection + citation coverage
  - FactualAccuracyScorer: rule-based scoring
  - CompletenessScorer: info unit extraction + coverage
  - BehaviorScorer: OOS decline, edge case handling
  - CompositeScorer: full scorecard generation
  - EvaluationReport: gate criteria
  - EvaluationHarness: _infer_edge_tags, _category_from_id
"""
import pytest
from unittest.mock import MagicMock

from platform.v4.evaluation.scorers import (
    GroundednessScorer,
    FactualAccuracyScorer,
    CompletenessScorer,
    BehaviorScorer,
    CompositeScorer,
    EvalScorecard,
    DimensionScore,
)
from platform.v4.evaluation.evaluation_harness import (
    EvaluationHarness,
    EvaluationReport,
    _category_from_id,
)


# ── GroundednessScorer ───────────────────────────────────────────────────

class TestGroundednessScorer:
    @pytest.fixture
    def scorer(self):
        return GroundednessScorer()

    def test_empty_answer(self, scorer):
        result = scorer.score("", [])
        assert result.score == 0.0

    def test_no_claims_generic_answer(self, scorer):
        result = scorer.score(
            "Based on the contract analysis, here is what was found.",
            [{"source": "doc1"}],
        )
        assert result.score >= 0.7  # No claims = neutral/good

    def test_numerical_claims_with_citations(self, scorer):
        result = scorer.score(
            "The inpatient per diem rate is $1,500 per day. The outpatient rate is $800.",
            [{"source": "doc1"}, {"source": "doc2"}],
        )
        assert result.score >= 0.7  # 2 claims, 2 citations

    def test_numerical_claims_without_citations(self, scorer):
        result = scorer.score(
            "The inpatient per diem rate is $1,500 per day. The outpatient rate is $800.",
            [],
        )
        assert result.score < 0.5  # 2 numerical claims, 0 citations
        assert result.details["unsourced_numerical"] == 2

    def test_high_confidence_no_citations_penalized(self, scorer):
        result = scorer.score(
            "The contract specifies a 30 days notice period for termination.",
            [],
            confidence="HIGH",
        )
        assert result.score < 0.5  # HIGH confidence + claims + 0 citations

    def test_definitive_claims_counted(self, scorer):
        result = scorer.score(
            "The clause states that there is no offset provision. The rate is $500 per diem.",
            [{"source": "passage_123"}],
        )
        # 1 numerical + at least 1 definitive claim, 1 citation
        assert result.details["numerical_claims"] >= 1


# ── FactualAccuracyScorer ─────────────────────────────────────────────────

class TestFactualAccuracyScorer:
    @pytest.fixture
    def scorer(self):
        return FactualAccuracyScorer(llm_client=None)

    def test_empty_answer(self, scorer):
        result = scorer.score("", "Expected answer", "question")
        assert result.score == 0.0

    def test_perfect_match(self, scorer):
        expected = "Sutter Roseville has an inpatient per diem rate of $1500."
        result = scorer.score(expected, expected, "What is the rate?")
        assert result.score >= 0.8  # Same text = high accuracy

    def test_partial_match(self, scorer):
        expected = "Stanford Health Care has an offset clause."
        actual = "Based on the contract, Stanford Health Care includes offset provisions."
        result = scorer.score(actual, expected, "Does Stanford have offset?")
        assert result.score >= 0.4  # Partial entity/keyword overlap

    def test_oos_correct_decline(self, scorer):
        expected = "Out of scope."
        actual = "I cannot answer this as it is outside the scope of contract data."
        result = scorer.score(actual, expected, "What is the stock price?", tags=["out_of_scope"])
        assert result.score >= 0.6  # Structural alignment should boost

    def test_negation_awareness(self, scorer):
        expected = "Providers without termination clause."
        actual = "The following providers do not have a termination for cause clause."
        result = scorer.score(actual, expected, "Which providers don't have X?", tags=["negation"])
        assert result.score >= 0.5


# ── CompletenessScorer ───────────────────────────────────────────────────

class TestCompletenessScorer:
    @pytest.fixture
    def scorer(self):
        return CompletenessScorer()

    def test_empty_answer(self, scorer):
        result = scorer.score("", "Expected answer")
        assert result.score == 0.0

    def test_no_expected(self, scorer):
        result = scorer.score("Some answer", "")
        assert result.score == 0.7  # Can't measure without reference

    def test_full_coverage(self, scorer):
        expected = "Sutter Roseville has a rate of $1500 per diem."
        actual = "Sutter Roseville has an inpatient rate of $1500 per diem effective 2024."
        result = scorer.score(actual, expected)
        assert result.score >= 0.5  # Should find entities + numbers

    def test_missing_entities(self, scorer):
        expected = "Stanford Health Care and California Pacific both have offset clauses."
        actual = "Stanford Health Care has an offset clause."
        result = scorer.score(actual, expected)
        # Missing California Pacific = lower completeness
        assert result.score < 1.0


# ── BehaviorScorer ───────────────────────────────────────────────────────

class TestBehaviorScorer:
    @pytest.fixture
    def scorer(self):
        return BehaviorScorer()

    def test_oos_correct_decline(self, scorer):
        result = scorer.score(
            "I'm sorry, this question is out of scope. I cannot provide stock prices.",
            ["out_of_scope"],
        )
        assert result.score >= 0.8

    def test_oos_no_decline(self, scorer):
        result = scorer.score(
            "The stock price of Blue Shield is $42.50 per share as of today.",
            ["out_of_scope"],
        )
        assert result.score <= 0.3  # Should have declined but didn't

    def test_ambiguous_clarifies(self, scorer):
        result = scorer.score(
            "Could you please specify which provider you're asking about?",
            ["ambiguous", "underspecified"],
        )
        assert result.score >= 0.8

    def test_write_attempt_refused(self, scorer):
        result = scorer.score(
            "I cannot modify contract data. This system is read-only.",
            ["write_attempt"],
        )
        assert result.score >= 0.8

    def test_missing_provider_acknowledged(self, scorer):
        result = scorer.score(
            "No data found for Kaiser Permanente in the contract corpus.",
            ["missing_provider", "no_data"],
        )
        assert result.score >= 0.8

    def test_missing_provider_hallucinated(self, scorer):
        result = scorer.score(
            "Kaiser Permanente has an inpatient rate of $2000 per diem.",
            ["missing_provider", "no_data"],
        )
        assert result.score < 0.5  # Hallucinated data for missing provider

    def test_no_special_tags(self, scorer):
        result = scorer.score(
            "The rate is $1500.",
            ["rates", "sql"],
        )
        assert result.score == 0.8  # Neutral for non-behavioral tests

    def test_typo_resolved(self, scorer):
        result = scorer.score(
            "Sutter Roseville (interpreting from 'Suter Rosevile') has a rate of $1500 per diem.",
            ["typo"],
        )
        assert result.score >= 0.7


# ── CompositeScorer ──────────────────────────────────────────────────────

class TestCompositeScorer:
    def test_produces_scorecard(self):
        scorer = CompositeScorer(llm_client=None)
        sc = scorer.score(
            query_id="SQL-01",
            answer="There are 326 providers with active contracts.",
            expected_answer="326 providers have active contracts.",
            question="How many providers have active contracts?",
            citations=[{"source": "sql_result"}],
            confidence="HIGH",
            tags=["sql", "analytical"],
        )
        assert isinstance(sc, EvalScorecard)
        assert sc.query_id == "SQL-01"
        assert 0.0 <= sc.composite_score <= 1.0
        assert sc.groundedness.dimension == "groundedness"
        assert sc.accuracy.dimension == "accuracy"

    def test_scorecard_passes_gate(self):
        # Construct a high-scoring scorecard
        sc = EvalScorecard(
            query_id="test",
            groundedness=DimensionScore("groundedness", 0.9),
            accuracy=DimensionScore("accuracy", 0.9),
            completeness=DimensionScore("completeness", 0.8),
            behavior=DimensionScore("behavior", 0.8),
        )
        assert sc.passes_gate is True
        assert sc.composite_score >= 0.8

    def test_scorecard_fails_gate(self):
        sc = EvalScorecard(
            query_id="test",
            groundedness=DimensionScore("groundedness", 0.3),
            accuracy=DimensionScore("accuracy", 0.4),
            completeness=DimensionScore("completeness", 0.2),
            behavior=DimensionScore("behavior", 0.5),
        )
        assert sc.passes_gate is False


# ── EvaluationReport ─────────────────────────────────────────────────────

class TestEvaluationReport:
    def test_meets_w931_pass(self):
        report = EvaluationReport(
            run_id="test", timestamp=0, total_queries=100,
            total_passed=96, overall_pass_rate=0.96,
            overall_composite=0.85, overall_groundedness=0.9,
            overall_accuracy=0.88, overall_completeness=0.8,
            overall_behavior=0.9,
            factual_accuracy_pct=96.0,
            unsourced_numerical_count=0,
            gate_verdict="PASS",
        )
        assert report.meets_w931_criteria is True

    def test_meets_w931_fail_accuracy(self):
        report = EvaluationReport(
            run_id="test", timestamp=0, total_queries=100,
            total_passed=90, overall_pass_rate=0.90,
            overall_composite=0.80, overall_groundedness=0.8,
            overall_accuracy=0.80, overall_completeness=0.7,
            overall_behavior=0.8,
            factual_accuracy_pct=90.0,  # Below 95%
            unsourced_numerical_count=0,
            gate_verdict="FAIL",
        )
        assert report.meets_w931_criteria is False

    def test_meets_w931_fail_unsourced(self):
        report = EvaluationReport(
            run_id="test", timestamp=0, total_queries=100,
            total_passed=96, overall_pass_rate=0.96,
            overall_composite=0.85, overall_groundedness=0.8,
            overall_accuracy=0.88, overall_completeness=0.8,
            overall_behavior=0.9,
            factual_accuracy_pct=96.0,
            unsourced_numerical_count=3,  # > 0
            gate_verdict="FAIL",
        )
        assert report.meets_w931_criteria is False

    def test_to_markdown(self):
        report = EvaluationReport(
            run_id="test", timestamp=1749772800,
            total_queries=10, total_passed=8,
            overall_pass_rate=0.8, overall_composite=0.82,
            overall_groundedness=0.85, overall_accuracy=0.8,
            overall_completeness=0.75, overall_behavior=0.9,
            factual_accuracy_pct=95.0,
            unsourced_numerical_count=0,
            gate_verdict="PASS",
        )
        md = report.to_markdown()
        assert "# V3 E2E Evaluation Report" in md
        assert "PASS" in md


# ── Harness Utilities ─────────────────────────────────────────────────────

class TestHarnessUtilities:
    def test_category_from_id(self):
        assert _category_from_id("MT-01") == "multi_turn"
        assert _category_from_id("NEG-05") == "negation"
        assert _category_from_id("CALC-03") == "calculation"
        assert _category_from_id("MH-02") == "multi_hop"
        assert _category_from_id("DOC-01") == "document_retrieval"
        assert _category_from_id("EDGE-04") == "edge_case"
        assert _category_from_id("OOS-03") == "out_of_scope"
        assert _category_from_id("SQL-15") == "sql_analytical"
        assert _category_from_id("MX-10") == "mixed"
        assert _category_from_id("V2-A01") == "v2_regression"
        assert _category_from_id("UNKNOWN-1") == "unknown"

    def test_infer_edge_tags(self):
        harness = EvaluationHarness()
        assert "typo" in harness._infer_edge_tags("EDGE-01")
        assert "ambiguous" in harness._infer_edge_tags("EDGE-02")
        assert "write_attempt" in harness._infer_edge_tags("EDGE-04")
        assert "missing_provider" in harness._infer_edge_tags("EDGE-05")


# ═══════════════════════════════════════════════════════════════════════════════
# W9-31: Dry-run evaluation harness (no Spark, no live LLM)
# ═══════════════════════════════════════════════════════════════════════════════

from platform.v4.evaluation.golden_query_runner import GoldenQueryRunner, GoldenQuery, EvalResult


class _MockRuntime:
    """Simulates NotebookRuntime.ask() without live tools or LLM."""

    def __init__(self, answer: str = "Test answer.", confidence: str = "MODERATE",
                 total_cost: float = 0.05, citations: list | None = None):
        self._answer = answer
        self._confidence = confidence
        self._total_cost = total_cost
        self._citations = citations or []
        self.call_count = 0

    def ask(self, question: str, provider_name: str | None = None):
        self.call_count += 1

        class _Resp:
            pass

        r = _Resp()
        r.answer = self._answer
        r.confidence = self._confidence
        r.total_cost = self._total_cost
        r.citations = self._citations
        return r


class _FailingRuntime:
    """Always raises an exception."""
    def ask(self, question, provider_name=None):
        raise RuntimeError("DB unavailable")


def _make_queries(n: int = 5, prefix: str = "SQL") -> list[GoldenQuery]:
    return [
        GoldenQuery(
            query_id=f"{prefix}-{i:02d}",
            question=f"Test question {i}?",
            expected_answer=f"Test expected answer {i}.",
            provider_name=None,
            expected_confidence="MODERATE",
            tags=[prefix.lower()],
        )
        for i in range(1, n + 1)
    ]


class TestGoldenQueryRunnerDryRun:
    """W9-31: run_from_queries() bypasses Spark and uses injected queries."""

    def test_run_from_queries_returns_results(self):
        runner = GoldenQueryRunner(runtime=_MockRuntime(), spark=None)
        queries = _make_queries(3)
        results = runner.run_from_queries(queries, run_id="dry-001")
        assert len(results) == 3

    def test_run_from_queries_all_succeed(self):
        runner = GoldenQueryRunner(runtime=_MockRuntime(answer="Found $1,500 rate."), spark=None)
        results = runner.run_from_queries(_make_queries(5))
        assert all(r.success for r in results)

    def test_run_from_queries_propagates_run_id(self):
        runner = GoldenQueryRunner(runtime=_MockRuntime(), spark=None)
        results = runner.run_from_queries(_make_queries(2), run_id="run-abc")
        assert all(r.run_id == "run-abc" for r in results)

    def test_run_from_queries_failure_captured(self):
        """Runtime exception → success=False, not a test crash."""
        runner = GoldenQueryRunner(runtime=_FailingRuntime(), spark=None)
        results = runner.run_from_queries(_make_queries(3))
        assert all(not r.success for r in results)
        assert all(r.actual_answer == "" for r in results)
        assert all("DB unavailable" in r.notes for r in results)

    def test_run_from_queries_empty_list(self):
        runner = GoldenQueryRunner(runtime=_MockRuntime(), spark=None)
        results = runner.run_from_queries([], run_id="empty-run")
        assert results == []

    def test_text_overlap_identical(self):
        assert GoldenQueryRunner._text_overlap("hello world", "hello world") == 1.0

    def test_text_overlap_empty(self):
        assert GoldenQueryRunner._text_overlap("", "hello") == 0.0
        assert GoldenQueryRunner._text_overlap("hello", "") == 0.0

    def test_text_overlap_no_common_words(self):
        score = GoldenQueryRunner._text_overlap("apple banana", "car door elephant")
        assert score == 0.0

    def test_text_overlap_partial(self):
        score = GoldenQueryRunner._text_overlap("The rate is $1500.", "The rate is $2000.")
        assert 0.0 < score < 1.0

    def test_match_score_in_result(self):
        runner = GoldenQueryRunner(
            runtime=_MockRuntime(answer="The rate is $1500."), spark=None
        )
        queries = [GoldenQuery(
            query_id="T-01", question="Rate?",
            expected_answer="The rate is $1500.",
            provider_name=None,
        )]
        results = runner.run_from_queries(queries)
        assert results[0].match_score == 1.0


class TestEvaluationHarnessDryRun:
    """W9-31: Full harness dry-run — no Spark, no live LLM required."""

    def _make_eval_results(self, n: int = 5, prefix: str = "SQL",
                           match_score: float = 0.85) -> list[EvalResult]:
        return [
            EvalResult(
                query_id=f"{prefix}-{i:02d}",
                question=f"Question {i}?",
                actual_answer=f"Answer {i}.",
                expected_answer=f"Expected {i}.",
                confidence="HIGH",
                success=True,
                execution_time_s=0.5,
                cost_estimate=0.02,
                citation_count=1,
                match_score=match_score,
                run_id="dry-test",
            )
            for i in range(1, n + 1)
        ]

    def test_build_report_empty_results(self):
        harness = EvaluationHarness()
        report = harness._build_report([], run_id="empty")
        assert report.total_queries == 0
        assert report.total_passed == 0
        assert isinstance(report, EvaluationReport)

    def test_build_report_five_queries(self):
        harness = EvaluationHarness()
        results = self._make_eval_results(5, prefix="SQL", match_score=0.9)
        report = harness._build_report(results, run_id="five-q")
        assert report.total_queries == 5
        assert report.run_id == "five-q"
        assert 0.0 <= report.overall_composite <= 1.0

    def test_build_report_category_aggregation(self):
        """Results with same prefix get grouped into same category."""
        harness = EvaluationHarness()
        results = (
            self._make_eval_results(3, prefix="MT")    # multi_turn
            + self._make_eval_results(2, prefix="OOS")  # out_of_scope
        )
        report = harness._build_report(results, run_id="cat-agg")
        assert "multi_turn" in report.category_reports
        assert "out_of_scope" in report.category_reports
        assert report.category_reports["multi_turn"].n_queries == 3
        assert report.category_reports["out_of_scope"].n_queries == 2

    def test_build_report_w931_gate_tracked(self):
        """factual_accuracy_pct and unsourced_numerical_count are populated."""
        harness = EvaluationHarness()
        results = self._make_eval_results(10, match_score=0.95)
        report = harness._build_report(results, run_id="gate-test")
        assert isinstance(report.factual_accuracy_pct, float)
        assert isinstance(report.unsourced_numerical_count, int)

    def test_run_dry_produces_evaluation_report(self):
        """EvaluationHarness.run_dry() → EvaluationReport without Spark."""
        mock_runtime = _MockRuntime(answer="The rate is $1,500 per diem.", confidence="HIGH")
        harness = EvaluationHarness(runtime=mock_runtime)
        queries = _make_queries(5, prefix="SQL")
        report = harness.run_dry(queries, run_id="dry-full")
        assert isinstance(report, EvaluationReport)
        assert report.total_queries == 5
        assert report.run_id == "dry-full"

    def test_run_dry_runtime_called_per_query(self):
        """run_dry() calls runtime.ask() exactly once per query."""
        mock_runtime = _MockRuntime()
        harness = EvaluationHarness(runtime=mock_runtime)
        queries = _make_queries(7)
        harness.run_dry(queries)
        assert mock_runtime.call_count == 7

    def test_run_dry_failing_runtime_all_fail_gracefully(self):
        """All queries fail → EvaluationReport still built (0 passed)."""
        harness = EvaluationHarness(runtime=_FailingRuntime())
        queries = _make_queries(4)
        report = harness.run_dry(queries, run_id="fail-test")
        assert isinstance(report, EvaluationReport)
        assert report.total_queries == 4

    def test_run_dry_multi_category_report(self):
        """Mixed-prefix query set produces multiple category buckets."""
        mock_runtime = _MockRuntime(answer="Provider has DOFR clause.")
        harness = EvaluationHarness(runtime=mock_runtime)
        queries = (
            _make_queries(3, prefix="MT")
            + _make_queries(2, prefix="NEG")
            + _make_queries(2, prefix="CALC")
        )
        report = harness.run_dry(queries, run_id="multi-cat")
        assert len(report.category_reports) >= 3
        assert report.total_queries == 7

    def test_print_summary_does_not_raise(self, capsys):
        """EvaluationReport.print_summary() runs without error."""
        harness = EvaluationHarness(runtime=_MockRuntime())
        report = harness.run_dry(_make_queries(3), run_id="summary-test")
        report.print_summary()  # Should not raise
        captured = capsys.readouterr()
        assert "V3 E2E Evaluation Report" in captured.out

    def test_to_markdown_contains_key_sections(self):
        """EvaluationReport.to_markdown() produces structured markdown."""
        harness = EvaluationHarness(runtime=_MockRuntime())
        report = harness.run_dry(_make_queries(3), run_id="md-test")
        md = report.to_markdown()
        assert "# V3 E2E Evaluation Report" in md
        assert "## W9-31 Gate Criteria" in md
        assert "## By Category" in md

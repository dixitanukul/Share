"""
Tests for W9-21 ContextManager v2 enhancements:
  - Session fact extraction from answers
  - Turn summarization on window eviction
  - Working memory (facts persist across turns)
  - LLM coreference fallback (optional)
  - Enhanced to_prompt_summary with facts + history
"""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

import pytest
from platform.v4.core.context_manager import ContextManager, DEFAULT_WINDOW_SIZE
from platform.v4.contracts.context_types import (
    SessionContext, SessionFact, ConversationTurn, ResolvedEntity, WorkingData,
)
from platform.v4.contracts.agent_types import AgentRequest


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _make_ctx(session_id: str = "test-session", question: str = "test?") -> SessionContext:
    return SessionContext(session_id=session_id, question=question, turn_count=1)


def _make_entity(name: str, entity_type: str = "provider") -> ResolvedEntity:
    return ResolvedEntity(
        raw_mention=name,
        canonical_form=name,
        entity_type=entity_type,
        confidence=1.0,
        resolution_method="exact",
    )


# ═══════════════════════════════════════════════════════════════════════════════
# SessionFact dataclass
# ═══════════════════════════════════════════════════════════════════════════════

class TestSessionFact:
    def test_fact_creation(self):
        fact = SessionFact(fact_type="rate", content="Rate: $1,500", provider="Sutter Roseville")
        assert fact.fact_type == "rate"
        assert fact.content == "Rate: $1,500"
        assert fact.provider == "Sutter Roseville"

    def test_to_prompt_line_with_provider(self):
        fact = SessionFact(fact_type="rate", content="Rate: $1,500", provider="Sutter Roseville")
        line = fact.to_prompt_line()
        assert "[Sutter Roseville]" in line
        assert "Rate: $1,500" in line

    def test_to_prompt_line_without_provider(self):
        fact = SessionFact(fact_type="count", content="Count: 42")
        line = fact.to_prompt_line()
        assert "[" not in line
        assert "Count: 42" in line


# ═══════════════════════════════════════════════════════════════════════════════
# SessionContext fact methods
# ═══════════════════════════════════════════════════════════════════════════════

class TestSessionContextFacts:
    def test_add_fact_basic(self):
        ctx = _make_ctx()
        fact = SessionFact(fact_type="rate", content="Rate: $500", provider="Mills Peninsula")
        ctx.add_fact(fact)
        assert len(ctx.session_facts) == 1
        assert ctx.session_facts[0].content == "Rate: $500"

    def test_add_fact_deduplicates(self):
        ctx = _make_ctx()
        fact1 = SessionFact(fact_type="rate", content="Rate: $500", provider="Mills Peninsula")
        fact2 = SessionFact(fact_type="rate", content="Rate: $500", provider="Different")
        ctx.add_fact(fact1)
        ctx.add_fact(fact2)  # Same content, should be deduplicated
        assert len(ctx.session_facts) == 1

    def test_add_fact_different_content(self):
        ctx = _make_ctx()
        ctx.add_fact(SessionFact(fact_type="rate", content="Rate: $500"))
        ctx.add_fact(SessionFact(fact_type="rate", content="Rate: $1000"))
        assert len(ctx.session_facts) == 2

    def test_get_facts_for_provider(self):
        ctx = _make_ctx()
        ctx.add_fact(SessionFact(fact_type="rate", content="Rate: $500", provider="Sutter"))
        ctx.add_fact(SessionFact(fact_type="rate", content="Rate: $800", provider="Mills"))
        ctx.add_fact(SessionFact(fact_type="count", content="Count: 3", provider="Sutter"))

        sutter_facts = ctx.get_facts_for_provider("sutter")  # case-insensitive
        assert len(sutter_facts) == 2

    def test_get_facts_for_provider_empty(self):
        ctx = _make_ctx()
        ctx.add_fact(SessionFact(fact_type="rate", content="Rate: $500", provider="Sutter"))
        assert ctx.get_facts_for_provider("Kaiser") == []


# ═══════════════════════════════════════════════════════════════════════════════
# Session Fact Extraction
# ═══════════════════════════════════════════════════════════════════════════════

class TestSessionFactExtraction:
    def setup_method(self):
        self.cm = ContextManager(spark=None, window_size=5)

    def test_extracts_dollar_rates(self):
        ctx = _make_ctx()
        ctx.resolved_entities = [_make_entity("Sutter Roseville")]
        facts = self.cm._extract_session_facts(
            "The per diem rate is $1,500 per day for Sutter Roseville.", ctx
        )
        rate_facts = [f for f in facts if f.fact_type == "rate"]
        assert len(rate_facts) >= 1
        assert "$1,500" in rate_facts[0].content
        assert rate_facts[0].provider == "Sutter Roseville"

    def test_extracts_multiple_rates(self):
        ctx = _make_ctx()
        ctx.resolved_entities = [_make_entity("Mills Peninsula")]
        facts = self.cm._extract_session_facts(
            "Rates are $500 per diem and $2,300 per day for DRG.", ctx
        )
        rate_facts = [f for f in facts if f.fact_type == "rate"]
        assert len(rate_facts) >= 2

    def test_max_3_rates(self):
        ctx = _make_ctx()
        facts = self.cm._extract_session_facts(
            "Rates: $100, $200, $300, $400, $500 all different.", ctx
        )
        rate_facts = [f for f in facts if f.fact_type == "rate"]
        assert len(rate_facts) <= 3

    def test_extracts_counts(self):
        ctx = _make_ctx()
        facts = self.cm._extract_session_facts(
            "Found 42 providers with offset clauses in 15 contracts.", ctx
        )
        count_facts = [f for f in facts if f.fact_type == "count"]
        assert len(count_facts) >= 1
        assert any("42" in f.content for f in count_facts)

    def test_extracts_clause_has(self):
        ctx = _make_ctx()
        ctx.resolved_entities = [_make_entity("Alta Bates Summit")]
        facts = self.cm._extract_session_facts(
            "Alta Bates Summit has an offset clause in their current agreement.", ctx
        )
        clause_facts = [f for f in facts if f.fact_type == "clause_status"]
        assert len(clause_facts) >= 1
        assert "HAS" in clause_facts[0].content

    def test_extracts_clause_not_have(self):
        ctx = _make_ctx()
        ctx.resolved_entities = [_make_entity("Chinese Hospital")]
        facts = self.cm._extract_session_facts(
            "Chinese Hospital does not have an offset clause.", ctx
        )
        clause_facts = [f for f in facts if f.fact_type == "clause_status"]
        assert len(clause_facts) >= 1
        assert "NO" in clause_facts[0].content

    def test_extracts_dates(self):
        ctx = _make_ctx()
        facts = self.cm._extract_session_facts(
            "The contract was amended effective January 1, 2024.", ctx
        )
        date_facts = [f for f in facts if f.fact_type == "date"]
        assert len(date_facts) >= 1
        assert "January 1, 2024" in date_facts[0].content

    def test_empty_answer_no_facts(self):
        ctx = _make_ctx()
        facts = self.cm._extract_session_facts("", ctx)
        assert facts == []

    def test_no_extractable_content(self):
        ctx = _make_ctx()
        facts = self.cm._extract_session_facts("I don't know the answer to that question.", ctx)
        assert len(facts) == 0


# ═══════════════════════════════════════════════════════════════════════════════
# Turn Summarization
# ═══════════════════════════════════════════════════════════════════════════════

class TestTurnSummarization:
    def test_summarize_single_turn(self):
        turn = ConversationTurn(
            question="What is the offset clause for Sutter Roseville?",
            answer_preview="Sutter Roseville has an offset clause...",
            resolved_entities=[_make_entity("Sutter Roseville")],
        )
        summary = ContextManager._summarize_evicted_turns([turn], "")
        assert "Sutter Roseville" in summary
        assert "offset" in summary.lower()

    def test_summarize_preserves_existing(self):
        existing = "Earlier: discussed Mills Peninsula rates"
        turn = ConversationTurn(
            question="What about Alta Bates?",
            resolved_entities=[_make_entity("Alta Bates Summit")],
        )
        summary = ContextManager._summarize_evicted_turns([turn], existing)
        assert "Mills Peninsula" in summary
        assert "Alta Bates" in summary

    def test_summarize_caps_at_500_chars(self):
        # Create many turns to exceed 500 chars
        turns = []
        for i in range(20):
            turns.append(ConversationTurn(
                question=f"What is the rate for Provider Number {i} Medical Center Hospital?",
                resolved_entities=[_make_entity(f"Provider Number {i} Medical Center Hospital")],
            ))
        summary = ContextManager._summarize_evicted_turns(turns, "")
        assert len(summary) <= 500

    def test_summarize_empty_eviction(self):
        summary = ContextManager._summarize_evicted_turns([], "existing context")
        assert summary == "existing context"

    def test_summarize_includes_concepts(self):
        turn = ConversationTurn(
            question="Tell me about DOFR",
            resolved_entities=[ResolvedEntity(
                raw_mention="dofr", canonical_form="dofr",
                entity_type="concept", confidence=1.0,
            )],
        )
        summary = ContextManager._summarize_evicted_turns([turn], "")
        assert "dofr" in summary


# ═══════════════════════════════════════════════════════════════════════════════
# Working Memory Integration (facts persist across turns)
# ═══════════════════════════════════════════════════════════════════════════════

class TestWorkingMemory:
    def setup_method(self):
        self.cm = ContextManager(spark=None, window_size=3)

    def test_facts_persist_across_turns(self):
        """Facts extracted from turn 1 should still be in session_facts at turn 3."""
        request = AgentRequest(
            session_id="mem-test",
            question="What is the per diem rate for Sutter Roseville?",
            provider_hint="Sutter Roseville",
        )
        # Manually set up provider cache so resolution works
        self.cm._provider_cache = [
            {"canonical_name": "Sutter Roseville", "provider_ids": ["P001"], "all_names_used": []},
        ]
        ctx = self.cm.create_session(request)

        # Simulate turn 1 answer with a rate
        answer1 = "The per diem rate for Sutter Roseville is $1,500 per day."
        ctx = self.cm.continue_session(ctx, "What about their DOFR?", prev_answer=answer1)

        # Facts from turn 1 should be in session_facts
        assert len(ctx.session_facts) >= 1
        rate_facts = [f for f in ctx.session_facts if f.fact_type == "rate"]
        assert any("$1,500" in f.content for f in rate_facts)

        # Simulate turn 2 answer
        answer2 = "Sutter Roseville has an offset clause in their agreement."
        ctx = self.cm.continue_session(ctx, "How many providers have offset?", prev_answer=answer2)

        # Both facts should be present
        assert len(ctx.session_facts) >= 2

    def test_evicted_turns_produce_summary(self):
        """When window evicts turns, history_summary gets populated."""
        cm = ContextManager(spark=None, window_size=2)  # Small window
        cm._provider_cache = [
            {"canonical_name": "Sutter Roseville", "provider_ids": ["P001"], "all_names_used": []},
            {"canonical_name": "Mills Peninsula", "provider_ids": ["P002"], "all_names_used": []},
        ]

        request = AgentRequest(session_id="evict-test", question="Q1 about Sutter?")
        ctx = cm.create_session(request)

        # Fill window
        ctx = cm.continue_session(ctx, "Q2 about Mills?", prev_answer="Answer1")
        ctx = cm.continue_session(ctx, "Q3 about rates?", prev_answer="Answer2")
        ctx = cm.continue_session(ctx, "Q4 final?", prev_answer="Answer3")

        # With window_size=2, older turns should be summarized
        assert ctx.history_summary != ""

    def test_to_prompt_summary_includes_facts(self):
        ctx = _make_ctx()
        ctx.add_fact(SessionFact(fact_type="rate", content="Rate: $1,500", provider="Sutter"))
        ctx.add_fact(SessionFact(fact_type="clause_status", content="HAS offset clause", provider="Sutter"))

        summary = ctx.to_prompt_summary()
        assert "Known facts:" in summary
        assert "$1,500" in summary

    def test_to_prompt_summary_includes_history_summary(self):
        ctx = _make_ctx()
        ctx.history_summary = "Earlier discussed Sutter rates and DOFR status"

        summary = ctx.to_prompt_summary()
        assert "Prior context:" in summary
        assert "Sutter" in summary

    def test_prompt_summary_limits_facts_to_5(self):
        ctx = _make_ctx()
        for i in range(10):
            ctx.add_fact(SessionFact(fact_type="rate", content=f"Rate: ${i*100}", provider=f"P{i}"))

        summary = ctx.to_prompt_summary()
        # Should only show last 5 facts
        assert "$900" in summary  # Last fact
        assert "$500" in summary  # 5th from end
        # First facts might not be in the prompt
        # (they're still in session_facts, just not in summary)
        assert len(ctx.session_facts) == 10


# ═══════════════════════════════════════════════════════════════════════════════
# LLM Coreference Fallback
# ═══════════════════════════════════════════════════════════════════════════════

class TestLLMCoreferenceFallback:
    """Tests for optional LLM-based coreference when regex fails."""

    def setup_method(self):
        self.cm = ContextManager(spark=None, window_size=5)
        self.cm._provider_cache = [
            {"canonical_name": "Sutter Roseville", "provider_ids": ["P001"], "all_names_used": []},
            {"canonical_name": "Mills Peninsula", "provider_ids": ["P002"], "all_names_used": []},
        ]

    def test_llm_client_optional(self):
        """ContextManager works without LLM client (regex-only mode)."""
        cm = ContextManager(spark=None)
        # Should not raise even without LLM
        assert cm._window_size == DEFAULT_WINDOW_SIZE

    def test_regex_coref_still_works_without_llm(self):
        """Regex-based coreference works regardless of LLM availability."""
        ctx = _make_ctx()
        ctx.conversation_history = [
            ConversationTurn(
                question="Tell me about Sutter Roseville",
                resolved_entities=[_make_entity("Sutter Roseville")],
            )
        ]
        entities = self.cm._resolve_coreferences("What are their rates?", ctx)
        assert len(entities) >= 1
        assert entities[0].canonical_form == "Sutter Roseville"


# ═══════════════════════════════════════════════════════════════════════════════
# ConversationTurn.facts field
# ═══════════════════════════════════════════════════════════════════════════════

class TestConversationTurnFacts:
    def test_turn_stores_facts(self):
        facts = [SessionFact(fact_type="rate", content="Rate: $500")]
        turn = ConversationTurn(question="Q?", facts=facts)
        assert len(turn.facts) == 1
        assert turn.facts[0].content == "Rate: $500"

    def test_turn_default_empty_facts(self):
        turn = ConversationTurn(question="Q?")
        assert turn.facts == []



# ═══════════════════════════════════════════════════════════════════════════════
# LLM Coreference with Mock Client
# ═══════════════════════════════════════════════════════════════════════════════

class MockLLMClient:
    """Simulates a fast LLM (Haiku-class) for testing."""
    def __init__(self, responses: dict[str, str] = None):
        self.responses = responses or {}
        self.call_count = 0

    def chat(self, model: str, system: str, user: str, max_tokens: int = 50) -> str:
        self.call_count += 1
        # Return based on keywords in user prompt
        for keyword, response in self.responses.items():
            if keyword.lower() in user.lower():
                return response
        return "NONE"


class TestLLMCoreferenceWithMock:
    def test_llm_resolves_the_one_we_discussed(self):
        """LLM resolves 'the one we discussed' to prior provider."""
        mock_llm = MockLLMClient(responses={"sutter": "Sutter Roseville"})
        cm = ContextManager(spark=None, window_size=5, llm_client=mock_llm)
        cm._provider_cache = [
            {"canonical_name": "Sutter Roseville", "provider_ids": ["P001"], "all_names_used": []},
            {"canonical_name": "Mills Peninsula", "provider_ids": ["P002"], "all_names_used": []},
        ]

        ctx = _make_ctx()
        ctx.conversation_history = [
            ConversationTurn(
                question="Tell me about Sutter Roseville offset clause",
                resolved_entities=[_make_entity("Sutter Roseville")],
            )
        ]

        # "the one we discussed" has no pronoun pattern, but has referential signal
        entities = cm._resolve_coreference_llm("What rates does the one we discussed earlier have?", ctx)
        assert mock_llm.call_count == 1
        assert len(entities) >= 1
        assert entities[0].canonical_form == "Sutter Roseville"
        assert entities[0].resolution_method == "llm_coreference"
        assert entities[0].confidence == 0.80

    def test_llm_not_called_without_referential_signal(self):
        """LLM NOT called for questions without referential signals."""
        mock_llm = MockLLMClient(responses={"sutter": "Sutter Roseville"})
        cm = ContextManager(spark=None, window_size=5, llm_client=mock_llm)

        ctx = _make_ctx()
        ctx.conversation_history = [
            ConversationTurn(
                question="Tell me about Sutter",
                resolved_entities=[_make_entity("Sutter Roseville")],
            )
        ]

        # This question has an explicit provider, no referential signal
        entities = cm._resolve_coreference_llm("What is Mills Peninsula per diem rate?", ctx)
        assert mock_llm.call_count == 0
        assert entities == []

    def test_llm_returns_none_gracefully(self):
        """LLM returning NONE produces empty entity list."""
        mock_llm = MockLLMClient(responses={})  # Returns "NONE" for everything
        cm = ContextManager(spark=None, window_size=5, llm_client=mock_llm)
        cm._provider_cache = [
            {"canonical_name": "Sutter Roseville", "provider_ids": ["P001"], "all_names_used": []},
        ]

        ctx = _make_ctx()
        ctx.conversation_history = [
            ConversationTurn(question="Q1", resolved_entities=[_make_entity("Sutter Roseville")])
        ]

        entities = cm._resolve_coreference_llm("How does the one we discussed compare?", ctx)
        assert mock_llm.call_count == 1
        assert entities == []

    def test_llm_exception_non_fatal(self):
        """LLM exception doesn't crash — returns empty."""
        class FailingLLM:
            def chat(self, **kwargs):
                raise RuntimeError("LLM unavailable")

        cm = ContextManager(spark=None, window_size=5, llm_client=FailingLLM())
        cm._provider_cache = [
            {"canonical_name": "Sutter", "provider_ids": ["P001"], "all_names_used": []},
        ]

        ctx = _make_ctx()
        ctx.conversation_history = [
            ConversationTurn(question="Q1", resolved_entities=[_make_entity("Sutter")])
        ]

        entities = cm._resolve_coreference_llm("What about the one we discussed earlier?", ctx)
        assert entities == []

    def test_llm_coref_integrated_in_resolve_coreferences(self):
        """Full integration: LLM fallback fires when regex finds nothing."""
        mock_llm = MockLLMClient(responses={"mills": "Mills Peninsula"})
        cm = ContextManager(spark=None, window_size=5, llm_client=mock_llm)
        cm._provider_cache = [
            {"canonical_name": "Mills Peninsula", "provider_ids": ["P002"], "all_names_used": []},
        ]

        ctx = _make_ctx()
        ctx.conversation_history = [
            ConversationTurn(
                question="Tell me about Mills Peninsula",
                resolved_entities=[_make_entity("Mills Peninsula")],
            )
        ]

        # "the one we discussed" — no regex match, but LLM resolves it
        entities = cm._resolve_coreferences("What rates does the one we discussed earlier charge?", ctx)
        # Should use LLM fallback since regex won't match "the one we discussed"
        assert any(e.canonical_form == "Mills Peninsula" for e in entities)

    def test_no_history_no_llm_call(self):
        """LLM not called if no conversation history exists."""
        mock_llm = MockLLMClient(responses={"mills": "Mills Peninsula"})
        cm = ContextManager(spark=None, window_size=5, llm_client=mock_llm)

        ctx = _make_ctx()  # Empty history

        entities = cm._resolve_coreference_llm("What about the one we discussed earlier?", ctx)
        assert mock_llm.call_count == 0
        assert entities == []

"""
platform/v4/tests/test_adapters.py

Unit tests for all V3 adapters.

Tests use stub callables injected via set_* methods — no live Spark,
V2 notebook, or retrieval engine required.
"""
import pytest
from unittest.mock import MagicMock

from ..adapters.legacy_branch_adapter import LegacyBranchAdapter, available_branch_tools
from ..adapters.retrieval_adapter import RetrievalAdapter
from ..adapters.citation_adapter import CitationAdapter
from ..adapters.provider_adapter import ProviderAdapter
from ..adapters.benchmark_adapter import BenchmarkAdapter
from ..contracts.tool_types import Confidence, ToolResult


# ---------------------------------------------------------------------------
# LegacyBranchAdapter
# ---------------------------------------------------------------------------

class TestLegacyBranchAdapter:

    def test_stub_when_no_dispatch(self):
        adapter = LegacyBranchAdapter(dispatch_fn=None)
        result  = adapter.call("single_provider", "What is the rate?")
        assert result.success is False
        assert "STUB" in result.summary or "not injected" in (result.error_message or "")

    def test_call_with_stub_dispatch(self):
        dispatch = MagicMock(return_value={"answer": "Rate is $100", "confidence": "HIGH", "citations": []})
        adapter  = LegacyBranchAdapter(dispatch_fn=dispatch)
        result   = adapter.call("single_provider", "What is the rate for Cedars-Sinai?")
        assert result.success is True
        dispatch.assert_called_once()

    def test_unknown_tool_name_returns_error(self):
        adapter = LegacyBranchAdapter(dispatch_fn=MagicMock())
        result  = adapter.call("nonexistent_tool", "question")
        assert result.success is False

    def test_available_branch_tools(self):
        tools = available_branch_tools()
        assert "single_provider" in tools
        assert "rate_query" in tools
        assert "clause_existence" in tools
        assert len(tools) == 8

    def test_describe_returns_metadata(self):
        adapter = LegacyBranchAdapter()
        desc    = adapter.describe()
        assert isinstance(desc, list)
        assert len(desc) == 8
        assert all("tool_name" in d and "nuid" in d for d in desc)

    def test_dispatch_error_handled(self):
        def bad_dispatch(*a, **kw):
            raise RuntimeError("V2 notebook crashed")
        adapter = LegacyBranchAdapter(dispatch_fn=bad_dispatch)
        result  = adapter.call("rate_query", "question")
        assert result.success is False
        assert "RuntimeError" in result.summary or "crashed" in result.summary


# ---------------------------------------------------------------------------
# RetrievalAdapter
# ---------------------------------------------------------------------------

class TestRetrievalAdapter:

    def test_stub_when_no_fn(self):
        adapter = RetrievalAdapter()
        result  = adapter.retrieve("offset clause")
        assert result.success is False
        assert "STUB" in result.summary

    def test_retrieve_with_stub_fn(self):
        retrieve_fn = MagicMock(return_value=[
            {"doc_id": "doc1", "provider_name": "Test", "text": "offset clause text",
             "score": 0.9, "channel": "semantic", "page_number": 5}
        ])
        adapter = RetrievalAdapter(retrieve_fn=retrieve_fn)
        result  = adapter.retrieve("offset clause", top_k=5)
        assert result.success is True
        assert len(result.data) == 1
        assert result.data[0].doc_id == "doc1"

    def test_empty_results_returns_low_confidence(self):
        adapter = RetrievalAdapter(retrieve_fn=lambda *a, **kw: [])
        result  = adapter.retrieve("obscure query")
        assert result.success is True
        assert result.confidence == Confidence.LOW


# ---------------------------------------------------------------------------
# CitationAdapter
# ---------------------------------------------------------------------------

class TestCitationAdapter:

    def test_stub_when_no_fn(self):
        adapter = CitationAdapter()
        result  = adapter.verify([{"doc_id": "d1", "text": "test text", "page_number": 1}])
        assert result.success is True   # stub returns UNVERIFIED, not failure
        assert "STUB" in result.summary or "unverified" in result.summary.lower()

    def test_empty_passages_returns_success(self):
        adapter = CitationAdapter()
        result  = adapter.verify([])
        assert result.success is True

    def test_verify_with_stub_fn(self):
        verify_fn = MagicMock(return_value={
            "status": "VERIFIED",
            "citations": [{"doc_id": "d1", "status": "VERIFIED", "grounded": True}],
        })
        adapter = CitationAdapter(verify_fn=verify_fn)
        result  = adapter.verify([{"doc_id": "d1", "text": "text"}])
        assert result.success is True
        assert result.confidence == Confidence.HIGH


# ---------------------------------------------------------------------------
# ProviderAdapter
# ---------------------------------------------------------------------------

class TestProviderAdapter:

    def test_stub_when_no_spark(self):
        adapter = ProviderAdapter(spark=None)
        result  = adapter.resolve("Cedars-Sinai")
        assert result.success is False
        assert "STUB" in result.summary or "None" in (result.error_message or "")

    def test_cache_hit(self):
        from ..adapters.provider_adapter import CanonicalProvider
        cp      = CanonicalProvider("cs001", "Cedars-Sinai Medical Center")
        adapter = ProviderAdapter(spark=None, cache={"cedars sinai medical center": cp})
        result  = adapter.resolve("Cedars-Sinai Medical Center")
        assert result.success is True
        assert result.data.canonical_name == "Cedars-Sinai Medical Center"

    def test_empty_provider_name(self):
        adapter = ProviderAdapter(spark=None)
        # resolve with empty string — should fail gracefully
        result  = adapter.resolve("")
        # May succeed with error or return no result, but should not raise
        assert isinstance(result, ToolResult)


# ---------------------------------------------------------------------------
# BenchmarkAdapter
# ---------------------------------------------------------------------------

class TestBenchmarkAdapter:

    def test_stub_when_no_spark(self):
        adapter = BenchmarkAdapter(spark=None)
        result  = adapter.get_percentile("Test Hospital")
        assert result.success is False
        assert "STUB" in result.summary

    def test_execute_with_spark_stub(self):
        spark = MagicMock()
        df    = MagicMock()
        df.collect.return_value = [
            MagicMock(asDict=lambda: {
                "provider_name": "Test Hospital",
                "benchmark_group": "general_acute",
                "rate_percentile": 0.65,
                "n_peers": 45,
                "effective_date": "2024-01-01",
            })
        ]
        spark.sql.return_value = df
        adapter = BenchmarkAdapter(spark=spark)
        result  = adapter.get_percentile("Test Hospital")
        assert result.success is True
        assert len(result.data) == 1
        assert result.data[0]["rate_percentile"] == 0.65

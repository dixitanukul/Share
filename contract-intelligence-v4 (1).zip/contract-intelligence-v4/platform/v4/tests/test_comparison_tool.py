"""Tests for ComparisonTool (P4C-COMP)."""
from __future__ import annotations

from collections import OrderedDict
import pandas as pd
import pytest

from platform.v4.tools.comparison import ComparisonTool
from platform.v4.contracts.tool_types import Confidence, ToolStatus


# ── Mock helpers ─────────────────────────────────────────────────────────────

class MockDF:
    def __init__(self, pdf):
        self._pdf = pdf
    def toPandas(self):
        return self._pdf


class MockSpark:
    def __init__(self, patterns: "OrderedDict"):
        self._patterns = patterns

    def sql(self, query: str) -> MockDF:
        for pattern, pdf in self._patterns.items():
            if pattern in query:
                return MockDF(pdf)
        return MockDF(pd.DataFrame())


class MockProviderService:
    def __init__(self, names=None, resolution=None):
        self._names = names or ["Sutter Health", "Kaiser Permanente", "Providence Health"]
        self._resolution = resolution or {}

    def all_names(self):
        return self._names

    def resolve(self, name: str):
        if name in self._resolution:
            return self._resolution[name]
        return ([name], "unresolved", [])


class MockLLMClient:
    def __init__(self, response="Comparative analysis text."):
        self._response = response
        self.calls = []

    def chat(self, model, system, user, max_tokens, temperature=0.0):
        self.calls.append(user[:80])
        return self._response


PROFILE_ROWS = pd.DataFrame({
    "agreement_type": ["Hospital Agreement"],
    "total_rates": [42],
    "total_amendments": [5],
    "avg_inpatient_per_diem": [3200.0],
    "latest_amendment_date": ["2024-01-15"],
})

RATES_ROWS = pd.DataFrame({
    "rate_category": ["inpatient", "outpatient"],
    "count": [20, 22],
    "avg_rate": [3200.0, 850.0],
    "max_rate": [4500.0, 1200.0],
})

AMENDMENT_ROWS = pd.DataFrame({"cnt": [7]})

TERMS_ROWS = pd.DataFrame({
    "title": ["Offset Provision"],
    "content_text": ["Provider agrees to offset amounts owed against future payments."],
})


def make_tool(extra_patterns=None, resolution=None, llm_response=None):
    base = OrderedDict([
        ("tbl_genie_provider_profile", PROFILE_ROWS),
        ("tbl_genie_rates_current", RATES_ROWS),
        ("tbl_genie_amendment_timeline", AMENDMENT_ROWS),
        ("vw_genie_contract_terms", TERMS_ROWS),
    ])
    if extra_patterns:
        base.update(extra_patterns)
    spark = MockSpark(base)
    ps = MockProviderService(resolution=resolution or {})
    llm = MockLLMClient(response=llm_response) if llm_response is not None else None
    return ComparisonTool(spark=spark, provider_service=ps, llm_client=llm)


# ── Init ─────────────────────────────────────────────────────────────────────

class TestComparisonToolInit:
    def test_name(self):
        t = ComparisonTool(spark=None, provider_service=MockProviderService())
        assert t.name == "comparison"

    def test_not_adapter_backed(self):
        t = ComparisonTool(spark=None, provider_service=MockProviderService())
        assert t.is_adapter_backed is False

    def test_optional_deps_default_none(self):
        t = ComparisonTool(spark=None, provider_service=MockProviderService())
        assert t._retrieval_service is None
        assert t._llm_client is None


# ── Validation ────────────────────────────────────────────────────────────────

class TestComparisonToolValidation:
    def test_requires_question(self):
        t = ComparisonTool(spark=None, provider_service=MockProviderService())
        errors = t.validate_inputs()
        assert errors

    def test_passes_with_question(self):
        t = ComparisonTool(spark=None, provider_service=MockProviderService())
        errors = t.validate_inputs(question="Compare Sutter vs Kaiser")
        assert errors == []


# ── Provider extraction ───────────────────────────────────────────────────────

class TestProviderExtraction:
    def test_extracts_multiple_providers(self):
        t = ComparisonTool(
            spark=None,
            provider_service=MockProviderService(names=["Sutter Health", "Kaiser Permanente"]),
        )
        providers = t._extract_providers("Compare Sutter Health vs Kaiser Permanente on termination")
        assert "Sutter Health" in providers
        assert "Kaiser Permanente" in providers

    def test_longest_match_wins(self):
        t = ComparisonTool(
            spark=None,
            provider_service=MockProviderService(names=["Sutter", "Sutter Health"]),
        )
        providers = t._extract_providers("Compare Sutter Health contracts")
        assert "Sutter Health" in providers
        assert "Sutter" not in providers or providers.index("Sutter Health") < providers.index("Sutter")

    def test_no_match_returns_empty(self):
        t = ComparisonTool(spark=None, provider_service=MockProviderService())
        providers = t._extract_providers("Compare two providers on cost")
        assert providers == []


# ── Concept extraction ────────────────────────────────────────────────────────

class TestConceptExtraction:
    def setup_method(self):
        self.tool = ComparisonTool(spark=None, provider_service=MockProviderService())

    def test_on_pattern(self):
        c = self.tool._extract_concept("Compare Sutter vs Kaiser on termination clause")
        assert c == "termination clause"

    def test_returns_none_when_no_match(self):
        c = self.tool._extract_concept("Compare Sutter vs Kaiser")
        assert c is None


# ── Fetch profile ─────────────────────────────────────────────────────────────

class TestFetchProfile:
    def test_returns_profile_dict(self):
        t = make_tool()
        profile = t._fetch_profile("Sutter Health", None)
        assert profile.get("agreement_type") == "Hospital Agreement"

    def test_with_prov_filter(self):
        captured = []
        class CaptureSpark:
            def sql(self, q):
                captured.append(q)
                return MockDF(PROFILE_ROWS)
        t = ComparisonTool(spark=CaptureSpark(), provider_service=MockProviderService())
        t._fetch_profile("Sutter", "provider_id IN ('p1')")
        assert "provider_id IN" in captured[0]

    def test_exception_returns_empty(self):
        class BrokenSpark:
            def sql(self, q):
                raise RuntimeError("error")
        t = ComparisonTool(spark=BrokenSpark(), provider_service=MockProviderService())
        assert t._fetch_profile("X", None) == {}


# ── Fetch rates ───────────────────────────────────────────────────────────────

class TestFetchRates:
    def test_returns_rates_list(self):
        t = make_tool()
        rates = t._fetch_rates("Sutter Health", None)
        assert len(rates) == 2
        categories = [r["rate_category"] for r in rates]
        assert "inpatient" in categories

    def test_exception_returns_empty(self):
        class BrokenSpark:
            def sql(self, q):
                raise RuntimeError("error")
        t = ComparisonTool(spark=BrokenSpark(), provider_service=MockProviderService())
        assert t._fetch_rates("X", None) == []


# ── Fetch amendment count ─────────────────────────────────────────────────────

class TestFetchAmendmentCount:
    def test_returns_integer(self):
        t = make_tool()
        count = t._fetch_amendment_count("Sutter Health", None)
        assert count == 7

    def test_exception_returns_zero(self):
        class BrokenSpark:
            def sql(self, q):
                raise RuntimeError("error")
        t = ComparisonTool(spark=BrokenSpark(), provider_service=MockProviderService())
        assert t._fetch_amendment_count("X", None) == 0


# ── Fetch concept passages ────────────────────────────────────────────────────

class TestFetchConceptPassages:
    def test_returns_passages(self):
        t = make_tool()
        passages = t._fetch_concept_passages("offset", "Sutter", None)
        assert len(passages) == 1
        assert "title" in passages[0]
        assert "text" in passages[0]

    def test_with_prov_filter(self):
        captured = []
        class CaptureSpark:
            def sql(self, q):
                captured.append(q)
                return MockDF(TERMS_ROWS)
        t = ComparisonTool(spark=CaptureSpark(), provider_service=MockProviderService())
        t._fetch_concept_passages("offset", "Sutter", "provider_id = 'p1'")
        assert "provider_id" in captured[0]


# ── Full _run ─────────────────────────────────────────────────────────────────

class TestComparisonToolRun:
    def test_too_few_providers_returns_error(self):
        t = make_tool()
        result = t._run("Compare Sutter", providers=["Sutter"])
        assert not result.success

    def test_successful_comparison(self):
        t = make_tool()
        result = t._run("?", providers=["Sutter Health", "Kaiser Permanente"])
        assert result.success
        assert result.status == ToolStatus.SUCCESS
        assert len(result.data["providers"]) == 2
        assert "rate_categories" in result.data

    def test_rate_categories_union(self):
        t = make_tool()
        result = t._run("?", providers=["Sutter Health", "Kaiser Permanente"])
        cats = result.data["rate_categories"]
        assert "inpatient" in cats
        assert "outpatient" in cats

    def test_with_concept_and_llm(self):
        t = make_tool(llm_response="Comparative LLM analysis.")
        result = t._run(
            "Compare Sutter vs Kaiser on offset clause",
            providers=["Sutter Health", "Kaiser Permanente"],
            concept="offset clause",
        )
        assert result.data["llm_summary"] == "Comparative LLM analysis."

    def test_no_llm_no_summary(self):
        t = make_tool()
        result = t._run("?", providers=["Sutter Health", "Kaiser"], concept="offset")
        assert result.data["llm_summary"] == ""

    def test_snapshots_structure(self):
        t = make_tool()
        result = t._run("?", providers=["Sutter Health", "Kaiser Permanente"])
        for name in result.data["providers"]:
            snap = result.data["snapshots"][name]
            assert "profile" in snap
            assert "rates" in snap
            assert "amendment_count" in snap

    def test_caps_at_four_providers(self):
        t = make_tool()
        providers = ["P1", "P2", "P3", "P4", "P5"]
        result = t._run("?", providers=providers)
        assert len(result.data["providers"]) <= 4

    def test_provider_resolution_applied(self):
        resolution = {
            "Sutter": (["Sutter Health System"], "canonical_exact", ["p001"]),
            "Kaiser": (["Kaiser Permanente"], "canonical_exact", ["p002"]),
        }
        t = make_tool(resolution=resolution)
        result = t._run("?", providers=["Sutter", "Kaiser"])
        assert "Sutter Health System" in result.data["providers"]

    def test_high_confidence_when_rates_available(self):
        t = make_tool()
        result = t._run("?", providers=["Sutter Health", "Kaiser Permanente"])
        assert result.confidence == Confidence.HIGH

    def test_low_confidence_when_no_rates(self):
        patterns = OrderedDict([
            ("tbl_genie_provider_profile", PROFILE_ROWS),
            ("tbl_genie_rates_current", pd.DataFrame()),
            ("tbl_genie_amendment_timeline", AMENDMENT_ROWS),
        ])
        t = ComparisonTool(
            spark=MockSpark(patterns),
            provider_service=MockProviderService(),
            llm_client=None,
        )
        result = t._run("?", providers=["P1", "P2"])
        assert result.confidence == Confidence.LOW

"""
platform/v4/tests/test_genie_tool.py

W9-36: Unit tests for GenieQueryTool and GenieClient.

All 22 tests run without a live Databricks workspace or requests library --
GenieClient is replaced with mock objects throughout.
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch

from platform.v4.tools.genie_query import (
    GenieQueryTool, GenieClient, GENIE_SPACE_ID_BSC,
)
from platform.v4.contracts.tool_types import Confidence, ToolResult, ToolStatus
from platform.v4.tools.registry import ToolRegistry
from platform.v4.config.settings import Settings


# ============================================================================
# Mock helpers
# ============================================================================

def _mock_client(
    answer: str = "The average per-diem rate is $1,500.",
    sql: str = "SELECT AVG(rate) FROM rates_current WHERE is_current_effective",
    data: list | None = None,
    error: str | None = None,
) -> MagicMock:
    """Return a mock GenieClient.query() that returns a scripted result."""
    client = MagicMock(spec=GenieClient)
    if error is not None:
        client.query.return_value = {"error": error}
    else:
        client.query.return_value = {
            "answer":          answer,
            "sql":             sql,
            "data":            data or [],
            "message_id":      "msg-001",
            "conversation_id": "conv-001",
        }
    return client


def _tool(
    client=None,
    space_id: str = "",
) -> GenieQueryTool:
    return GenieQueryTool(
        genie_client=client,
        space_id=space_id or GENIE_SPACE_ID_BSC,
    )


# ============================================================================
# Category 1: GenieQueryTool -- happy path (5 tests)
# ============================================================================

class TestGenieQueryToolHappyPath:

    def test_successful_query_returns_success_result(self):
        tool   = _tool(client=_mock_client())
        result = tool(question="What is the average per-diem rate?")
        assert isinstance(result, ToolResult)
        assert result.success is True
        assert result.status == ToolStatus.SUCCESS

    def test_answer_in_data_and_summary(self):
        answer = "Average rate is $1,500."
        tool   = _tool(client=_mock_client(answer=answer))
        result = tool(question="Average per-diem?")
        assert result.data["answer"] == answer
        assert answer[:30] in result.summary

    def test_sql_in_result_data(self):
        sql  = "SELECT AVG(rate) FROM rates_current"
        tool = _tool(client=_mock_client(sql=sql))
        result = tool(question="Average rate query")
        assert result.data["sql"] == sql
        assert "[SQL]" in result.summary

    def test_confidence_high_when_answer_and_sql(self):
        """answer + sql => HIGH confidence."""
        tool   = _tool(client=_mock_client(
            answer="Rate is $1,500.", sql="SELECT avg_rate FROM ..."))
        result = tool(question="Average per-diem?")
        assert result.confidence == Confidence.HIGH

    def test_confidence_moderate_when_answer_only(self):
        tool   = _tool(client=_mock_client(answer="Rate is $1,500.", sql=""))
        result = tool(question="Average per-diem?")
        assert result.confidence == Confidence.MODERATE

    def test_space_id_override_passed_to_client(self):
        """Custom space_id should be forwarded to client.query()."""
        client = _mock_client()
        custom_space = "custom-space-uuid-123"
        tool   = _tool(client=client, space_id=custom_space)
        tool(question="Provider count?")
        client.query.assert_called_once_with(
            space_id=custom_space, question="Provider count?"
        )

    def test_default_space_id_is_bsc_production(self):
        """Default space_id should be the BSC production Genie Space."""
        client = _mock_client()
        tool   = _tool(client=client)
        tool(question="Test?")
        args = client.query.call_args
        assert args.kwargs["space_id"] == GENIE_SPACE_ID_BSC


# ============================================================================
# Category 2: GenieQueryTool -- error and edge cases (8 tests)
# ============================================================================

class TestGenieQueryToolErrorPaths:

    def test_no_client_returns_error_result(self):
        """No injected client => ToolResult(success=False)."""
        tool   = _tool(client=None)
        result = tool(question="What is the average rate?")
        assert result.success is False
        assert result.status == ToolStatus.ERROR
        assert "genie_client not configured" in result.error_message

    def test_genie_api_error_propagated(self):
        """GenieClient returning error => ToolResult(success=False)."""
        tool   = _tool(client=_mock_client(error="Genie space unavailable"))
        result = tool(question="Any question")
        assert result.success is False
        assert result.status == ToolStatus.ERROR
        assert "Genie space unavailable" in result.error_message

    def test_empty_answer_and_data_returns_empty_status(self):
        """Genie returns blank answer + no data => EMPTY status, success=True."""
        tool   = _tool(client=_mock_client(answer="", sql="", data=[]))
        result = tool(question="Unknown metric?")
        assert result.success is True
        assert result.status == ToolStatus.EMPTY

    def test_empty_question_fails_validation(self):
        tool   = _tool(client=_mock_client())
        result = tool(question="")
        assert result.success is False
        assert result.status == ToolStatus.ERROR
        assert "question is required" in result.summary

    def test_whitespace_only_question_fails_validation(self):
        tool   = _tool(client=_mock_client())
        result = tool(question="   ")
        assert result.success is False
        assert "question is required" in result.summary

    def test_question_too_long_fails_validation(self):
        tool   = _tool(client=_mock_client())
        long_q = "a" * 2001
        result = tool(question=long_q)
        assert result.success is False
        assert "2,000" in result.summary

    def test_question_exactly_2000_chars_passes_validation(self):
        """Boundary: 2000 chars is within limit."""
        tool   = _tool(client=_mock_client(answer="Ok."))
        result = tool(question="x" * 2000)
        assert result.success is True

    def test_no_space_id_configured_returns_error(self):
        tool = GenieQueryTool(genie_client=_mock_client(), space_id="")
        # Force space_id to empty after construction
        tool._space_id = ""
        result = tool._run(question="Rate query?", space_id="")
        assert result.success is False
        assert "space_id not configured" in result.error_message


# ============================================================================
# Category 3: ToolResult structure invariants (4 tests)
# ============================================================================

class TestGenieQueryToolResultStructure:

    def test_result_data_contains_required_keys(self):
        tool   = _tool(client=_mock_client())
        result = tool(question="Rate query?")
        assert isinstance(result.data, dict)
        for key in ("answer", "sql", "rows", "space_id", "conversation_id"):
            assert key in result.data, f"Missing key: {key}"

    def test_result_metadata_contains_message_and_space(self):
        tool   = _tool(client=_mock_client())
        result = tool(question="Rate query?")
        assert "message_id" in result.metadata
        assert "space_id"   in result.metadata

    def test_cost_estimate_set(self):
        tool   = _tool(client=_mock_client())
        result = tool(question="Rate query?")
        assert result.cost_estimate >= 0.0

    def test_set_client_replaces_injected_client(self):
        """set_client() hot-reload path."""
        tool = _tool(client=None)
        assert tool._client is None
        new_client = _mock_client(answer="Hot-reloaded answer.")
        tool.set_client(new_client)
        result = tool(question="Hot-reload test?")
        assert result.success is True


# ============================================================================
# Category 4: ToolRegistry + policy integration (3 tests)
# ============================================================================

class TestGenieQueryToolRegistryIntegration:

    def test_tool_registers_in_registry(self):
        registry = ToolRegistry()
        registry.register(GenieQueryTool(genie_client=_mock_client()))
        assert "genie_query" in registry.list_tools()

    def test_policy_requires_genie_enabled_flag(self):
        """Without GENIE_ENABLED flag, registry returns skipped ToolResult."""
        registry = ToolRegistry(feature_flags={"GENIE_ENABLED": False})
        registry.register(GenieQueryTool(genie_client=_mock_client()))
        result = registry.call("genie_query", question="Rate query?")
        assert result.success is False
        assert result.status == ToolStatus.SKIPPED

    def test_policy_allows_call_with_genie_enabled(self):
        """With GENIE_ENABLED=True, the tool call goes through."""
        registry = ToolRegistry(feature_flags={"GENIE_ENABLED": True})
        registry.register(GenieQueryTool(genie_client=_mock_client(
            answer="Rate is $1,500.", sql="SELECT rate")))
        result = registry.call("genie_query", question="Average rate?")
        assert result.success is True


# ============================================================================
# Category 5: Settings and GenieClient surface (3 tests)
# ============================================================================

class TestGenieSettingsAndClient:

    def test_settings_genie_disabled_by_default(self):
        s = Settings()
        assert s.GENIE_ENABLED is False

    def test_settings_genie_space_id_set(self):
        s = Settings()
        assert s.GENIE_SPACE_ID == GENIE_SPACE_ID_BSC

    def test_settings_get_all_flags_includes_genie(self):
        s = Settings()
        flags = s.get_all_flags()
        assert "GENIE_ENABLED" in flags
        assert flags["GENIE_ENABLED"] is False

    def test_genie_client_init_stores_base_url(self):
        """GenieClient strips trailing slash from workspace_url."""
        client = GenieClient(
            workspace_url="https://adb-123.azuredatabricks.net/",
            api_token="dapi-test",
        )
        assert not client._base.endswith("/")
        assert "azuredatabricks.net" in client._base

"""
platform/v4/tests/test_context_manager_v2.py

W9-21: Unit tests for ContextManager v2 features:
  - Coreference resolution (pronouns/anaphora → canonical providers)
  - Sliding window for multi-turn conversations
  - continue_session() workflow
  - Implicit carryforward for follow-up questions

No live Spark required — uses pre-populated caches.
"""
import pytest

from ..core.context_manager import ContextManager
from ..contracts.context_types import (
    SessionContext, ConversationTurn, ResolvedEntity, WorkingData,
)
from ..contracts.agent_types import AgentRequest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_manager(window_size: int = 5) -> ContextManager:
    """Create a ContextManager with pre-populated provider cache."""
    cm = ContextManager(spark=None, window_size=window_size)
    cm._provider_cache = [
        {
            "canonical_name": "Cedars-Sinai Medical Center",
            "provider_ids": ["cs001"],
            "all_names_used": ["cedars", "cedars-sinai", "cedars sinai"],
        },
        {
            "canonical_name": "Kaiser Permanente",
            "provider_ids": ["k001"],
            "all_names_used": ["kaiser"],
        },
        {
            "canonical_name": "St. John's Regional Medical Center",
            "provider_ids": ["sj001"],
            "all_names_used": ["st john", "st johns"],
        },
    ]
    return cm


def _make_ctx_with_provider_history(provider_name: str = "Cedars-Sinai Medical Center",
                                     provider_id: str = "cs001") -> SessionContext:
    """Create a SessionContext with one prior turn mentioning a provider."""
    provider_entity = ResolvedEntity(
        raw_mention="Cedars-Sinai",
        canonical_form=provider_name,
        entity_type="provider",
        provider_ids=[provider_id],
        confidence=1.0,
        resolution_method="exact",
    )
    ctx = SessionContext(
        session_id="test-session",
        question="What is the offset clause for Cedars-Sinai?",
        turn_count=1,
        resolved_entities=[provider_entity],
    )
    prior_turn = ConversationTurn(
        question="Tell me about Cedars-Sinai",
        answer_preview="Cedars-Sinai has an offset clause allowing recoupment...",
        resolved_entities=[
            ResolvedEntity(
                raw_mention="Cedars-Sinai",
                canonical_form=provider_name,
                entity_type="provider",
                provider_ids=[provider_id],
                confidence=1.0,
                resolution_method="exact",
            )
        ],
    )
    ctx.conversation_history = [prior_turn]
    return ctx


# ---------------------------------------------------------------------------
# TestCoreferenceResolution
# ---------------------------------------------------------------------------

class TestCoreferenceResolution:
    """Tests for pronoun/anaphora resolution from conversation history."""

    def test_their_resolves_to_last_provider(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "What about their stop loss?")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_them_resolves_to_last_provider(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "Show rates for them")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_that_hospital_resolves(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "Does that hospital have a DOFR?")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_that_provider_resolves(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "Show me that provider's rates")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_this_facility_resolves(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "Is this facility in network?")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_same_provider_resolves(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "Show me same provider capitation")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_explicit_different_provider_blocks_carryforward(self):
        """When question names a different provider, implicit carryforward should not fire."""
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "What is Kaiser Permanente's offset?")
        # _extract_provider_mentions detects Kaiser in the question text,
        # which blocks implicit_carryforward of Cedars. Kaiser itself isn't
        # resolved as an entity by _extract_from_question (which only scans concepts),
        # but the key behavior is: no Cedars carryforward.
        coref_cedars = [
            e for e in new_ctx.resolved_entities
            if e.canonical_form == "Cedars-Sinai Medical Center"
            and e.resolution_method == "implicit_carryforward"
        ]
        assert len(coref_cedars) == 0

    def test_no_history_no_coref(self):
        """Without conversation history, pronouns should not resolve."""
        cm = _make_manager()
        ctx = SessionContext(session_id="test", question="initial")
        # No history
        new_ctx = cm.continue_session(ctx, "What about their stop loss?")
        # May resolve empty or not at all
        assert len(new_ctx.get_providers()) == 0

    def test_coref_confidence_below_exact(self):
        """Coreference resolution should have lower confidence than exact match."""
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "What about their rates?")
        # Find the coref-resolved entity
        coref_entities = [
            e for e in new_ctx.resolved_entities
            if e.resolution_method in ("coreference", "implicit_carryforward")
        ]
        assert len(coref_entities) >= 1
        assert all(e.confidence < 1.0 for e in coref_entities)


# ---------------------------------------------------------------------------
# TestImplicitCarryforward
# ---------------------------------------------------------------------------

class TestImplicitCarryforward:
    """Tests for implicit provider carryforward on short follow-up questions."""

    def test_short_followup_carries_provider(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "Show me rates")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_what_about_carries_provider(self):
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        new_ctx = cm.continue_session(ctx, "What about DOFR?")
        assert "Cedars-Sinai Medical Center" in new_ctx.get_providers()

    def test_long_independent_question_no_carryforward(self):
        """A long, independent question without pronouns should not carryforward."""
        cm = _make_manager()
        ctx = _make_ctx_with_provider_history()
        # Long question with no pronouns or follow-up markers — and no known provider
        new_ctx = cm.continue_session(
            ctx,
            "List all providers in the network that have capitation rates above $500 per member per month"
        )
        # Should not carry forward Cedars from history for this independent question
        coref = [e for e in new_ctx.resolved_entities if e.resolution_method == "implicit_carryforward"]
        assert len(coref) == 0


# ---------------------------------------------------------------------------
# TestSlidingWindow
# ---------------------------------------------------------------------------

class TestSlidingWindow:
    """Tests for multi-turn conversation history management."""

    def test_continue_records_prior_turn(self):
        cm = _make_manager()
        ctx = SessionContext(session_id="test", question="Q0", turn_count=0)
        ctx.resolved_entities = [
            ResolvedEntity("offset", "offset_clause", "concept", confidence=1.0)
        ]
        new_ctx = cm.continue_session(ctx, "Q1", prev_answer="Answer to Q0")
        assert len(new_ctx.conversation_history) == 1
        assert new_ctx.conversation_history[0].question == "Q0"
        assert new_ctx.conversation_history[0].answer_preview == "Answer to Q0"

    def test_window_eviction_at_limit(self):
        """Window of size 3 should evict oldest turns beyond limit."""
        cm = _make_manager(window_size=3)
        ctx = SessionContext(session_id="test", question="Q0")
        # Simulate 5 turns
        for i in range(5):
            ctx = cm.continue_session(ctx, f"Q{i+1}", prev_answer=f"A{i}")
        # Window size 3 => at most 3 turns in history
        assert len(ctx.conversation_history) <= 3

    def test_recent_turns_preserved_after_eviction(self):
        """Most recent turns should survive eviction."""
        cm = _make_manager(window_size=3)
        ctx = SessionContext(session_id="test", question="Q0")
        for i in range(6):
            ctx = cm.continue_session(ctx, f"Q{i+1}", prev_answer=f"A{i}")
        questions = [t.question for t in ctx.conversation_history]
        # The last recorded question should be in history
        assert "Q5" in questions

    def test_turn_count_increments(self):
        cm = _make_manager()
        ctx = SessionContext(session_id="test", question="Q0", turn_count=0)
        ctx = cm.continue_session(ctx, "Q1")
        assert ctx.turn_count == 1
        ctx = cm.continue_session(ctx, "Q2")
        assert ctx.turn_count == 2
        ctx = cm.continue_session(ctx, "Q3")
        assert ctx.turn_count == 3

    def test_working_data_reset_on_continue(self):
        """continue_session should reset working_data for the new turn."""
        cm = _make_manager()
        ctx = SessionContext(session_id="test", question="Q0")
        ctx.working_data.sql_results = [{"dummy": True}]
        ctx.working_data.passages = [{"text": "hello"}]
        ctx = cm.continue_session(ctx, "Q1")
        assert ctx.working_data.sql_results == []
        assert ctx.working_data.passages == []
        assert not ctx.working_data.has_data()

    def test_resolved_entities_reset_on_continue(self):
        """Prior turn's resolved entities are recorded in history, then cleared."""
        cm = _make_manager()
        ctx = SessionContext(session_id="test", question="Q0")
        ctx.resolved_entities = [
            ResolvedEntity("test", "Test Provider", "provider", ["t1"], 1.0, "exact")
        ]
        ctx = cm.continue_session(ctx, "Q1")
        # Prior entities should be in history
        assert len(ctx.conversation_history[0].resolved_entities) == 1
        # Current turn entities should NOT include the prior turn's exact entity
        # (unless coref resolves it)
        prior_exact = [e for e in ctx.resolved_entities if e.resolution_method == "exact" and e.raw_mention == "test"]
        assert len(prior_exact) == 0


# ---------------------------------------------------------------------------
# TestConversationTurn
# ---------------------------------------------------------------------------

class TestConversationTurn:
    """Tests for the ConversationTurn dataclass."""

    def test_get_providers(self):
        turn = ConversationTurn(
            question="test",
            resolved_entities=[
                ResolvedEntity("A", "Provider A", "provider"),
                ResolvedEntity("B", "Concept B", "concept"),
                ResolvedEntity("C", "Provider C", "provider"),
            ],
        )
        assert turn.get_providers() == ["Provider A", "Provider C"]

    def test_get_concepts(self):
        turn = ConversationTurn(
            question="test",
            resolved_entities=[
                ResolvedEntity("offset", "offset_clause", "concept"),
                ResolvedEntity("P", "Provider P", "provider"),
            ],
        )
        assert turn.get_concepts() == ["offset_clause"]

    def test_empty_entities(self):
        turn = ConversationTurn(question="test")
        assert turn.get_providers() == []
        assert turn.get_concepts() == []


# ---------------------------------------------------------------------------
# TestSessionContextHistoryHelpers
# ---------------------------------------------------------------------------

class TestSessionContextHistoryHelpers:
    """Tests for last_providers / last_concepts on SessionContext."""

    def test_last_providers_single_turn(self):
        ctx = SessionContext(session_id="test", question="current")
        ctx.conversation_history = [
            ConversationTurn(
                question="Q1",
                resolved_entities=[ResolvedEntity("A", "Provider A", "provider", ["a1"])],
            ),
        ]
        assert ctx.last_providers(n_turns=1) == ["Provider A"]

    def test_last_providers_multiple_turns(self):
        ctx = SessionContext(session_id="test", question="current")
        ctx.conversation_history = [
            ConversationTurn(
                question="Q1",
                resolved_entities=[ResolvedEntity("A", "Provider A", "provider", ["a1"])],
            ),
            ConversationTurn(
                question="Q2",
                resolved_entities=[ResolvedEntity("B", "Provider B", "provider", ["b1"])],
            ),
        ]
        # n_turns=1 should get only most recent
        assert ctx.last_providers(n_turns=1) == ["Provider B"]
        # n_turns=2 should get both (most recent first)
        result = ctx.last_providers(n_turns=2)
        assert "Provider B" in result
        assert "Provider A" in result

    def test_last_concepts_multiple_turns(self):
        ctx = SessionContext(session_id="test", question="current")
        ctx.conversation_history = [
            ConversationTurn(
                question="Q1",
                resolved_entities=[ResolvedEntity("x", "offset_clause", "concept")],
            ),
            ConversationTurn(
                question="Q2",
                resolved_entities=[ResolvedEntity("y", "dofr", "concept")],
            ),
        ]
        result = ctx.last_concepts(n_turns=2)
        assert "dofr" in result
        assert "offset_clause" in result

    def test_empty_history_returns_empty_lists(self):
        ctx = SessionContext(session_id="test", question="current")
        assert ctx.last_providers() == []
        assert ctx.last_concepts() == []

    def test_deduplication_in_last_providers(self):
        """Same provider in multiple turns should appear once."""
        ctx = SessionContext(session_id="test", question="current")
        ctx.conversation_history = [
            ConversationTurn(
                question="Q1",
                resolved_entities=[ResolvedEntity("A", "Provider A", "provider", ["a1"])],
            ),
            ConversationTurn(
                question="Q2",
                resolved_entities=[ResolvedEntity("A", "Provider A", "provider", ["a1"])],
            ),
        ]
        result = ctx.last_providers(n_turns=2)
        assert result.count("Provider A") == 1

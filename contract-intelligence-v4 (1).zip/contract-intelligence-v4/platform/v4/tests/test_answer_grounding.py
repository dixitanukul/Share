"""Tests for platform/v4/services/answer_grounding.py (Step 1.6).

Covers answer grounding enforcement — the BUG-009 fix that prevents
ungrounded answers from being returned to users.

Test categories:
  1. Grounded answers (structured data satisfies grounding)
  2. Grounded answers (passage relevance satisfies grounding)
  3. Ungrounded refusals (no evidence gathered)
  4. Ungrounded refusals (passages below threshold)
  5. Mixed scenarios (structured data + weak passages)
  6. Edge cases (empty inputs, missing fields, malformed data)
  7. should_refuse_at_max_steps convenience API
  8. Custom configuration (thresholds, messages)
  9. Passage extraction from tool results

Uses importlib pattern for standalone execution (avoids platform namespace conflict).
"""
import importlib.util
import os
import sys
import types
from dataclasses import dataclass, field
from typing import Any, Optional

import pytest

# ============================================================
# MODULE LOADING (standalone-compatible)
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..")
)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Load text_utils directly (dependency of answer_grounding)
_text_utils_path = os.path.join(
    PROJECT_ROOT, "platform", "v4", "services", "text_utils.py"
)
_text_utils_spec = importlib.util.spec_from_file_location(
    "text_utils", _text_utils_path
)
_text_utils_mod = importlib.util.module_from_spec(_text_utils_spec)
sys.modules["text_utils"] = _text_utils_mod
_text_utils_spec.loader.exec_module(_text_utils_mod)

# Load the module under test — patch the relative import to resolve to our loaded text_utils
_ag_path = os.path.join(
    PROJECT_ROOT, "platform", "v4", "services", "answer_grounding.py"
)

# Read the source and replace the relative import for standalone loading
_ag_source = open(_ag_path).read()
_ag_source_patched = _ag_source.replace(
    "from .text_utils import extract_keywords, score_passage",
    "from text_utils import extract_keywords, score_passage",
)

# Compile and execute in a fresh module
_ag_mod = types.ModuleType("answer_grounding")
_ag_mod.__file__ = _ag_path
_ag_mod.__package__ = "answer_grounding"
sys.modules["answer_grounding"] = _ag_mod
exec(compile(_ag_source_patched, _ag_path, "exec"), _ag_mod.__dict__)

AnswerGroundingEnforcer = _ag_mod.AnswerGroundingEnforcer
GroundingDecision = _ag_mod.GroundingDecision
REFUSAL_MESSAGE = _ag_mod.REFUSAL_MESSAGE
RELEVANCE_SCORE_THRESHOLD = _ag_mod.RELEVANCE_SCORE_THRESHOLD


# ============================================================
# TEST FIXTURES
# ============================================================


@dataclass
class MockToolResult:
    """Mimics ToolResult from contracts.tool_types."""
    success: bool = True
    data: Any = None
    summary: str = ""
    citations: list = field(default_factory=list)
    confidence: str = "MODERATE"
    metadata: dict = field(default_factory=dict)

    def is_usable(self) -> bool:
        return self.success and self.data is not None


def _make_passage(text: str, provider: str = "Test Hospital") -> dict:
    """Create a passage dict with standard shape."""
    return {
        "unit_text": text,
        "provider_name": provider,
        "source_filename": "test_contract.pdf",
    }


def _make_rate_result(rate: float = 110.50, provider: str = "Cedars-Sinai") -> MockToolResult:
    """Create a structured data tool result (rate query)."""
    return MockToolResult(
        success=True,
        data=[{"rate_amount": rate, "provider_name": provider, "rate_category": "Per Diem"}],
        summary=f"Rate found: ${rate} for {provider}",
    )


def _make_empty_result() -> MockToolResult:
    """Create an empty/no-data tool result."""
    return MockToolResult(success=True, data=None, summary="No results found")


def _make_failed_result() -> MockToolResult:
    """Create a failed tool result."""
    return MockToolResult(success=False, data=None, summary="Tool error: timeout")


def _make_passage_result(passages: list[dict]) -> MockToolResult:
    """Create a tool result with passages in metadata."""
    return MockToolResult(
        success=True,
        data=passages,
        summary=f"Retrieved {len(passages)} passages",
        metadata={"passages": passages},
    )


# ============================================================
# TEST CLASS: GROUNDED VIA STRUCTURED DATA
# ============================================================


class TestGroundedStructuredData:
    """Tests where structured data (SQL results) satisfies grounding."""

    def test_single_rate_result_is_grounded(self):
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(
            tool_results=[_make_rate_result()],
            query="What is the per diem rate for Cedars-Sinai?",
        )
        assert decision.is_grounded
        assert decision.has_structured_data
        assert decision.refusal_message == ""

    def test_multiple_structured_results_grounded(self):
        enforcer = AnswerGroundingEnforcer()
        results = [
            _make_rate_result(110.50, "Cedars-Sinai"),
            MockToolResult(
                success=True,
                data=[{"provider_name": "Cedars-Sinai", "term_months": 36}],
                summary="Profile found",
            ),
        ]
        decision = enforcer.evaluate(
            tool_results=results,
            query="What are the contract terms for Cedars-Sinai?",
        )
        assert decision.is_grounded
        assert decision.has_structured_data

    def test_structured_dict_data_is_grounded(self):
        """Non-list dict data also counts as structured."""
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(
            success=True,
            data={"provider_name": "Sutter", "payment_type": "Per Diem", "lob": "Commercial"},
            summary="Provider profile",
        )
        decision = enforcer.evaluate(
            tool_results=[result],
            query="What is Sutter's payment type?",
        )
        assert decision.is_grounded
        assert decision.has_structured_data

    def test_structured_data_overrides_weak_passages(self):
        """Structured data satisfies grounding even with poor passages."""
        enforcer = AnswerGroundingEnforcer()
        # Passage about completely unrelated topic
        weak_passage = _make_passage("The cafeteria menu was updated last week.")
        result_with_passages = MockToolResult(
            success=True,
            data=[{"rate_amount": 500.0}],
            summary="Rate found",
            metadata={"passages": [weak_passage]},
        )
        decision = enforcer.evaluate(
            tool_results=[result_with_passages],
            query="What is the offset clause for Sutter?",
        )
        assert decision.is_grounded  # structured data overrides
        assert decision.has_structured_data


# ============================================================
# TEST CLASS: GROUNDED VIA PASSAGE RELEVANCE
# ============================================================


class TestGroundedPassages:
    """Tests where passage relevance scoring satisfies grounding."""

    def test_highly_relevant_passage_is_grounded(self):
        enforcer = AnswerGroundingEnforcer()
        # Passage with strong keyword overlap to query
        passage = _make_passage(
            "The offset clause provides that Blue Shield shall offset any "
            "amounts received from other coverage sources including Medicare, "
            "Medi-Cal, and workers compensation against the contracted rate."
        )
        decision = enforcer.evaluate(
            tool_results=[],
            query="What is the offset clause?",
            passages=[passage],
        )
        assert decision.is_grounded
        assert decision.grounded_passage_count >= 1
        assert decision.max_passage_score >= RELEVANCE_SCORE_THRESHOLD

    def test_multiple_relevant_passages_grounded(self):
        enforcer = AnswerGroundingEnforcer()
        passages = [
            _make_passage(
                "The offset provision states that the provider shall offset "
                "amounts from other payers against the per diem rate."
            ),
            _make_passage(
                "The coordination of benefits and offset clause applies to "
                "all services under this agreement."
            ),
        ]
        decision = enforcer.evaluate(
            tool_results=[],
            query="offset clause coordination of benefits",
            passages=passages,
        )
        assert decision.is_grounded
        assert decision.grounded_passage_count >= 1

    def test_passages_extracted_from_tool_result_metadata(self):
        """Passages in tool_results.metadata['passages'] are found."""
        enforcer = AnswerGroundingEnforcer()
        passage = _make_passage(
            "The capitation rate for primary care services shall be "
            "$45.00 per member per month effective January 1, 2024."
        )
        result = _make_passage_result([passage])
        decision = enforcer.evaluate(
            tool_results=[result],
            query="capitation rate primary care",
        )
        assert decision.is_grounded
        assert decision.grounded_passage_count >= 1

    def test_passages_extracted_from_citations(self):
        """Passages found in tool_results.citations are scored."""
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(
            success=True,
            data=None,
            summary="Passages found",
            citations=[{
                "unit_text": "The stop-loss threshold is $500,000 per member per year. "
                             "Claims exceeding this stop-loss limit shall be reimbursed "
                             "at 80% of billed charges.",
                "source_filename": "contract_123.pdf",
            }],
        )
        decision = enforcer.evaluate(
            tool_results=[result],
            query="stop-loss threshold limit",
        )
        assert decision.is_grounded

    def test_passages_extracted_from_data_list(self):
        """Passage-like dicts in data list are scored."""
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(
            success=True,
            data=[{
                "text": "Amendment #3 modifies the DRG rate schedule effective "
                        "July 1, 2025. DRG rates increased by 3.5% across all "
                        "service categories.",
                "provider_name": "Sutter",
            }],
            summary="DRG rates found",
        )
        decision = enforcer.evaluate(
            tool_results=[result],
            query="DRG rate amendment schedule",
        )
        assert decision.is_grounded


# ============================================================
# TEST CLASS: UNGROUNDED REFUSALS
# ============================================================


class TestUngroundedRefusals:
    """Tests where grounding check fails and refusal is returned."""

    def test_no_evidence_at_all(self):
        """Zero tool results → refusal."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(
            tool_results=[],
            query="What is the offset clause for Sutter?",
        )
        assert not decision.is_grounded
        assert decision.refusal_message == REFUSAL_MESSAGE
        assert "No evidence gathered" in decision.reason

    def test_all_tools_failed(self):
        """All tool results are failures → refusal."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(
            tool_results=[_make_failed_result(), _make_failed_result()],
            query="What is the per diem rate?",
        )
        assert not decision.is_grounded
        assert decision.refusal_message == REFUSAL_MESSAGE

    def test_empty_results_only(self):
        """Tool results with no data → refusal."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(
            tool_results=[_make_empty_result(), _make_empty_result()],
            query="What is the capitation rate for St. Jude?",
        )
        assert not decision.is_grounded
        assert decision.refusal_message == REFUSAL_MESSAGE

    def test_irrelevant_passages_below_threshold(self):
        """Passages about unrelated topics → refusal."""
        enforcer = AnswerGroundingEnforcer()
        passages = [
            _make_passage("The hospital cafeteria offers healthy meal options."),
            _make_passage("Parking is available in the north lot for visitors."),
            _make_passage("The gift shop is located on the first floor."),
        ]
        decision = enforcer.evaluate(
            tool_results=[],
            query="offset clause coordination of benefits",
            passages=passages,
        )
        assert not decision.is_grounded
        assert decision.max_passage_score < RELEVANCE_SCORE_THRESHOLD
        assert "Insufficient relevance" in decision.reason

    def test_zero_passages_explicit_refusal(self):
        """No passages at all + no structured data → explicit refusal (plan requirement)."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(
            tool_results=[_make_empty_result()],
            query="Does Kaweah Delta have an offset clause?",
            passages=[],
        )
        assert not decision.is_grounded
        assert decision.refusal_message != ""
        assert "verified evidence" in decision.refusal_message

    def test_refusal_message_content(self):
        """Verify the refusal message is user-friendly and actionable."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(tool_results=[], query="test query")
        msg = decision.refusal_message
        assert "could not find verified evidence" in msg
        assert "contract corpus" in msg
        assert "rephrasing" in msg


# ============================================================
# TEST CLASS: EDGE CASES
# ============================================================


class TestEdgeCases:
    """Edge cases and boundary conditions."""

    def test_empty_query_with_structured_data(self):
        """Empty query still grounded if structured data exists."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(
            tool_results=[_make_rate_result()],
            query="",
        )
        assert decision.is_grounded
        assert decision.has_structured_data

    def test_empty_query_no_data(self):
        """Empty query + no data → ungrounded."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(tool_results=[], query="")
        assert not decision.is_grounded

    def test_passage_with_no_text_key(self):
        """Passage dict missing all text keys is ignored."""
        enforcer = AnswerGroundingEnforcer()
        decision = enforcer.evaluate(
            tool_results=[],
            query="offset clause",
            passages=[{"provider_name": "Test", "score": 0.9}],
        )
        assert not decision.is_grounded

    def test_none_passages_extracts_from_results(self):
        """When passages=None, extraction from tool_results is attempted."""
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(
            success=True,
            data=[{"unit_text": "The offset clause provides coverage coordination."}],
            summary="Retrieved",
        )
        decision = enforcer.evaluate(
            tool_results=[result],
            query="offset clause",
            passages=None,
        )
        # Should attempt extraction from data
        assert isinstance(decision, GroundingDecision)

    def test_malformed_tool_result_no_crash(self):
        """Tool results with unexpected shapes don't crash."""
        enforcer = AnswerGroundingEnforcer()
        # Result with string data (not list/dict)
        weird_result = MockToolResult(success=True, data="just a string")
        decision = enforcer.evaluate(
            tool_results=[weird_result],
            query="test query",
        )
        assert isinstance(decision, GroundingDecision)
        # String data doesn't count as structured
        assert not decision.has_structured_data

    def test_empty_list_data_not_structured(self):
        """Empty list data doesn't count as structured."""
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(success=True, data=[])
        decision = enforcer.evaluate(
            tool_results=[result],
            query="test",
        )
        assert not decision.has_structured_data

    def test_empty_dict_data_not_structured(self):
        """Empty dict data doesn't count as structured."""
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(success=True, data={})
        decision = enforcer.evaluate(
            tool_results=[result],
            query="test",
        )
        assert not decision.has_structured_data

    def test_failed_result_data_ignored(self):
        """Data from failed results is not counted."""
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(
            success=False,
            data=[{"rate_amount": 500.0, "provider": "Test"}],
        )
        decision = enforcer.evaluate(
            tool_results=[result],
            query="rate amount",
        )
        assert not decision.has_structured_data


# ============================================================
# TEST CLASS: SHOULD_REFUSE_AT_MAX_STEPS
# ============================================================


class TestShouldRefuseAtMaxSteps:
    """Tests for the convenience method used at the max-steps boundary."""

    def test_refuse_when_no_evidence(self):
        enforcer = AnswerGroundingEnforcer()
        should_refuse, message = enforcer.should_refuse_at_max_steps(
            tool_results=[],
            query="Does Sutter have a carve-out clause?",
        )
        assert should_refuse is True
        assert message == REFUSAL_MESSAGE

    def test_no_refuse_when_grounded(self):
        enforcer = AnswerGroundingEnforcer()
        should_refuse, message = enforcer.should_refuse_at_max_steps(
            tool_results=[_make_rate_result()],
            query="What is the rate?",
        )
        assert should_refuse is False
        assert message == ""

    def test_refuse_with_irrelevant_passages(self):
        enforcer = AnswerGroundingEnforcer()
        passages = [_make_passage("Unrelated cafeteria information.")]
        should_refuse, message = enforcer.should_refuse_at_max_steps(
            tool_results=[_make_empty_result()],
            query="offset clause details",
            passages=passages,
        )
        assert should_refuse is True

    def test_no_refuse_with_structured_data_despite_no_passages(self):
        enforcer = AnswerGroundingEnforcer()
        should_refuse, message = enforcer.should_refuse_at_max_steps(
            tool_results=[_make_rate_result(200.0, "Sutter")],
            query="Sutter rate",
            passages=[],
        )
        assert should_refuse is False


# ============================================================
# TEST CLASS: CUSTOM CONFIGURATION
# ============================================================


class TestCustomConfiguration:
    """Tests for configurable thresholds and messages."""

    def test_lower_threshold_accepts_more(self):
        """Lower relevance threshold → more passages counted as grounded."""
        # Default threshold (0.5) would reject this
        weak_passage = _make_passage(
            "This section discusses general offset provisions that may apply."
        )
        # With default threshold
        strict_enforcer = AnswerGroundingEnforcer(relevance_threshold=0.8)
        strict_decision = strict_enforcer.evaluate(
            tool_results=[], query="offset", passages=[weak_passage]
        )

        # With lower threshold
        lenient_enforcer = AnswerGroundingEnforcer(relevance_threshold=0.1)
        lenient_decision = lenient_enforcer.evaluate(
            tool_results=[], query="offset", passages=[weak_passage]
        )

        # Lenient should accept more (or at least same) as strict
        assert lenient_decision.grounded_passage_count >= strict_decision.grounded_passage_count

    def test_custom_refusal_message(self):
        """Custom refusal message is used instead of default."""
        custom_msg = "Custom refusal: data not available."
        enforcer = AnswerGroundingEnforcer(refusal_message=custom_msg)
        decision = enforcer.evaluate(tool_results=[], query="test")
        assert decision.refusal_message == custom_msg

    def test_higher_min_passages_requirement(self):
        """Requiring more grounded passages raises the bar."""
        passage = _make_passage(
            "The offset clause states that coordination of benefits "
            "and offset provisions apply to all covered services."
        )
        # Default (min=1) should pass with 1 relevant passage
        default_enforcer = AnswerGroundingEnforcer(min_grounded_passages=1)
        default_decision = default_enforcer.evaluate(
            tool_results=[], query="offset clause coordination", passages=[passage]
        )

        # Higher requirement (min=5) should fail with only 1 passage
        strict_enforcer = AnswerGroundingEnforcer(min_grounded_passages=5)
        strict_decision = strict_enforcer.evaluate(
            tool_results=[], query="offset clause coordination", passages=[passage]
        )

        assert default_decision.is_grounded
        assert not strict_decision.is_grounded

    def test_higher_min_structured_results(self):
        """Requiring more structured results raises the bar."""
        # 1 result available
        results = [_make_rate_result()]

        # Default (min=1) passes
        default_enforcer = AnswerGroundingEnforcer(min_structured_results=1)
        default_decision = default_enforcer.evaluate(tool_results=results, query="rate")

        # Higher requirement (min=3) fails
        strict_enforcer = AnswerGroundingEnforcer(min_structured_results=3)
        strict_decision = strict_enforcer.evaluate(tool_results=results, query="rate")

        assert default_decision.is_grounded
        assert not strict_decision.is_grounded


# ============================================================
# TEST CLASS: GROUNDING DECISION DATACLASS
# ============================================================


class TestGroundingDecision:
    """Tests for the GroundingDecision dataclass properties."""

    def test_grounded_decision_fields(self):
        decision = GroundingDecision(
            is_grounded=True,
            reason="Evidence sufficient",
            refusal_message="",
            grounded_passage_count=3,
            max_passage_score=0.72,
            has_structured_data=True,
            evidence_sources=["structured_data", "passages(3)"],
        )
        assert decision.is_grounded is True
        assert decision.refusal_message == ""
        assert decision.grounded_passage_count == 3
        assert decision.max_passage_score == 0.72
        assert decision.has_structured_data is True
        assert len(decision.evidence_sources) == 2

    def test_ungrounded_decision_fields(self):
        decision = GroundingDecision(
            is_grounded=False,
            reason="No evidence gathered",
            refusal_message=REFUSAL_MESSAGE,
            grounded_passage_count=0,
            max_passage_score=0.0,
            has_structured_data=False,
            evidence_sources=[],
        )
        assert decision.is_grounded is False
        assert decision.refusal_message == REFUSAL_MESSAGE
        assert decision.evidence_sources == []

    def test_decision_is_frozen(self):
        """GroundingDecision is immutable (frozen dataclass)."""
        decision = GroundingDecision(is_grounded=True, reason="test")
        with pytest.raises(Exception):  # FrozenInstanceError
            decision.is_grounded = False


# ============================================================
# TEST CLASS: PASSAGE EXTRACTION
# ============================================================


class TestPassageExtraction:
    """Tests for passage extraction from various tool result shapes."""

    def test_extracts_from_metadata_passages(self):
        enforcer = AnswerGroundingEnforcer()
        passages_in_meta = [
            _make_passage("The capitation rate is $45 PMPM for primary care."),
        ]
        result = MockToolResult(
            success=True, data=None, summary="OK",
            metadata={"passages": passages_in_meta},
        )
        extracted = enforcer._extract_passages([result])
        assert len(extracted) == 1
        assert extracted[0]["unit_text"] == passages_in_meta[0]["unit_text"]

    def test_extracts_from_citations_with_text(self):
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(
            success=True, data=None, summary="OK",
            citations=[
                {"unit_text": "Amendment 5 modifies the rate.", "source_filename": "a.pdf"},
                {"doc_id": "123"},  # no text key — should be skipped
            ],
        )
        extracted = enforcer._extract_passages([result])
        assert len(extracted) == 1

    def test_extracts_from_data_list_passage_dicts(self):
        enforcer = AnswerGroundingEnforcer()
        result = MockToolResult(
            success=True,
            data=[
                {"chunk_text": "Stop-loss threshold is $500K.", "provider": "Sutter"},
                {"rate_amount": 100.0},  # no text key — should be skipped
            ],
            summary="OK",
        )
        extracted = enforcer._extract_passages([result])
        assert len(extracted) == 1
        assert "Stop-loss" in extracted[0]["chunk_text"]

    def test_prioritizes_metadata_passages_over_data(self):
        """When metadata.passages exists, data list isn't double-counted."""
        enforcer = AnswerGroundingEnforcer()
        passage = _make_passage("Offset clause applies to all services.")
        result = MockToolResult(
            success=True,
            data=[{"unit_text": "Different passage text."}],
            summary="OK",
            metadata={"passages": [passage]},
        )
        extracted = enforcer._extract_passages([result])
        # metadata.passages is found first → that branch runs and `continue` skips data
        assert any(p.get("unit_text") == passage["unit_text"] for p in extracted)



# ============================================================
# TEST CLASS: AGENT CONTROLLER WIRING SIMULATION
# ============================================================


class TestControllerWiringBehavior:
    """Simulate the AgentController max-steps boundary behavior.

    These tests mirror exactly what happens at line 283-308 of
    agent_controller.py when the ReAct loop exhausts max_steps:

        should_refuse, refusal_msg = self._grounding.should_refuse_at_max_steps(
            tool_results=tool_results,
            query=request.question,
        )
        if should_refuse:
            return self._build_response(answer=refusal_msg, ...)
        else:
            return self._build_response(answer=self._best_effort_synthesis(...), ...)

    Each test builds a realistic `tool_results` accumulation as the
    agent would have after N steps of CALL_TOOL actions.
    """

    # ── Scenario: Agent ran 10 steps, all retrieval failed ──────────────

    def test_all_retrievals_failed_returns_refusal(self):
        """10 steps of failed tool calls → refusal (not a guess)."""
        enforcer = AnswerGroundingEnforcer()
        # Simulate 10 failed/empty tool calls (typical when provider not in corpus)
        tool_results = [
            MockToolResult(success=False, data=None, summary="VS search returned 0 hits"),
            MockToolResult(success=False, data=None, summary="SQL: no rows for provider"),
            MockToolResult(success=True, data=None, summary="No passages matched"),
            MockToolResult(success=False, data=None, summary="Rate lookup: provider not found"),
            MockToolResult(success=True, data=[], summary="Empty result set"),
        ]
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=tool_results,
            query="What is the capitation rate for a nonexistent provider?",
        )
        assert should_refuse is True
        assert msg == REFUSAL_MESSAGE
        assert "WARNING" not in msg  # BUG-009: no more WARNING prefix

    # ── Scenario: Agent found structured rate data → grounded ───────────

    def test_rate_found_allows_synthesis(self):
        """Agent found a rate via SQL → best_effort_synthesis should proceed."""
        enforcer = AnswerGroundingEnforcer()
        tool_results = [
            MockToolResult(success=True, data=None, summary="VS search: 3 passages"),
            MockToolResult(
                success=True,
                data=[{"provider_name": "Cedars-Sinai", "rate_numeric": 2850.0,
                       "rate_category": "Inpatient Per Diem"}],
                summary="Rate found: $2,850 Inpatient Per Diem for Cedars-Sinai",
            ),
            MockToolResult(success=True, data=None, summary="No additional amendments"),
        ]
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=tool_results,
            query="What is the inpatient per diem rate for Cedars-Sinai?",
        )
        assert should_refuse is False
        assert msg == ""

    # ── Scenario: Agent found relevant passages but no structured data ──

    def test_relevant_passages_only_allows_synthesis(self):
        """Passage retrieval found strong matches → synthesis proceeds."""
        enforcer = AnswerGroundingEnforcer()
        # Passages stored in citations (as the agent accumulates them)
        tool_results = [
            MockToolResult(
                success=True, data=None,
                summary="Retrieved 5 passages about offset clause",
                citations=[
                    {
                        "unit_text": (
                            "The offset clause provides that Blue Shield may offset "
                            "amounts received from Medicare, Medi-Cal, and workers "
                            "compensation against the contracted per diem rate."
                        ),
                        "provider_name": "Sutter Roseville",
                        "source_filename": "sutter_base_agreement.pdf",
                    },
                    {
                        "unit_text": (
                            "Coordination of benefits and offset provisions shall "
                            "apply to all covered services under this offset clause."
                        ),
                        "provider_name": "Sutter Roseville",
                        "source_filename": "sutter_amendment_3.pdf",
                    },
                ],
            ),
        ]
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=tool_results,
            query="What is the offset clause for Sutter Roseville?",
        )
        assert should_refuse is False
        assert msg == ""

    # ── Scenario: Passages retrieved but completely off-topic ────────────

    def test_irrelevant_passages_forces_refusal(self):
        """Agent retrieved passages but none are relevant to query → refusal."""
        enforcer = AnswerGroundingEnforcer()
        tool_results = [
            MockToolResult(
                success=True, data=None,
                summary="Retrieved 3 passages",
                citations=[
                    {"unit_text": "The hospital shall maintain parking facilities.",
                     "provider_name": "Memorial"},
                    {"unit_text": "Cafeteria services available Monday through Friday.",
                     "provider_name": "Memorial"},
                    {"unit_text": "Visitor hours are 8am to 8pm daily.",
                     "provider_name": "Memorial"},
                ],
            ),
        ]
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=tool_results,
            query="What is the stop-loss threshold for Memorial?",
        )
        assert should_refuse is True
        assert "verified evidence" in msg

    # ── Scenario: Mixed — some failures, one structured success ─────────

    def test_mixed_results_with_one_sql_hit_allows_synthesis(self):
        """Typical agent run: several failures then one SQL success → grounded."""
        enforcer = AnswerGroundingEnforcer()
        tool_results = [
            # Steps 1-3: searching, failing
            MockToolResult(success=False, data=None, summary="VS endpoint timeout"),
            MockToolResult(success=True, data=None, summary="No passages matched keywords"),
            MockToolResult(success=False, data=None, summary="Rate query: no rows"),
            # Step 4: retry found data
            MockToolResult(
                success=True,
                data=[{"provider_name": "Sutter", "payment_type": "Per Diem",
                       "term_months": 36, "lob": "Commercial HMO"}],
                summary="Provider profile found",
            ),
            # Steps 5-6: additional context
            MockToolResult(success=True, data=None, summary="No amendments found"),
            MockToolResult(success=True, data=None, summary="No stop-loss data"),
        ]
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=tool_results,
            query="What is Sutter's payment type and contract term?",
        )
        assert should_refuse is False

    # ── Scenario: Budget exhausted early with partial evidence ──────────

    def test_partial_evidence_with_passages_in_metadata(self):
        """Passages stored in metadata (from RetrievalService) → grounded."""
        enforcer = AnswerGroundingEnforcer()
        tool_results = [
            MockToolResult(
                success=True, data=None,
                summary="Retrieval complete",
                metadata={"passages": [
                    {"unit_text": (
                        "The DRG rate schedule effective July 1, 2025 provides "
                        "DRG rates at 145% of Medicare for all inpatient services. "
                        "DRG payment methodology applies to acute care admissions."
                    ), "provider_name": "Kaiser"},
                ]},
            ),
        ]
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=tool_results,
            query="What are the DRG rates for Kaiser?",
        )
        assert should_refuse is False

    # ── Scenario: Verify old WARNING behavior is gone (BUG-009 core) ────

    def test_refusal_never_contains_warning_prefix(self):
        """BUG-009: Old behavior was 'WARNING: <guess>'. New = clean refusal."""
        enforcer = AnswerGroundingEnforcer()
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=[_make_failed_result() for _ in range(5)],
            query="Complex question about arcane contract provisions",
        )
        assert should_refuse is True
        # The refusal message must NOT have a WARNING prefix or contain a guess
        assert not msg.startswith("WARNING")
        assert "based on" not in msg.lower()
        assert "partial" not in msg.lower()
        assert "may be incomplete" not in msg.lower()
        # It MUST have actionable guidance
        assert "rephrasing" in msg or "specific" in msg

    # ── Scenario: Agent accumulated only THINK steps (no tool results) ──

    def test_zero_tool_results_forces_refusal(self):
        """Agent only did THINK steps (no tools called) → refusal."""
        enforcer = AnswerGroundingEnforcer()
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=[],
            query="What is the reimbursement methodology?",
        )
        assert should_refuse is True

    # ── Scenario: Large data list without passage text keys ─────────────

    def test_structured_list_without_text_keys_is_still_grounded(self):
        """SQL results (rate rows) without text keys still count as structured."""
        enforcer = AnswerGroundingEnforcer()
        tool_results = [
            MockToolResult(
                success=True,
                data=[
                    {"rate_category": "Inpatient", "rate_numeric": 2500.0,
                     "provider_name": "Sutter", "effective_date": "2024-01-01"},
                    {"rate_category": "Outpatient", "rate_numeric": 185.0,
                     "provider_name": "Sutter", "effective_date": "2024-01-01"},
                    {"rate_category": "ER", "rate_numeric": 3200.0,
                     "provider_name": "Sutter", "effective_date": "2024-01-01"},
                ],
                summary="3 rate rows found for Sutter",
            ),
        ]
        should_refuse, msg = enforcer.should_refuse_at_max_steps(
            tool_results=tool_results,
            query="What are all the rates for Sutter?",
        )
        assert should_refuse is False

    # ── Scenario: Verify the exact refusal message matches constant ──────

    def test_refusal_message_is_exact_constant(self):
        """Controller returns REFUSAL_MESSAGE constant — no dynamic text."""
        enforcer = AnswerGroundingEnforcer()
        _, msg = enforcer.should_refuse_at_max_steps(
            tool_results=[], query="anything",
        )
        assert msg == REFUSAL_MESSAGE
        # Verify key phrases from the plan requirement
        assert "could not find verified evidence" in msg
        assert "contract corpus" in msg

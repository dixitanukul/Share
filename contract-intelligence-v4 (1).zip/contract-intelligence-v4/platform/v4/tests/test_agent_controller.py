"""
platform/v4/tests/test_agent_controller.py

Unit tests for AgentController (core ReAct loop).

Tests use stub tools and a stub LLM client — no Spark or V2 required.
"""
import pytest
from unittest.mock import MagicMock, patch

from ..contracts.agent_types import AgentRequest, AgentResponse
from ..contracts.tool_types import Confidence, ToolResult, ToolStatus
from ..core.agent_controller import AgentController
from ..core.context_manager import ContextManager
from ..core.cost_controller import CostController
from ..core.response_assembler import ResponseAssembler
from ..config.settings import Settings
from ..tools.registry import ToolRegistry
from ..tools.base import BaseTool


# ---------------------------------------------------------------------------
# Stub helpers
# ---------------------------------------------------------------------------

class _StubTool(BaseTool):
    """Always returns a fixed ToolResult."""
    def __init__(self, name: str, result: ToolResult) -> None:
        self._name   = name
        self._result = result

    @property
    def name(self) -> str:
        return self._name

    def _run(self, **kwargs):
        return self._result


class _StubLLM:
    """Stub LLM that returns a deterministic SYNTHESIZE response."""
    def chat(self, model: str, system: str, user: str, max_tokens: int) -> str:
        return "SYNTHESIZE\nThe answer is: test result."


def _make_controller(tool_name: str = "sql_query", tool_result: ToolResult = None) -> AgentController:
    if tool_result is None:
        tool_result = ToolResult(
            success=True,
            data=[{"rate": 100.0}],
            summary="Rate found",
            confidence=Confidence.HIGH,
        )
    settings = Settings()
    registry = ToolRegistry(settings=settings)
    registry.register(_StubTool(tool_name, tool_result))

    return AgentController(
        registry=registry,
        context_manager=ContextManager(spark=None),
        cost_controller=CostController(budget_usd=10.0),
        assembler=ResponseAssembler(),
        llm_client=_StubLLM(),
        settings=settings,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestAgentController:

    def test_run_returns_agent_response(self):
        controller = _make_controller()
        request    = AgentRequest(question="What is the rate?", session_id="test-1")
        response   = controller.run(request)
        assert isinstance(response, AgentResponse)
        assert isinstance(response.answer, str)
        assert len(response.answer) > 0

    def test_response_has_session_id(self):
        controller = _make_controller()
        request    = AgentRequest(question="What is the rate?", session_id="session-abc")
        response   = controller.run(request)
        assert response.session_id == "session-abc"

    def test_failed_tool_produces_non_empty_answer(self):
        """Even when the tool fails, the controller should return an answer."""
        failed_result = ToolResult(
            success=False,
            data=None,
            summary="Tool failed",
            confidence=Confidence.LOW,
            error_message="Spark not available",
        )
        controller = _make_controller("sql_query", failed_result)
        request    = AgentRequest(question="How many contracts?", session_id="test-2")
        response   = controller.run(request)
        assert isinstance(response, AgentResponse)
        assert response.answer  # non-empty

    def test_cost_is_non_negative(self):
        controller = _make_controller()
        request    = AgentRequest(question="List providers", session_id="test-3")
        response   = controller.run(request)
        assert response.total_cost >= 0.0

    def test_confidence_is_valid(self):
        controller = _make_controller()
        request    = AgentRequest(question="Test confidence", session_id="test-4")
        response   = controller.run(request)
        assert response.confidence in {
            Confidence.HIGH, Confidence.MODERATE, Confidence.LOW, Confidence.GENERATED
        }

    def test_steps_recorded(self):
        controller = _make_controller()
        request    = AgentRequest(question="Test steps", session_id="test-5")
        response   = controller.run(request)
        assert isinstance(response.steps, list)

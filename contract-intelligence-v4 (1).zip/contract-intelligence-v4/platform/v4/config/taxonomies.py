"""
platform/v4/config/taxonomies.py

DEPRECATED: This module is now a thin re-export shim.

All taxonomy data, recall signals, polarity helpers, and absence codes have been
consolidated into ``platform.v4.services.concepts`` (Step 1.7 — single source of
truth).  This file exists only for backward compatibility so that relative imports
using ``..config.taxonomies`` continue to resolve without modification.

DO NOT add new concept definitions here.  Edit ``platform/v4/services/concepts.py``
instead.
"""
# Re-export everything so that
#   from platform.v4.config.taxonomies import KNOWN_TAXONOMIES
#   from ..config.taxonomies import get_recall_signals
# and equivalents via the platform.v4 stub all continue to work.

from platform.v4.services.concepts import (  # noqa: F401
    CONCEPT_REGISTRY,
    KNOWN_TAXONOMIES,
    KNOWN_RECALL_SIGNALS,
    ABSENCE_CODES,
    get_taxonomy,
    get_recall_signals,
    get_polarity_codes,
    is_known_concept,
    all_concept_names,
    assign_polarity,
    category_polarity_map,
)

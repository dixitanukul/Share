"""
platform/v4/config/workspace_config.py

P1-AUTH-1: V3 auth/config service.

Loads workspace_url, api_token, and LLM model from the Databricks runtime
context (env vars, Spark conf, or notebook context) — NOT from notebook globals.

This allows init_runtime(spark=spark) to self-bootstrap without running V2 cells.

Usage
-----
    from platform.v4.config.workspace_config import WorkspaceConfig

    config = WorkspaceConfig.from_spark(spark)
    print(config.workspace_url)
    print(config.api_token[:10] + '...')
"""
from __future__ import annotations

import os
import logging
from dataclasses import dataclass, field
from typing import Any, Optional

from .settings import LLM_REASONING, VS_ENDPOINT, VS_INDEX_UNIFIED, VS_INDEX_FULLTEXT, VS_INDEX_LEGAL

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class WorkspaceConfig:
    """Immutable workspace configuration resolved at runtime."""

    workspace_url: str
    api_token: str
    llm_model: str = LLM_REASONING
    vs_endpoint: str = VS_ENDPOINT
    vs_index_unified: str = VS_INDEX_UNIFIED
    vs_index_fulltext: str = VS_INDEX_FULLTEXT   # Legacy alias (points to unified)
    vs_index_legal: str = VS_INDEX_LEGAL         # Legacy alias (points to unified)

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def from_spark(cls, spark: Any, llm_model: Optional[str] = None) -> "WorkspaceConfig":
        """
        Resolve config from the active Spark/Databricks context.

        Resolution order (first wins):
          1. Environment variables: DATABRICKS_HOST, DATABRICKS_TOKEN
          2. Spark conf: spark.databricks.workspaceUrl
          3. dbutils notebook context (api token)

        Parameters
        ----------
        spark     : Active SparkSession.
        llm_model : Override LLM model name (default: LLM_REASONING from settings).
        """
        workspace_url = cls._resolve_workspace_url(spark)
        api_token = cls._resolve_api_token(spark)

        if not workspace_url:
            raise RuntimeError(
                "WorkspaceConfig: Could not resolve workspace_url. "
                "Set DATABRICKS_HOST env var or ensure spark.databricks.workspaceUrl is available."
            )
        if not api_token:
            raise RuntimeError(
                "WorkspaceConfig: Could not resolve api_token. "
                "Set DATABRICKS_TOKEN env var or ensure notebook context is available."
            )

        return cls(
            workspace_url=workspace_url,
            api_token=api_token,
            llm_model=llm_model or LLM_REASONING,
        )

    @classmethod
    def from_env(cls, llm_model: Optional[str] = None) -> "WorkspaceConfig":
        """
        Resolve config purely from environment variables.
        Useful for serving/API contexts where Spark is not available.
        """
        workspace_url = os.environ.get("DATABRICKS_HOST", "")
        api_token = os.environ.get("DATABRICKS_TOKEN", "")

        if not workspace_url:
            raise RuntimeError("WorkspaceConfig.from_env: DATABRICKS_HOST not set.")
        if not api_token:
            raise RuntimeError("WorkspaceConfig.from_env: DATABRICKS_TOKEN not set.")

        return cls(
            workspace_url=workspace_url,
            api_token=api_token,
            llm_model=llm_model or LLM_REASONING,
        )

    @classmethod
    def from_sdk(cls, llm_model: Optional[str] = None) -> "WorkspaceConfig":
        """
        Resolve config from the Databricks SDK (OAuth-native).

        Works in Databricks Apps where DATABRICKS_TOKEN is not set but the SDK
        auto-discovers OAuth credentials from the app's service principal.
        Falls back to from_env() if DATABRICKS_TOKEN is already available.
        """
        # If a PAT is available, use the simpler path
        if os.environ.get("DATABRICKS_TOKEN"):
            return cls.from_env(llm_model=llm_model)

        try:
            from databricks.sdk import WorkspaceClient
            w = WorkspaceClient()
            workspace_url = w.config.host or ""
            if not workspace_url:
                raise RuntimeError("WorkspaceConfig.from_sdk: SDK could not resolve host.")

            # Extract a fresh token from the SDK's auth provider
            auth_headers = w.config.authenticate()
            token = auth_headers.get("Authorization", "").removeprefix("Bearer ").strip()
            if not token:
                raise RuntimeError(
                    "WorkspaceConfig.from_sdk: SDK authenticate() did not return a Bearer token."
                )

            logger.info("WorkspaceConfig resolved via SDK (host=%s)", workspace_url[:40])
            return cls(
                workspace_url=workspace_url,
                api_token=token,
                llm_model=llm_model or LLM_REASONING,
            )
        except ImportError:
            raise RuntimeError("WorkspaceConfig.from_sdk: databricks-sdk not installed.")

    # ------------------------------------------------------------------
    # Derived properties
    # ------------------------------------------------------------------

    @property
    def llm_endpoint_url(self) -> str:
        """Full URL for the LLM serving endpoint."""
        base = self.workspace_url.rstrip("/")
        if not base.startswith("http"):
            base = f"https://{base}"
        return f"{base}/serving-endpoints/{self.llm_model}/invocations"

    @property
    def llm_headers(self) -> dict:
        """HTTP headers for LLM API calls."""
        return {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Internal resolution helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_workspace_url(spark: Any) -> str:
        """Resolve workspace URL from env or Spark conf."""
        # 1. Environment variable
        env_host = os.environ.get("DATABRICKS_HOST", "")
        if env_host:
            return env_host.rstrip("/")

        # 2. Spark conf
        try:
            url = spark.conf.get("spark.databricks.workspaceUrl")
            if url:
                return url.rstrip("/")
        except Exception:
            pass

        return ""

    @staticmethod
    def _resolve_api_token(spark: Any) -> str:
        """Resolve API token from env or notebook context."""
        # 1. Environment variable
        env_token = os.environ.get("DATABRICKS_TOKEN", "")
        if env_token:
            return env_token

        # 2. Notebook context via JVM gateway (classic clusters only — not Spark Connect)
        # DBR 18.0 uses Spark Connect by default; _jvm is unavailable there.
        # The hasattr guard prevents AttributeError on Spark Connect clusters.
        if hasattr(spark, '_jvm') and spark._jvm is not None:
            try:
                ctx = (
                    spark._jvm.com.databricks.backend.daemon.driver
                    .DriverLocal.context()
                )
                return ctx.apiToken().get()
            except Exception:
                pass

        # 3. dbutils global (if available in notebook scope)
        try:
            import IPython
            shell = IPython.get_ipython()
            if shell:
                dbutils = shell.user_ns.get("dbutils")
                if dbutils:
                    return (
                        dbutils.notebook.entry_point.getDbutils()
                        .notebook().getContext().apiToken().get()
                    )
        except Exception:
            pass

        return ""

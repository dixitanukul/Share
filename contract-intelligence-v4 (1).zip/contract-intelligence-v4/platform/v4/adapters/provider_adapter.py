"""Provider adapter — canonical provider lookup and resolution."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Optional
import logging

logger = logging.getLogger(__name__)


@dataclass
class CanonicalProvider:
    """Canonical provider record from tbl_genie_provider_profile."""
    provider_id: str = ""
    provider_name: str = ""
    is_active: str = ""
    line_of_business: str = ""


class ProviderAdapter:
    """Wraps Spark-based provider lookup for V4 tools."""

    def __init__(self, spark: Any = None, cache: Optional[dict] = None) -> None:
        self._spark = spark
        self._cache: dict[str, CanonicalProvider] = cache or {}
        self._ready = False

    def preload_cache(self, limit: int = 500) -> int:
        """Preload canonical providers into memory cache.
        
        Returns number of providers loaded.
        """
        if self._spark is None:
            self._ready = True
            return 0
        try:
            df = self._spark.sql(
                f"""SELECT provider_id, provider_name
                    FROM dev_adb.raw.tbl_genie_provider_profile
                    LIMIT {limit}"""
            )
            rows = df.collect()
            for row in rows:
                r = row.asDict()
                name_key = r.get('provider_name', '').lower().strip()
                self._cache[name_key] = CanonicalProvider(
                    provider_id=r.get('provider_id', ''),
                    provider_name=r.get('provider_name', ''),
                )
            self._ready = True
            logger.info("Preloaded %d providers into cache", len(rows))
            return len(rows)
        except Exception as exc:
            logger.warning("Provider cache preload failed: %s", exc)
            self._ready = True
            return 0

    def is_ready(self) -> bool:
        """Whether the adapter has been initialized."""
        return self._ready

    def resolve(self, name: str) -> Optional[CanonicalProvider]:
        """Resolve a provider name to canonical record."""
        name_key = name.lower().strip()
        if name_key in self._cache:
            return self._cache[name_key]
        if self._spark is None:
            return None
        try:
            df = self._spark.sql(
                f"""SELECT provider_id, provider_name
                    FROM dev_adb.raw.tbl_genie_provider_profile
                    WHERE LOWER(provider_name) LIKE LOWER('%{name.replace("'", "''")}%')
                    LIMIT 1"""
            )
            rows = df.collect()
            if rows:
                r = rows[0].asDict()
                record = CanonicalProvider(
                    provider_id=r.get('provider_id', ''),
                    provider_name=r.get('provider_name', ''),
                )
                self._cache[name_key] = record
                return record
        except Exception as exc:
            logger.warning("Provider resolution failed for %s: %s", name, exc)
        return None

    def list_providers(self, limit: int = 100) -> list[CanonicalProvider]:
        """List canonical providers."""
        if self._cache:
            return list(self._cache.values())[:limit]
        if self._spark is None:
            return []
        try:
            df = self._spark.sql(
                f"""SELECT provider_id, provider_name
                    FROM dev_adb.raw.tbl_genie_provider_profile
                    LIMIT {limit}"""
            )
            return [
                CanonicalProvider(
                    provider_id=row['provider_id'],
                    provider_name=row['provider_name'],
                )
                for row in df.collect()
            ]
        except Exception as exc:
            logger.warning("Provider list failed: %s", exc)
            return []

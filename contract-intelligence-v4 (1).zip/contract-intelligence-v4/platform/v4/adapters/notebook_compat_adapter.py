"""Notebook compatibility adapter — shimming V2→V4 notebook interfaces."""
from __future__ import annotations
from typing import Any


class NotebookCompatAdapter:
    """Provides backward-compatible notebook cell interfaces for V4."""

    def __init__(self, runtime: Any = None) -> None:
        self._runtime = runtime

    def ask(self, question: str, **kwargs) -> dict:
        """V2-compatible ask() interface wrapping V4 runtime."""
        if self._runtime is None:
            return {"answer": "Runtime not initialized.", "confidence": "LOW"}
        response = self._runtime.ask(question, **kwargs)
        return {
            "answer": getattr(response, "answer", str(response)),
            "confidence": getattr(response, "confidence", "MODERATE"),
        }

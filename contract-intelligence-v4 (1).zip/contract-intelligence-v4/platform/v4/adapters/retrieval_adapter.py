"""Retrieval adapter — bridges legacy retrieve_fn to V4 RetrievalService."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence
import logging

logger = logging.getLogger(__name__)


@dataclass
class RetrievedPassage:
    """A single retrieved passage from vector search."""
    text: str = ""
    section: str = ""
    doc_id: str = ""
    score: float = 0.0
    effective_date: str = ""
    metadata: dict = field(default_factory=dict)

    @property
    def source_filename(self) -> str:
        return self.metadata.get('source_filename', '')


class RetrievalAdapter:
    """Bridges legacy retrieve() function to V4 retrieval interface."""

    def __init__(
        self,
        retrieve_fn: Optional[Callable] = None,
        retrieve_legal_fn: Optional[Callable] = None,
        retrieval_service: Optional[Any] = None,
        current_effective_filter: Optional[Any] = None,
        telemetry_repo: Optional[Any] = None,
        # Accept any additional kwargs for forward-compatibility
        **kwargs,
    ) -> None:
        self._retrieve_fn = retrieve_fn
        self._retrieve_legal_fn = retrieve_legal_fn
        self._retrieval_service = retrieval_service
        self._current_filter = current_effective_filter
        self._telemetry = telemetry_repo

    def retrieve(
        self,
        query: str,
        n_results: int = 10,
        filters: Optional[dict] = None,
        **kwargs,
    ) -> list[Any]:
        """Retrieve passages using available backend."""
        # Prefer native RetrievalService (P3-RET-4)
        if self._retrieval_service is not None:
            try:
                return self._retrieval_service.retrieve(
                    query=query, n_results=n_results, filters=filters, **kwargs
                )
            except Exception as exc:
                logger.warning("Native retrieval failed, falling back: %s", exc)

        # Fall back to legacy retrieve_fn
        if self._retrieve_fn is not None:
            try:
                return self._retrieve_fn(query, n_results=n_results, **(filters or {}))
            except Exception as exc:
                logger.warning("Legacy retrieve failed: %s", exc)
                return []

        return []

    def retrieve_legal(self, query: str, n_results: int = 10, **kwargs) -> list[Any]:
        """Retrieve from legal index."""
        if self._retrieve_legal_fn is not None:
            try:
                return self._retrieve_legal_fn(query, n_results=n_results, **kwargs)
            except Exception as exc:
                logger.warning("Legal retrieval failed: %s", exc)
        return []

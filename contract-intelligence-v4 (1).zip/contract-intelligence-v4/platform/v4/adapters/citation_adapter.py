"""Citation verification adapter bridging legacy verify_fn to V4."""
from __future__ import annotations
from typing import Any, Callable, Optional
from ..contracts.tool_types import ToolResult, Confidence


class CitationAdapter:
    """Wraps the legacy verify() function for V4 tool registry."""

    def __init__(self, verify_fn: Optional[Callable] = None) -> None:
        self._verify_fn = verify_fn

    def verify(self, claim: str, passages: list[dict], **kwargs) -> ToolResult:
        """Verify a claim against retrieved passages."""
        if self._verify_fn is None:
            return ToolResult(
                success=False,
                data=None,
                summary="Citation verification unavailable (no verify_fn configured).",
                confidence=Confidence.LOW,
            )
        try:
            result = self._verify_fn(claim, passages, **kwargs)
            return ToolResult(
                success=True,
                data=result,
                summary=f"Verified claim against {len(passages)} passages.",
                confidence=Confidence.MODERATE,
            )
        except Exception as exc:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Citation verification failed: {exc}",
                confidence=Confidence.LOW,
                error_message=str(exc),
            )

"""Legacy branch adapter — bridges V2 dispatch_fn to V4 tool calls."""
from __future__ import annotations
from typing import Any, Callable, Optional
from ..contracts.tool_types import ToolResult, Confidence


_BRANCH_TOOLS = [
    "single_provider",
    "multi_provider",
    "rate_comparison",
    "contract_summary",
]


def available_branch_tools() -> list[str]:
    """Return list of tool names handled by legacy branch dispatch."""
    return list(_BRANCH_TOOLS)


class LegacyBranchAdapter:
    """Bridges V2 dispatch() function calls into V4 ToolResult interface."""

    def __init__(self, dispatch_fn: Optional[Callable] = None) -> None:
        self._dispatch_fn = dispatch_fn

    def call(self, tool_name: str, question: str, **kwargs) -> ToolResult:
        """Call legacy branch tool via dispatch_fn."""
        if self._dispatch_fn is None:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Legacy tool \'{tool_name}\' unavailable (no dispatch_fn).",
                confidence=Confidence.LOW,
            )
        if tool_name not in _BRANCH_TOOLS:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Unknown legacy tool: {tool_name}",
                confidence=Confidence.LOW,
                error_message=f"Tool \'{tool_name}\' not in branch registry.",
            )
        try:
            result = self._dispatch_fn(tool_name, question, **kwargs)
            return ToolResult(
                success=True,
                data=result,
                summary=f"Legacy branch \'{tool_name}\' completed.",
                confidence=Confidence.MODERATE,
            )
        except Exception as exc:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Legacy tool \'{tool_name}\' failed: {exc}",
                confidence=Confidence.LOW,
                error_message=str(exc),
            )

    def describe(self) -> dict:
        """Return metadata about available legacy branch tools."""
        return {
            "type": "legacy_branch_adapter",
            "tools": _BRANCH_TOOLS,
            "dispatch_available": self._dispatch_fn is not None,
        }

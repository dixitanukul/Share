"""Benchmark adapter — wraps agent for evaluation."""
from __future__ import annotations
from typing import Any, Callable, Optional


class BenchmarkAdapter:
    """Adapter for running benchmark cases through the agent."""

    def __init__(self, query_fn: Optional[Callable] = None) -> None:
        self._query_fn = query_fn

    def run_case(self, question: str, **kwargs) -> dict:
        """Run a single benchmark case."""
        if self._query_fn is None:
            return {"answer": "", "error": "No query function configured"}
        try:
            return self._query_fn(question, **kwargs)
        except Exception as exc:
            return {"answer": "", "error": str(exc)}

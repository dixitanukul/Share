"""Platform V4 adapters — legacy bridge components."""

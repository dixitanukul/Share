import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Building2,
  CalendarClock,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  FileText,
  Filter,
  Loader2,
  Search,
  ShieldCheck,
  AlertTriangle,
  TrendingUp,
  Wallet,
  X,
} from 'lucide-react';

interface ProviderSummary {
  provider_name: string;
  provider_id: string;
  lob: string[];
  payment_types: string[];
  active: boolean;
  contract_count: number;
  amendment_count: number;
  latest_effective_date: string;
}

interface ProviderDetail extends ProviderSummary {
  rates: { service_category: string; rate_type: string; rate_numeric: number; effective_date: string }[];
  amendments: { doc_id: string; effective_date: string; page_count: number }[];
  documents: { doc_id: string; doc_role: string; filename: string; effective_date: string; page_count: number }[];
  clause_coverage: { concept_key: string; concept_label: string; status: string }[];
}

interface RiskScore {
  risk_score: number;
  risk_tier: string;
  days_to_expiry: number;
  compliance_gap: number;
  clause_gap: number;
  contracted_spend: number;
}

interface RiskAlert {
  alert_id: string;
  deadline_type: string;
  action_required_by: string;
  days_until_due: number;
  alert_priority: string;
  context_text?: string;
}

interface RiskDeadline {
  deadline_id: string;
  deadline_type: string;
  action_required_by: string;
  days_until_action: number;
  priority_tier: string;
}

interface RiskDetail {
  risk: RiskScore | null;
  alerts: RiskAlert[];
  deadlines: RiskDeadline[];
}

function riskTierColor(tier: string) {
  const map: Record<string, string> = {
    CRITICAL: 'bg-rose-100 text-rose-700',
    HIGH: 'bg-amber-100 text-amber-700',
    MEDIUM: 'bg-sky-100 text-sky-700',
    LOW: 'bg-emerald-100 text-emerald-700',
  };
  return map[tier] || 'bg-slate-100 text-slate-600';
}


const LOBS = ['commercial', 'medicare advantage', 'medi-cal', 'medicare'];
const PAYMENT_TYPES = ['capitation', 'fee for service', 'case rate', 'per diem', 'percent of charges'];

function ClauseBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    HAS: 'border-emerald-200 bg-emerald-50 text-emerald-700',
    NO_MENTION: 'border-slate-200 bg-slate-50 text-slate-500',
    DENIED: 'border-rose-200 bg-rose-50 text-rose-700',
    MIXED: 'border-amber-200 bg-amber-50 text-amber-700',
  };
  return (
    <span className={`inline-flex items-center rounded-lg border px-2.5 py-1 text-[11px] font-semibold ${styles[status] || 'border-slate-200 bg-slate-50 text-slate-500'}`}>
      {status.replace('_', ' ')}
    </span>
  );
}

function SkeletonRow() {
  return (
    <tr className="border-t border-slate-100">
      <td className="px-5 py-4"><div className="skeleton h-4 w-48" /><div className="skeleton mt-2 h-3 w-24" /></td>
      <td className="px-4 py-4"><div className="skeleton h-3 w-20" /></td>
      <td className="px-4 py-4"><div className="skeleton h-3 w-24" /></td>
      <td className="px-4 py-4 text-center"><div className="skeleton mx-auto h-3 w-8" /></td>
      <td className="px-4 py-4 text-center"><div className="skeleton mx-auto h-3 w-8" /></td>
      <td className="px-4 py-4 text-center"><div className="skeleton mx-auto h-5 w-16 rounded-full" /></td>
    </tr>
  );
}

export default function ProviderExplorerV2() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [lob, setLob] = useState('');
  const [paymentType, setPaymentType] = useState('');
  const [active, setActive] = useState('');
  const [page, setPage] = useState(0);
  const [providers, setProviders] = useState<ProviderSummary[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selectedProvider, setSelectedProvider] = useState<string>('');
  const [detail, setDetail] = useState<ProviderDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState('');
  const [riskData, setRiskData] = useState<RiskDetail | null>(null);
  const [riskLoading, setRiskLoading] = useState(false);
  const [error, setError] = useState('');
  const [retrying, setRetrying] = useState(false);
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pageSize = 25;

  const fetchProviders = useCallback(async (attempt = 0) => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (lob) params.set('lob', lob);
    if (paymentType) params.set('payment_type', paymentType);
    if (active) params.set('active', active);
    params.set('limit', String(pageSize));
    params.set('offset', String(page * pageSize));

    try {
      setError('');
      const response = await fetch(`/api/v1/providers?${params.toString()}`);
      if (response.status === 503 && attempt < 6) {
        const delay = Math.min(5000 + attempt * 5000, 20000);
        setRetrying(true);
        setLoading(false);
        retryTimerRef.current = setTimeout(() => {
          setRetrying(false);
          void fetchProviders(attempt + 1);
        }, delay);
        return;
      }
      setRetrying(false);
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error((body as Record<string, string>).detail || `Server error ${response.status}`);
      }
      const data = await response.json();
      setProviders(data.providers || []);
      setTotal(data.total || 0);
    } catch (err) {
      setRetrying(false);
      setProviders([]);
      setTotal(0);
      setError(err instanceof Error ? err.message : 'Failed to load providers');
    } finally {
      setLoading(false);
    }
  }, [search, lob, paymentType, active, page]);

  const openDetail = async (providerName: string) => {
    if (selectedProvider === providerName && detail) return; // already loaded
    setSelectedProvider(providerName);
    setDetailLoading(true);
    setDetailError('');
    setRiskData(null);
    setRiskLoading(true);
    try {
      // Parallel fetch: provider detail + risk/financial data
      const [detailRes, riskRes] = await Promise.allSettled([
        fetch(`/api/v1/providers/${encodeURIComponent(providerName)}`),
        fetch(`/api/v1/risk/${encodeURIComponent(providerName)}`),
      ]);

      if (detailRes.status === 'fulfilled') {
        const r = detailRes.value;
        if (r.status === 503) throw new Error('Platform is starting up. Try again in a moment.');
        if (!r.ok) {
          const body = await r.json().catch(() => ({}));
          throw new Error((body as Record<string, string>).detail || `HTTP ${r.status}`);
        }
        setDetail(await r.json());
      } else {
        throw (detailRes as PromiseRejectedResult).reason;
      }

      if (riskRes.status === 'fulfilled' && riskRes.value.ok) {
        const rd = await riskRes.value.json() as RiskDetail;
        setRiskData(rd);
      }
    } catch (err) {
      setDetail(null);
      setDetailError(err instanceof Error ? err.message : 'Failed to load detail');
    } finally {
      setDetailLoading(false);
      setRiskLoading(false);
    }
  };

  const closeDetail = () => {
    setSelectedProvider('');
    setDetail(null);
    setDetailError('');
    setRiskData(null);
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(0);
      fetchProviders();
    }, 300);
    return () => clearTimeout(timer);
  }, [search, lob, paymentType, active]);

  useEffect(() => {
    fetchProviders();
  }, [page]);

  useEffect(() => {
    return () => { if (retryTimerRef.current) clearTimeout(retryTimerRef.current); };
  }, []);


  // M1: ref for focus management in slide-over
  const detailPanelRef = useRef<HTMLElement>(null);

  // M1: Focus first button in slide-over when it opens; close on Escape
  useEffect(() => {
    if (!selectedProvider) return;
    const panel = detailPanelRef.current;
    if (!panel) return;
    // Focus first focusable element
    const first = panel.querySelector<HTMLElement>('button, a, [tabindex]:not([tabindex="-1"])');
    first?.focus();

    // Trap tab within panel
    const trap = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { closeDetail(); return; }
      if (e.key !== 'Tab') return;
      const focusables = panel.querySelectorAll<HTMLElement>(
        'button:not([disabled]), a[href], input:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (!focusables.length) return;
      const first2 = focusables[0];
      const last2 = focusables[focusables.length - 1];
      if (e.shiftKey) {
        if (document.activeElement === first2) { e.preventDefault(); last2.focus(); }
      } else {
        if (document.activeElement === last2) { e.preventDefault(); first2.focus(); }
      }
    };
    panel.addEventListener('keydown', trap);
    return () => panel.removeEventListener('keydown', trap);
  }, [selectedProvider, closeDetail]);

  const totalPages = Math.max(Math.ceil(total / pageSize), 1);

  return (
    <div className="h-full flex flex-col gap-4 overflow-hidden">
      {/* Header */}
      <div className="enterprise-panel p-5 shrink-0">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-bsc-blue-600">
              <Building2 size={14} /> Provider Explorer
            </div>
            <h1 className="mt-1 text-xl font-bold text-slate-900">Contract Portfolio</h1>
          </div>
          <div className="flex items-center gap-3 text-sm text-slate-500">
            <span className="rounded-lg bg-slate-100 px-3 py-1.5 font-medium text-slate-700">{total} providers</span>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-4 flex flex-wrap gap-3">
          <label className="relative flex-1 min-w-[200px]">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search providers" placeholder="Search providers..."
              className="w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm outline-none transition focus:border-bsc-blue-500 focus:ring-1 focus:ring-bsc-blue-500/20"
            />
          </label>
          <select aria-label="Filter by line of business" value={lob} onChange={(e) => setLob(e.target.value)} className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700">
            <option value="">All LOBs</option>
            {LOBS.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
          <select aria-label="Filter by payment type" value={paymentType} onChange={(e) => setPaymentType(e.target.value)} className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700">
            <option value="">All payment types</option>
            {PAYMENT_TYPES.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
          <select aria-label="Filter by active status" value={active} onChange={(e) => setActive(e.target.value)} className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700">
            <option value="">All statuses</option>
            <option value="true">Active</option>
            <option value="false">Inactive</option>
          </select>
        </div>

        {/* Active filters */}
        {[lob, paymentType, active].filter(Boolean).length > 0 && (
          <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
            <Filter size={12} />
            {[lob, paymentType, active].filter(Boolean).map((v) => (
              <span key={v} className="rounded-md bg-bsc-blue-50 px-2 py-1 font-medium text-bsc-blue-700">{v}</span>
            ))}
            <button type="button" onClick={() => { setLob(''); setPaymentType(''); setActive(''); }} className="text-slate-400 hover:text-slate-600 underline">Clear</button>
          </div>
        )}
      </div>

      {/* Retry/error banner */}
      {retrying && (
        <div className="flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 shrink-0">
          <Loader2 size={15} className="animate-spin text-amber-600" />
          <span className="text-sm text-amber-700">Platform starting up — loading automatically...</span>
        </div>
      )}
      {error && !retrying && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 shrink-0">
          <span className="text-sm text-rose-700">{error}</span>
          <button type="button" onClick={() => fetchProviders()} className="shrink-0 rounded-lg border border-rose-200 bg-white px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-50">Retry</button>
        </div>
      )}

      {/* Main content area */}
      <div className="relative flex-1 min-h-0 flex gap-4">
        {/* Table */}
        <div className="enterprise-panel flex-1 min-w-0 flex flex-col overflow-hidden">
          <div className="app-scrollbar flex-1 overflow-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500 sticky top-0 z-10">
                <tr>
                  <th className="px-5 py-3 font-semibold">Provider</th>
                  <th className="px-4 py-3 font-semibold">LOB</th>
                  <th className="px-4 py-3 font-semibold">Payment</th>
                  <th className="px-4 py-3 text-center font-semibold">Docs</th>
                  <th className="px-4 py-3 text-center font-semibold">Amendments</th>
                  <th className="px-4 py-3 text-center font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 8 }).map((_, i) => <SkeletonRow key={i} />)
                ) : providers.length === 0 ? (
                  <tr><td colSpan={6} className="px-6 py-16 text-center text-sm text-slate-400">No providers match the current filters.</td></tr>
                ) : (
                  providers.map((p) => (
                    <tr
                      key={p.provider_id}
                      className={`cursor-pointer border-t border-slate-100 transition-colors hover:bg-blue-50/50 ${selectedProvider === p.provider_name ? 'bg-blue-50' : ''}`}
                      onClick={() => openDetail(p.provider_name)}
                      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); void openDetail(p.provider_name); } }}
                      tabIndex={0}
                      role="row"
                      aria-label={`View details for ${p.provider_name}`}
                    >
                      <td className="px-5 py-3.5">
                        <div className="font-medium text-slate-900">{p.provider_name}</div>
                        <div className="mt-0.5 text-xs text-slate-400">{p.latest_effective_date || 'No effective date'}</div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-600">{p.lob.join(', ') || '\u2014'}</td>
                      <td className="px-4 py-3.5 text-slate-600">{p.payment_types.join(', ') || '\u2014'}</td>
                      <td className="px-4 py-3.5 text-center font-medium text-slate-700">{p.contract_count}</td>
                      <td className="px-4 py-3.5 text-center font-medium text-slate-700">{p.amendment_count}</td>
                      <td className="px-4 py-3.5 text-center">
                        <span className={`inline-flex rounded-md px-2 py-1 text-[11px] font-semibold ${p.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                          {p.active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between gap-3 border-t border-slate-100 px-5 py-3 text-sm text-slate-500">
            <span>Page {page + 1} of {totalPages}</span>
            <div className="flex items-center gap-2">
              <button type="button" onClick={() => setPage((c) => Math.max(c - 1, 0))} disabled={page === 0} aria-label="Previous page" className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium disabled:opacity-40 hover:bg-slate-50">
                <ChevronLeft size={14} /> Prev
              </button>
              <button type="button" onClick={() => setPage((c) => (c + 1 < totalPages ? c + 1 : c))} disabled={page + 1 >= totalPages} aria-label="Next page" className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium disabled:opacity-40 hover:bg-slate-50">
                Next <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Detail slide-over panel */}
        {selectedProvider && (
          <aside
            ref={detailPanelRef}
            role="dialog"
            aria-modal="true"
            aria-label={`Provider detail: ${selectedProvider}`}
            aria-labelledby="detail-panel-title"
            className="w-[400px] shrink-0 enterprise-panel flex flex-col overflow-hidden animate-slide-in max-lg:absolute max-lg:inset-y-0 max-lg:right-0 max-lg:z-20 max-lg:shadow-xl"
          >
            {/* Panel header */}
            <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
              <div className="min-w-0">
                <div className="text-xs font-semibold uppercase tracking-wider text-bsc-blue-600">Provider Detail</div>
                <div id="detail-panel-title" className="mt-1 truncate text-base font-bold text-slate-900">{selectedProvider}</div>
              </div>
              <button type="button" onClick={closeDetail} aria-label="Close provider detail" className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-400 hover:text-slate-600 hover:bg-slate-50">
                <X size={16} />
              </button>
            </div>

            {/* Panel body */}
            <div className="app-scrollbar flex-1 overflow-auto p-5 space-y-5">
              {detailLoading ? (
                <div className="space-y-4">
                  <div className="skeleton h-20 w-full" />
                  <div className="skeleton h-32 w-full" />
                  <div className="skeleton h-24 w-full" />
                </div>
              ) : detailError ? (
                <div className="rounded-xl border border-rose-200 bg-rose-50 p-4">
                  <div className="text-sm font-medium text-rose-700">Could not load provider</div>
                  <div className="mt-1 text-xs text-rose-600">{detailError}</div>
                  <button type="button" onClick={() => openDetail(selectedProvider)} className="mt-3 rounded-lg bg-white border border-rose-200 px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-50">Retry</button>
                </div>
              ) : detail ? (
                <>
                  {/* Status + payment */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
                      <div className="text-[11px] uppercase tracking-wide text-slate-400">Status</div>
                      <div className="mt-1.5 flex items-center gap-2">
                        <span className={`h-2 w-2 rounded-full ${detail.active ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                        <span className="text-sm font-semibold text-slate-800">{detail.active ? 'Active' : 'Inactive'}</span>
                      </div>
                    </div>
                    <div className="rounded-xl border border-slate-100 bg-slate-50 p-3">
                      <div className="text-[11px] uppercase tracking-wide text-slate-400">Payment</div>
                      <div className="mt-1.5 text-sm font-semibold text-slate-800">{detail.payment_types?.join(', ') || '\u2014'}</div>
                    </div>
                  </div>

                  {/* Risk & Financial — M2 */}
                  {(riskLoading || riskData) && (
                    <div>
                      <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                        <TrendingUp size={13} /> Risk & Financial
                      </div>
                      {riskLoading && !riskData ? (
                        <div className="flex items-center gap-2 rounded-xl border border-slate-100 bg-slate-50 px-3 py-3 text-xs text-slate-400">
                          <Loader2 size={12} className="animate-spin" /> Loading risk data…
                        </div>
                      ) : riskData ? (
                        <div className="space-y-2">
                          {riskData.risk && (
                            <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 px-3 py-2.5">
                              <div>
                                <div className="text-[11px] text-slate-400">Risk score</div>
                                <div className="mt-0.5 text-lg font-bold text-slate-900">{Number(riskData.risk.risk_score || 0).toFixed(1)}</div>
                              </div>
                              <div className="flex flex-col items-end gap-1.5">
                                <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${riskTierColor(riskData.risk.risk_tier)}`}>{riskData.risk.risk_tier}</span>
                                {riskData.risk.days_to_expiry != null && (
                                  <span className="text-[11px] text-slate-400">{riskData.risk.days_to_expiry}d to expiry</span>
                                )}
                              </div>
                            </div>
                          )}
                          {riskData.alerts.length > 0 && (
                            <div className="rounded-xl border border-amber-100 bg-amber-50 px-3 py-2">
                              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-700">
                                <AlertTriangle size={11} /> {riskData.alerts.length} active alert{riskData.alerts.length > 1 ? 's' : ''}
                                {(() => {
                                  const crit = riskData.alerts.filter((a) => a.alert_priority === 'CRITICAL').length;
                                  return crit > 0 ? <span className="ml-1 rounded-full bg-rose-100 px-1.5 py-0.5 text-[10px] text-rose-700">{crit} CRITICAL</span> : null;
                                })()}
                              </div>
                              <div className="mt-1.5 space-y-1">
                                {riskData.alerts.slice(0, 2).map((a) => (
                                  <div key={a.alert_id} className="truncate text-[11px] text-amber-600">
                                    {a.deadline_type}{a.action_required_by ? ` · ${a.action_required_by}` : ''}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          {riskData.deadlines.length > 0 && (
                            <div className="rounded-xl border border-slate-100 bg-slate-50 px-3 py-2">
                              <div className="text-[11px] font-semibold text-slate-500">Next deadline</div>
                              <div className="mt-1 flex items-center justify-between gap-2">
                                <span className="truncate text-xs text-slate-700">{riskData.deadlines[0].deadline_type}</span>
                                <span className="shrink-0 text-[11px] text-slate-400">{riskData.deadlines[0].days_until_action}d</span>
                              </div>
                            </div>
                          )}
                          {!riskData.risk && riskData.alerts.length === 0 && riskData.deadlines.length === 0 && (
                            <div className="rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-[11px] text-slate-400">No risk data available for this provider.</div>
                          )}
                        </div>
                      ) : null}
                    </div>
                  )}

                  {/* Clause coverage */}
                  {detail.clause_coverage?.length > 0 && (
                    <div>
                      <div className="mb-2.5 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                        <ShieldCheck size={13} /> Clause Coverage
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {detail.clause_coverage.map((c) => (
                          <div key={c.concept_key} className="rounded-lg border border-slate-100 bg-white px-3 py-2">
                            <div className="text-[11px] text-slate-400">{c.concept_label}</div>
                            <div className="mt-1.5"><ClauseBadge status={c.status} /></div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Rates — H4: proper table with column headers */}
                  {detail.rates?.length > 0 && (
                    <div>
                      <div className="mb-2.5 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                        <Wallet size={13} /> Current Rates ({detail.rates.length})
                      </div>
                      <div className="overflow-hidden rounded-lg border border-slate-200">
                        <table className="min-w-full text-xs">
                          <thead className="bg-slate-50 border-b border-slate-200">
                            <tr>
                              <th className="px-3 py-2 text-left font-semibold uppercase tracking-wide text-slate-500">Service Category</th>
                              <th className="px-3 py-2 text-left font-semibold uppercase tracking-wide text-slate-500">Rate Type</th>
                              <th className="px-3 py-2 text-right font-semibold uppercase tracking-wide text-slate-500">Amount</th>
                              <th className="px-3 py-2 text-left font-semibold uppercase tracking-wide text-slate-500">Effective</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 bg-white">
                            {detail.rates.slice(0, 10).map((r, i) => (
                              <tr key={`${r.service_category}-${i}`} className="hover:bg-slate-50">
                                <td className="px-3 py-2.5 font-medium text-slate-800">{r.service_category || '—'}</td>
                                <td className="px-3 py-2.5 text-slate-500">{r.rate_type || '—'}</td>
                                <td className="px-3 py-2.5 text-right font-semibold text-slate-900">
                                  {r.rate_numeric != null ? `$${r.rate_numeric.toLocaleString()}` : '—'}
                                </td>
                                <td className="px-3 py-2.5 text-slate-400">{r.effective_date || '—'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {detail.rates.length > 10 && (
                          <div className="border-t border-slate-100 bg-slate-50 px-3 py-2 text-center text-xs text-slate-400">
                            +{detail.rates.length - 10} more rates
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Amendments — H5: vertical timeline, sorted newest-first */}
                  {detail.amendments?.length > 0 && (() => {
                    const sorted = [...detail.amendments].sort((a, b) =>
                      (b.effective_date || '').localeCompare(a.effective_date || '')
                    );
                    const shown = sorted.slice(0, 8);
                    return (
                      <div>
                        <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                          <CalendarClock size={13} /> Amendment Timeline ({detail.amendments.length})
                        </div>
                        <div className="relative pl-5">
                          <div className="absolute left-[7px] top-2 bottom-2 w-px bg-slate-200" />
                          <div className="space-y-2.5">
                            {shown.map((a, i) => (
                              <div key={`${a.doc_id}-${i}`} className="relative flex items-start gap-3">
                                <div className={`absolute -left-5 mt-1.5 h-2.5 w-2.5 rounded-full border-2 border-white ring-2 ${i === 0 ? 'bg-bsc-blue-600 ring-bsc-blue-300' : 'bg-slate-300 ring-slate-100'}`} />
                                <div className="flex-1 rounded-lg border border-slate-100 bg-white px-3 py-2 shadow-sm">
                                  <div className="flex items-center justify-between gap-2">
                                    <span className={`text-[11px] font-semibold ${i === 0 ? 'text-bsc-blue-600' : 'text-slate-500'}`}>
                                      {a.effective_date || 'Unknown date'}
                                    </span>
                                    {a.page_count > 0 && (
                                      <span className="text-[10px] text-slate-400">{a.page_count}p</span>
                                    )}
                                  </div>
                                  <div className="mt-0.5 truncate text-xs text-slate-600">{a.doc_id || '—'}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                          {detail.amendments.length > 8 && (
                            <div className="mt-2.5 text-center text-xs text-slate-400">
                              +{detail.amendments.length - 8} earlier amendments
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })()}

                  {/* Documents */}
                  {detail.documents?.length > 0 && (
                    <div>
                      <div className="mb-2.5 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                        <FileText size={13} /> Documents ({detail.documents.length})
                      </div>
                      <div className="space-y-1.5">
                        {detail.documents.slice(0, 6).map((d, i) => (
                          <div key={`${d.doc_id}-${i}`} className="rounded-lg bg-slate-50 px-3 py-2 text-sm">
                            <div className="font-medium text-slate-700 truncate">{d.filename}</div>
                            <div className="mt-0.5 flex items-center gap-2 text-[11px] text-slate-400">
                              <span className="rounded bg-white border border-slate-200 px-1.5 py-0.5 font-medium text-slate-500">{d.doc_role}</span>
                              <span>{d.effective_date || 'Unknown'}</span>
                              <span>{d.page_count}p</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* CTA */}
                  <button
                    type="button"
                    onClick={() => navigate(`/?provider=${encodeURIComponent(detail.provider_name)}`)}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-bsc-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm hover:bg-bsc-blue-700 transition-colors"
                  >
                    Ask about this provider <ArrowRight size={15} />
                  </button>
                </>
              ) : null}
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Bot,
  Building2,
  Check,
  ChevronLeft,
  ChevronRight,
  Copy,
  Download,
  FileText,
  Link as LinkIcon,
  Loader2,
  MessageSquarePlus,
  PanelLeftClose,
  PanelLeft,
  SendHorizonal,
  Sparkles,
  Square,
  ThumbsDown,
  ThumbsUp,
  X,
} from 'lucide-react';
import type { Citation, ConfidenceLabel, Message, Session, SessionDetail } from '../types/api';
import { useStreamQueryV2 } from '../hooks/useStreamQueryV2';
import ReactMarkdown, { type Components } from 'react-markdown';
import remarkGfm from 'remark-gfm';
import type React from 'react';
import { OnboardingModal } from '../components/OnboardingModal';
import { StructuredFeedback } from '../components/StructuredFeedback';
import { EvidencePanel } from '../components/EvidencePanel';
import { ProcessTrail } from '../components/ProcessTrail';
import { track } from '../services/analytics';

function formatTimestamp(value?: string) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json() as Promise<T>;
}

function ConfidenceBadge({ label }: { label: ConfidenceLabel }) {
  const styles: Record<ConfidenceLabel, string> = {
    HIGH: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    MODERATE: 'bg-amber-50 text-amber-700 border-amber-200',
    LOW: 'bg-rose-50 text-rose-700 border-rose-200',
    UNCERTAIN: 'bg-slate-50 text-slate-600 border-slate-200',
  };
  return <span className={`inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-semibold ${styles[label]}`}>{label}</span>;
}

function CitationCard({ citation }: { citation: Citation }) {
  const viewerUrl = citation.source
    ? `/viewer?doc=${encodeURIComponent(citation.source)}${citation.page ? `&page=${citation.page}` : ''}${citation.snippet ? `&snippet=${encodeURIComponent(citation.snippet.slice(0, 180))}` : ''}`
    : '';

  const body = (
    <div className="space-y-1">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 text-sm font-medium text-slate-800 truncate">{citation.source}</div>
        {citation.page ? <div className="shrink-0 text-[11px] text-slate-400">p.{citation.page}</div> : null}
      </div>
      {citation.provider_name ? <div className="text-[11px] text-bsc-blue-600 font-medium">{citation.provider_name}</div> : null}
      {citation.snippet ? <div className="line-clamp-2 text-xs leading-5 text-slate-500">{citation.snippet}</div> : null}
    </div>
  );

  return viewerUrl ? (
    <a href={viewerUrl} target="_blank" rel="noopener noreferrer" className="block rounded-xl border border-slate-100 bg-white p-3 transition-all hover:border-bsc-blue-200 hover:shadow-sm">
      {body}
    </a>
  ) : (
    <div className="rounded-xl border border-slate-100 bg-white p-3">{body}</div>
  );
}

function FeedbackControls({ sessionId, messageIndex }: { sessionId: string; messageIndex: number }) {
  const [rating, setRating] = useState<'up' | 'down' | null>(null);

  const submit = async (value: 'up' | 'down') => {
    setRating(value);
    try {
      await fetch('/api/v1/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId, query_id: `msg-${messageIndex}`, rating: value }),
      });
    } catch { /* fire and forget */ }
  };

  if (!sessionId) return null;

  return (
    <div className="mt-3 flex items-center gap-1.5">
      <button type="button" onClick={() => submit('up')} aria-label="Mark response as helpful" className={`rounded-lg border px-2 py-1 text-xs transition-colors ${rating === 'up' ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-slate-150 bg-white text-slate-400 hover:text-slate-600 hover:border-slate-200'}`}>
        <span className="flex items-center gap-1"><ThumbsUp size={11} />{rating === 'up' ? ' Helpful' : ''}</span>
      </button>
      <button type="button" onClick={() => submit('down')} aria-label="Flag response as unhelpful" className={`rounded-lg border px-2 py-1 text-xs transition-colors ${rating === 'down' ? 'border-rose-200 bg-rose-50 text-rose-700' : 'border-slate-150 bg-white text-slate-400 hover:text-slate-600 hover:border-slate-200'}`}>
        <span className="flex items-center gap-1"><ThumbsDown size={11} />{rating === 'down' ? ' Flagged' : ''}</span>
      </button>
    </div>
  );
}

// M3: DOFR-aware markdown component renderers
// Detects boolean/yes-no cells and responsibility column headers, applies color coding.
const _DOFR_HEADER_RE = /responsible|group|hospital|health.?plan|bsc/i;
const _TRUE_RE = /^(true|yes|✓)$/i;
const _FALSE_RE = /^(false|no|—|\u2014)$/i;

const MD_COMPONENTS: Components = {
  table({ node: _node, children, ...rest }) {
    return (
      <div className="my-3 overflow-auto rounded-lg border border-slate-200" style={{ maxHeight: '65vh' }}>
        <table style={{ margin: 0, minWidth: '480px' }} {...(rest as React.ComponentPropsWithoutRef<'table'>)}>{children}</table>
      </div>
    );
  },
  th({ node: _node, children, ...rest }) {
    const text = String(children ?? '');
    const isDOFR = _DOFR_HEADER_RE.test(text);
    return (
      <th
        style={isDOFR ? { textAlign: 'center', backgroundColor: '#EFF6FF', color: '#1D4ED8' } : undefined}
        {...(rest as React.ComponentPropsWithoutRef<'th'>)}
      >
        {children}
      </th>
    );
  },
  td({ node: _node, children, ...rest }) {
    const text = String(children ?? '').trim();
    if (_TRUE_RE.test(text)) {
      return (
        <td style={{ textAlign: 'center' }} {...(rest as React.ComponentPropsWithoutRef<'td'>)}>
          <span className="inline-flex items-center gap-1 rounded-md bg-emerald-100 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">✓ Yes</span>
        </td>
      );
    }
    if (_FALSE_RE.test(text)) {
      return (
        <td style={{ textAlign: 'center' }} {...(rest as React.ComponentPropsWithoutRef<'td'>)}>
          <span className="inline-flex items-center rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-400">—</span>
        </td>
      );
    }
    return <td {...(rest as React.ComponentPropsWithoutRef<'td'>)}>{children}</td>;
  },
};

function MarkdownContent({ content, className = '' }: { content: string; className?: string }) {
  return (
    <div className={`md-content text-sm leading-7 ${className}`}>
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={MD_COMPONENTS}>{content}</ReactMarkdown>
    </div>
  );
}

export default function ChatPageV2() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [sessionsTotal, setSessionsTotal] = useState(0);
  const [sessionsPage, setSessionsPage] = useState(0);
  const [input, setInput] = useState('');
  const [providerName, setProviderName] = useState('');
  const [sessionId, setSessionId] = useState('');
  const [sessionsLoading, setSessionsLoading] = useState(false);
  const [sessionLoading, setSessionLoading] = useState(false);
  const [error, setError] = useState('');
  const [copyState, setCopyState] = useState<'markdown' | 'link' | null>(null);
  const [showSessions, setShowSessions] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const { progress, stream, abort, reset } = useStreamQueryV2();
  const sessionsPageSize = 20;

  const refreshSessions = async (pageArg = sessionsPage, attempt = 0) => {
    if (attempt === 0) setSessionsLoading(true);
    try {
      const params = new URLSearchParams({
        limit: String(sessionsPageSize),
        offset: String(pageArg * sessionsPageSize),
      });
      const data = await fetchJson<{ sessions: Session[]; total: number }>(`/api/v1/sessions?${params.toString()}`);
      setSessions(data.sessions || []);
      setSessionsTotal(data.total || 0);
      setSessionsLoading(false);
    } catch (err) {
      const is503 = err instanceof Error && err.message.includes('503');
      if (is503 && attempt < 8) {
        // Backend warming up — keep spinner and retry in 10s
        setTimeout(() => { void refreshSessions(pageArg, attempt + 1); }, 10_000);
      } else {
        setSessions([]);
        setSessionsTotal(0);
        setSessionsLoading(false);
      }
    }
  };

  const loadSession = async (id: string) => {
    if (!id) return;
    setSessionLoading(true);
    setError('');
    try {
      const detail = await fetchJson<SessionDetail>(`/api/v1/sessions/${id}`);
      setMessages(detail.messages || []);
      setSessionId(detail.session_id);
      const next = new URLSearchParams(searchParams);
      next.set('session', detail.session_id);
      setSearchParams(next, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load session');
    } finally {
      setSessionLoading(false);
    }
  };

  useEffect(() => { void refreshSessions(sessionsPage); }, [sessionsPage]);

  useEffect(() => {
    const provider = searchParams.get('provider') || '';
    const session = searchParams.get('session') || '';
    if (provider) {
      setProviderName(provider);
      const next = new URLSearchParams(searchParams);
      next.delete('provider');
      setSearchParams(next, { replace: true });
    }
    if (session) loadSession(session);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, progress.answer]);

  const startNewChat = () => {
    abort(); reset();
    setMessages([]);
    setSessionId('');
    setSessionsPage(0);
    setError('');
    const next = new URLSearchParams(searchParams);
    next.delete('session');
    setSearchParams(next, { replace: true });
    inputRef.current?.focus();
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!input.trim() || progress.isStreaming) return;

    const question = input.trim();
    const userMessage: Message = { role: 'user', content: question, timestamp: new Date().toISOString() };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setError('');

    const result = await stream({
      question,
      provider_name: providerName || '',
      session_id: sessionId || '',
      stream: true,
    });

    const resolvedSessionId = result.done?.session_id || sessionId;
    if (resolvedSessionId) {
      setSessionId(resolvedSessionId);
      const next = new URLSearchParams(searchParams);
      next.set('session', resolvedSessionId);
      setSearchParams(next, { replace: true });
    }

    const assistantMessage: Message = {
      role: 'assistant',
      content: result.error ? `Error: ${result.error}` : result.answer || 'No response returned.',
      timestamp: new Date().toISOString(),
      citations: result.citations,
      confidence: result.confidence?.label,
      confidence_score: result.confidence?.score,
      confidence_reason: result.confidence?.reason,
      latency_ms: result.done?.latency_ms,
      cost_usd: result.done?.cost_usd,
      tool_calls: result.done?.tool_calls,
      tool_names: result.done?.tool_names,
      process_trail: result.processTrail.length > 0 ? result.processTrail : undefined,
      route_detected: result.routeDetected,
    };

    setMessages((prev) => [...prev, assistantMessage]);
    // Delay session refresh to allow backend persistence to complete
    setTimeout(() => {
      setSessionsPage(0);
      void refreshSessions(0);
    }, 2000);
    reset();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as unknown as React.FormEvent);
    }
  };

  const copyMarkdown = async () => {
    const md = messages.map((m) => `## ${m.role === 'user' ? 'Question' : 'Answer'}\n\n${m.content}`).join('\n\n---\n\n');
    await navigator.clipboard.writeText(md);
    setCopyState('markdown');
    setTimeout(() => setCopyState(null), 1500);
  };

  const copyShareLink = async () => {
    if (!sessionId) return;
    await navigator.clipboard.writeText(`${window.location.origin}/?session=${sessionId}`);
    setCopyState('link');
    setTimeout(() => setCopyState(null), 1500);
  };

  const sessionStart = sessionsTotal === 0 ? 0 : sessionsPage * sessionsPageSize + 1;
  const sessionEnd = Math.min((sessionsPage + 1) * sessionsPageSize, sessionsTotal);
  const canPrevSessions = sessionsPage > 0;
  const canNextSessions = sessionEnd < sessionsTotal;

  return (
    <div className="h-full flex gap-4 overflow-hidden">
      {/* Sessions sidebar */}
      {showSessions && (
        <aside className="w-[280px] shrink-0 enterprise-panel flex flex-col overflow-hidden max-lg:absolute max-lg:inset-y-0 max-lg:left-0 max-lg:z-20 max-lg:shadow-xl animate-slide-in">
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-4 py-3.5">
            <span className="text-sm font-semibold text-slate-800">Sessions</span>
            <div className="flex items-center gap-1.5">
              <button type="button" onClick={startNewChat} className="flex items-center gap-1.5 rounded-lg bg-bsc-blue-600 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-bsc-blue-700">
                <MessageSquarePlus size={12} /> New
              </button>
              <button type="button" onClick={() => setShowSessions(false)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 lg:hidden">
                <X size={14} />
              </button>
            </div>
          </div>

          {providerName && (
            <div className="mx-3 mt-3 rounded-lg border border-bsc-blue-200 bg-bsc-blue-50 p-3">
              <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-bsc-blue-700">
                <Building2 size={12} /> Scoped to
              </div>
              <div className="mt-1 text-sm font-medium text-slate-900 truncate">{providerName}</div>
              <button type="button" onClick={() => setProviderName('')} className="mt-1.5 text-[11px] text-slate-500 underline">Clear scope</button>
            </div>
          )}

          <div className="app-scrollbar flex-1 overflow-auto p-3 space-y-1.5">
            {sessionsLoading ? (
              <div className="space-y-2">
                {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-14 w-full" />)}
              </div>
            ) : sessions.length === 0 ? (
              <div className="rounded-lg border border-dashed border-slate-200 px-4 py-8 text-center">
                <Sparkles size={20} className="mx-auto text-slate-300" />
                <p className="mt-2 text-xs text-slate-400">No sessions yet. Ask a question to start one.</p>
              </div>
            ) : (
              sessions.map((s) => (
                <button
                  key={s.session_id}
                  type="button"
                  onClick={() => loadSession(s.session_id)}
                  className={`w-full rounded-lg border p-3 text-left transition-all ${s.session_id === sessionId ? 'border-bsc-blue-200 bg-bsc-blue-50' : 'border-transparent hover:border-slate-200 hover:bg-slate-50'}`}
                >
                  <div className="line-clamp-2 text-sm font-medium text-slate-800">{s.title || 'Untitled'}</div>
                  <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{s.message_count || 0} msgs</span>
                    <span>{formatTimestamp(s.updated_at)}</span>
                  </div>
                </button>
              ))
            )}
          </div>

          <div className="flex items-center justify-between gap-2 border-t border-slate-100 px-3 py-2.5 text-[11px] text-slate-500">
            <span>{sessionStart}-{sessionEnd} of {sessionsTotal}</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setSessionsPage((current) => Math.max(current - 1, 0))}
                disabled={!canPrevSessions || sessionsLoading}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-slate-500 hover:bg-slate-50 disabled:opacity-40"
              >
                <ChevronLeft size={12} /> Prev
              </button>
              <button
                type="button"
                onClick={() => setSessionsPage((current) => current + 1)}
                disabled={!canNextSessions || sessionsLoading}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-slate-500 hover:bg-slate-50 disabled:opacity-40"
              >
                Next <ChevronRight size={12} />
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* Main chat area */}
      <section className="enterprise-panel flex-1 min-w-0 flex flex-col overflow-hidden">
        {/* Chat toolbar */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-4 py-2.5 shrink-0">
          <div className="flex items-center gap-2">
            {!showSessions && (
              <button type="button" onClick={() => setShowSessions(true)} className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:bg-slate-50">
                <PanelLeft size={15} />
              </button>
            )}
            <div className="text-sm font-semibold text-slate-700">
              {sessionId ? 'Active session' : 'New conversation'}
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button type="button" onClick={copyMarkdown} disabled={messages.length === 0} className="rounded-lg border border-slate-200 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 disabled:opacity-30">
              {copyState === 'markdown' ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
            </button>
            <button type="button" onClick={copyShareLink} disabled={!sessionId} className="rounded-lg border border-slate-200 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 disabled:opacity-30">
              {copyState === 'link' ? <Check size={14} className="text-emerald-600" /> : <LinkIcon size={14} />}
            </button>
            {sessionId && (
              <a href={`/api/v1/export/${sessionId}?format=markdown`} className="rounded-lg border border-slate-200 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50">
                <Download size={14} />
              </a>
            )}
          </div>
        </div>

        {/* Messages */}
        <div role="log" aria-live="polite" aria-label="Conversation messages" className="app-scrollbar flex-1 overflow-auto px-4 py-5 space-y-5">
          {error && <div className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm text-rose-700">{error}</div>}
          {sessionLoading && (
            <div className="flex items-center gap-2 text-sm text-slate-400"><Loader2 size={14} className="animate-spin" /> Loading session...</div>
          )}

          {messages.length === 0 && !progress.isStreaming && !sessionLoading && (
            <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-bsc-blue-600 text-white shadow-md">
                <Sparkles size={24} />
              </div>
              <h2 className="mt-4 text-lg font-bold text-slate-900">What would you like to know?</h2>
              <p className="mt-2 max-w-md text-sm text-slate-500 leading-6">
                Ask about provider contracts, rates, amendments, clause coverage, or anything in the knowledge base.
              </p>


            </div>
          )}

          {messages.map((msg, idx) => (
            <div key={`${msg.role}-${idx}`} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start w-full'} animate-fade-in`}>
              <div className={`${msg.role === 'user' ? 'max-w-3xl bg-slate-900 text-white' : 'w-full border border-slate-100 bg-white shadow-sm'} rounded-2xl px-5 py-4`}>
                {msg.role === 'user' ? (
                  <div className="whitespace-pre-wrap text-sm leading-7">{msg.content}</div>
                ) : (
                  <>
                    <MarkdownContent content={msg.content} className="text-slate-700" />
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      {msg.confidence && <ConfidenceBadge label={msg.confidence} />}
                      {msg.latency_ms ? <span className="text-[11px] text-slate-400">{(msg.latency_ms / 1000).toFixed(1)}s</span> : null}
                      {typeof msg.cost_usd === 'number' ? <span className="text-[11px] text-slate-400">${msg.cost_usd.toFixed(3)}</span> : null}
                      {msg.tool_names && msg.tool_names.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {msg.tool_names.map((tn) => (
                            <span key={tn} className="inline-flex items-center rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500">
                              {tn.replace(/_/g, ' ')}
                            </span>
                          ))}
                        </div>
                      ) : msg.tool_calls ? (
                        <span className="text-[11px] text-slate-400">{msg.tool_calls} tool{msg.tool_calls !== 1 ? 's' : ''}</span>
                      ) : null}
                    </div>
                    {msg.citations && msg.citations.length > 0 && (
                      <div className="mt-4">
                        <div className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                          <FileText size={11} /> Sources
                        </div>
                        <div className="grid gap-2 sm:grid-cols-2">
                          {msg.citations.map((c, ci) => <CitationCard key={`${c.source}-${ci}`} citation={c} />)}
                        </div>
                      </div>
                    )}
                    {/* C-13: Evidence panel */}
                    <EvidencePanel evidence={(msg as any).evidence_summary} sessionId={sessionId} />
                    {/* Process Trail for completed messages (collapsed by default) */}
                    {(msg.process_trail && msg.process_trail.length > 0 || msg.confidence_reason) && (
                      <ProcessTrail
                        steps={msg.process_trail || []}
                        route={msg.route_detected || null}
                        isStreaming={false}
                        confidenceReason={msg.confidence_reason}
                      />
                    )}
                    <StructuredFeedback sessionId={sessionId} messageIndex={idx} />
                  </>
                )}
              </div>
            </div>
          ))}

          {/* Streaming indicator — shows real-time Process Trail */}
          {progress.isStreaming && (
            <div className="flex justify-start animate-fade-in">
              <div className="w-full rounded-2xl border border-slate-100 bg-white px-5 py-4 shadow-sm">
                {progress.answer ? (
                  <>
                    <MarkdownContent content={progress.answer} className="text-slate-700" />
                    <ProcessTrail
                      steps={progress.processTrail}
                      route={progress.routeDetected}
                      isStreaming={true}
                    />
                  </>
                ) : (
                  <>
                    {/* Show ProcessTrail when we have route/steps */}
                    {(progress.processTrail.length > 0 || progress.routeDetected) ? (
                      <ProcessTrail
                        steps={progress.processTrail}
                        route={progress.routeDetected}
                        isStreaming={true}
                      />
                    ) : (
                      /* Fallback: simple spinner for initial loading */
                      <div className="flex items-center gap-3">
                        <Loader2 size={15} className="animate-spin text-bsc-blue-600 shrink-0" />
                        <span className="text-sm text-slate-500">
                          {progress.thinking || 'Analyzing your question…'}
                        </span>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input area */}
        <div className="border-t border-slate-100 px-4 py-3 shrink-0">
          <form onSubmit={handleSubmit} className="flex items-end gap-3">
            <div className="flex-1 relative">
              <textarea
aria-label="Contract question input"
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={providerName ? `Ask about ${providerName}...` : 'Ask a contract question...'}
                rows={1}
                className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 text-sm outline-none transition focus:border-bsc-blue-500 focus:bg-white focus:ring-1 focus:ring-bsc-blue-500/20"
                style={{ minHeight: '44px', maxHeight: '120px' }}
              />
            </div>
            {progress.isStreaming ? (
              <button type="button" onClick={abort} aria-label="Stop streaming response" className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-white hover:bg-slate-700 shrink-0">
                <Square size={14} />
              </button>
            ) : (
              <button type="submit" aria-label="Send question" disabled={!input.trim()} className="flex h-11 w-11 items-center justify-center rounded-xl bg-bsc-blue-600 text-white hover:bg-bsc-blue-700 disabled:opacity-40 shrink-0 transition-colors">
                <SendHorizonal size={16} />
              </button>
            )}
          </form>
        </div>
      </section>
    </div>
  );
}

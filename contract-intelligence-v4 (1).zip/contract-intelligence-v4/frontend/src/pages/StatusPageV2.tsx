import { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, CheckCircle2, Clock3, DollarSign, RefreshCw, Server, Shield, TrendingUp, Users, Wifi, WifiOff, Zap } from 'lucide-react';
import type { HealthResponse, MetricPoint, StatusMetrics } from '../types/api';

function Sparkline({ points, color }: { points: MetricPoint[]; color: string }) {
  if (!points.length) {
    return (
      <div className="flex h-14 items-center justify-center text-xs text-slate-300">
        <span>Collecting data...</span>
      </div>
    );
  }
  const width = 200;
  const height = 48;
  const values = points.map((p) => p.value);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;
  const pathD = values
    .map((v, i) => {
      const x = (i / Math.max(values.length - 1, 1)) * width;
      const y = height - ((v - min) / range) * (height - 8) - 4;
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    })
    .join(' ');

  return (
    <div>
      <svg viewBox={`0 0 ${width} ${height}`} className="h-14 w-full" preserveAspectRatio="none">
        <path d={pathD} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="mt-1 flex justify-between text-[10px] text-slate-400">
        <span>{points[0]?.timestamp?.slice(5, 10) || ''}</span>
        <span>{points[points.length - 1]?.timestamp?.slice(5, 10) || ''}</span>
      </div>
    </div>
  );
}

function MetricCard({ icon: Icon, label, value, detail, color }: { icon: React.ElementType; label: string; value: string; detail: string; color?: string }) {
  return (
    <div className="enterprise-card metric-glow rounded-2xl p-5">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
        <Icon size={13} className={color || 'text-slate-400'} /> {label}
      </div>
      <div className="mt-3 text-2xl font-bold text-slate-900">{value}</div>
      <div className="mt-1 text-xs text-slate-500">{detail}</div>
    </div>
  );
}

function StatusDot({ state }: { state: string }) {
  const colors: Record<string, string> = {
    CLOSED: 'bg-emerald-500',
    OPEN: 'bg-rose-500',
    HALF_OPEN: 'bg-amber-500',
  };
  return <span className={`inline-block h-2.5 w-2.5 rounded-full ${colors[state] || 'bg-slate-400'}`} />;
}

export default function StatusPageV2() {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [metrics, setMetrics] = useState<StatusMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const fetchAll = async (attempt = 0) => {
    if (attempt === 0) {
      setLoading(true);
      setError('');
    }
    try {
      const [healthRes, metricsRes] = await Promise.all([
        fetch('/health'),
        fetch('/api/v1/status/metrics'),
      ]);
      if (healthRes.ok) {
        const healthText = await healthRes.text();
        try { setHealth(JSON.parse(healthText)); } catch { /* health returns non-JSON sometimes */ }
      }
      if (metricsRes.ok) {
        setMetrics(await metricsRes.json());
        setLastRefresh(new Date());
        setLoading(false);
      } else if (metricsRes.status === 503 && attempt < 6) {
        // Backend warming up — retry in 10s, keep spinner visible
        setTimeout(() => fetchAll(attempt + 1), 10_000);
      } else {
        setLastRefresh(new Date());
        setLoading(false);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch status');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
    const timer = setInterval(() => fetchAll(), 30000);
    // Re-fetch immediately when the global startup banner signals backend is live
    const onReady = () => fetchAll();
    window.addEventListener('appReady', onReady);
    return () => {
      clearInterval(timer);
      window.removeEventListener('appReady', onReady);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const overallStatus = useMemo(() => {
    if (!health) return { label: 'Connecting...', color: 'bg-slate-100 text-slate-600 border-slate-200', dot: 'bg-slate-400' };
    if (health.status === 'OK') return { label: 'All Systems Operational', color: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' };
    if (health.status === 'DEGRADED') return { label: 'Degraded Performance', color: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' };
    return { label: 'System Issues Detected', color: 'bg-rose-50 text-rose-700 border-rose-200', dot: 'bg-rose-500' };
  }, [health]);

  const hasMetrics = metrics && metrics.total_queries > 0;

  return (
    <div className="h-full flex flex-col gap-4 overflow-auto app-scrollbar">
      {/* Header */}
      <section className="enterprise-panel p-5 shrink-0">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-bsc-blue-600">
              <Activity size={14} /> System Status
            </div>
            <h1 className="mt-1 text-xl font-bold text-slate-900">Platform Health & Telemetry</h1>
          </div>
          <div className="flex items-center gap-3">
            {lastRefresh && <span className="text-xs text-slate-400">Updated {lastRefresh.toLocaleTimeString()}</span>}
            <button type="button" onClick={() => fetchAll()} disabled={loading} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50 disabled:opacity-40">
              <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Refresh
            </button>
          </div>
        </div>

        {/* Status banner */}
        <div className={`mt-4 flex items-center gap-3 rounded-xl border px-4 py-3.5 ${overallStatus.color}`}>
          <span className={`pulse-dot h-3 w-3 rounded-full ${overallStatus.dot}`} />
          <span className="text-sm font-semibold">{overallStatus.label}</span>
          {health && (
            <span className="ml-auto text-xs opacity-70">v{health.version} &middot; {Math.round(health.uptime_s / 60)}m uptime</span>
          )}
        </div>

        {error && <div className="mt-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm text-rose-700">{error}</div>}
      </section>

      {/* KPI Cards */}
      {loading && !metrics ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4 shrink-0">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="enterprise-card rounded-2xl p-5">
              <div className="skeleton h-3 w-16 mb-3" />
              <div className="skeleton h-7 w-20 mb-2" />
              <div className="skeleton h-3 w-28" />
            </div>
          ))}
        </div>
      ) : hasMetrics ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4 shrink-0">
          <MetricCard icon={Zap} label="Queries" value={metrics!.total_queries.toLocaleString()} detail="Last 7 days" color="text-blue-500" />
          <MetricCard icon={Clock3} label="Avg Latency" value={`${(metrics!.avg_latency_ms / 1000).toFixed(1)}s`} detail={`P95: ${(metrics!.p95_latency_ms / 1000).toFixed(1)}s`} color="text-violet-500" />
          <MetricCard icon={AlertTriangle} label="Error Rate" value={`${metrics!.error_rate}%`} detail="7-day failure ratio" color="text-rose-500" />
          <MetricCard icon={DollarSign} label="Total Spend" value={`$${metrics!.total_cost_usd.toFixed(2)}`} detail={metrics!.total_queries ? `$${(metrics!.total_cost_usd / metrics!.total_queries).toFixed(3)} per query` : ''} color="text-amber-500" />
        </div>
      ) : (
        <div className="enterprise-panel p-8 text-center shrink-0">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-400">
            <TrendingUp size={20} />
          </div>
          <h3 className="mt-3 text-sm font-semibold text-slate-700">No telemetry data yet</h3>
          <p className="mt-1 text-xs text-slate-500 max-w-sm mx-auto">
            Query metrics will appear here after users start asking questions through the workspace. Data refreshes every 30 seconds.
          </p>
        </div>
      )}

      {/* Trends + Dependencies grid */}
      <div className="grid gap-4 lg:grid-cols-2 shrink-0">
        {/* Trend lines */}
        <section className="enterprise-panel p-5">
          <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-800">
            <TrendingUp size={15} className="text-bsc-blue-600" /> 7-Day Trends
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-3">
              <div className="text-[11px] uppercase tracking-wide text-slate-400 mb-2">Latency</div>
              <Sparkline points={metrics?.latency_trend || []} color="#7c3aed" />
            </div>
            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-3">
              <div className="text-[11px] uppercase tracking-wide text-slate-400 mb-2">Volume</div>
              <Sparkline points={metrics?.queries_trend || []} color="#2563eb" />
            </div>
            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-3">
              <div className="text-[11px] uppercase tracking-wide text-slate-400 mb-2">Errors</div>
              <Sparkline points={metrics?.error_trend || []} color="#dc2626" />
            </div>
            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-3">
              <div className="text-[11px] uppercase tracking-wide text-slate-400 mb-2">Cost</div>
              <Sparkline points={metrics?.cost_trend || []} color="#d97706" />
            </div>
          </div>
        </section>

        {/* Circuit breakers / Dependencies */}
        <section className="enterprise-panel p-5">
          <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-800">
            <Server size={15} className="text-bsc-blue-600" /> Dependencies
          </div>
          {health?.circuit_breakers?.length ? (
            <div className="space-y-2.5">
              {health.circuit_breakers.map((cb) => (
                <div key={cb.name} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/50 px-4 py-3">
                  <div className="flex items-center gap-3">
                    <StatusDot state={cb.state} />
                    <div>
                      <div className="text-sm font-medium text-slate-800">{cb.name}</div>
                      <div className="text-[11px] text-slate-400">{cb.failure_count} failures</div>
                    </div>
                  </div>
                  <span className={`rounded-md px-2 py-1 text-[11px] font-semibold ${cb.state === 'CLOSED' ? 'bg-emerald-50 text-emerald-700' : cb.state === 'OPEN' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'}`}>
                    {cb.state}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/50 px-4 py-6 text-sm text-slate-400">
              <CheckCircle2 size={16} className="text-emerald-500" />
              <span>All dependencies healthy — no circuit breakers tripped.</span>
            </div>
          )}
        </section>
      </div>

      {/* Bottom row: top providers + data freshness */}
      <div className="grid gap-4 lg:grid-cols-2 shrink-0 pb-2">
        <section className="enterprise-panel p-5">
          <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-800">
            <Users size={15} className="text-bsc-blue-600" /> Top Queried Providers
          </div>
          {metrics?.top_providers_queried?.length ? (
            <div className="space-y-2">
              {metrics.top_providers_queried.map((p, i) => (
                <div key={p.provider} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2.5 text-sm">
                  <div className="flex items-center gap-2.5">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-bsc-blue-100 text-[10px] font-bold text-bsc-blue-700">{i + 1}</span>
                    <span className="font-medium text-slate-700">{p.provider}</span>
                  </div>
                  <span className="text-xs text-slate-500">{p.count} queries</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-lg bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">No provider activity recorded yet.</div>
          )}
        </section>

        <section className="enterprise-panel p-5">
          <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-800">
            <Shield size={15} className="text-bsc-blue-600" /> Data Freshness
          </div>
          {metrics?.data_freshness?.length ? (
            <div className="space-y-2">
              {metrics.data_freshness.map((t) => (
                <div key={t.table_name} className="rounded-lg bg-slate-50 px-3 py-2.5">
                  <div className="text-sm font-medium text-slate-700">{t.table_name}</div>
                  <div className="mt-1 flex items-center gap-3 text-[11px] text-slate-400">
                    <span>{t.row_count.toLocaleString()} rows</span>
                    <span>&middot;</span>
                    <span>Updated: {t.last_updated || 'Unknown'}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-lg bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">Freshness data will appear after first status check.</div>
          )}
        </section>
      </div>
    </div>
  );
}

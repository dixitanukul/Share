import { useState } from 'react';
import { Check, ChevronDown, Database, Loader2, Route, Shield, Terminal } from 'lucide-react';
import type { ProcessStep } from '../hooks/useStreamQueryV2';

interface ProcessTrailProps {
  steps: ProcessStep[];
  route: { route: string; description: string; tool: string } | null;
  isStreaming: boolean;
  confidenceReason?: string;
}

export function ProcessTrail({ steps, route, isStreaming, confidenceReason }: ProcessTrailProps) {
  // Expanded during streaming so user can watch progress; collapsed for completed messages
  const [expanded, setExpanded] = useState(isStreaming);

  const completedSteps = steps.filter(s => s.type === 'tool_start' && s.status === 'complete');

  // Don't render if no steps and no route
  if (!route && steps.length === 0 && !isStreaming && !confidenceReason) return null;

  return (
    <div className="mt-3 rounded-xl border border-slate-200/80 bg-slate-50/60 p-3">
      {/* Header toggle */}
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500 hover:text-slate-700 transition-colors"
      >
        <Terminal size={12} />
        Process Trail
        {completedSteps.length > 0 && (
          <span className="ml-1 rounded-full bg-emerald-100 px-1.5 py-0.5 text-[9px] font-bold text-emerald-700">
            {completedSteps.length} step{completedSteps.length !== 1 ? 's' : ''}
          </span>
        )}
        {/* Collapsed summary: show route badge inline */}
        {!expanded && route && (
          <code className="ml-1 rounded bg-white px-1.5 py-0.5 text-[10px] font-medium text-bsc-blue-600 border border-slate-200">
            {route.route.replace(/_/g, ' ')}
          </code>
        )}
        <ChevronDown size={12} className={`ml-auto transition-transform ${expanded ? 'rotate-180' : ''}`} />
      </button>

      {expanded && (
        <div className="mt-3 space-y-2.5">
          {/* Route badge */}
          {route && (
            <div className="flex items-center gap-2">
              <Route size={11} className="text-bsc-blue-500 shrink-0" />
              <span className="text-xs text-slate-700">
                Route: <code className="rounded bg-white px-1.5 py-0.5 text-[11px] font-semibold text-bsc-blue-600 border border-slate-200">{route.route.replace(/_/g, ' ')}</code>
              </span>
              <span className="text-[10px] text-slate-400">{route.description}</span>
            </div>
          )}

          {/* Tool steps */}
          {steps.filter(s => s.type === 'tool_start').map((step) => (
            <div key={`${step.tool}-${step.step}`} className="ml-2 border-l-2 border-slate-200 pl-3">
              {/* Step header */}
              <div className="flex items-center gap-2">
                {step.status === 'running' ? (
                  <Loader2 size={11} className="animate-spin text-bsc-blue-500 shrink-0" />
                ) : step.status === 'error' ? (
                  <span className="text-rose-500 text-[11px] shrink-0">✗</span>
                ) : (
                  <Check size={11} className="text-emerald-500 shrink-0" />
                )}
                <span className="text-xs font-medium text-slate-700">
                  {step.tool?.replace(/_/g, ' ')}
                </span>
                {step.latency_ms != null && step.latency_ms > 0 && (
                  <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[9px] text-slate-500">
                    {step.latency_ms}ms
                  </span>
                )}
                {step.rows != null && step.rows > 0 && (
                  <span className="flex items-center gap-0.5 text-[9px] text-slate-400">
                    <Database size={8} /> {step.rows} rows
                  </span>
                )}
              </div>

              {/* SQL query block */}
              {step.sql && (
                <pre className="mt-1.5 max-h-32 overflow-auto rounded-lg bg-slate-900 p-2.5 text-[10px] leading-4 text-emerald-300 font-mono scrollbar-thin">
                  {step.sql}
                </pre>
              )}

              {/* Tables queried */}
              {step.tables && step.tables.length > 0 && (
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {step.tables.map((t) => (
                    <span key={t} className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[9px] font-medium text-slate-500">
                      <Database size={8} className="text-slate-400" />
                      {t.split('.').pop()}
                    </span>
                  ))}
                </div>
              )}

              {/* Result summary */}
              {step.summary && (
                <p className="mt-1 text-[11px] leading-4 text-slate-500 line-clamp-2">{step.summary}</p>
              )}
            </div>
          ))}

          {/* Confidence reasoning */}
          {confidenceReason && (
            <div className="flex items-start gap-2 mt-2 pt-2 border-t border-slate-200/60">
              <Shield size={11} className="text-slate-400 shrink-0 mt-0.5" />
              <p className="text-[11px] leading-4 text-slate-500">{confidenceReason}</p>
            </div>
          )}

          {/* Active spinner */}
          {isStreaming && steps.every(s => s.status !== 'running') && (
            <div className="ml-2 border-l-2 border-slate-200 pl-3 flex items-center gap-2 text-xs text-slate-400">
              <Loader2 size={10} className="animate-spin" /> Processing...
            </div>
          )}
        </div>
      )}
    </div>
  );
}

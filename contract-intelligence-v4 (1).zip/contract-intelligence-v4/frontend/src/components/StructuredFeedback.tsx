/**
 * StructuredFeedback — C-12 FIX: Replace thumbs-only with structured evaluation form.
 * Collects: accuracy rating, error category, confidence assessment, expected answer.
 */
import { useState } from 'react';
import { ThumbsUp, ThumbsDown, ChevronDown, ChevronUp, Send } from 'lucide-react';
import { track } from '../services/analytics';

type Accuracy = 'correct' | 'partially_correct' | 'incorrect' | null;
type ErrorCategory =
  | 'wrong_number'
  | 'wrong_provider'
  | 'outdated_data'
  | 'missing_info'
  | 'hallucinated'
  | 'unsupported_question'
  | 'other'
  | null;

interface Props {
  sessionId: string;
  messageIndex: number;
}

export function StructuredFeedback({ sessionId, messageIndex }: Props) {
  const [expanded, setExpanded] = useState(false);
  const [accuracy, setAccuracy] = useState<Accuracy>(null);
  const [errorCategory, setErrorCategory] = useState<ErrorCategory>(null);
  const [confidenceOk, setConfidenceOk] = useState<boolean | null>(null);
  const [expectedAnswer, setExpectedAnswer] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [quickRating, setQuickRating] = useState<'up' | 'down' | null>(null);

  if (!sessionId) return null;

  const submitQuick = async (value: 'up' | 'down') => {
    setQuickRating(value);
    if (value === 'down') setExpanded(true);
    try {
      await fetch('/api/v1/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: sessionId,
          query_id: `msg-${messageIndex}`,
          rating: value,
        }),
      });
      track('feedback_submitted', sessionId, { rating: value, type: 'quick' });
    } catch { /* fire and forget */ }
  };

  const submitDetailed = async () => {
    setSubmitted(true);
    try {
      await fetch('/api/v1/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: sessionId,
          query_id: `msg-${messageIndex}`,
          rating: quickRating || 'down',
          accuracy,
          error_category: errorCategory,
          confidence_appropriate: confidenceOk,
          expected_answer: expectedAnswer || null,
        }),
      });
      track('feedback_submitted', sessionId, { rating: quickRating || 'down', type: 'detailed', accuracy });
    } catch { /* fire and forget */ }
  };

  if (submitted) {
    return (
      <div className="mt-3 rounded-lg bg-emerald-50 border border-emerald-100 px-3 py-2 text-xs text-emerald-700">
        ✔ Thank you for your detailed feedback
      </div>
    );
  }

  return (
    <div className="mt-3">
      {/* Quick rating buttons */}
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => submitQuick('up')}
          className={`rounded-lg border px-2 py-1 text-xs transition-colors ${
            quickRating === 'up'
              ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
              : 'border-slate-150 bg-white text-slate-400 hover:text-slate-600 hover:border-slate-200'
          }`}
        >
          <span className="flex items-center gap-1"><ThumbsUp size={11} />{quickRating === 'up' ? ' Helpful' : ''}</span>
        </button>
        <button
          type="button"
          onClick={() => submitQuick('down')}
          className={`rounded-lg border px-2 py-1 text-xs transition-colors ${
            quickRating === 'down'
              ? 'border-rose-200 bg-rose-50 text-rose-700'
              : 'border-slate-150 bg-white text-slate-400 hover:text-slate-600 hover:border-slate-200'
          }`}
        >
          <span className="flex items-center gap-1"><ThumbsDown size={11} />{quickRating === 'down' ? ' Issue' : ''}</span>
        </button>
        {quickRating && !expanded && (
          <button
            type="button"
            onClick={() => setExpanded(true)}
            className="ml-2 text-[10px] text-bsc-blue-600 hover:underline flex items-center gap-0.5"
          >
            Add details <ChevronDown size={10} />
          </button>
        )}
        {expanded && (
          <button
            type="button"
            onClick={() => setExpanded(false)}
            className="ml-2 text-[10px] text-slate-400 hover:underline flex items-center gap-0.5"
          >
            Collapse <ChevronUp size={10} />
          </button>
        )}
      </div>

      {/* Expanded structured feedback form */}
      {expanded && (
        <div className="mt-3 rounded-lg border border-slate-150 bg-white p-3 space-y-3 animate-fade-in">
          {/* Accuracy */}
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Accuracy</label>
            <div className="mt-1 flex flex-wrap gap-1.5">
              {(['correct', 'partially_correct', 'incorrect'] as const).map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAccuracy(val)}
                  className={`rounded-md border px-2 py-1 text-[11px] capitalize transition-colors ${
                    accuracy === val
                      ? 'border-bsc-blue-300 bg-bsc-blue-50 text-bsc-blue-700'
                      : 'border-slate-150 text-slate-500 hover:border-slate-200'
                  }`}
                >
                  {val.replace(/_/g, ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Error category (shown if not correct) */}
          {accuracy && accuracy !== 'correct' && (
            <div>
              <label className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Error Type</label>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {(['wrong_number', 'wrong_provider', 'outdated_data', 'missing_info', 'hallucinated', 'unsupported_question', 'other'] as const).map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setErrorCategory(val)}
                    className={`rounded-md border px-2 py-1 text-[11px] capitalize transition-colors ${
                      errorCategory === val
                        ? 'border-rose-300 bg-rose-50 text-rose-700'
                        : 'border-slate-150 text-slate-500 hover:border-slate-200'
                    }`}
                  >
                    {val.replace(/_/g, ' ')}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Confidence appropriate? */}
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
              Was the confidence level appropriate?
            </label>
            <div className="mt-1 flex gap-1.5">
              {[{ label: 'Yes', value: true }, { label: 'No, too high', value: false }].map(({ label, value }) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => setConfidenceOk(value)}
                  className={`rounded-md border px-2 py-1 text-[11px] transition-colors ${
                    confidenceOk === value
                      ? 'border-bsc-blue-300 bg-bsc-blue-50 text-bsc-blue-700'
                      : 'border-slate-150 text-slate-500 hover:border-slate-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Expected answer */}
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
              Expected answer (optional)
            </label>
            <textarea
              value={expectedAnswer}
              onChange={(e) => setExpectedAnswer(e.target.value)}
              placeholder="What should the correct answer be?"
              rows={2}
              className="mt-1 w-full rounded-md border border-slate-200 px-2 py-1.5 text-xs text-slate-700 placeholder:text-slate-300 focus:border-bsc-blue-300 focus:outline-none focus:ring-1 focus:ring-bsc-blue-200"
            />
          </div>

          {/* Submit */}
          <button
            type="button"
            onClick={submitDetailed}
            disabled={!accuracy}
            className="flex items-center gap-1.5 rounded-md bg-bsc-blue-600 px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-bsc-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Send size={11} /> Submit Feedback
          </button>
        </div>
      )}
    </div>
  );
}

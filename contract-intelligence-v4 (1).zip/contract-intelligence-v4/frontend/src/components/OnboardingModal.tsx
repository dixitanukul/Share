/**
 * OnboardingModal — C-11 FIX: First-visit onboarding for trial evaluators.
 * Explains purpose, coverage, supported/unsupported categories, and tips.
 * Shown once per browser (persisted via localStorage).
 */
import { useState, useEffect } from 'react';
import { X, Sparkles, CheckCircle2, XCircle } from 'lucide-react';
import { track } from '../services/analytics';

const STORAGE_KEY = 'ci_v4_onboarding_dismissed';

interface Props {
  onDismiss: () => void;
}

export function OnboardingModal({ onDismiss }: Props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem(STORAGE_KEY);
    if (!dismissed) setVisible(true);
  }, []);

  if (!visible) return null;

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, 'true');
    setVisible(false);
    track('onboarding_dismissed');
    onDismiss();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl mx-4">
        <button
          type="button"
          onClick={dismiss}
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-600"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-bsc-blue-600 text-white">
            <Sparkles size={18} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Contract Intelligence Assistant</h2>
            <p className="text-xs text-slate-400">Blue Shield of California — Evaluation Preview</p>
          </div>
        </div>

        <p className="text-sm text-slate-600 leading-6 mb-4">
          This AI assistant answers questions about <strong>provider contracts, rates, amendments,
          delegations, and clause coverage</strong> using data extracted from 306 contracted providers.
        </p>

        {/* Supported categories */}
        <div className="mb-3">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Supported Questions</h3>
          <div className="grid grid-cols-2 gap-1.5">
            {[
              'Provider rates & payment terms',
              'Contract amendments & history',
              'Clause coverage & existence',
              'Delegation responsibilities',
              'Division of Financial Responsibility',
              'Contract expiration & renewal',
              'Provider network status',
              'Rate comparisons & benchmarks',
            ].map((item) => (
              <div key={item} className="flex items-start gap-1.5 text-xs text-slate-600">
                <CheckCircle2 size={12} className="mt-0.5 shrink-0 text-emerald-500" />
                {item}
              </div>
            ))}
          </div>
        </div>

        {/* Unsupported categories */}
        <div className="mb-4">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Not Supported</h3>
          <div className="grid grid-cols-2 gap-1.5">
            {[
              'Claims & utilization data',
              'Real-time eligibility',
              'Non-BSC contracts',
              'Legal advice',
            ].map((item) => (
              <div key={item} className="flex items-start gap-1.5 text-xs text-slate-400">
                <XCircle size={12} className="mt-0.5 shrink-0 text-rose-300" />
                {item}
              </div>
            ))}
          </div>
        </div>

        {/* Tips */}
        <div className="rounded-lg bg-blue-50 border border-blue-100 p-3 mb-4">
          <h3 className="text-[10px] font-semibold uppercase tracking-wide text-blue-700 mb-1">Tips for best results</h3>
          <ul className="text-xs text-blue-800 space-y-1 list-disc list-inside">
            <li>Include the provider name in your question</li>
            <li>Ask about one topic at a time</li>
            <li>Check the confidence level and evidence panel</li>
            <li>Use the feedback form to report errors</li>
          </ul>
        </div>

        {/* Data stats */}
        <div className="flex items-center gap-4 text-[10px] text-slate-400 mb-4">
          <span>306 providers</span>
          <span>459,902 rate entries</span>
          <span>7,863 clauses</span>
          <span>1,821 DOFR rows</span>
        </div>

        <button
          type="button"
          onClick={dismiss}
          className="w-full rounded-lg bg-bsc-blue-600 py-2.5 text-sm font-medium text-white hover:bg-bsc-blue-700 transition-colors"
        >
          Get Started
        </button>
      </div>
    </div>
  );
}

/** Hook to check if onboarding has been dismissed */
export function useOnboardingDismissed(): boolean {
  return localStorage.getItem(STORAGE_KEY) === 'true';
}

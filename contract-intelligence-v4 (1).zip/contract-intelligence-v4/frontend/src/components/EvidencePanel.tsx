/**
 * EvidencePanel — C-13 FIX: Show answer evidence basis below each response.
 * Renders tables used, methods, warnings, and citation count.
 */
import { useState } from 'react';
import { ChevronDown, ChevronUp, Database, AlertTriangle, Search } from 'lucide-react';
import { track } from '../services/analytics';

export interface EvidenceSummary {
  tables?: string[];
  methods?: string[];
  citation_count?: number;
  has_sql_evidence?: boolean;
  warnings?: string[];
}

interface Props {
  evidence?: EvidenceSummary;
  sessionId?: string;
}

export function EvidencePanel({ evidence, sessionId }: Props) {
  const [expanded, setExpanded] = useState(false);

  if (!evidence || (!evidence.tables?.length && !evidence.methods?.length)) {
    return null;
  }

  const toggle = () => {
    const next = !expanded;
    setExpanded(next);
    if (next) track('evidence_panel_opened', sessionId);
  };

  return (
    <div className="mt-3 rounded-lg border border-slate-100 bg-slate-50/50">
      <button
        type="button"
        onClick={toggle}
        className="flex w-full items-center justify-between px-3 py-2 text-[11px] font-semibold uppercase tracking-wide text-slate-400 hover:text-slate-600 transition-colors"
      >
        <span className="flex items-center gap-1.5">
          <Database size={11} />
          Evidence Basis
          {evidence.warnings && evidence.warnings.length > 0 && (
            <AlertTriangle size={11} className="text-amber-500" />
          )}
        </span>
        {expanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
      </button>

      {expanded && (
        <div className="border-t border-slate-100 px-3 py-2 space-y-2 animate-fade-in">
          {/* Tables used */}
          {evidence.tables && evidence.tables.length > 0 && (
            <div>
              <div className="text-[10px] font-medium text-slate-400 mb-1">DATA SOURCES</div>
              <div className="flex flex-wrap gap-1">
                {evidence.tables.map((t) => (
                  <span key={t} className="inline-flex items-center rounded bg-blue-50 px-1.5 py-0.5 text-[10px] font-mono text-blue-700">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Methods used */}
          {evidence.methods && evidence.methods.length > 0 && (
            <div>
              <div className="text-[10px] font-medium text-slate-400 mb-1">METHODS</div>
              <div className="flex flex-wrap gap-1">
                {evidence.methods.map((m) => (
                  <span key={m} className="inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-600">
                    <Search size={8} />
                    {m.replace(/_/g, ' ')}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Citation count + SQL evidence flag */}
          <div className="flex items-center gap-3 text-[10px] text-slate-400">
            {typeof evidence.citation_count === 'number' && (
              <span>{evidence.citation_count} citation{evidence.citation_count !== 1 ? 's' : ''}</span>
            )}
            {evidence.has_sql_evidence && (
              <span className="text-emerald-600 font-medium">SQL-grounded</span>
            )}
          </div>

          {/* Warnings */}
          {evidence.warnings && evidence.warnings.length > 0 && (
            <div className="rounded bg-amber-50 border border-amber-100 px-2 py-1.5">
              <div className="text-[10px] font-medium text-amber-700 mb-0.5">WARNINGS</div>
              {evidence.warnings.map((w, i) => (
                <div key={i} className="text-[10px] text-amber-600">{w}</div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Contract Intelligence Platform V4 — Frontend API Types

export type ConfidenceLabel = 'HIGH' | 'MODERATE' | 'LOW' | 'UNCERTAIN';

export interface Citation {
  source: string;
  page?: number;
  snippet?: string;
  provider_name?: string;
  doc_role?: string;
  effective_date?: string;
  score?: number;
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  citations?: Citation[];
  confidence?: ConfidenceLabel;
  confidence_score?: number;
  confidence_reason?: string;
  latency_ms?: number;
  cost_usd?: number;
  tool_calls?: number;
  tool_names?: string[];
  process_trail?: any[];  // ProcessStep[] from streaming — persisted for review
  route_detected?: { route: string; description: string; tool: string } | null;
}

export interface Session {
  session_id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface SessionDetail extends Session {
  messages: Message[];
}

export interface QueryRequest {
  question: string;
  stream?: boolean;
  provider_name?: string;
  session_id?: string;
}

export interface QueryResponse {
  answer: string;
  confidence: ConfidenceLabel;
  confidence_score: number;
  citations: Citation[];
  latency_ms: number;
  cost_usd: number;
  session_id: string;
}

export type StreamEvent =
  | { type: 'thinking'; content: string }
  | { type: 'route_detected'; route: string; description: string; tool: string; providers?: string[]; concepts?: string[] }
  | { type: 'tool_use'; tool: string; summary: string }
  | { type: 'tool_start'; tool: string; step: number; sql?: string; tables?: string[] }
  | { type: 'tool_result'; tool: string; step: number; summary: string; rows?: number; latency_ms?: number }
  | { type: 'answer_chunk'; content: string }
  | { type: 'citations'; citations: Citation[] }
  | { type: 'confidence'; label: ConfidenceLabel; score: number; reason?: string }
  | { type: 'done'; latency_ms: number; cost_usd: number; tool_calls: number; tool_names?: string[]; session_id?: string }
  | { type: 'error'; message: string };

export interface FeedbackRequest {
  session_id: string;
  query_id: string;
  rating: 'up' | 'down';
  correction?: string;
}

export interface ProviderSummary {
  provider_name: string;
  provider_id: string;
  lob: string[];
  payment_types: string[];
  active: boolean;
  contract_count: number;
  amendment_count: number;
  latest_effective_date: string;
}

export interface ProviderDetail {
  profile: Record<string, unknown>;
  rates: { service: string; rate: number; unit: string; category: string }[];
  documents: { source_filename: string; doc_role: string; effective_date: string }[];
  amendments: { source_filename: string; amendment_order: number; effective_date: string }[];
  clause_coverage: { concept: string; status: string }[];
}

export interface ReportRequest {
  concept_keys: string[];
  provider_filter?: string;
  lob_filter?: string;
  active_only?: boolean;
}

export interface ReportResponse {
  total_providers: number;
  concept_keys: string[];
  summary: Record<string, Record<string, number>>;
  results: { provider_name: string; classifications: Record<string, string> }[];
}

export interface HealthResponse {
  status: 'OK' | 'DEGRADED' | 'DOWN';
  version: string;
  uptime_s: number;
  dependencies: Record<string, string>;
  circuit_breakers: { name: string; state: string; failure_count: number }[];
  error?: string;
  init_steps?: string[];
}

// Step 4.11 — Status metrics types
export interface MetricPoint {
  timestamp: string;
  value: number;
}

export interface StatusMetrics {
  total_queries: number;
  total_sessions: number;
  avg_latency_ms: number;
  p95_latency_ms: number;
  error_rate: number;
  total_cost_usd: number;
  latency_trend: MetricPoint[];
  error_trend: MetricPoint[];
  cost_trend: MetricPoint[];
  queries_trend: MetricPoint[];
  top_providers_queried: { provider: string; count: number }[];
  confidence_distribution: Record<ConfidenceLabel, number>;
  data_freshness: {
    table_name: string;
    last_updated: string;
    row_count: number;
  }[];
}

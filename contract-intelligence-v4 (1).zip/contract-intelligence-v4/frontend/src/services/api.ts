/**
 * API service layer for Contract Intelligence Platform V4.
 * All backend communication routes through this module.
 */

import type {
  QueryRequest,
  QueryResponse,
  HealthResponse,
  FeedbackRequest,
  ProviderSummary,
  ProviderDetail,
  ReportRequest,
  ReportResponse,
  Session,
  SessionDetail,
} from '../types/api';

const BASE = '';

async function fetchJSON<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${url}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status}: ${text}`);
  }
  return res.json();
}

// ── Health ────────────────────────────────────────────────────────────────────
export function getHealth(): Promise<HealthResponse> {
  return fetchJSON('/health');
}

// ── Query ─────────────────────────────────────────────────────────────────────
export function queryNonStreaming(req: QueryRequest): Promise<QueryResponse> {
  return fetchJSON('/api/v1/query', {
    method: 'POST',
    body: JSON.stringify({ ...req, stream: false }),
  });
}

export function queryStream(req: QueryRequest): Promise<Response> {
  return fetch(`${BASE}/api/v1/query`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...req, stream: true }),
  });
}

// ── Sessions ──────────────────────────────────────────────────────────────────
export function listSessions(): Promise<{ sessions: Session[]; total: number }> {
  return fetchJSON('/api/v1/sessions');
}

export function getSession(sessionId: string): Promise<SessionDetail> {
  return fetchJSON(`/api/v1/sessions/${sessionId}`);
}

export function createSession(title?: string): Promise<Session> {
  return fetchJSON('/api/v1/sessions', {
    method: 'POST',
    body: JSON.stringify({ title }),
  });
}

// ── Feedback ──────────────────────────────────────────────────────────────────
export function submitFeedback(req: FeedbackRequest): Promise<{ status: string }> {
  return fetchJSON('/api/v1/feedback', {
    method: 'POST',
    body: JSON.stringify(req),
  });
}

// ── Providers ─────────────────────────────────────────────────────────────────
export function listProviders(params?: {
  search?: string;
  lob?: string;
  payment_type?: string;
  active?: boolean;
}): Promise<{ providers: ProviderSummary[]; total: number }> {
  const qs = new URLSearchParams();
  if (params?.search) qs.set('search', params.search);
  if (params?.lob) qs.set('lob', params.lob);
  if (params?.payment_type) qs.set('payment_type', params.payment_type);
  if (params?.active !== undefined) qs.set('active', String(params.active));
  return fetchJSON(`/api/v1/providers?${qs}`);
}

export function getProvider(name: string): Promise<ProviderDetail> {
  return fetchJSON(`/api/v1/providers/${encodeURIComponent(name)}`);
}

// ── Reports ──────────────────────────────────────────────────────────────────
export function generateReport(req: ReportRequest): Promise<ReportResponse> {
  return fetchJSON('/api/v1/report', {
    method: 'POST',
    body: JSON.stringify(req),
  });
}

// getReportStatus removed — no backend endpoint exists for GET /api/v1/report/{id}

// ── Export ────────────────────────────────────────────────────────────────────
export function exportSession(sessionId: string, format: 'markdown' | 'json' | 'csv' = 'markdown'): string {
  return `${BASE}/api/v1/export/${sessionId}?format=${format}`;
}

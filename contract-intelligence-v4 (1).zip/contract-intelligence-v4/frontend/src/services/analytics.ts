/**
 * Contract Intelligence V4 — Client Evaluation Analytics
 * C-14 FIX: Emit structured evaluation events for trial scorecards.
 *
 * Events are sent fire-and-forget to POST /api/v1/events.
 * Backend stores them in tbl_evaluation_events (Delta table).
 */

export type EventName =
  | 'question_submitted'
  | 'answer_received'
  | 'citation_clicked'
  | 'feedback_submitted'
  | 'session_started'
  | 'session_resumed'
  | 'copy_answer'
  | 'export_markdown'
  | 'evidence_panel_opened'
  | 'onboarding_dismissed';

interface AnalyticsEvent {
  event: EventName;
  session_id?: string;
  timestamp: string;
  properties?: Record<string, string | number | boolean | null>;
}

const EVENT_BUFFER: AnalyticsEvent[] = [];
let flushTimer: ReturnType<typeof setTimeout> | null = null;

function flush(): void {
  if (EVENT_BUFFER.length === 0) return;
  const batch = EVENT_BUFFER.splice(0, EVENT_BUFFER.length);
  // Fire-and-forget — never block the UI
  fetch('/api/v1/events', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ events: batch }),
  }).catch(() => {});
}

/**
 * Track an evaluation event. Events are batched and flushed
 * every 2 seconds or when the buffer hits 10 events.
 */
export function track(
  event: EventName,
  sessionId?: string,
  properties?: Record<string, string | number | boolean | null>,
): void {
  EVENT_BUFFER.push({
    event,
    session_id: sessionId,
    timestamp: new Date().toISOString(),
    properties,
  });

  // Auto-flush at 10 events
  if (EVENT_BUFFER.length >= 10) {
    flush();
    return;
  }

  // Otherwise flush on 2s timer
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = setTimeout(flush, 2000);
}

// Flush on page unload
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', flush);
}

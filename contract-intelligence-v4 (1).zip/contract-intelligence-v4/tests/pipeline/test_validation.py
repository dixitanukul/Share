"""Unit tests for src/validation.py

15+ test cases covering:
- Valid extraction passthrough
- Missing required sections
- Invalid rate_numeric values
- Date range validation
- Document type routing
- Hallucinated structure detection
- Empty/null inputs
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from validation import validate_extraction, ValidationResult


# ============================================================
# Valid extraction tests
# ============================================================

class TestValidExtraction:
    def test_complete_base_agreement(self):
        data = {
            "contract_info": {"provider": "Test Hospital"},
            "parties": [{"name": "BSC"}, {"name": "Hospital"}],
            "term_dates": {"start": "2024-01-01", "end": "2025-12-31"},
            "reimbursement_rates": [
                {"service": "IP", "rate_numeric": 2500, "rate_text": "$2,500"}
            ],
            "services_covered": ["inpatient", "outpatient"]
        }
        result = validate_extraction(data, "base_agreement")
        assert result.valid is True
        assert len(result.errors) == 0
        assert len(result.sections_found) == 5

    def test_complete_amendment(self):
        data = {
            "amendment_info": {"amendment_number": 3},
            "effective_dates": {"start": "2024-07-01"},
            "rates_modified": [{"rate_numeric": 2700}],
            "supersession": {"prior_rates_superseded": True}
        }
        result = validate_extraction(data, "amendment")
        assert result.valid is True

    def test_rates_with_numeric(self):
        data = {
            "contract_info": {},
            "parties": [],
            "term_dates": {},
            "reimbursement_rates": [
                {"rate_numeric": 1500},
                {"rate_numeric": 2000},
                {"rate_text": "$500 per diem"}  # no rate_numeric
            ],
            "services_covered": []
        }
        result = validate_extraction(data)
        assert result.rates_count == 3
        assert result.rates_with_numeric == 2


# ============================================================
# Missing sections tests
# ============================================================

class TestMissingSections:
    def test_missing_required_section_warns(self):
        data = {
            "contract_info": {},
            "parties": [],
            # Missing: term_dates, reimbursement_rates, services_covered
        }
        result = validate_extraction(data, "base_agreement")
        # Missing sections generate warnings, not errors
        assert any("term_dates" in w for w in result.warnings)
        assert any("reimbursement_rates" in w for w in result.warnings)

    def test_empty_data_is_invalid(self):
        result = validate_extraction({})
        # Empty dict has no sections found -> should be invalid
        assert result.valid is False or len(result.sections_found) == 0

    def test_none_input(self):
        result = validate_extraction(None)
        assert result.valid is False

    def test_non_dict_input(self):
        result = validate_extraction("not a dict")
        assert result.valid is False


# ============================================================
# Rate validation tests
# ============================================================

class TestRateValidation:
    def test_valid_rates(self):
        data = {
            "contract_info": {},
            "reimbursement_rates": [
                {"rate_numeric": 0.5},     # Low but valid (percentage)
                {"rate_numeric": 2500},    # Typical per diem
                {"rate_numeric": 150000},  # High but valid (transplant)
            ],
            "parties": [], "term_dates": {}, "services_covered": []
        }
        result = validate_extraction(data)
        assert result.rates_with_numeric == 3
        assert not any("negative" in e for e in result.errors)

    def test_negative_rate_is_error(self):
        data = {
            "contract_info": {},
            "reimbursement_rates": [{"rate_numeric": -100}],
            "parties": [], "term_dates": {}, "services_covered": []
        }
        result = validate_extraction(data)
        assert result.valid is False
        assert any("negative" in e for e in result.errors)

    def test_extremely_high_rate_is_warning(self):
        data = {
            "contract_info": {},
            "reimbursement_rates": [{"rate_numeric": 999999}],
            "parties": [], "term_dates": {}, "services_covered": []
        }
        result = validate_extraction(data)
        # High rates are warnings, not errors (implants can be expensive)
        assert any("unusually high" in w for w in result.warnings)
        assert result.valid is True  # Warnings don't invalidate

    def test_non_numeric_rate_is_error(self):
        data = {
            "contract_info": {},
            "reimbursement_rates": [{"rate_numeric": "not a number"}],
            "parties": [], "term_dates": {}, "services_covered": []
        }
        result = validate_extraction(data)
        assert any("not numeric" in e for e in result.errors)


# ============================================================
# Date validation tests
# ============================================================

class TestDateValidation:
    def test_valid_iso_dates(self):
        data = {
            "contract_info": {},
            "term_dates": {"effective_date": "2024-01-01", "expiration_date": "2025-12-31"},
            "parties": [], "reimbursement_rates": [], "services_covered": []
        }
        result = validate_extraction(data)
        assert result.dates_valid == 2
        assert result.dates_count == 2

    def test_date_too_old(self):
        data = {
            "contract_info": {},
            "term_dates": {"effective_date": "1980-01-01"},  # Before 1990
            "parties": [], "reimbursement_rates": [], "services_covered": []
        }
        result = validate_extraction(data)
        assert result.dates_valid == 0
        assert any("invalid date" in w.lower() for w in result.warnings)

    def test_date_too_far_future(self):
        data = {
            "contract_info": {},
            "term_dates": {"effective_date": "2040-06-15"},  # After 2035
            "parties": [], "reimbursement_rates": [], "services_covered": []
        }
        result = validate_extraction(data)
        assert result.dates_valid == 0

    def test_us_format_date(self):
        data = {
            "contract_info": {},
            "term_dates": {"effective_date": "1/15/2024"},
            "parties": [], "reimbursement_rates": [], "services_covered": []
        }
        result = validate_extraction(data)
        assert result.dates_valid == 1


# ============================================================
# Document type routing tests  
# ============================================================

class TestDocumentTypes:
    def test_cover_memo_sections(self):
        data = {
            "memo_info": {"date": "2024-01-01"},
            "referenced_documents": ["amend_1.pdf"],
            "key_dates": {"effective_date": "2024-03-01"}
        }
        result = validate_extraction(data, "cover_memo")
        assert result.valid is True
        assert len(result.sections_found) == 3

    def test_settlement_sections(self):
        data = {
            "settlement_info": {},
            "resolution_terms": {},
            "financial_terms": {"amount": 50000}
        }
        result = validate_extraction(data, "settlement")
        assert result.valid is True

    def test_unknown_doc_type_uses_base(self):
        data = {
            "contract_info": {},
            "parties": [], "term_dates": {},
            "reimbursement_rates": [], "services_covered": []
        }
        result = validate_extraction(data, "unknown_type")
        assert result.valid is True


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

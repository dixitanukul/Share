"""Unit tests for src/json_repair.py

20+ test cases covering:
- Valid JSON passthrough
- Markdown code fence stripping
- Trailing comma repair
- Unclosed brackets/braces
- Truncated arrays and objects
- Unclosed string literals
- Empty/null inputs
- Nested structure repair
- BOM handling
- Large truncated outputs (simulated max_tokens hit)
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from json_repair import (
    clean_json_response,
    repair_trailing_commas,
    repair_truncated_json,
    repair_llm_json_final,
    _close_brackets,
    _close_unclosed_strings,
)


# ============================================================
# clean_json_response tests
# ============================================================

class TestCleanJsonResponse:
    def test_plain_json(self):
        assert clean_json_response('{"a": 1}') == '{"a": 1}'

    def test_markdown_json_fence(self):
        assert clean_json_response('```json\n{"a": 1}\n```') == '{"a": 1}'

    def test_markdown_plain_fence(self):
        assert clean_json_response('```\n{"a": 1}\n```') == '{"a": 1}'

    def test_whitespace_stripping(self):
        assert clean_json_response('  \n  {"a": 1}  \n  ') == '{"a": 1}'

    def test_bom_removal(self):
        assert clean_json_response('\ufeff{"a": 1}') == '{"a": 1}'

    def test_empty_string(self):
        assert clean_json_response('') == ''

    def test_none_input(self):
        assert clean_json_response(None) == ''

    def test_only_fences(self):
        assert clean_json_response('```json\n```') == ''


# ============================================================
# repair_trailing_commas tests
# ============================================================

class TestRepairTrailingCommas:
    def test_trailing_comma_object(self):
        assert repair_trailing_commas('{"a": 1, "b": 2,}') == '{"a": 1, "b": 2}'

    def test_trailing_comma_array(self):
        assert repair_trailing_commas('[1, 2, 3,]') == '[1, 2, 3]'

    def test_nested_trailing_commas(self):
        result = repair_trailing_commas('{"a": [1, 2,], "b": {"c": 3,},}')
        assert result == '{"a": [1, 2], "b": {"c": 3}}'

    def test_no_trailing_comma(self):
        original = '{"a": 1, "b": 2}'
        assert repair_trailing_commas(original) == original

    def test_comma_with_whitespace(self):
        assert repair_trailing_commas('{"a": 1 ,  }') == '{"a": 1 }'


# ============================================================
# repair_truncated_json tests
# ============================================================

class TestRepairTruncatedJson:
    def test_valid_json_no_repair(self):
        text, strategy = repair_truncated_json('{"a": 1}')
        assert strategy == 'none'
        assert text == '{"a": 1}'

    def test_unclosed_brace(self):
        text, strategy = repair_truncated_json('{"a": 1, "b": 2')
        import json
        parsed = json.loads(text)
        assert parsed['a'] == 1

    def test_unclosed_bracket(self):
        text, strategy = repair_truncated_json('[1, 2, 3')
        import json
        parsed = json.loads(text)
        assert 1 in parsed

    def test_deeply_nested_unclosed(self):
        text, strategy = repair_truncated_json('{"a": {"b": [{"c": 1')
        import json
        parsed = json.loads(text)
        assert parsed['a']['b'][0]['c'] == 1

    def test_trailing_comma_in_truncated(self):
        text, strategy = repair_truncated_json('{"a": 1, "b": 2,')
        import json
        parsed = json.loads(text)
        assert parsed['b'] == 2

    def test_empty_string(self):
        text, strategy = repair_truncated_json('')
        assert text == '{}'
        assert strategy == 'empty_input'

    def test_truncated_array_mid_element(self):
        text, strategy = repair_truncated_json('[{"rate": 100}, {"rate": 20')
        import json
        parsed = json.loads(text)
        assert isinstance(parsed, list)
        assert parsed[0]['rate'] == 100

    def test_truncated_string_value(self):
        text, strategy = repair_truncated_json('{"name": "Dr. Smith at Cedar')
        import json
        parsed = json.loads(text)
        # May repair or fallback - either 'name' exists or repair_failed
        assert 'name' in parsed or '_repair_failed' in parsed


# ============================================================
# repair_llm_json_final (full pipeline) tests
# ============================================================

class TestRepairLlmJsonFinal:
    def test_clean_json(self):
        result, strategy = repair_llm_json_final('{"rates": [{"rate_numeric": 1500}]}')
        assert result is not None
        assert result['rates'][0]['rate_numeric'] == 1500
        assert strategy == 'none'

    def test_markdown_wrapped_json(self):
        result, strategy = repair_llm_json_final('```json\n{"a": 1}\n```')
        assert result == {'a': 1}
        assert strategy == 'none'

    def test_truncated_with_fence(self):
        result, strategy = repair_llm_json_final('```json\n{"a": [1, 2, 3')
        assert result is not None
        # Truncation repair may keep [1,2,3] or truncate to [1,2] depending on boundary
        assert len(result['a']) >= 2

    def test_empty_input(self):
        result, strategy = repair_llm_json_final('')
        assert result is None
        assert strategy == 'empty_input'

    def test_none_input(self):
        result, strategy = repair_llm_json_final(None)
        assert result is None
        assert strategy == 'empty_input'

    def test_whitespace_only(self):
        result, strategy = repair_llm_json_final('   \n   ')
        assert result is None

    def test_realistic_extraction_output(self):
        """Simulates a typical LLM extraction output with minor truncation."""
        raw = '''```json
{
    "contract_info": {
        "provider_name": "Cedars-Sinai Medical Center",
        "contract_id": "CSM-2024-001"
    },
    "reimbursement_rates": [
        {"service": "Inpatient", "rate_numeric": 2500.00, "rate_text": "$2,500 per diem"},
        {"service": "Outpatient", "rate_numeric": 350.00, "rate_text": "$350 per visit"},
        {"service": "Emergency", "rate_numeric": 1800.00, "rate_text": "$1,800 case rate"}
    ],
    "effective_dates": {
        "start": "2024-01-01",
        "end": "2025-12-31"
    }
}```'''
        result, strategy = repair_llm_json_final(raw)
        assert result is not None
        assert result['contract_info']['provider_name'] == 'Cedars-Sinai Medical Center'
        assert len(result['reimbursement_rates']) == 3
        assert result['reimbursement_rates'][1]['rate_numeric'] == 350.00
        assert strategy == 'none'

    def test_simulated_max_tokens_truncation(self):
        """Simulates output truncated at max_tokens."""
        raw = '{"rates": [{"svc": "IP", "rate": 2000}, {"svc": "OP", "rate": 500}, {"svc": "ER", "ra'
        result, strategy = repair_llm_json_final(raw)
        assert result is not None
        assert 'rates' in result
        # Should have at least the first 2 complete rates
        assert len(result['rates']) >= 2

    def test_unicode_in_provider_name(self):
        raw = '{"provider": "Centro M\u00e9dico", "rate": 100}'
        result, strategy = repair_llm_json_final(raw)
        assert result is not None
        assert 'M\u00e9dico' in result['provider'] or 'Mdico' in result['provider'] or result['provider'] == 'Centro M\u00e9dico'


# ============================================================
# Edge cases
# ============================================================

class TestEdgeCases:
    def test_just_opening_brace(self):
        text, strategy = repair_truncated_json('{')
        import json
        parsed = json.loads(text)
        assert isinstance(parsed, dict)

    def test_just_opening_bracket(self):
        text, strategy = repair_truncated_json('[')
        import json
        parsed = json.loads(text)
        assert isinstance(parsed, list)

    def test_nested_5_levels(self):
        text, strategy = repair_truncated_json('{"a":{"b":{"c":{"d":{"e":1')
        import json
        parsed = json.loads(text)
        assert parsed['a']['b']['c']['d']['e'] == 1

    def test_mixed_brackets_and_braces(self):
        text, strategy = repair_truncated_json('[{"a":1},{"b":[2,3')
        import json
        parsed = json.loads(text)
        assert isinstance(parsed, list)

    def test_escaped_quotes_in_string(self):
        raw = '{"text": "He said \\"hello\\" to the doctor"}'
        result, strategy = repair_llm_json_final(raw)
        assert result is not None
        assert 'hello' in result['text']


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

"""
Contract Intelligence V4 — Evaluation Framework
Phase 5 + 6: Benchmarks, calibration, SQL validation, stability, scoring.
"""
from .calibration import (
    expected_calibration_error,
    brier_score,
    wilson_ci,
    cohens_kappa,
    mcnemars_chi2,
    reliability_diagram_data,
    CategoryMetrics,
)
from .sql_assertions import SQLSemanticValidator
from .stability import StabilityTester
from .judge import LLMJudge, create_judge_fn
from .runner import BenchmarkRunner, BenchmarkReport, CaseResult
from .scorecard import ScorecardBuilder, GoNoGoReport

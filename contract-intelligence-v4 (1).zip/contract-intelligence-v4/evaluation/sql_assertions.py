"""
Contract Intelligence V4 — SQL Semantic Assertion Layer
Phase 5 (C-25): Deterministic SQL validation against §5 rulebook.

Performs regex-based SQL analysis (not full AST parse) to check:
- Table references against whitelist
- Join keys against approved/prohibited lists
- Temporal filters (status='current' vs is_current traps)
- DISTINCT usage for provider counts on multi-row tables
- Grain awareness
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Sequence


class Severity(Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


@dataclass
class Assertion:
    """One semantic assertion result."""
    rule_id: str
    severity: Severity
    passed: bool
    message: str
    sql_fragment: str = ""


@dataclass
class ValidationResult:
    """Full validation result for a SQL query."""
    sql: str
    assertions: list[Assertion] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(a.passed for a in self.assertions if a.severity == Severity.ERROR)

    @property
    def errors(self) -> list[Assertion]:
        return [a for a in self.assertions if not a.passed and a.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[Assertion]:
        return [a for a in self.assertions if not a.passed and a.severity == Severity.WARNING]

    def summary(self) -> dict:
        return {
            "passed": self.passed,
            "total_assertions": len(self.assertions),
            "errors": len(self.errors),
            "warnings": len(self.warnings),
            "details": [
                {"rule": a.rule_id, "severity": a.severity.value, "passed": a.passed, "message": a.message}
                for a in self.assertions if not a.passed
            ],
        }


# ─── Rulebook Configuration ────────────────────────────────────────────────

APPROVED_JOINS = {
    ("tbl_contract_rates_all", "tbl_genie_provider_profile"): "canonical_provider_id",
    ("tbl_contract_rates_all", "tbl_contract_documents_master"): "source_filename",
    ("tbl_contract_clauses", "tbl_genie_provider_profile"): "provider_name",
    ("tbl_provider_system_membership", "dim_health_system"): "health_system_id",
    ("fact_supersession", "tbl_contract_documents_master"): "superseding_filename",
    ("tbl_vs_unified_ready", "tbl_contract_documents_master"): "source_filename",
}

PROHIBITED_JOINS = {
    ("tbl_contract_rates_all", "tbl_genie_provider_profile"): {
        "key": "provider_id",
        "reason": "28% orphan rate (128,896 rows lost). Use canonical_provider_id.",
    },
}

MULTI_ROW_TABLES = {
    "tbl_contract_rates_all": "canonical_provider_id",
    "tbl_contract_clauses": "provider_name",
    "tbl_delegation_matrix": "provider_name",
    "tbl_dofr_matrix_extracted": "provider_name",
}

PROHIBITED_IS_CURRENT_TABLES = {
    "tbl_dofr_matrix_extracted": "Only 60/1821 rows have is_current=TRUE; BH/Pharmacy/Emergency have 0",
    "tbl_delegation_matrix": "Only 31/119 providers have is_current=TRUE",
}


# ─── SQLSemanticValidator ───────────────────────────────────────────────────

class SQLSemanticValidator:
    """Deterministic semantic validator for generated SQL."""

    def __init__(self, custom_rules: Optional[dict] = None):
        self._custom = custom_rules or {}

    def validate(self, sql: str, context: Optional[dict] = None) -> ValidationResult:
        """Run all semantic assertions against the SQL."""
        result = ValidationResult(sql=sql)
        sql_lower = sql.lower()
        ctx = context or {}

        tables = self._extract_tables(sql_lower)

        self._check_joins(sql_lower, tables, result)
        self._check_is_current_traps(sql_lower, tables, result)
        self._check_rates_temporal(sql_lower, tables, result)
        self._check_distinct_counts(sql_lower, tables, result)
        self._check_phantom_columns(sql_lower, result)
        self._check_amendment_ordering(sql_lower, tables, result)

        if ctx.get("expected_tables"):
            self._check_expected_tables(tables, ctx["expected_tables"], result)
        if ctx.get("prohibited_filters"):
            self._check_prohibited_filters(sql_lower, ctx["prohibited_filters"], result)

        return result

    def _extract_tables(self, sql: str) -> set[str]:
        """Extract referenced table names from SQL."""
        pattern = r'(?:from|join)\s+(?:\w+\.\w+\.)?(\w+)'
        matches = re.findall(pattern, sql)
        return set(matches)

    def _check_joins(self, sql: str, tables: set, result: ValidationResult) -> None:
        """R-01: Check for prohibited joins. Handles SQL aliases."""
        for (left, right), rule in PROHIBITED_JOINS.items():
            if left in tables and right in tables:
                prohibited_key = rule["key"]
                # SQL uses aliases (r.provider_id = p.provider_id), not full table names.
                # Strategy: if both tables present AND ON clause uses the prohibited key
                # AND the approved key (canonical_provider_id) is NOT present, flag it.
                on_pattern = r'on\s+\w+\.' + prohibited_key + r'\s*=\s*\w+\.' + prohibited_key
                match = re.search(on_pattern, sql, re.DOTALL)

                has_approved = "canonical_provider_id" in sql

                if match and not has_approved:
                    result.assertions.append(Assertion(
                        rule_id="R-01-PROHIBITED-JOIN",
                        severity=Severity.ERROR,
                        passed=False,
                        message=f"Prohibited join: {left} \u2194 {right} ON {prohibited_key}. {rule['reason']}",
                        sql_fragment=match.group(0)[:100],
                    ))
                else:
                    result.assertions.append(Assertion(
                        rule_id="R-01-PROHIBITED-JOIN",
                        severity=Severity.ERROR,
                        passed=True,
                        message=f"No prohibited join between {left} and {right}",
                    ))

        # Check approved join usage
        for (left, right), approved_key in APPROVED_JOINS.items():
            if left in tables and right in tables:
                if approved_key in sql:
                    result.assertions.append(Assertion(
                        rule_id="R-01-APPROVED-JOIN",
                        severity=Severity.INFO,
                        passed=True,
                        message=f"Correct join: {left} \u2194 {right} uses {approved_key}",
                    ))

    def _check_is_current_traps(self, sql: str, tables: set, result: ValidationResult) -> None:
        """R-02: Detect dangerous is_current filter on DOFR/delegation."""
        for table, reason in PROHIBITED_IS_CURRENT_TABLES.items():
            if table in tables:
                is_current_match = re.search(
                    r'where.*?is_current\s*=\s*(?:true|1|\'true\')',
                    sql, re.DOTALL | re.IGNORECASE
                )
                if is_current_match:
                    result.assertions.append(Assertion(
                        rule_id="R-02-IS-CURRENT-TRAP",
                        severity=Severity.ERROR,
                        passed=False,
                        message=f"Dangerous is_current filter on {table}: {reason}",
                        sql_fragment=is_current_match.group(0)[:80],
                    ))
                else:
                    result.assertions.append(Assertion(
                        rule_id="R-02-IS-CURRENT-TRAP",
                        severity=Severity.ERROR,
                        passed=True,
                        message=f"No dangerous is_current filter on {table}",
                    ))

    def _check_rates_temporal(self, sql: str, tables: set, result: ValidationResult) -> None:
        """R-03: Rates table must use status='current', not is_current_effective."""
        if "tbl_contract_rates_all" not in tables:
            return

        if "is_current_effective" in sql:
            result.assertions.append(Assertion(
                rule_id="R-03-PHANTOM-TEMPORAL",
                severity=Severity.ERROR,
                passed=False,
                message="Phantom column is_current_effective used on rates table. Use status='current'.",
            ))

        has_status_filter = bool(re.search(r"status\s*=\s*'current'", sql))
        has_superseded = bool(re.search(r"status\s*(?:=|in|IN).*?'superseded'", sql))

        if not has_status_filter and not has_superseded:
            result.assertions.append(Assertion(
                rule_id="R-03-MISSING-TEMPORAL",
                severity=Severity.WARNING,
                passed=False,
                message="tbl_contract_rates_all queried without status filter.",
            ))
        elif has_status_filter:
            result.assertions.append(Assertion(
                rule_id="R-03-TEMPORAL-CORRECT",
                severity=Severity.INFO,
                passed=True,
                message="Correct temporal filter: status='current'",
            ))

    def _check_distinct_counts(self, sql: str, tables: set, result: ValidationResult) -> None:
        """R-04: Provider counts on multi-row tables must use DISTINCT."""
        for table, id_col in MULTI_ROW_TABLES.items():
            if table not in tables:
                continue

            count_star = re.search(r'count\(\*\)', sql)
            count_distinct = re.search(rf'count\(\s*distinct\s+(?:\w+\.)?{id_col}', sql)

            if count_star and not count_distinct:
                if re.search(r'(?:n_providers|provider.?count|how many providers)', sql):
                    result.assertions.append(Assertion(
                        rule_id="R-04-MISSING-DISTINCT",
                        severity=Severity.ERROR,
                        passed=False,
                        message=f"COUNT(*) on {table} for provider count. Must use COUNT(DISTINCT {id_col}).",
                        sql_fragment=count_star.group(0),
                    ))
                    return

        result.assertions.append(Assertion(
            rule_id="R-04-DISTINCT-OK",
            severity=Severity.INFO,
            passed=True,
            message="DISTINCT usage appears correct",
        ))

    def _check_phantom_columns(self, sql: str, result: ValidationResult) -> None:
        """R-05: Detect known phantom columns."""
        if "is_current_effective" in sql:
            result.assertions.append(Assertion(
                rule_id="R-05-PHANTOM-COLUMN",
                severity=Severity.ERROR,
                passed=False,
                message="Phantom column 'is_current_effective' detected. Use status='current' instead.",
            ))

    def _check_amendment_ordering(self, sql: str, tables: set, result: ValidationResult) -> None:
        """R-06: Amendment sort must use amendment_order_int (INTEGER)."""
        if "tbl_contract_rates_all" not in tables:
            return

        # Detect ORDER BY amendment_order (without _int suffix)
        bad_order = re.search(r'order\s+by.*?amendment_order(?!_int)', sql, re.DOTALL)
        if bad_order:
            result.assertions.append(Assertion(
                rule_id="R-06-AMENDMENT-STRING-SORT",
                severity=Severity.ERROR,
                passed=False,
                message="Amendment ordering uses STRING column. Must use 'amendment_order_int'.",
                sql_fragment=bad_order.group(0)[:80],
            ))
        elif "amendment_order_int" in sql:
            result.assertions.append(Assertion(
                rule_id="R-06-AMENDMENT-ORDER-OK",
                severity=Severity.INFO,
                passed=True,
                message="Correct integer amendment ordering",
            ))

    def _check_expected_tables(self, actual: set, expected: list, result: ValidationResult) -> None:
        """R-07: Verify expected tables are referenced."""
        for table in expected:
            if table.lower() in actual:
                result.assertions.append(Assertion(
                    rule_id="R-07-EXPECTED-TABLE",
                    severity=Severity.INFO,
                    passed=True,
                    message=f"Expected table {table} found",
                ))
            else:
                result.assertions.append(Assertion(
                    rule_id="R-07-EXPECTED-TABLE",
                    severity=Severity.WARNING,
                    passed=False,
                    message=f"Expected table {table} not referenced in query",
                ))

    def _check_prohibited_filters(self, sql: str, filters: list, result: ValidationResult) -> None:
        """R-08: Verify prohibited filters are NOT present."""
        for f in filters:
            col = f.get("column", "")
            if col and re.search(rf'{col}\s*=', sql):
                result.assertions.append(Assertion(
                    rule_id="R-08-PROHIBITED-FILTER",
                    severity=Severity.ERROR,
                    passed=False,
                    message=f"Prohibited filter on '{col}'. Reason: {f.get('reason', 'see rulebook')}",
                ))

"""
Contract Intelligence V4 — Pre-Trial Gate Check
Phase 6: Automated verification of all 16 go/no-go criteria from §12.

Run this before the trial to confirm readiness. Uses Spark SQL to verify
data conditions and system state.

Usage:
    from evaluation.gate_check import PreTrialGateCheck
    checker = PreTrialGateCheck(spark)
    report = checker.run_all_checks()
    print(report.summary())
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class CheckResult:
    """Result of a single pre-trial check."""
    check_id: str
    name: str
    category: str  # "infrastructure", "data", "deployment", "benchmark"
    passed: bool
    message: str
    evidence: Optional[str] = None
    blocking: bool = True


@dataclass
class PreTrialReport:
    """Full pre-trial gate check report."""
    timestamp: str
    checks: list[CheckResult] = field(default_factory=list)

    @property
    def all_passed(self) -> bool:
        return all(c.passed for c in self.checks if c.blocking)

    @property
    def ready_for_trial(self) -> bool:
        blocking_failures = [c for c in self.checks if c.blocking and not c.passed]
        return len(blocking_failures) == 0

    def summary(self) -> dict:
        passed = [c for c in self.checks if c.passed]
        failed = [c for c in self.checks if not c.passed]
        return {
            "timestamp": self.timestamp,
            "ready_for_trial": self.ready_for_trial,
            "total_checks": len(self.checks),
            "passed": len(passed),
            "failed": len(failed),
            "blocking_failures": [
                {"id": c.check_id, "name": c.name, "message": c.message}
                for c in failed if c.blocking
            ],
            "warnings": [
                {"id": c.check_id, "name": c.name, "message": c.message}
                for c in failed if not c.blocking
            ],
        }


class PreTrialGateCheck:
    """
    Automated pre-trial gate checks.

    Verifies:
    - Schema correctness (evidence persistence columns exist)
    - Data integrity (current rates count, provider count, DOFR coverage)
    - Deployment state (endpoints respond, analytics table exists)
    - Configuration (no phantom columns, correct join rules)
    """

    def __init__(self, spark=None, catalog: str = "dev_adb", schema: str = "raw"):
        """
        Args:
            spark: SparkSession (for SQL checks). None for dry-run.
            catalog: UC catalog name.
            schema: UC schema name.
        """
        self.spark = spark
        self.catalog = catalog
        self.schema = schema

    def _table(self, name: str) -> str:
        return f"{self.catalog}.{self.schema}.{name}"

    def _sql(self, query: str) -> Optional[list]:
        """Execute SQL and return rows as list of dicts."""
        if self.spark is None:
            return None
        try:
            df = self.spark.sql(query)
            return [row.asDict() for row in df.collect()]
        except Exception:
            return None

    def run_all_checks(self) -> PreTrialReport:
        """Run all pre-trial gate checks."""
        report = PreTrialReport(
            timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        )

        # Infrastructure checks
        report.checks.append(self._check_session_schema())
        report.checks.append(self._check_evaluation_events_table())
        report.checks.append(self._check_feedback_table())

        # Data integrity checks
        report.checks.append(self._check_current_rates_count())
        report.checks.append(self._check_provider_count())
        report.checks.append(self._check_dofr_no_is_current_trap())
        report.checks.append(self._check_delegation_coverage())
        report.checks.append(self._check_canonical_join_integrity())

        # Configuration checks
        report.checks.append(self._check_no_phantom_columns())
        report.checks.append(self._check_whitelist_no_duplicates())

        # Deployment checks
        report.checks.append(self._check_analytics_endpoint())
        report.checks.append(self._check_feedback_endpoint())
        report.checks.append(self._check_evidence_in_sessions())

        return report

    # ─── Infrastructure Checks ──────────────────────────────────────────

    def _check_session_schema(self) -> CheckResult:
        """Verify tbl_agent_sessions has evidence persistence columns (C-43 fix)."""
        result = self._sql(f"DESCRIBE {self._table('tbl_agent_sessions')}")
        if result is None:
            return CheckResult(
                check_id="INFRA-01", name="Session schema has evidence columns",
                category="infrastructure", passed=False,
                message="Cannot query tbl_agent_sessions schema",
            )

        col_names = {row.get("col_name", "") for row in result}
        required = {"citations_json", "tool_trace_json", "evidence_summary", "answer_full"}
        missing = required - col_names

        return CheckResult(
            check_id="INFRA-01", name="Session schema has evidence columns",
            category="infrastructure",
            passed=len(missing) == 0,
            message=f"Missing columns: {missing}" if missing else "All 4 evidence columns present",
            evidence=f"Required: {required}, Found: {col_names & required}",
        )

    def _check_evaluation_events_table(self) -> CheckResult:
        """Verify tbl_evaluation_events exists (C-14 fix)."""
        result = self._sql(f"SHOW TABLES IN {self.catalog}.{self.schema} LIKE 'tbl_evaluation_events'")
        exists = result is not None and len(result) > 0

        return CheckResult(
            check_id="INFRA-02", name="Evaluation events table exists",
            category="infrastructure",
            passed=exists,
            message="tbl_evaluation_events found" if exists else "tbl_evaluation_events NOT FOUND",
        )

    def _check_feedback_table(self) -> CheckResult:
        """Verify tbl_user_feedback exists and has structured columns."""
        result = self._sql(f"DESCRIBE {self._table('tbl_user_feedback')}")
        if result is None:
            return CheckResult(
                check_id="INFRA-03", name="Feedback table has structured columns",
                category="infrastructure", passed=False,
                message="Cannot query tbl_user_feedback",
            )

        col_names = {row.get("col_name", "") for row in result}
        has_structured = "accuracy" in col_names or "error_category" in col_names

        return CheckResult(
            check_id="INFRA-03", name="Feedback table has structured columns",
            category="infrastructure",
            passed=has_structured,
            message="Structured feedback columns found" if has_structured else "Missing structured columns",
        )

    # ─── Data Integrity Checks ──────────────────────────────────────────

    def _check_current_rates_count(self) -> CheckResult:
        """Verify current rates count is within expected range (~171,763)."""
        result = self._sql(
            f"SELECT COUNT(*) as cnt FROM {self._table('tbl_contract_rates_all')} WHERE status = 'current'"
        )
        if result is None:
            return CheckResult(
                check_id="DATA-01", name="Current rates count in range",
                category="data", passed=False, message="Cannot query rates",
            )

        count = result[0]["cnt"]
        in_range = 150000 <= count <= 200000

        return CheckResult(
            check_id="DATA-01", name="Current rates count in range",
            category="data",
            passed=in_range,
            message=f"Count: {count:,} (expected ~171,763)",
            evidence=f"SELECT COUNT(*) ... WHERE status = 'current' = {count}",
        )

    def _check_provider_count(self) -> CheckResult:
        """Verify provider count is ~306."""
        result = self._sql(
            f"SELECT COUNT(*) as cnt FROM {self._table('tbl_genie_provider_profile')}"
        )
        if result is None:
            return CheckResult(
                check_id="DATA-02", name="Provider count ~306",
                category="data", passed=False, message="Cannot query provider profile",
            )

        count = result[0]["cnt"]
        in_range = 290 <= count <= 320

        return CheckResult(
            check_id="DATA-02", name="Provider count ~306",
            category="data",
            passed=in_range,
            message=f"Count: {count} (expected ~306)",
        )

    def _check_dofr_no_is_current_trap(self) -> CheckResult:
        """Verify DOFR behavioral health returns rows WITHOUT is_current filter."""
        result = self._sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self._table('tbl_dofr_matrix_extracted')}
            WHERE UPPER(service_category) LIKE '%BEHAVIORAL%'
        """)
        if result is None:
            return CheckResult(
                check_id="DATA-03", name="DOFR BH returns rows (no is_current)",
                category="data", passed=False, message="Cannot query DOFR",
            )

        count = result[0]["cnt"]
        return CheckResult(
            check_id="DATA-03", name="DOFR BH returns rows (no is_current)",
            category="data",
            passed=count > 0,
            message=f"BH rows without is_current filter: {count}",
        )

    def _check_delegation_coverage(self) -> CheckResult:
        """Verify delegation returns >100 providers WITHOUT is_current."""
        result = self._sql(f"""
            SELECT COUNT(DISTINCT provider_name) as cnt
            FROM {self._table('tbl_delegation_matrix')}
        """)
        if result is None:
            return CheckResult(
                check_id="DATA-04", name="Delegation covers >100 providers",
                category="data", passed=False, message="Cannot query delegation",
            )

        count = result[0]["cnt"]
        return CheckResult(
            check_id="DATA-04", name="Delegation covers >100 providers",
            category="data",
            passed=count >= 100,
            message=f"Delegation providers (no is_current filter): {count}",
        )

    def _check_canonical_join_integrity(self) -> CheckResult:
        """Verify canonical_provider_id join has 0% orphans."""
        result = self._sql(f"""
            SELECT COUNT(*) as orphans
            FROM {self._table('tbl_contract_rates_all')} r
            LEFT JOIN {self._table('tbl_genie_provider_profile')} p
              ON r.canonical_provider_id = p.provider_id
            WHERE p.provider_id IS NULL AND r.status = 'current'
        """)
        if result is None:
            return CheckResult(
                check_id="DATA-05", name="Canonical join 0% orphans",
                category="data", passed=False, message="Cannot verify join",
            )

        orphans = result[0]["orphans"]
        return CheckResult(
            check_id="DATA-05", name="Canonical join 0% orphans",
            category="data",
            passed=orphans == 0,
            message=f"Orphan rows on canonical join: {orphans}",
        )

    # ─── Configuration Checks ──────────────────────────────────────────

    def _check_no_phantom_columns(self) -> CheckResult:
        """Verify is_current_effective is NOT referenced in system prompt."""
        import os
        sql_query_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "platform", "v4", "tools", "sql_query.py"
        )
        try:
            with open(sql_query_path) as f:
                content = f.read()
            has_phantom = "is_current_effective" in content
            return CheckResult(
                check_id="CONFIG-01", name="No phantom column in system prompt",
                category="configuration",
                passed=not has_phantom,
                message="Phantom column removed" if not has_phantom else "is_current_effective STILL PRESENT",
            )
        except FileNotFoundError:
            return CheckResult(
                check_id="CONFIG-01", name="No phantom column in system prompt",
                category="configuration", passed=False,
                message="Cannot read sql_query.py", blocking=False,
            )

    def _check_whitelist_no_duplicates(self) -> CheckResult:
        """Verify table_whitelist.py has no duplicate keys."""
        import os
        whitelist_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "platform", "v4", "config", "table_whitelist.py"
        )
        try:
            with open(whitelist_path) as f:
                content = f.read()
            # Count occurrences of table name keys
            import re
            keys = re.findall(r'tbl_\w+', content)
            unique_keys = set(keys)
            has_dupes = len(keys) != len(unique_keys)
            return CheckResult(
                check_id="CONFIG-02", name="Whitelist has no duplicate keys",
                category="configuration",
                passed=not has_dupes,
                message=f"{len(keys)} keys, {len(unique_keys)} unique" + (" — DUPLICATES" if has_dupes else ""),
            )
        except FileNotFoundError:
            return CheckResult(
                check_id="CONFIG-02", name="Whitelist has no duplicate keys",
                category="configuration", passed=False,
                message="Cannot read table_whitelist.py", blocking=False,
            )

    # ─── Deployment Checks ──────────────────────────────────────────────

    def _check_analytics_endpoint(self) -> CheckResult:
        """Verify /api/v1/events endpoint exists in main.py."""
        import os
        main_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "app", "main.py"
        )
        try:
            with open(main_path) as f:
                content = f.read()
            has_endpoint = "/api/v1/events" in content
            return CheckResult(
                check_id="DEPLOY-01", name="Analytics endpoint deployed",
                category="deployment",
                passed=has_endpoint,
                message="POST /api/v1/events found" if has_endpoint else "Events endpoint MISSING",
            )
        except FileNotFoundError:
            return CheckResult(
                check_id="DEPLOY-01", name="Analytics endpoint deployed",
                category="deployment", passed=False, message="Cannot read main.py",
            )

    def _check_feedback_endpoint(self) -> CheckResult:
        """Verify /api/v1/feedback has structured fields."""
        import os
        main_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "app", "main.py"
        )
        try:
            with open(main_path) as f:
                content = f.read()
            has_structured = "accuracy:" in content and "error_category:" in content
            return CheckResult(
                check_id="DEPLOY-02", name="Feedback endpoint has structured fields",
                category="deployment",
                passed=has_structured,
                message="Structured feedback fields present" if has_structured else "Missing structured fields",
            )
        except FileNotFoundError:
            return CheckResult(
                check_id="DEPLOY-02", name="Feedback endpoint has structured fields",
                category="deployment", passed=False, message="Cannot read main.py",
            )

    def _check_evidence_in_sessions(self) -> CheckResult:
        """Verify at least one session has non-empty citations_json."""
        result = self._sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self._table('tbl_agent_sessions')}
            WHERE citations_json IS NOT NULL AND citations_json != '[]' AND citations_json != ''
        """)
        if result is None:
            return CheckResult(
                check_id="DEPLOY-03", name="Evidence persisted in sessions",
                category="deployment", passed=False,
                message="Cannot query sessions for evidence", blocking=False,
            )

        count = result[0]["cnt"]
        return CheckResult(
            check_id="DEPLOY-03", name="Evidence persisted in sessions",
            category="deployment",
            passed=count > 0,
            message=f"Sessions with citations: {count}",
            blocking=False,  # May be 0 if no queries run yet in trial env
        )

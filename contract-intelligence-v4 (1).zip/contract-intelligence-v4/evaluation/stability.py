"""
Contract Intelligence V4 — Stability & Repeatability Testing
Phase 5 (C-26, C-30): Repeat testing (3x) + paraphrase group testing (5 variants).

Measures system consistency:
- Repeat stability: same question asked 3x should give same answer
- Paraphrase stability: semantically equivalent questions should give same answer
- Version comparison: compare two versions with McNemar's test
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence

from .calibration import mcnemars_chi2, McNemarResult


# ─── Data Structures ────────────────────────────────────────────────────────

@dataclass
class RepeatResult:
    """Result of running one question N times."""
    question: str
    test_id: str
    runs: list[dict] = field(default_factory=list)  # [{answer, confidence, tables, latency_ms}]

    @property
    def n_runs(self) -> int:
        return len(self.runs)

    @property
    def answer_hashes(self) -> list[str]:
        """SHA256 of normalized answers."""
        return [hashlib.sha256(r["answer"].strip().lower().encode()).hexdigest()[:16] for r in self.runs]

    @property
    def is_stable(self) -> bool:
        """All runs produce same normalized answer hash."""
        hashes = self.answer_hashes
        return len(set(hashes)) == 1 if hashes else True

    @property
    def confidence_consistent(self) -> bool:
        """All runs produce same confidence level."""
        confs = [r.get("confidence", "") for r in self.runs]
        return len(set(confs)) <= 1

    @property
    def stability_score(self) -> float:
        """Fraction of runs matching the majority answer."""
        if not self.runs:
            return 1.0
        hashes = self.answer_hashes
        from collections import Counter
        most_common_count = Counter(hashes).most_common(1)[0][1]
        return most_common_count / len(hashes)


@dataclass
class ParaphraseGroupResult:
    """Result of running a paraphrase group (multiple equivalent questions)."""
    group_id: str
    questions: list[str]
    results: list[dict] = field(default_factory=list)  # [{question, answer, confidence, tables}]

    @property
    def n_questions(self) -> int:
        return len(self.results)

    @property
    def answer_hashes(self) -> list[str]:
        return [hashlib.sha256(r["answer"].strip().lower().encode()).hexdigest()[:16] for r in self.results]

    @property
    def is_consistent(self) -> bool:
        """All paraphrases give same answer."""
        hashes = self.answer_hashes
        return len(set(hashes)) == 1 if hashes else True

    @property
    def consistency_score(self) -> float:
        """Fraction matching majority answer across paraphrases."""
        if not self.results:
            return 1.0
        hashes = self.answer_hashes
        from collections import Counter
        most_common_count = Counter(hashes).most_common(1)[0][1]
        return most_common_count / len(hashes)

    @property
    def confidence_spread(self) -> set[str]:
        """Distinct confidence levels across paraphrases."""
        return set(r.get("confidence", "UNKNOWN") for r in self.results)


@dataclass
class StabilityReport:
    """Full stability test report."""
    timestamp: str
    app_version: str
    repeat_results: list[RepeatResult] = field(default_factory=list)
    paraphrase_results: list[ParaphraseGroupResult] = field(default_factory=list)

    @property
    def repeat_stability(self) -> float:
        """Overall repeat stability: fraction of questions that are stable."""
        if not self.repeat_results:
            return 1.0
        stable_count = sum(1 for r in self.repeat_results if r.is_stable)
        return stable_count / len(self.repeat_results)

    @property
    def paraphrase_consistency(self) -> float:
        """Overall paraphrase consistency: fraction of groups that are consistent."""
        if not self.paraphrase_results:
            return 1.0
        consistent_count = sum(1 for r in self.paraphrase_results if r.is_consistent)
        return consistent_count / len(self.paraphrase_results)

    @property
    def overall_stability(self) -> float:
        """Combined stability metric (average of repeat + paraphrase)."""
        return (self.repeat_stability + self.paraphrase_consistency) / 2

    @property
    def passes_threshold(self) -> bool:
        """Phase 5 exit criterion: stability >= 0.85."""
        return self.overall_stability >= 0.85

    def summary(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "app_version": self.app_version,
            "repeat_stability": round(self.repeat_stability, 4),
            "paraphrase_consistency": round(self.paraphrase_consistency, 4),
            "overall_stability": round(self.overall_stability, 4),
            "passes_threshold": self.passes_threshold,
            "repeat_count": len(self.repeat_results),
            "paraphrase_group_count": len(self.paraphrase_results),
            "unstable_questions": [
                r.question for r in self.repeat_results if not r.is_stable
            ],
            "inconsistent_groups": [
                r.group_id for r in self.paraphrase_results if not r.is_consistent
            ],
        }


# ─── StabilityTester ────────────────────────────────────────────────────────

class StabilityTester:
    """
    Orchestrates stability testing:
    - Repeat: run each question N times, measure answer consistency
    - Paraphrase: run equivalent questions, measure cross-question consistency
    - Version comparison: compare two runs with McNemar's
    """

    def __init__(
        self,
        query_fn: Optional[Callable[[str], dict]] = None,
        repeat_count: int = 3,
        delay_seconds: float = 1.0,
    ):
        """
        Args:
            query_fn: Callable that takes a question string and returns
                      dict with {answer, confidence, tables, latency_ms}.
                      If None, must be set before running.
            repeat_count: Number of times to repeat each question (default 3).
            delay_seconds: Delay between repeated calls (avoid rate limits).
        """
        self.query_fn = query_fn
        self.repeat_count = repeat_count
        self.delay_seconds = delay_seconds

    def run_repeat_test(self, questions: Sequence[dict]) -> list[RepeatResult]:
        """
        Run repeat stability test.

        Args:
            questions: List of dicts with at least {test_id, question}.

        Returns:
            List of RepeatResult, one per question.
        """
        assert self.query_fn, "query_fn must be set"
        results = []

        for q in questions:
            rr = RepeatResult(question=q["question"], test_id=q["test_id"])

            for _ in range(self.repeat_count):
                try:
                    response = self.query_fn(q["question"])
                    rr.runs.append({
                        "answer": response.get("answer", ""),
                        "confidence": response.get("confidence", "UNKNOWN"),
                        "tables": response.get("tables", []),
                        "latency_ms": response.get("latency_ms", 0),
                    })
                except Exception as exc:
                    rr.runs.append({
                        "answer": f"ERROR: {exc}",
                        "confidence": "ERROR",
                        "tables": [],
                        "latency_ms": 0,
                    })

                time.sleep(self.delay_seconds)

            results.append(rr)

        return results

    def run_paraphrase_test(self, groups: Sequence[dict]) -> list[ParaphraseGroupResult]:
        """
        Run paraphrase consistency test.

        Args:
            groups: List of dicts with {group_id, questions: [str, ...]}.

        Returns:
            List of ParaphraseGroupResult, one per group.
        """
        assert self.query_fn, "query_fn must be set"
        results = []

        for group in groups:
            pgr = ParaphraseGroupResult(
                group_id=group["group_id"],
                questions=group["questions"],
            )

            for question in group["questions"]:
                try:
                    response = self.query_fn(question)
                    pgr.results.append({
                        "question": question,
                        "answer": response.get("answer", ""),
                        "confidence": response.get("confidence", "UNKNOWN"),
                        "tables": response.get("tables", []),
                    })
                except Exception as exc:
                    pgr.results.append({
                        "question": question,
                        "answer": f"ERROR: {exc}",
                        "confidence": "ERROR",
                        "tables": [],
                    })

                time.sleep(self.delay_seconds)

            results.append(pgr)

        return results

    def run_full_stability_test(
        self,
        questions: Sequence[dict],
        paraphrase_groups: Sequence[dict],
        app_version: str = "unknown",
    ) -> StabilityReport:
        """
        Run complete stability suite.

        Args:
            questions: Test cases for repeat testing.
            paraphrase_groups: Paraphrase groups for consistency testing.
            app_version: Version string for tracking.

        Returns:
            StabilityReport with full results.
        """
        report = StabilityReport(
            timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            app_version=app_version,
        )

        report.repeat_results = self.run_repeat_test(questions)
        report.paraphrase_results = self.run_paraphrase_test(paraphrase_groups)

        return report

    @staticmethod
    def compare_versions(
        v1_results: Sequence[dict],
        v2_results: Sequence[dict],
    ) -> McNemarResult:
        """
        Compare two versions using McNemar's test (C-30).

        Args:
            v1_results: List of {test_id, correct: bool} for version 1.
            v2_results: List of {test_id, correct: bool} for version 2.

        Returns:
            McNemarResult with significance and direction.
        """
        # Align by test_id
        v1_map = {r["test_id"]: int(r["correct"]) for r in v1_results}
        v2_map = {r["test_id"]: int(r["correct"]) for r in v2_results}

        common_ids = sorted(set(v1_map.keys()) & set(v2_map.keys()))
        v1_correct = [v1_map[tid] for tid in common_ids]
        v2_correct = [v2_map[tid] for tid in common_ids]

        return mcnemars_chi2(v1_correct, v2_correct)


# ─── Paraphrase Groups (from benchmark YAML) ───────────────────────────────

PARAPHRASE_GROUPS = [
    {
        "group_id": "PG-01",
        "intent": "provider_rate_lookup",
        "questions": [
            "What are Sharp HealthCare's current inpatient per-diem rates?",
            "Show me Sharp HealthCare's inpatient rates",
            "I need to see the per-diem rates for Sharp HealthCare",
            "Can you pull up Sharp's current inpatient per-diem pricing?",
            "What does Sharp HealthCare charge for inpatient per-diem?",
        ],
    },
    {
        "group_id": "PG-02",
        "intent": "rate_comparison",
        "questions": [
            "Compare inpatient rates between Sharp HealthCare and Dignity Health",
            "How do Sharp and Dignity's inpatient rates compare?",
            "What's the difference between Sharp HealthCare and Dignity Health inpatient rates?",
            "Sharp vs Dignity inpatient per-diem rates comparison",
            "Show me a side-by-side of Sharp HealthCare and Dignity Health inpatient rates",
        ],
    },
    {
        "group_id": "PG-03",
        "intent": "provider_count",
        "questions": [
            "How many providers have capitation payment models?",
            "What is the count of capitation providers?",
            "Count the providers with cap payment arrangements",
            "How many providers are on capitation?",
            "Number of capitated providers in the network",
        ],
    },
    {
        "group_id": "PG-04",
        "intent": "amendment_history",
        "questions": [
            "Show me the amendment history for Dignity Health",
            "List all amendments for Dignity Health",
            "What amendments has Dignity Health had?",
            "Dignity Health contract amendment timeline",
            "How many times has the Dignity Health contract been amended?",
        ],
    },
    {
        "group_id": "PG-05",
        "intent": "clause_existence",
        "questions": [
            "Which providers have an offset clause?",
            "List providers with offset clauses",
            "Who has an offset clause in their contract?",
            "Show me which providers have offset provisions",
            "Providers with offset clause coverage",
        ],
    },
]

"""
Contract Intelligence V4 — LLM-as-Judge for Benchmark Accuracy Scoring

Uses Databricks Foundation Model API to evaluate agent answers against
gold-standard criteria from benchmark cases.

Usage:
    from evaluation.judge import LLMJudge, create_judge_fn

    judge = LLMJudge(model="databricks-claude-sonnet-4")
    accuracy = judge.evaluate(question, answer, case)
    # Returns: "correct", "partial", or "incorrect"

    # Or create a judge_fn compatible with BenchmarkRunner:
    judge_fn = create_judge_fn(model="databricks-claude-sonnet-4")
    runner = BenchmarkRunner(query_fn=..., judge_fn=judge_fn)
"""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import requests

logger = logging.getLogger(__name__)

# ─── Default Configuration ───────────────────────────────────────────────────

DEFAULT_MODEL = "databricks-claude-sonnet-4"
FALLBACK_MODEL = "databricks-meta-llama-3-3-70b-instruct"
MAX_RETRIES = 2
RETRY_DELAY = 2.0


# ─── Judge Prompt Templates ──────────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expert evaluator for a contract intelligence system at Blue Shield of California.

Your task: Given a USER QUESTION, the SYSTEM ANSWER, and GOLD CRITERIA, score the answer.

## Scoring Rules

- **correct**: The answer substantively addresses the question and contains the key facts/values specified in the gold criteria. Minor formatting differences, extra context, or slightly different wording are acceptable if the core facts match.

- **partial**: The answer addresses the question but is incomplete (missing some expected facts), or contains the right information mixed with minor errors that don't fundamentally mislead.

- **incorrect**: The answer is wrong (contradicts gold criteria), hallucinates facts not in the data, answers a different question than asked, or fails to provide meaningful information (e.g., "I don't know" when an answer exists, or confidently states wrong numbers).

## Special Cases

- If the gold criteria includes `no_answer_expected: true`, score "correct" if the system appropriately declines/says it cannot answer, and "incorrect" if it fabricates an answer.
- If the answer says "no data found" or similar, and gold criteria expects specific values, score "incorrect".
- If temporal filters are specified in gold criteria (e.g., "must use status='current'"), score "incorrect" if the answer clearly uses stale/superseded data.
- Confidence level is NOT part of accuracy scoring — only the factual content matters.

## Response Format

Respond with EXACTLY this JSON structure (no markdown, no extra text):
{"verdict": "<correct|partial|incorrect>", "reasoning": "<1-2 sentence explanation>"}
"""

USER_PROMPT_TEMPLATE = """## USER QUESTION
{question}

## SYSTEM ANSWER
{answer}

## GOLD CRITERIA
{criteria}

## EVALUATION CONTEXT
- Category: {category}
- Difficulty: {difficulty}
- Expected tables: {expected_tables}
- No-answer expected: {no_answer}

Score this answer:"""


# ─── Data Structures ─────────────────────────────────────────────────────────

@dataclass
class JudgeResult:
    """Result from a single judge evaluation."""
    verdict: str  # "correct", "partial", "incorrect"
    reasoning: str
    model_used: str
    latency_ms: float = 0.0
    raw_response: str = ""
    retries: int = 0


@dataclass
class JudgeStats:
    """Aggregate statistics for a judge run."""
    total: int = 0
    correct: int = 0
    partial: int = 0
    incorrect: int = 0
    errors: int = 0
    avg_latency_ms: float = 0.0
    model_used: str = ""

    @property
    def accuracy(self) -> float:
        scored = self.correct + self.partial + self.incorrect
        return (self.correct + self.partial) / scored if scored else 0.0

    def summary(self) -> dict:
        return {
            "total": self.total,
            "correct": self.correct,
            "partial": self.partial,
            "incorrect": self.incorrect,
            "errors": self.errors,
            "accuracy": round(self.accuracy, 4),
            "avg_latency_ms": round(self.avg_latency_ms, 1),
            "model": self.model_used,
        }


# ─── LLM Judge ───────────────────────────────────────────────────────────────

class LLMJudge:
    """LLM-as-Judge for scoring benchmark answers.

    Uses Databricks Foundation Model API (OpenAI-compatible chat endpoint).
    """

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        fallback_model: str = FALLBACK_MODEL,
        max_retries: int = MAX_RETRIES,
        temperature: float = 0.0,
        max_tokens: int = 256,
        workspace_url: Optional[str] = None,
        token: Optional[str] = None,
    ) -> None:
        """
        Args:
            model: Primary model endpoint name.
            fallback_model: Fallback if primary fails.
            max_retries: Retries per call before falling back.
            temperature: LLM temperature (0 for deterministic).
            max_tokens: Max response tokens.
            workspace_url: Databricks workspace URL (auto-detected if None).
            token: API token (auto-detected if None).
        """
        self.model = model
        self.fallback_model = fallback_model
        self.max_retries = max_retries
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._stats = JudgeStats(model_used=model)

        # Auto-detect workspace config
        if workspace_url is None or token is None:
            self._workspace_url, self._token = self._auto_detect_auth()
        else:
            self._workspace_url = workspace_url.rstrip("/")
            self._token = token

    def _auto_detect_auth(self) -> tuple[str, str]:
        """Auto-detect workspace URL and token from notebook context."""
        try:
            from dbruntime.databricks_repl_context import get_context
            ctx = get_context()
            url = ctx.browserHostName
            if not url.startswith("http"):
                url = f"https://{url}"
            token = ctx.apiToken
            return url.rstrip("/"), token
        except Exception:
            pass

        # Fallback: try environment variables
        import os
        url = os.environ.get("DATABRICKS_HOST", "")
        token = os.environ.get("DATABRICKS_TOKEN", "")
        if url and token:
            return url.rstrip("/"), token

        raise RuntimeError(
            "Cannot auto-detect Databricks auth. "
            "Provide workspace_url and token explicitly."
        )

    def _call_llm(self, model: str, system: str, user: str) -> str:
        """Call the chat endpoint."""
        url = f"{self._workspace_url}/serving-endpoints/{model}/invocations"
        headers = {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        }
        payload = {
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

        resp = requests.post(url, headers=headers, json=payload, timeout=60)
        resp.raise_for_status()
        data = resp.json()

        # Extract content from OpenAI-style response
        choices = data.get("choices", [])
        if choices:
            return choices[0].get("message", {}).get("content", "")
        return ""

    def _parse_verdict(self, raw: str) -> tuple[str, str]:
        """Parse JSON verdict from LLM response."""
        # Try direct JSON parse
        raw_stripped = raw.strip()
        # Remove markdown code fences if present
        if raw_stripped.startswith("```"):
            raw_stripped = re.sub(r"^```(?:json)?\n?", "", raw_stripped)
            raw_stripped = re.sub(r"\n?```$", "", raw_stripped)

        try:
            obj = json.loads(raw_stripped)
            verdict = obj.get("verdict", "").lower().strip()
            reasoning = obj.get("reasoning", "")
            if verdict in ("correct", "partial", "incorrect"):
                return verdict, reasoning
        except json.JSONDecodeError:
            pass

        # Regex fallback
        match = re.search(r'"verdict"\s*:\s*"(correct|partial|incorrect)"', raw, re.I)
        if match:
            verdict = match.group(1).lower()
            reason_match = re.search(r'"reasoning"\s*:\s*"([^"]+)"', raw)
            reasoning = reason_match.group(1) if reason_match else "Parsed via regex fallback"
            return verdict, reasoning

        # Last resort: look for keyword
        lower = raw.lower()
        if "incorrect" in lower:
            return "incorrect", f"Keyword-parsed from: {raw[:100]}"
        elif "partial" in lower:
            return "partial", f"Keyword-parsed from: {raw[:100]}"
        elif "correct" in lower:
            return "correct", f"Keyword-parsed from: {raw[:100]}"

        return "", f"UNPARSEABLE: {raw[:200]}"

    def evaluate(self, question: str, answer: str, case: dict) -> JudgeResult:
        """Evaluate a single answer against its benchmark case.

        Args:
            question: The user's question.
            answer: The system's answer text.
            case: Full benchmark case dict (from YAML).

        Returns:
            JudgeResult with verdict and reasoning.
        """
        # Build gold criteria from case
        criteria_parts = []
        if case.get("expected_facts"):
            criteria_parts.append(f"Expected facts: {case['expected_facts']}")
        if case.get("expected_grain"):
            criteria_parts.append(f"Expected grain: {case['expected_grain']}")
        if case.get("aggregation"):
            criteria_parts.append(f"Expected aggregation: {case['aggregation']}")
        if case.get("temporal_rule"):
            criteria_parts.append(f"Temporal rule: {case['temporal_rule']}")
        if case.get("required_filters"):
            criteria_parts.append(f"Required filters: {case['required_filters']}")
        if case.get("confidence_expectation"):
            criteria_parts.append(f"Expected confidence: {case['confidence_expectation']}")
        if not criteria_parts:
            criteria_parts.append("General factual accuracy expected.")

        criteria_str = "\n".join(criteria_parts)

        user_prompt = USER_PROMPT_TEMPLATE.format(
            question=question,
            answer=answer[:2000],  # Truncate very long answers
            criteria=criteria_str,
            category=case.get("category", "unknown"),
            difficulty=case.get("difficulty", "unknown"),
            expected_tables=case.get("expected_tables", []),
            no_answer=case.get("no_answer_expected", False),
        )

        # Try primary model, then fallback
        models_to_try = [self.model]
        if self.fallback_model and self.fallback_model != self.model:
            models_to_try.append(self.fallback_model)

        last_error = None
        retries_total = 0

        for model in models_to_try:
            for attempt in range(self.max_retries + 1):
                try:
                    t0 = time.time()
                    raw = self._call_llm(model, SYSTEM_PROMPT, user_prompt)
                    latency = (time.time() - t0) * 1000

                    verdict, reasoning = self._parse_verdict(raw)
                    if verdict:
                        self._stats.total += 1
                        if verdict == "correct":
                            self._stats.correct += 1
                        elif verdict == "partial":
                            self._stats.partial += 1
                        else:
                            self._stats.incorrect += 1

                        return JudgeResult(
                            verdict=verdict,
                            reasoning=reasoning,
                            model_used=model,
                            latency_ms=latency,
                            raw_response=raw[:500],
                            retries=retries_total,
                        )
                    else:
                        last_error = f"Unparseable response: {raw[:100]}"

                except Exception as exc:
                    last_error = str(exc)
                    retries_total += 1
                    if attempt < self.max_retries:
                        time.sleep(RETRY_DELAY * (attempt + 1))

        # All attempts failed
        self._stats.total += 1
        self._stats.errors += 1
        logger.warning("Judge failed for question '%s': %s", question[:50], last_error)

        return JudgeResult(
            verdict="",
            reasoning=f"JUDGE ERROR: {last_error}",
            model_used=models_to_try[-1],
            retries=retries_total,
        )

    @property
    def stats(self) -> JudgeStats:
        """Return aggregate judge statistics."""
        return self._stats

    def reset_stats(self) -> None:
        """Reset aggregate statistics."""
        self._stats = JudgeStats(model_used=self.model)


# ─── Factory Functions ────────────────────────────────────────────────────────

def create_judge_fn(
    model: str = DEFAULT_MODEL,
    fallback_model: str = FALLBACK_MODEL,
    **kwargs,
):
    """Create a judge_fn compatible with BenchmarkRunner.

    Returns:
        Callable(question, answer, case) -> "correct" | "partial" | "incorrect"

    Usage:
        judge_fn = create_judge_fn(model="databricks-claude-sonnet-4")
        runner = BenchmarkRunner(query_fn=..., judge_fn=judge_fn)
        report = runner.run_suite("benchmarks/benchmark_cases.yaml")
    """
    judge = LLMJudge(model=model, fallback_model=fallback_model, **kwargs)

    def _judge_fn(question: str, answer: str, case: dict) -> str:
        result = judge.evaluate(question, answer, case)
        return result.verdict  # "correct", "partial", "incorrect", or ""

    # Attach stats accessor for post-run analysis
    _judge_fn.judge = judge
    _judge_fn.stats = lambda: judge.stats

    return _judge_fn


def create_judge_fn_from_spark(spark, model: str = DEFAULT_MODEL, **kwargs):
    """Create judge_fn using Spark context for auth (notebook-friendly).

    Usage (in notebook):
        from evaluation.judge import create_judge_fn_from_spark
        judge_fn = create_judge_fn_from_spark(spark)
    """
    # Extract auth from Spark context
    try:
        token = spark.conf.get("spark.databricks.token", "")
        url = spark.conf.get("spark.databricks.workspaceUrl", "")
        if not url:
            url = f"https://{spark.conf.get('spark.databricks.clusterUsageTags.clusterOwnerOrgId', '')}"
    except Exception:
        token, url = None, None

    return create_judge_fn(model=model, workspace_url=url, token=token, **kwargs)

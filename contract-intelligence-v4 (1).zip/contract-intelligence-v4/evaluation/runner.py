"""
Contract Intelligence V4 — Benchmark Runner
Phase 5: Orchestration for loading YAML cases, executing benchmarks,
collecting results, and computing metrics.

Usage:
    from evaluation.runner import BenchmarkRunner
    runner = BenchmarkRunner(query_fn=my_query_function)
    report = runner.run_suite("benchmarks/benchmark_cases.yaml")
    print(report.summary())
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

import yaml

from .calibration import (
    brier_score,
    compute_category_metrics,
    confidence_to_prob,
    expected_calibration_error,
    reliability_diagram_data,
    wilson_ci,
    CategoryMetrics,
)
from .sql_assertions import SQLSemanticValidator, ValidationResult
from .stability import StabilityTester, StabilityReport, PARAPHRASE_GROUPS


# ─── Data Structures ────────────────────────────────────────────────────────

@dataclass
class CaseResult:
    """Result of running one benchmark case."""
    test_id: str
    category: str
    question: str
    difficulty: str
    # System output
    answer: str = ""
    confidence: str = ""
    tables_used: list[str] = field(default_factory=list)
    sql_generated: str = ""
    latency_ms: float = 0.0
    error: Optional[str] = None
    # Evaluation
    accuracy: str = ""  # "correct", "partial", "incorrect"
    judge_reasoning: str = ""
    sql_validation: Optional[dict] = None
    # Metadata
    timestamp: str = ""


@dataclass
class BenchmarkReport:
    """Full benchmark execution report."""
    timestamp: str
    app_version: str
    yaml_version: str
    total_cases: int = 0
    results: list[CaseResult] = field(default_factory=list)
    category_metrics: list[CategoryMetrics] = field(default_factory=list)
    calibration_ece: float = 0.0
    calibration_brier: float = 0.0
    reliability_data: list[dict] = field(default_factory=list)
    stability_report: Optional[StabilityReport] = None
    # Phase 5 exit criteria
    overall_accuracy: float = 0.0
    passes_accuracy_gate: bool = False  # >= 85%
    passes_category_gate: bool = False  # all categories >= 75% lower CI
    passes_ece_gate: bool = False  # ECE < 0.20
    passes_stability_gate: bool = False  # stability >= 0.85

    def summary(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "app_version": self.app_version,
            "total_cases": self.total_cases,
            "overall_accuracy": round(self.overall_accuracy, 4),
            "calibration_ece": round(self.calibration_ece, 4),
            "calibration_brier": round(self.calibration_brier, 4),
            "gates": {
                "accuracy_85pct": self.passes_accuracy_gate,
                "category_75pct_wilson": self.passes_category_gate,
                "ece_020": self.passes_ece_gate,
                "stability_085": self.passes_stability_gate,
            },
            "category_breakdown": [
                {
                    "category": m.category,
                    "accuracy": m.accuracy,
                    "wilson_ci": (m.wilson_lower, m.wilson_upper),
                    "passes": m.passes_threshold,
                    "n": m.total,
                }
                for m in self.category_metrics
            ],
        }

    def to_json(self) -> str:
        """Serialize report to JSON for persistence."""
        return json.dumps(self.summary(), indent=2, default=str)


# ─── BenchmarkRunner ────────────────────────────────────────────────────────

class BenchmarkRunner:
    """
    Loads YAML benchmark cases, executes them through the system,
    optionally runs LLM judge, computes calibration metrics.
    """

    def __init__(
        self,
        query_fn: Optional[Callable[[str], dict]] = None,
        judge_fn: Optional[Callable[[str, str, dict], str]] = None,
        sql_validator: Optional[SQLSemanticValidator] = None,
        app_version: str = "unknown",
        delay_seconds: float = 0.5,
    ):
        """
        Args:
            query_fn: Callable(question: str) -> {answer, confidence, tables, sql, latency_ms}
            judge_fn: Callable(question, answer, case) -> "correct"|"partial"|"incorrect"
            sql_validator: Optional SQL semantic validator instance.
            app_version: Version tag for report.
            delay_seconds: Delay between queries (rate limiting).
        """
        self.query_fn = query_fn
        self.judge_fn = judge_fn
        self.sql_validator = sql_validator or SQLSemanticValidator()
        self.app_version = app_version
        self.delay_seconds = delay_seconds

    def load_cases(self, yaml_path: str) -> list[dict]:
        """Load benchmark cases from YAML file."""
        path = Path(yaml_path)
        if not path.exists():
            raise FileNotFoundError(f"Benchmark file not found: {yaml_path}")

        with open(path) as f:
            data = yaml.safe_load(f)

        return data.get("cases", [])

    def run_suite(
        self,
        yaml_path: str,
        categories: Optional[list[str]] = None,
        max_cases: Optional[int] = None,
        run_stability: bool = False,
    ) -> BenchmarkReport:
        """
        Execute full benchmark suite.

        Args:
            yaml_path: Path to benchmark YAML file.
            categories: Optional filter to run only specific categories.
            max_cases: Optional cap on number of cases to run.
            run_stability: Whether to also run stability tests.

        Returns:
            BenchmarkReport with full results and metrics.
        """
        assert self.query_fn, "query_fn must be set before running"

        cases = self.load_cases(yaml_path)

        # Filter by category if specified
        if categories:
            cases = [c for c in cases if c.get("category") in categories]

        # Cap
        if max_cases:
            cases = cases[:max_cases]

        report = BenchmarkReport(
            timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            app_version=self.app_version,
            yaml_version="1.0.0",
            total_cases=len(cases),
        )

        # Execute each case
        for case in cases:
            result = self._run_case(case)
            report.results.append(result)
            time.sleep(self.delay_seconds)

        # Compute metrics (only if judge provided accuracy scores)
        scored_results = [r for r in report.results if r.accuracy]
        if scored_results:
            self._compute_metrics(report, scored_results)

        # Stability test
        if run_stability and self.query_fn:
            tester = StabilityTester(
                query_fn=self.query_fn,
                repeat_count=3,
                delay_seconds=self.delay_seconds,
            )
            # Pick 10 representative questions for repeat testing
            repeat_questions = [
                {"test_id": c["test_id"], "question": c["question"]}
                for c in cases[:10]
            ]
            report.stability_report = tester.run_full_stability_test(
                questions=repeat_questions,
                paraphrase_groups=PARAPHRASE_GROUPS,
                app_version=self.app_version,
            )
            report.passes_stability_gate = report.stability_report.passes_threshold

        return report

    def _run_case(self, case: dict) -> CaseResult:
        """Execute a single benchmark case."""
        result = CaseResult(
            test_id=case.get("test_id", ""),
            category=case.get("category", ""),
            question=case.get("question", ""),
            difficulty=case.get("difficulty", "unknown"),
            timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        )

        try:
            t0 = time.time()
            response = self.query_fn(case["question"])
            result.latency_ms = (time.time() - t0) * 1000

            result.answer = response.get("answer", "")
            result.confidence = response.get("confidence", "UNKNOWN")
            result.tables_used = response.get("tables", [])
            result.sql_generated = response.get("sql", "")

        except Exception as exc:
            result.error = str(exc)
            result.confidence = "ERROR"

        # SQL semantic validation
        if result.sql_generated:
            validation = self.sql_validator.validate(
                result.sql_generated,
                context={
                    "expected_tables": case.get("expected_tables", []),
                    "prohibited_filters": case.get("prohibited_filters", []),
                },
            )
            result.sql_validation = validation.summary()

        # LLM Judge (if provided)
        if self.judge_fn and result.answer and not result.error:
            try:
                result.accuracy = self.judge_fn(case["question"], result.answer, case)
            except Exception:
                result.accuracy = ""

        return result

    def _compute_metrics(self, report: BenchmarkReport, results: list[CaseResult]) -> None:
        """Compute calibration and category metrics from scored results."""
        # Map confidence to probabilities
        confidences = [confidence_to_prob(r.confidence) for r in results]
        actuals = [1 if r.accuracy in ("correct", "partial") else 0 for r in results]

        # ECE
        report.calibration_ece = expected_calibration_error(confidences, actuals)
        report.passes_ece_gate = report.calibration_ece < 0.20

        # Brier
        report.calibration_brier = brier_score(confidences, actuals)

        # Reliability diagram
        report.reliability_data = reliability_diagram_data(confidences, actuals)

        # Overall accuracy
        correct_count = sum(1 for r in results if r.accuracy in ("correct", "partial"))
        report.overall_accuracy = correct_count / len(results) if results else 0
        report.passes_accuracy_gate = report.overall_accuracy >= 0.85

        # Category metrics
        cat_data = [
            {"category": r.category, "accuracy": r.accuracy}
            for r in results
        ]
        report.category_metrics = compute_category_metrics(cat_data)
        report.passes_category_gate = all(m.passes_threshold for m in report.category_metrics)

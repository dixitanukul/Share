"""
Contract Intelligence V4 — Calibration & Statistical Validation
Phase 5 (C-10): ECE, Brier, Wilson CI, Cohen's kappa, McNemar's chi-squared.

All functions are pure Python (numpy-optional) for portability.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Sequence, Tuple

# ─── Confidence → numeric mapping ───────────────────────────────────────────

CONFIDENCE_NUMERIC = {
    "HIGH": 0.90,
    "MODERATE": 0.65,
    "LOW": 0.35,
    "UNCERTAIN": 0.15,
    "GENERATED": 0.50,
}


def confidence_to_prob(label: str) -> float:
    """Map ordinal confidence label to calibration probability."""
    return CONFIDENCE_NUMERIC.get(label.upper(), 0.50)


# ─── Expected Calibration Error (ECE) ───────────────────────────────────────

@dataclass
class CalibrationBin:
    """One bin in the reliability diagram."""
    bin_lower: float
    bin_upper: float
    count: int = 0
    sum_confidence: float = 0.0
    sum_accuracy: float = 0.0

    @property
    def avg_confidence(self) -> float:
        return self.sum_confidence / self.count if self.count else 0.0

    @property
    def avg_accuracy(self) -> float:
        return self.sum_accuracy / self.count if self.count else 0.0

    @property
    def gap(self) -> float:
        return abs(self.avg_accuracy - self.avg_confidence)


def expected_calibration_error(
    confidences: Sequence[float],
    actuals: Sequence[int],
    n_bins: int = 10,
) -> float:
    """
    Compute ECE: weighted average of |accuracy - confidence| per bin.

    Args:
        confidences: Predicted probabilities (0-1) for each sample.
        actuals: Binary ground truth (1=correct, 0=incorrect).
        n_bins: Number of equal-width bins.

    Returns:
        ECE value in [0, 1]. Lower is better. Target: <0.20.
    """
    assert len(confidences) == len(actuals), "Length mismatch"
    N = len(confidences)
    if N == 0:
        return 0.0

    bins = [CalibrationBin(i / n_bins, (i + 1) / n_bins) for i in range(n_bins)]

    for conf, actual in zip(confidences, actuals):
        idx = min(int(conf * n_bins), n_bins - 1)
        bins[idx].count += 1
        bins[idx].sum_confidence += conf
        bins[idx].sum_accuracy += actual

    ece = sum(b.count * b.gap for b in bins) / N
    return ece


def reliability_diagram_data(
    confidences: Sequence[float],
    actuals: Sequence[int],
    n_bins: int = 10,
) -> list[dict]:
    """
    Generate data points for a reliability diagram.

    Returns list of dicts with: bin_midpoint, avg_confidence, avg_accuracy, count.
    """
    N = len(confidences)
    if N == 0:
        return []

    bins = [CalibrationBin(i / n_bins, (i + 1) / n_bins) for i in range(n_bins)]

    for conf, actual in zip(confidences, actuals):
        idx = min(int(conf * n_bins), n_bins - 1)
        bins[idx].count += 1
        bins[idx].sum_confidence += conf
        bins[idx].sum_accuracy += actual

    return [
        {
            "bin_midpoint": (b.bin_lower + b.bin_upper) / 2,
            "avg_confidence": round(b.avg_confidence, 4),
            "avg_accuracy": round(b.avg_accuracy, 4),
            "count": b.count,
            "gap": round(b.gap, 4),
        }
        for b in bins
        if b.count > 0
    ]


# ─── Brier Score ────────────────────────────────────────────────────────────

def brier_score(
    confidences: Sequence[float],
    actuals: Sequence[int],
) -> float:
    """
    Brier score: mean squared error between predicted probability and actual.

    Lower is better. Target: <0.25.
    """
    assert len(confidences) == len(actuals)
    N = len(confidences)
    if N == 0:
        return 0.0
    return sum((c - a) ** 2 for c, a in zip(confidences, actuals)) / N


# ─── Wilson Confidence Interval ─────────────────────────────────────────────

def wilson_ci(
    successes: int,
    trials: int,
    z: float = 1.96,
) -> Tuple[float, float]:
    """
    Wilson score interval for binomial proportion.

    Args:
        successes: Number of correct answers in category.
        trials: Total questions in category.
        z: Z-score (1.96 for 95% CI).

    Returns:
        (lower_bound, upper_bound) tuple.
        Target: lower_bound >= 0.75 for every category.
    """
    if trials == 0:
        return (0.0, 0.0)

    p_hat = successes / trials
    z2 = z * z
    denom = 1 + z2 / trials
    center = (p_hat + z2 / (2 * trials)) / denom
    spread = z * math.sqrt(p_hat * (1 - p_hat) / trials + z2 / (4 * trials * trials)) / denom

    return (max(0.0, round(center - spread, 4)), min(1.0, round(center + spread, 4)))


# ─── Cohen's Kappa ──────────────────────────────────────────────────────────

def cohens_kappa(
    rater1: Sequence[int],
    rater2: Sequence[int],
    n_categories: int = 2,
) -> float:
    """
    Cohen's kappa for inter-rater agreement.

    Args:
        rater1, rater2: Category assignments (0-indexed).
        n_categories: Number of rating categories.

    Returns:
        Kappa value. Target: >= 0.60.
    """
    assert len(rater1) == len(rater2)
    N = len(rater1)
    if N == 0:
        return 0.0

    # Build confusion matrix
    matrix = [[0] * n_categories for _ in range(n_categories)]
    for r1, r2 in zip(rater1, rater2):
        matrix[r1][r2] += 1

    # Observed agreement
    p_obs = sum(matrix[i][i] for i in range(n_categories)) / N

    # Expected agreement (by chance)
    p_exp = 0.0
    for i in range(n_categories):
        row_sum = sum(matrix[i])
        col_sum = sum(matrix[j][i] for j in range(n_categories))
        p_exp += (row_sum * col_sum) / (N * N)

    if p_exp >= 1.0:
        return 1.0

    kappa = (p_obs - p_exp) / (1 - p_exp)
    return round(kappa, 4)


# ─── McNemar's Chi-Squared ──────────────────────────────────────────────────

@dataclass
class McNemarResult:
    """Result of McNemar's test for version comparison."""
    b: int  # V1 wrong, V2 right (improvement)
    c: int  # V1 right, V2 wrong (regression)
    chi2: float
    p_value: float
    significant: bool  # p < 0.05
    direction: str  # "improvement", "regression", or "no_change"


def mcnemars_chi2(
    v1_correct: Sequence[int],
    v2_correct: Sequence[int],
    alpha: float = 0.05,
) -> McNemarResult:
    """
    McNemar's test for paired nominal data (version comparison).

    Compare two versions on the same test set:
    - b = cases V1 got wrong but V2 got right (improvements)
    - c = cases V1 got right but V2 got wrong (regressions)

    Args:
        v1_correct: Binary (1=correct) for version 1.
        v2_correct: Binary (1=correct) for version 2.
        alpha: Significance level.

    Returns:
        McNemarResult with chi2, p_value, significance, and direction.
    """
    assert len(v1_correct) == len(v2_correct)

    b = sum(1 for a, b_ in zip(v1_correct, v2_correct) if a == 0 and b_ == 1)
    c = sum(1 for a, b_ in zip(v1_correct, v2_correct) if a == 1 and b_ == 0)

    # McNemar's chi-squared with continuity correction
    if b + c == 0:
        chi2 = 0.0
        p_value = 1.0
    else:
        chi2 = (abs(b - c) - 1) ** 2 / (b + c)
        # Approximate p-value from chi2 with 1 df using survival function
        # Using standard normal approximation: chi2 ~ N(0,1)^2
        p_value = _chi2_survival(chi2, df=1)

    significant = p_value < alpha
    if b > c:
        direction = "improvement"
    elif c > b:
        direction = "regression"
    else:
        direction = "no_change"

    return McNemarResult(
        b=b, c=c, chi2=round(chi2, 4),
        p_value=round(p_value, 6),
        significant=significant,
        direction=direction,
    )


def _chi2_survival(x: float, df: int = 1) -> float:
    """
    Approximate chi-squared survival function (p-value) for df=1.
    Uses the complementary error function approximation.
    """
    if x <= 0:
        return 1.0
    # For df=1, chi2 CDF = 2*Phi(sqrt(x)) - 1 where Phi is std normal CDF
    # So survival = 2*(1 - Phi(sqrt(x))) = erfc(sqrt(x/2))
    return math.erfc(math.sqrt(x / 2))


# ─── Category-Level Summary ─────────────────────────────────────────────────

@dataclass
class CategoryMetrics:
    """Per-category evaluation metrics."""
    category: str
    total: int
    correct: int
    partial: int
    incorrect: int
    accuracy: float
    wilson_lower: float
    wilson_upper: float
    passes_threshold: bool  # wilson_lower >= 0.75


def compute_category_metrics(
    results: Sequence[dict],
    accuracy_field: str = "accuracy",
    category_field: str = "category",
) -> list[CategoryMetrics]:
    """
    Compute per-category accuracy with Wilson CI.

    Args:
        results: List of benchmark result dicts with category and accuracy fields.
                 accuracy should be: "correct", "partial", or "incorrect".

    Returns:
        List of CategoryMetrics, one per category.
    """
    from collections import defaultdict
    cats: dict[str, list] = defaultdict(list)

    for r in results:
        cats[r[category_field]].append(r[accuracy_field])

    metrics = []
    for cat, outcomes in sorted(cats.items()):
        total = len(outcomes)
        correct = sum(1 for o in outcomes if o == "correct")
        partial = sum(1 for o in outcomes if o == "partial")
        incorrect = total - correct - partial

        # Count correct + partial as successes for Wilson CI
        successes = correct + partial
        lower, upper = wilson_ci(successes, total)

        metrics.append(CategoryMetrics(
            category=cat,
            total=total,
            correct=correct,
            partial=partial,
            incorrect=incorrect,
            accuracy=round(successes / total, 4) if total > 0 else 0.0,
            wilson_lower=lower,
            wilson_upper=upper,
            passes_threshold=lower >= 0.75,
        ))

    return metrics

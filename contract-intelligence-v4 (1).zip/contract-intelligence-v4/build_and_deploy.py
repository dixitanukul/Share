#!/usr/bin/env python3
"""
build_and_deploy.py — Contract Intelligence Platform V4
========================================================

Single-command frontend build + app deploy.

HOW TO USE
----------
Run this in a Databricks notebook cell (Python):

    exec(open("/Workspace/Users/adixit01@blueshieldca.com/contract-intelligence-v4/build_and_deploy.py").read())

Or inline in executeCode tool:

    %run /Workspace/Users/adixit01@blueshieldca.com/contract-intelligence-v4/build_and_deploy.py

MODES
-----
  SKIP_BUILD=True   → skip npm build, just deploy current app/static/  (backend-only changes)
  SKIP_DEPLOY=True  → build frontend only, don't deploy                 (for testing builds)
  FORCE_INSTALL=True→ force npm ci even if package-lock.json unchanged  (after adding packages)

Set these as globals before exec():
    SKIP_BUILD = True
    exec(open("...build_and_deploy.py").read())

NODE_MODULES STRATEGY
---------------------
node_modules is NEVER stored in the workspace. It lives only in /tmp/ (cluster SSD).
Workflow:
  1. npm ci  → /tmp/contract-intel-ci/node_modules/   (cached by package-lock.json MD5)
  2. symlink → frontend/node_modules  (workspace, exists only during npm run build)
  3. build   → app/static/            (vite output goes directly here)
  4. unlink  → remove filesystem symlink
  5. delete  → remove workspace catalog entry  ← CRITICAL: prevents deploy failures
  6. deploy  → Databricks Apps SDK SNAPSHOT deploy

This makes the workflow safe to run as many times as needed without manual cleanup.
Cache hit (same cluster, same package-lock.json) = ~2 min build only, no reinstall.
Cache miss (new cluster or package added) = ~4 min total.
"""

import hashlib, os, shutil, subprocess, time
from datetime import timedelta
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.apps import AppDeployment, AppDeploymentMode

# ── Config ─────────────────────────────────────────────────────────────────────
APP_NAME   = "contract-intelligence"
REPO_ROOT  = "/Workspace/Users/adixit01@blueshieldca.com/contract-intelligence-v4"
FRONTEND   = f"{REPO_ROOT}/frontend"
STATIC     = f"{REPO_ROOT}/app/static"

# /tmp/ cluster SSD cache — survives across builds on the SAME cluster,
# auto-cleared on cluster restart (which also clears the workspace catalog entry).
TMP_ROOT   = "/tmp/contract-intel-ci"
NM_CACHE   = f"{TMP_ROOT}/node_modules"          # cached node_modules here
NPM_BOOT   = f"{TMP_ROOT}/npm_bootstrap"         # npm binary cache
STAMP_FILE = f"{TMP_ROOT}/.lock_hash"            # stores last installed lock hash

NM_LINK    = f"{FRONTEND}/node_modules"          # symlink in workspace (temp only)
NM_WS_PATH = f"{REPO_ROOT}/frontend/node_modules"  # workspace catalog path

# ── Mode flags (override before exec() if needed) ──────────────────────────────
SKIP_BUILD    = globals().get("SKIP_BUILD",    False)
SKIP_DEPLOY   = globals().get("SKIP_DEPLOY",   False)
FORCE_INSTALL = globals().get("FORCE_INSTALL", False)

# ── Helpers ────────────────────────────────────────────────────────────────────
def _run(cmd, cwd=None, timeout=360, check=True):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd, timeout=timeout)
    if check and r.returncode != 0:
        raise RuntimeError(f"Command failed (rc={r.returncode}):\n{r.stdout[-2000:]}\n{r.stderr[-2000:]}")
    return r.stdout, r.stderr

def _md5(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()

def _cleanup_nm(w):
    """Remove node_modules symlink from filesystem AND workspace catalog.
    Safe to call multiple times — handles already-absent cases gracefully."""
    # 1. Filesystem
    if os.path.islink(NM_LINK):
        os.unlink(NM_LINK)
        print("  ✓ filesystem symlink removed")
    elif os.path.isdir(NM_LINK):
        shutil.rmtree(NM_LINK)
        print("  ✓ real directory removed (was not a symlink — cleaned up)")
    # 2. Workspace catalog — MUST be deleted even if .databricksignore lists it
    try:
        w.workspace.delete(path=NM_WS_PATH, recursive=True)
        print("  ✓ workspace catalog entry deleted")
    except Exception as e:
        if "RESOURCE_DOES_NOT_EXIST" in str(e) or "does not exist" in str(e).lower():
            print("  ✓ workspace catalog entry already absent")
        else:
            print(f"  ⚠ workspace catalog delete warning: {e}")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 0: Initialise SDK client
# ──────────────────────────────────────────────────────────────────────────────
w = WorkspaceClient()
print("=" * 60)
print("Contract Intelligence — Build & Deploy")
print("=" * 60)
print(f"  App:         {APP_NAME}")
print(f"  Source:      {REPO_ROOT}")
print(f"  Skip build:  {SKIP_BUILD}")
print(f"  Skip deploy: {SKIP_DEPLOY}")
print()

# ──────────────────────────────────────────────────────────────────────────────
# STEP 1: Pre-flight — ensure workspace is clean before we start
# ──────────────────────────────────────────────────────────────────────────────
print("[ 1/5 ] Pre-flight cleanup...")
_cleanup_nm(w)

# ──────────────────────────────────────────────────────────────────────────────
# STEP 2: Frontend build (skipped if SKIP_BUILD=True)
# ──────────────────────────────────────────────────────────────────────────────
if not SKIP_BUILD:
    print("\n[ 2/5 ] Frontend build...")

    # 2a. Bootstrap npm binary to /tmp/ if needed
    npm_bin = f"{NPM_BOOT}/package/bin/npm-cli.js"
    if not os.path.exists(npm_bin):
        print("  Bootstrapping npm binary...")
        os.makedirs(NPM_BOOT, exist_ok=True)
        _run(f"curl -fsSL https://registry.npmjs.org/npm/-/npm-10.9.2.tgz | tar -xz -C {NPM_BOOT}")
    NPM = f"node {npm_bin}"

    # 2b. Check node_modules cache validity (keyed by package-lock.json MD5)
    lock_path  = f"{FRONTEND}/package-lock.json"
    lock_hash  = _md5(lock_path)
    cached_hash = open(STAMP_FILE).read().strip() if os.path.exists(STAMP_FILE) else ""
    nm_exists   = os.path.isdir(f"{NM_CACHE}/react")  # quick existence check

    if FORCE_INSTALL or not nm_exists or cached_hash != lock_hash:
        reason = "FORCE_INSTALL" if FORCE_INSTALL else ("cache missing" if not nm_exists else f"lock changed ({cached_hash[:6]}→{lock_hash[:6]})")
        print(f"  npm ci required ({reason})...")
        os.makedirs(TMP_ROOT, exist_ok=True)
        if os.path.exists(NM_CACHE):
            shutil.rmtree(NM_CACHE)
        # Install directly to /tmp/ — never touches workspace filesystem
        t0 = time.time()
        _run(f"{NPM} ci --prefix {TMP_ROOT} --ignore-scripts", cwd=FRONTEND, timeout=600)
        # npm ci --prefix puts node_modules at {TMP_ROOT}/node_modules
        with open(STAMP_FILE, "w") as f:
            f.write(lock_hash)
        print(f"  ✓ npm ci done in {time.time()-t0:.0f}s  (cached at {NM_CACHE})")
    else:
        print(f"  ✓ node_modules cache HIT (lock={lock_hash[:8]}) — skipping npm ci")

    # 2c. Symlink node_modules into workspace — exists ONLY during npm run build
    print("  Creating temporary symlink for build...")
    if os.path.islink(NM_LINK) or os.path.exists(NM_LINK):
        _cleanup_nm(w)
    os.symlink(NM_CACHE, NM_LINK)
    print(f"  ✓ symlink: {NM_LINK} → {NM_CACHE}")

    # 2d. Run Vite build
    print("  Running npm run build...")
    t0 = time.time()
    try:
        stdout, stderr = _run(f"{NPM} run build --prefix {FRONTEND}", cwd=FRONTEND, timeout=300)
        build_output = stdout + stderr
        # Show key vite lines
        for line in build_output.split("\n"):
            if any(k in line.lower() for k in ["built", "error", "warn", "✓", "kB"]):
                print(f"    {line.strip()}")
        print(f"  ✓ Build done in {time.time()-t0:.0f}s")
    finally:
        # 2e. ALWAYS clean up symlink + catalog entry — even if build fails
        print("  Cleaning up node_modules symlink...")
        _cleanup_nm(w)

    # 2f. Verify output
    static_files = os.listdir(STATIC) if os.path.exists(STATIC) else []
    assert "index.html" in static_files, f"Build failed: index.html missing from {STATIC}"
    js_count  = sum(1 for f in static_files if f.endswith(".js") or
                    any(f2.endswith(".js") for f2 in os.listdir(f"{STATIC}/assets") if os.path.isdir(f"{STATIC}/assets")))
    print(f"  ✓ app/static verified: {static_files}")
else:
    print("\n[ 2/5 ] Frontend build SKIPPED (SKIP_BUILD=True)")
    static_files = os.listdir(STATIC) if os.path.exists(STATIC) else []
    assert "index.html" in static_files, f"index.html missing — run with SKIP_BUILD=False first"
    print(f"  Using existing build: {static_files}")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 3: Pre-deploy workspace check
# ──────────────────────────────────────────────────────────────────────────────
print("\n[ 3/5 ] Pre-deploy workspace check...")
# Paranoid check: ensure no node_modules in workspace right now
if os.path.exists(NM_LINK):
    print("  ⚠ node_modules still in workspace — cleaning again...")
    _cleanup_nm(w)
    print("  ✓ cleaned")
else:
    print("  ✓ workspace is clean (no node_modules)")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 4: Deploy (skipped if SKIP_DEPLOY=True)
# ──────────────────────────────────────────────────────────────────────────────
if not SKIP_DEPLOY:
    print(f"\n[ 4/5 ] Deploying {APP_NAME}...")

    # Wait for any in-progress deployment to clear (max 8 min)
    deadline = time.time() + 480
    while time.time() < deadline:
        app = w.apps.get(APP_NAME)
        app_state = app.app_status.state.value if app.app_status and app.app_status.state else "UNKNOWN"
        pd = app.pending_deployment
        if not pd:
            break
        pd_state = pd.status.state.value if pd.status and pd.status.state else "PENDING"
        print(f"  Waiting for pending deployment ({pd_state})... [{int(deadline-time.time())}s left]")
        if pd_state in ("FAILED", "CANCELLED", "SUCCEEDED"):
            break
        time.sleep(15)

    # Confirm app is RUNNING before deploying
    app = w.apps.get(APP_NAME)
    app_state = app.app_status.state.value if app.app_status and app.app_status.state else "UNKNOWN"
    if app_state != "RUNNING":
        raise RuntimeError(f"App is {app_state} — must be RUNNING before deploy. Start it first.")
    print(f"  App is {app_state} — proceeding with deploy")

    t0 = time.time()
    wait_obj = w.apps.deploy(
        app_name=APP_NAME,
        app_deployment=AppDeployment(
            source_code_path=REPO_ROOT,
            mode=AppDeploymentMode.SNAPSHOT,
        ),
    )
    print("  Deploy submitted — waiting for result (up to 5 min)...")
    result = wait_obj.result(timeout=timedelta(seconds=300))
    dep_state = result.status.state.value if result.status and result.status.state else "UNKNOWN"
    dep_msg   = result.status.message if result.status else ""
    elapsed   = time.time() - t0

    print(f"  Deployment ID:  {result.deployment_id}")
    print(f"  State:          {dep_state}")
    if dep_msg:
        print(f"  Message:        {dep_msg[:120]}")
    print(f"  Elapsed:        {elapsed:.0f}s")

    if dep_state != "SUCCEEDED":
        raise RuntimeError(f"Deployment {dep_state}: {dep_msg}")
else:
    print("\n[ 4/5 ] Deploy SKIPPED (SKIP_DEPLOY=True)")
    dep_state = "SKIPPED"

# ──────────────────────────────────────────────────────────────────────────────
# STEP 5: Summary
# ──────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("✅ COMPLETE")
print(f"   Build:  {'SKIPPED' if SKIP_BUILD else 'OK'}")
print(f"   Deploy: {dep_state}")
if not SKIP_DEPLOY and dep_state == "SUCCEEDED":
    print(f"   URL:    https://contract-intelligence-640321604414221.1.azure.databricksapps.com")
print("=" * 60)

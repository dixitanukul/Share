"""
app/sql_client.py — Lightweight SQL executor for Databricks Apps.

Replaces DatabricksSession (Databricks Connect) with the Statement Execution API
via the Databricks SDK. This works in App containers where there is no Spark cluster.

The class provides a spark-like interface: sql(query).toPandas() / .collect()
so existing endpoint code continues to work unchanged.
"""
from __future__ import annotations

import logging
import os
from typing import Any

import pandas as pd
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementState

logger = logging.getLogger(__name__)


class _ResultProxy:
    """Wraps statement execution result to provide .toPandas() and .collect()."""

    def __init__(self, df: pd.DataFrame):
        self._df = df

    def toPandas(self) -> pd.DataFrame:
        return self._df

    def collect(self) -> list[Any]:
        """Return list of Row-like dicts (compatible with row[0], row["col"])."""
        return [_RowProxy(row) for _, row in self._df.iterrows()]


class _RowProxy:
    """Mimics a Spark Row: supports row[0], row["col_name"], and row.col."""

    def __init__(self, series: pd.Series):
        self._data = series

    def __getitem__(self, key):
        if isinstance(key, int):
            return self._data.iloc[key]
        return self._data[key]

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self._data[name]

    def asDict(self, recursive: bool = False) -> dict:
        """Return row as a plain dict — mirrors pyspark.sql.Row.asDict().

        The `recursive` parameter is accepted for API compatibility with Spark
        Row but is ignored here (all values are already Python primitives from
        the pandas Series).
        """
        return self._data.to_dict()


class WarehouseSpark:
    """
    Drop-in replacement for a Spark session in Databricks Apps.
    Uses the Statement Execution API to run SQL on a SQL warehouse.

    Usage:
        spark = WarehouseSpark()
        df = spark.sql("SELECT * FROM catalog.schema.table LIMIT 10").toPandas()
    """

    def __init__(self, warehouse_id: str | None = None, client: WorkspaceClient | None = None):
        self._client = client or WorkspaceClient()
        self._warehouse_id = warehouse_id or self._resolve_warehouse_id()
        if not self._warehouse_id:
            raise RuntimeError(
                "No SQL warehouse ID found. Set DATABRICKS_WAREHOUSE_ID env var "
                "or configure a sql_warehouse resource in app.yaml."
            )
        logger.info("WarehouseSpark initialized with warehouse_id=%s", self._warehouse_id)

    def _resolve_warehouse_id(self) -> str:
        """Try multiple env var conventions used by Databricks Apps."""
        for var in [
            "DATABRICKS_WAREHOUSE_ID",
            "CONTRACT_INTEL_WAREHOUSE_ID",
            "SQL_WAREHOUSE_ID",
        ]:
            val = os.environ.get(var, "")
            if val:
                return val

        # Try to get from the resource binding via SDK
        try:
            # In Databricks Apps, resources are accessible via env vars
            # The convention is <RESOURCE_NAME>_<RESOURCE_TYPE>_ID
            # e.g., CONTRACT_INTEL_WAREHOUSE_SQL_WAREHOUSE_ID
            for key, val in os.environ.items():
                if "WAREHOUSE" in key and val and len(val) > 10:
                    logger.info("Found warehouse ID in env var %s", key)
                    return val
        except Exception:
            pass
        return ""

    # Statement Execution API constraint: wait_timeout must be 0s (async/poll)
    # or 5s–50s (synchronous). Values outside this range are rejected with a
    # 400 error. We use 50s as the synchronous cap and poll for longer queries.
    _SYNC_TIMEOUT_S = 50
    _POLL_INTERVAL_S = 2
    _POLL_MAX_S = 300   # 5 minutes hard ceiling for long agent tool queries

    def sql(self, statement: str) -> _ResultProxy:
        """Execute SQL and return a result proxy with .toPandas() / .collect().

        Uses the synchronous wait path (wait_timeout=50s) for fast queries.
        Falls back to a polling loop for queries that exceed 50s, up to
        _POLL_MAX_S (300s) total.
        """
        import time

        try:
            response = self._client.statement_execution.execute_statement(
                warehouse_id=self._warehouse_id,
                statement=statement,
                wait_timeout=f"{self._SYNC_TIMEOUT_S}s",
            )
        except Exception as exc:
            raise RuntimeError(f"SQL execution failed: {exc}") from exc

        if response.status and response.status.state == StatementState.FAILED:
            error_msg = response.status.error.message if response.status.error else "Unknown error"
            raise RuntimeError(f"SQL statement failed: {error_msg}")

        # If the query is still running after the synchronous wait, poll for completion.
        if response.status and response.status.state in (
            StatementState.RUNNING, StatementState.PENDING
        ):
            statement_id = response.statement_id
            deadline = time.time() + self._POLL_MAX_S
            while time.time() < deadline:
                time.sleep(self._POLL_INTERVAL_S)
                try:
                    response = self._client.statement_execution.get_statement(
                        statement_id=statement_id
                    )
                except Exception as exc:
                    raise RuntimeError(f"SQL poll failed: {exc}") from exc
                if response.status and response.status.state not in (
                    StatementState.RUNNING, StatementState.PENDING
                ):
                    break
            else:
                # Cancel the runaway statement before raising
                try:
                    self._client.statement_execution.cancel_execution(
                        statement_id=statement_id
                    )
                except Exception:
                    pass
                raise TimeoutError(
                    f"SQL statement timed out after {self._POLL_MAX_S}s. "
                    "Consider adding filters or raising _POLL_MAX_S."
                )

        if response.status and response.status.state == StatementState.FAILED:
            error_msg = response.status.error.message if response.status.error else "Unknown error"
            raise RuntimeError(f"SQL statement failed: {error_msg}")

        if response.status and response.status.state != StatementState.SUCCEEDED:
            raise RuntimeError(f"SQL statement in unexpected state: {response.status.state}")

        # Convert result to DataFrame
        if response.manifest and response.result and response.result.data_array:
            columns = [col.name for col in response.manifest.schema.columns]
            data = list(response.result.data_array)  # first inline chunk

            # Paginate through additional chunks.
            # The Statement Execution API returns results in <=1 MB inline chunks.
            # Queries that return large text columns (e.g. LEFT(clause_text, 600))
            # may spill into chunk 2+ — if we don't fetch them, rows are silently lost.
            _total_chunks = (response.manifest.total_chunk_count or 1)
            _chunk_idx = 1
            while _chunk_idx < _total_chunks:
                try:
                    _chunk = self._client.statement_execution.get_statement_result_chunk_n(
                        statement_id=response.statement_id,
                        chunk_index=_chunk_idx,
                    )
                    if _chunk.data_array:
                        data.extend(_chunk.data_array)
                except Exception as _ce:
                    logger.warning("Failed to fetch result chunk %d: %s", _chunk_idx, _ce)
                    break
                _chunk_idx += 1

            df = pd.DataFrame(data, columns=columns)

            # Cast types based on manifest
            for col_info in response.manifest.schema.columns:
                col_name = col_info.name
                type_name = (col_info.type_name.value if hasattr(col_info.type_name, "value") else str(col_info.type_name)).upper() if col_info.type_name else ""
                try:
                    if type_name in ("INT", "LONG", "SHORT", "BIGINT"):
                        df[col_name] = pd.to_numeric(df[col_name], errors="coerce").astype("Int64")
                    elif type_name in ("FLOAT", "DOUBLE", "DECIMAL"):
                        df[col_name] = pd.to_numeric(df[col_name], errors="coerce")
                    elif type_name == "BOOLEAN":
                        df[col_name] = df[col_name].map({"true": True, "false": False, None: None})
                except Exception:
                    pass  # Keep as string if cast fails
        else:
            df = pd.DataFrame()

        return _ResultProxy(df)

"""
app/middleware/circuit_breaker.py

Three-state circuit breaker for protecting SQL warehouse, Vector Search,
and LLM endpoint from cascading failures.

Step 3.4 — prevents a single dependency outage from bringing down the
entire API layer.

States
------
  CLOSED    : Normal operation — all requests pass through.
  OPEN      : Tripped — requests are rejected immediately (fast-fail).
  HALF_OPEN : Trial — one probe request is allowed to test recovery.

Transitions
-----------
  CLOSED  → OPEN      : consecutive failures ≥ failure_threshold
  OPEN    → HALF_OPEN : cooldown_s elapsed since trip
  HALF_OPEN → CLOSED  : probe succeeds
  HALF_OPEN → OPEN    : probe fails

Usage
-----
    from app.middleware.circuit_breaker import CircuitBreaker

    breaker = CircuitBreaker("sql", failure_threshold=3, cooldown_s=30.0)

    if not breaker.allow():
        raise HTTPException(503, "SQL warehouse temporarily unavailable")
    try:
        result = spark.sql("SELECT 1").collect()
        breaker.record_success()
    except Exception as exc:
        breaker.record_failure()
        raise
"""
from __future__ import annotations

import threading
import time
from enum import Enum
from typing import Optional


class CircuitState(Enum):
    CLOSED    = "CLOSED"
    OPEN      = "OPEN"
    HALF_OPEN = "HALF_OPEN"


class CircuitBreaker:
    """
    Thread-safe circuit breaker.

    Parameters
    ----------
    name              : Human-readable label used in health/status output.
    failure_threshold : Consecutive failures before the circuit opens.
    cooldown_s        : Seconds the circuit stays OPEN before going HALF_OPEN.
    """

    def __init__(
        self,
        name: str,
        *,
        failure_threshold: int   = 3,
        cooldown_s:        float = 30.0,
    ) -> None:
        self.name              = name
        self._threshold        = failure_threshold
        self._cooldown         = cooldown_s
        self._state            = CircuitState.CLOSED
        self._failures         = 0
        self._opened_at: float = 0.0
        self._lock             = threading.Lock()

    # ── Public interface ────────────────────────────────────────────────

    def allow(self) -> bool:
        """Return True if the caller should proceed with the protected operation."""
        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True
            if self._state == CircuitState.OPEN:
                if time.monotonic() - self._opened_at >= self._cooldown:
                    self._state = CircuitState.HALF_OPEN
                    return True   # allow one probe request
                return False
            # HALF_OPEN: allow the single probe
            return True

    def record_success(self) -> None:
        """Call after a protected operation succeeds. Resets failure counter."""
        with self._lock:
            self._failures = 0
            self._state    = CircuitState.CLOSED

    def record_failure(self) -> None:
        """Call after a protected operation fails. May trip the circuit."""
        with self._lock:
            self._failures += 1
            if (
                self._failures >= self._threshold
                or self._state == CircuitState.HALF_OPEN
            ):
                self._state     = CircuitState.OPEN
                self._opened_at = time.monotonic()

    @property
    def state(self) -> CircuitState:
        """Current circuit state (thread-safe snapshot)."""
        with self._lock:
            return self._state

    @property
    def failure_count(self) -> int:
        """Number of consecutive failures (thread-safe). Used by /health endpoint."""
        with self._lock:
            return self._failures

    def status(self) -> dict:
        """Return a JSON-serialisable status snapshot."""
        with self._lock:
            age_s = (
                round(time.monotonic() - self._opened_at, 1)
                if self._state != CircuitState.CLOSED
                else 0.0
            )
            return {
                "name":       self.name,
                "state":      self._state.value,
                "failures":   self._failures,
                "open_age_s": age_s,
            }


# ── Pre-configured breakers for the three V4 dependencies ──────────────────

def make_sql_breaker()  -> CircuitBreaker:
    """SQL warehouse breaker: trips at 8 consecutive failures, 60 s cooldown.

    Threshold raised from 3 → 8 to survive SQL warehouse cold-start latency
    (first query may take 2-4 min to spin up, causing false-positive trips).
    Cooldown raised from 30 s → 60 s to give the warehouse more recovery time.
    """
    return CircuitBreaker("sql_warehouse", failure_threshold=8, cooldown_s=60.0)


def make_vs_breaker() -> CircuitBreaker:
    """Vector Search breaker: trips at 2 consecutive failures, 60 s cooldown."""
    return CircuitBreaker("vector_search", failure_threshold=2, cooldown_s=60.0)


def make_llm_breaker() -> CircuitBreaker:
    """LLM endpoint breaker: trips at 2 consecutive failures, 45 s cooldown."""
    return CircuitBreaker("llm_api",       failure_threshold=2, cooldown_s=45.0)

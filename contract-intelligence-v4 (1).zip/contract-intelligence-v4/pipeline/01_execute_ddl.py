"""
Step 1: Execute All DDL — Create Empty Tables + Seed Data
==========================================================
Creates 18 tables (8 state engine + 9 reimbursement + 1 dim) and seeds taxonomy.
Run AFTER: 00_config.py
Run BEFORE: 02_state_engine.py, 03_reimbursement_migration.py

Results: 18 tables, 50 taxonomy rows, 45 pattern rows.
"""

from datetime import datetime
from pyspark.sql import SparkSession
import re

spark = SparkSession.builder.getOrCreate()

# ============================================================
# CONFIGURATION
# ============================================================
CATALOG = "dev_adb"
SCHEMA = "raw"
FQ_PREFIX = f"{CATALOG}.{SCHEMA}"
BASE_PATH = "/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline"
SQL_PATH = f"{BASE_PATH}/sql"

DDL_FILES = [
    (f"{SQL_PATH}/state_engine_ddl.sql", "State Engine DDL (8 tables)"),
    (f"{SQL_PATH}/reimbursement_ddl.sql", "Reimbursement DDL (9 tables)"),
    (f"{SQL_PATH}/taxonomy_seed.sql", "Taxonomy seed data"),
]

# ============================================================
# SQL PARSER — handles semicolons inside quoted strings
# ============================================================

def split_sql_statements(sql_content):
    """Split SQL on semicolons, but NOT inside single-quoted strings."""
    statements = []
    current = []
    in_quote = False
    i = 0
    while i < len(sql_content):
        char = sql_content[i]
        if char == "'" and not in_quote:
            in_quote = True
            current.append(char)
        elif char == "'" and in_quote:
            if i + 1 < len(sql_content) and sql_content[i + 1] == "'":
                current.append("''")
                i += 1
            else:
                in_quote = False
                current.append(char)
        elif char == ";" and not in_quote:
            stmt = "".join(current).strip()
            if stmt:
                statements.append(stmt)
            current = []
        else:
            current.append(char)
        i += 1
    stmt = "".join(current).strip()
    if stmt:
        non_comment = [l for l in stmt.split("\n") if l.strip() and not l.strip().startswith("--")]
        if non_comment:
            statements.append(stmt)
    return statements

# ============================================================
# EXECUTION FUNCTIONS
# ============================================================

def log_step(step_name, status, details=""):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    icon = "✓" if status == "SUCCESS" else "✗" if status == "FAILED" else "○"
    print(f"[{ts}] {icon} {step_name}: {status}")
    if details:
        print(f"    {details}")


def execute_sql_file(file_path, description=""):
    """Execute all statements in a SQL file with DEFAULT clause fallback."""
    desc = description or file_path.split("/")[-1]
    log_step(f"Executing: {desc}", "RUNNING")
    start = datetime.now()

    workspace_path = f"/Workspace{file_path}"
    with open(workspace_path, "r") as f:
        sql_content = f.read()

    statements = split_sql_statements(sql_content)
    success_count = 0
    error_count = 0

    for i, stmt in enumerate(statements, 1):
        non_comment_lines = [
            l for l in stmt.split("\n")
            if l.strip() and not l.strip().startswith("--")
        ]
        if not non_comment_lines:
            continue
        try:
            spark.sql(stmt)
            success_count += 1
        except Exception as e:
            error_msg = str(e)
            # Retry with DEFAULT clauses removed if unsupported
            if "WRONG_COLUMN_DEFAULTS_FOR_DELTA_FEATURE_NOT_ENABLED" in error_msg:
                fixed = re.sub(r'\bDEFAULT\s+\S+', '', stmt)
                try:
                    spark.sql(fixed)
                    success_count += 1
                    continue
                except Exception:
                    pass
            error_count += 1
            print(f"  ✗ Statement {i}: {error_msg[:120]}")

    elapsed = (datetime.now() - start).total_seconds()
    status = "SUCCESS" if error_count == 0 else "PARTIAL"
    log_step(desc, status, f"{success_count} ok, {error_count} failed ({elapsed:.1f}s)")
    return success_count, error_count


# ============================================================
# MAIN
# ============================================================
print("=" * 60)
print("DDL EXECUTION — Creating All Tables")
print(f"  Target: {CATALOG}.{SCHEMA}")
print(f"  Time:   {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 60)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

for file_path, desc in DDL_FILES:
    execute_sql_file(file_path, desc)
    print()

# ============================================================
# VALIDATION
# ============================================================
print("VALIDATION:")
result = spark.sql(f"SHOW TABLES IN {CATALOG}.{SCHEMA}").collect()
v2_tables = [r["tableName"] for r in result if r["tableName"].startswith(("tbl_v2_", "tbl_reimb_", "dim_service"))]
print(f"  Tables created: {len(v2_tables)}")

tax_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ_PREFIX}.dim_service_line_taxonomy").collect()[0]["n"]
pat_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ_PREFIX}.dim_service_line_patterns").collect()[0]["n"]
print(f"  Taxonomy rows: {tax_count} (expected ~50)")
print(f"  Pattern rows:  {pat_count} (expected ~45)")
print("=" * 60)

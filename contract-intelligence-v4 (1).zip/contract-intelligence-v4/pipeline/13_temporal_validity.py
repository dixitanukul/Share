# Databricks notebook source
# DBTITLE 1,Temporal Validity Engine
# MAGIC %md
# MAGIC # Platform Module 13: Temporal Validity Engine
# MAGIC
# MAGIC **Wave 2 — Version Correctness**
# MAGIC
# MAGIC Adds temporal validity windows (`valid_from`, `valid_to`, `is_current_temporal`) to rate rules and legal units, enabling point-in-time queries and verifying amendment supersession chains.
# MAGIC
# MAGIC **Tables Modified:**
# MAGIC - `tbl_reimb_rate_rules` — valid_from, valid_to, is_current_temporal, contract_chain_id
# MAGIC - `tbl_retrieval_legal_units` — valid_from, valid_to, contract_chain_id
# MAGIC - `tbl_qa_temporal_validation` — validation check results
# MAGIC
# MAGIC **Key Logic:**
# MAGIC - Contract chain = filename-derived numeric ID grouping renewals/amendments
# MAGIC - `valid_from` = source document's effective_date
# MAGIC - `valid_to` = next document's effective_date - 1 day (within same chain)
# MAGIC - `is_current_temporal` = TRUE when no subsequent document exists in the chain

# COMMAND ----------

# DBTITLE 1,Configuration
# Configuration
SCHEMA = "dev_adb.raw"
CHAIN_ID_REGEX = r'_(\d{5,})_[A-Z]'  # Phase 4.1: Expanded from \d{9,} to \d{5,} for broader coverage  # Extracts contract chain ID from filename

# Tables
RATE_RULES_TABLE = f"{SCHEMA}.tbl_reimb_rate_rules"
LEGAL_UNITS_TABLE = f"{SCHEMA}.tbl_retrieval_legal_units"
TIMELINE_TABLE = f"{SCHEMA}.tbl_genie_amendment_timeline"
VALIDATION_TABLE = f"{SCHEMA}.tbl_qa_temporal_validation"

print(f"Schema: {SCHEMA}")
print(f"Chain ID regex: {CHAIN_ID_REGEX} (Phase 4.1: expanded from 9+ to 5+ digits)")
print(f"  Pattern: providerID_ProviderName_{{contractChainID}}_DocType_version.pdf")

# COMMAND ----------

# DBTITLE 1,Build Temporal Reference View
# MAGIC %sql
# MAGIC -- Phase 4.1: Expanded temporal reference with fallback chain key
# MAGIC -- Primary: filename-derived chain ID (now matches 5+ digit IDs, up from 9+)
# MAGIC -- Fallback: provider_id || '_' || LEFT(document_type, 8) for files without regex match
# MAGIC -- This brings coverage from ~66.8% to ~90%+
# MAGIC
# MAGIC CREATE OR REPLACE TEMP VIEW temporal_reference AS
# MAGIC SELECT 
# MAGIC     source_filename,
# MAGIC     provider_id,
# MAGIC     -- Phase 4.1: Use COALESCE with fallback chain key
# MAGIC     COALESCE(
# MAGIC         REGEXP_EXTRACT(source_filename, '_(\\d{5,})_[A-Z]', 1),
# MAGIC         -- Fallback: derive chain from provider_id + document_type prefix
# MAGIC         -- Groups all docs of same type for same provider into one chain
# MAGIC         CONCAT(provider_id, '_', LEFT(COALESCE(document_type, 'Unknown'), 8))
# MAGIC     ) AS chain_id,
# MAGIC     effective_date_parsed AS valid_from,
# MAGIC     DATE_SUB(
# MAGIC         LEAD(effective_date_parsed) OVER (
# MAGIC             PARTITION BY provider_id, COALESCE(
# MAGIC                 REGEXP_EXTRACT(source_filename, '_(\\d{5,})_[A-Z]', 1),
# MAGIC                 CONCAT(provider_id, '_', LEFT(COALESCE(document_type, 'Unknown'), 8))
# MAGIC             )
# MAGIC             ORDER BY effective_date_parsed, amendment_order
# MAGIC         ),
# MAGIC         1
# MAGIC     ) AS valid_to,
# MAGIC     CASE 
# MAGIC         WHEN LEAD(effective_date_parsed) OVER (
# MAGIC             PARTITION BY provider_id, COALESCE(
# MAGIC                 REGEXP_EXTRACT(source_filename, '_(\\d{5,})_[A-Z]', 1),
# MAGIC                 CONCAT(provider_id, '_', LEFT(COALESCE(document_type, 'Unknown'), 8))
# MAGIC             )
# MAGIC             ORDER BY effective_date_parsed, amendment_order
# MAGIC         ) IS NULL THEN TRUE 
# MAGIC         ELSE FALSE 
# MAGIC     END AS is_current
# MAGIC FROM dev_adb.raw.tbl_genie_amendment_timeline
# MAGIC WHERE effective_date_parsed IS NOT NULL;
# MAGIC
# MAGIC -- Verify improvement
# MAGIC SELECT 
# MAGIC     COUNT(*) AS total_refs,
# MAGIC     SUM(CASE WHEN chain_id IS NOT NULL THEN 1 ELSE 0 END) AS has_chain_id,
# MAGIC     ROUND(SUM(CASE WHEN chain_id IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS chain_coverage_pct,
# MAGIC     SUM(CASE WHEN is_current THEN 1 ELSE 0 END) AS current_count,
# MAGIC     COUNT(DISTINCT chain_id) AS unique_chains
# MAGIC FROM temporal_reference
# MAGIC

# COMMAND ----------

# DBTITLE 1,Ensure Temporal Columns Exist
# Add temporal columns if they don't exist (idempotent)

column_defs = {
    RATE_RULES_TABLE: [
        ("valid_from", "DATE", "Start of rate validity period (= effective_date of source document)"),
        ("valid_to", "DATE", "End of rate validity period (= day before next document in contract chain). NULL if current."),
        ("is_current_temporal", "BOOLEAN", "TRUE if this is the latest rate in the contract chain (valid_to IS NULL)"),
        ("contract_chain_id", "STRING", "Contract chain identifier extracted from source filename (groups related base+amendments)"),
    ],
    LEGAL_UNITS_TABLE: [
        ("valid_from", "DATE", "Start of validity period (= effective_date of source document)"),
        ("valid_to", "DATE", "End of validity period (day before next doc in chain). NULL if current."),
        ("contract_chain_id", "STRING", "Contract chain identifier from source filename"),
    ],
}

for table, cols in column_defs.items():
    for col_name, col_type, comment in cols:
        try:
            spark.sql(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type} COMMENT '{comment}'")
            print(f"  ✅ {table.split('.')[-1]}.{col_name} added")
        except Exception as e:
            if "already exists" in str(e):
                print(f"  ⏭️  {table.split('.')[-1]}.{col_name} exists")
            else:
                print(f"  ❌ {table.split('.')[-1]}.{col_name}: {e}")

# COMMAND ----------

# DBTITLE 1,Populate Rate Rules Temporal Columns
# Phase 3.1: MERGE with retry (3 attempts, 30s exponential backoff)
# Protects against ConcurrentAppendException / ConcurrentDeleteReadException
import time as _rt

_merge_sql_rate_rules = """
MERGE INTO dev_adb.raw.tbl_reimb_rate_rules AS r
USING temporal_reference AS t
ON r.source_filename = t.source_filename
WHEN MATCHED THEN UPDATE SET
    r.valid_from = t.valid_from,
    r.valid_to = t.valid_to,
    r.is_current_temporal = t.is_current,
    r.contract_chain_id = t.chain_id
"""

for _attempt in range(3):
    try:
        spark.sql(_merge_sql_rate_rules)
        print(f"  ✅ MERGE tbl_reimb_rate_rules completed (attempt {_attempt + 1})")
        break
    except Exception as _e:
        if 'Concurrent' in str(_e) and _attempt < 2:
            _wait = 30 * (2 ** _attempt)  # 30s, 60s
            print(f"  ⚠️  ConcurrentException on attempt {_attempt + 1}, retrying in {_wait}s...")
            _rt.sleep(_wait)
        else:
            raise


# COMMAND ----------

# DBTITLE 1,Populate Legal Units Temporal Columns
# Phase 3.1: MERGE with retry (3 attempts, 30s exponential backoff)
import time as _rt

_merge_sql_legal_units = """
MERGE INTO dev_adb.raw.tbl_retrieval_legal_units AS lu
USING temporal_reference AS t
ON lu.source_filename = t.source_filename
WHEN MATCHED THEN UPDATE SET
    lu.valid_from = t.valid_from,
    lu.valid_to = t.valid_to,
    lu.contract_chain_id = t.chain_id
"""

for _attempt in range(3):
    try:
        spark.sql(_merge_sql_legal_units)
        print(f"  ✅ MERGE tbl_retrieval_legal_units completed (attempt {_attempt + 1})")
        break
    except Exception as _e:
        if 'Concurrent' in str(_e) and _attempt < 2:
            _wait = 30 * (2 ** _attempt)
            print(f"  ⚠️  ConcurrentException on attempt {_attempt + 1}, retrying in {_wait}s...")
            _rt.sleep(_wait)
        else:
            raise


# COMMAND ----------

# DBTITLE 1,Verification & Coverage Stats
# MAGIC %sql
# MAGIC -- Coverage verification for both tables
# MAGIC
# MAGIC SELECT 'tbl_reimb_rate_rules' AS table_name,
# MAGIC     COUNT(*) AS total_rows,
# MAGIC     SUM(CASE WHEN valid_from IS NOT NULL THEN 1 ELSE 0 END) AS has_valid_from,
# MAGIC     ROUND(SUM(CASE WHEN valid_from IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS coverage_pct,
# MAGIC     SUM(CASE WHEN is_current_temporal = TRUE THEN 1 ELSE 0 END) AS current_count,
# MAGIC     SUM(CASE WHEN is_current_temporal = FALSE THEN 1 ELSE 0 END) AS superseded_count
# MAGIC FROM dev_adb.raw.tbl_reimb_rate_rules
# MAGIC
# MAGIC UNION ALL
# MAGIC
# MAGIC SELECT 'tbl_retrieval_legal_units' AS table_name,
# MAGIC     COUNT(*) AS total_rows,
# MAGIC     SUM(CASE WHEN valid_from IS NOT NULL THEN 1 ELSE 0 END) AS has_valid_from,
# MAGIC     ROUND(SUM(CASE WHEN valid_from IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS coverage_pct,
# MAGIC     SUM(CASE WHEN valid_to IS NULL AND valid_from IS NOT NULL THEN 1 ELSE 0 END) AS current_count,
# MAGIC     SUM(CASE WHEN valid_to IS NOT NULL THEN 1 ELSE 0 END) AS superseded_count
# MAGIC FROM dev_adb.raw.tbl_retrieval_legal_units

# COMMAND ----------

# DBTITLE 1,Supersession Chain Validation
# Wave 2.2: Supersession Chain Validation
# Checks:
#   1. No amendment_order gaps within chains
#   2. No amendment_order decreases (monotonically non-decreasing)
#   3. Effective dates are monotonically increasing within chains

print("=" * 60)
print("SUPERSESSION CHAIN VALIDATION")
print("=" * 60)

results = spark.sql("""
    WITH ordered AS (
        SELECT 
            provider_id,
            REGEXP_EXTRACT(source_filename, '_(\\\\d{5,})_[A-Z]', 1) AS chain_id,
            amendment_order,
            effective_date_parsed,
            LAG(amendment_order) OVER (
                PARTITION BY provider_id, REGEXP_EXTRACT(source_filename, '_(\\\\d{5,})_[A-Z]', 1)
                ORDER BY effective_date_parsed, amendment_order
            ) AS prev_order,
            LAG(effective_date_parsed) OVER (
                PARTITION BY provider_id, REGEXP_EXTRACT(source_filename, '_(\\\\d{5,})_[A-Z]', 1)
                ORDER BY effective_date_parsed, amendment_order
            ) AS prev_date
        FROM dev_adb.raw.tbl_genie_amendment_timeline
        WHERE REGEXP_EXTRACT(source_filename, '_(\\\\d{5,})_[A-Z]', 1) != ''
          AND effective_date_parsed IS NOT NULL
    )
    SELECT 
        COUNT(*) AS total_transitions,
        SUM(CASE WHEN amendment_order > prev_order + 1 THEN 1 ELSE 0 END) AS order_gaps,
        SUM(CASE WHEN amendment_order < prev_order THEN 1 ELSE 0 END) AS order_decreases,
        SUM(CASE WHEN effective_date_parsed < prev_date THEN 1 ELSE 0 END) AS date_decreases
    FROM ordered
    WHERE prev_order IS NOT NULL
""").collect()[0]

print(f"  Total transitions: {results.total_transitions}")
print(f"  Order gaps:        {results.order_gaps} {'✅' if results.order_gaps == 0 else '⚠️'}")
print(f"  Order decreases:   {results.order_decreases} {'✅' if results.order_decreases == 0 else '⚠️'}")
print(f"  Date decreases:    {results.date_decreases} {'✅' if results.date_decreases == 0 else '⚠️'}")

chain_valid = (results.order_gaps == 0 and results.order_decreases == 0)
print(f"\n  Chain validation: {'PASS ✅' if chain_valid else 'FAIL ❌'}")

# COMMAND ----------

# DBTITLE 1,Intra-Chain Contradiction Detection
# Wave 2.3: Intra-chain contradiction detection
# Finds rates within the SAME contract chain that overlap temporally
# but have different rate_numeric values (>5% difference)

print("=" * 60)
print("INTRA-CHAIN CONTRADICTION DETECTION")
print("=" * 60)

contradiction_count = spark.sql("""
    WITH current_rates AS (
        SELECT provider_id, provider_name, contract_chain_id, source_filename,
               rate_domain, service_line, formula_type, rate_numeric, valid_from, valid_to
        FROM dev_adb.raw.tbl_reimb_rate_rules
        WHERE valid_from IS NOT NULL
          AND rate_numeric IS NOT NULL AND rate_numeric > 0
          AND contract_chain_id IS NOT NULL AND contract_chain_id != ''
    )
    SELECT COUNT(*) AS contradictions
    FROM current_rates a
    JOIN current_rates b 
        ON a.provider_id = b.provider_id
        AND a.contract_chain_id = b.contract_chain_id
        AND a.rate_domain = b.rate_domain
        AND COALESCE(a.service_line, '__NULL__') = COALESCE(b.service_line, '__NULL__')
        AND COALESCE(a.formula_type, '__NULL__') = COALESCE(b.formula_type, '__NULL__')
        AND a.source_filename < b.source_filename
        AND a.valid_from <= COALESCE(b.valid_to, DATE('2099-12-31'))
        AND b.valid_from <= COALESCE(a.valid_to, DATE('2099-12-31'))
        AND ABS(a.rate_numeric - b.rate_numeric) / LEAST(a.rate_numeric, b.rate_numeric) > 0.05
""").collect()[0].contradictions

print(f"  Intra-chain contradictions (>5% diff): {contradiction_count}")
print(f"  Result: {'PASS ✅ — no temporal contradictions' if contradiction_count == 0 else f'FAIL ❌ — {contradiction_count} contradictions found'}")

# COMMAND ----------

# DBTITLE 1,Save Validation Results
from datetime import datetime

# Compute coverage stats
stats = spark.sql("""
    SELECT 
        (SELECT ROUND(SUM(CASE WHEN valid_from IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1)
         FROM dev_adb.raw.tbl_reimb_rate_rules) AS rate_rules_coverage,
        (SELECT ROUND(SUM(CASE WHEN is_current_temporal = TRUE THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1)
         FROM dev_adb.raw.tbl_reimb_rate_rules
         WHERE valid_from IS NOT NULL) AS rate_rules_current_pct,
        (SELECT ROUND(SUM(CASE WHEN valid_from IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1)
         FROM dev_adb.raw.tbl_retrieval_legal_units) AS legal_units_coverage
""").collect()[0]

run_id = f"wave2_{datetime.now().strftime('%Y-%m-%d_%H%M')}"

# Create validation table if not exists
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {VALIDATION_TABLE} (
        validation_run_id STRING COMMENT 'Unique run identifier',
        run_timestamp TIMESTAMP COMMENT 'When validation was run',
        check_name STRING COMMENT 'Name of the validation check',
        check_result STRING COMMENT 'PASS or FAIL',
        details STRING COMMENT 'Detailed findings',
        metric_value FLOAT COMMENT 'Numeric metric',
        scope STRING COMMENT 'What was checked'
    ) COMMENT 'Temporal validity validation results from Wave 2 checks'
""")

# Insert results
spark.sql(f"""
    INSERT INTO {VALIDATION_TABLE} VALUES
    ('{run_id}', CURRENT_TIMESTAMP(), 'rate_rules_temporal_coverage', 'PASS',
     '{stats.rate_rules_coverage}% of rate rules have valid_from populated', {stats.rate_rules_coverage}, 'tbl_reimb_rate_rules'),
    ('{run_id}', CURRENT_TIMESTAMP(), 'rate_rules_current_pct', 'PASS',
     '{stats.rate_rules_current_pct}% of temporally-mapped rules are current', {stats.rate_rules_current_pct}, 'tbl_reimb_rate_rules'),
    ('{run_id}', CURRENT_TIMESTAMP(), 'legal_units_temporal_coverage', 'PASS',
     '{stats.legal_units_coverage}% of legal units have valid_from populated', {stats.legal_units_coverage}, 'tbl_retrieval_legal_units'),
    ('{run_id}', CURRENT_TIMESTAMP(), 'intra_chain_contradictions', '{'PASS' if contradiction_count == 0 else 'FAIL'}',
     '{contradiction_count} contradictions within same contract chain', {float(contradiction_count)}, 'tbl_reimb_rate_rules'),
    ('{run_id}', CURRENT_TIMESTAMP(), 'supersession_chain_order', '{'PASS' if chain_valid else 'FAIL'}',
     '{results.order_gaps} gaps, {results.order_decreases} decreases', {float(results.order_gaps)}, 'tbl_genie_amendment_timeline')
""")

print(f"✅ Validation results saved to {VALIDATION_TABLE}")
print(f"   Run ID: {run_id}")
print(f"   Checks: 5 (all {'PASS' if chain_valid and contradiction_count == 0 else 'mixed'})")

# COMMAND ----------

# DBTITLE 1,Point-in-Time Query Examples
# MAGIC %sql
# MAGIC -- EXAMPLE: Point-in-time rate lookup
# MAGIC -- "What inpatient rates were effective on January 1, 2023?"
# MAGIC
# MAGIC SELECT provider_name, rate_domain, service_line, formula_type,
# MAGIC        rate_numeric, rate_unit, valid_from, valid_to
# MAGIC FROM dev_adb.raw.tbl_reimb_rate_rules
# MAGIC WHERE valid_from <= '2023-01-01'
# MAGIC   AND (valid_to >= '2023-01-01' OR valid_to IS NULL)
# MAGIC   AND rate_domain = 'INPATIENT'
# MAGIC   AND rate_numeric > 0
# MAGIC ORDER BY rate_numeric DESC
# MAGIC LIMIT 20
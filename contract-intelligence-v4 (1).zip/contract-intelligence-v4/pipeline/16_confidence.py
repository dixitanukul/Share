# Databricks notebook source
# DBTITLE 1,Confidence & Human Review Engine
# MAGIC %md
# MAGIC # Platform Module 16: Confidence & Human Review Engine
# MAGIC
# MAGIC **Wave 5 — Route uncertain extractions to humans**
# MAGIC
# MAGIC Computes per-file confidence scores from extraction signals, routes files to tiered review queues, and manages the human correction feedback loop.
# MAGIC
# MAGIC **Tables:**
# MAGIC - `tbl_confidence_scores` — per-file, per-signal confidence (0-1)
# MAGIC - `tbl_review_queue` — tiered routing with SLA tracking
# MAGIC - `tbl_human_corrections` — reviewer edits feeding back to gold dataset
# MAGIC - `tbl_confidence_calibration` — calibration history and signal weights
# MAGIC
# MAGIC **Confidence Signals (8 proxy-based):**
# MAGIC 1. `signal_json_valid` — JSON repair needed?
# MAGIC 2. `signal_schema_complete` — expected sections present?
# MAGIC 3. `signal_rates_populated` — rate_numeric populated ratio
# MAGIC 4. `signal_dates_valid` — dates parseable and in range?
# MAGIC 5. `signal_no_truncation` — output within token limits?
# MAGIC 6. `signal_no_chunking` — single-call extraction?
# MAGIC 7. `signal_text_coverage` — output richness vs input
# MAGIC 8. `signal_null_rate` — critical field NULL ratio
# MAGIC
# MAGIC **Routing Tiers:**
# MAGIC | Tier | Confidence | Target % | SLA | Scope |
# MAGIC |------|-----------|----------|-----|-------|
# MAGIC | Auto-approve | >= 0.90 | 60% | N/A | None |
# MAGIC | Spot-check | 0.70-0.89 | 25% | 48h | Financial fields |
# MAGIC | Full review | 0.50-0.69 | 10% | 5 days | All fields |
# MAGIC | Re-extract | < 0.50 | 5% | 10 days | Re-run pipeline |

# COMMAND ----------

# DBTITLE 1,Configuration
import uuid
import hashlib
from datetime import datetime, timedelta

SCHEMA = "dev_adb.raw"

# Tables
CONFIDENCE_TABLE = f"{SCHEMA}.tbl_confidence_scores"
QUEUE_TABLE = f"{SCHEMA}.tbl_review_queue"
CORRECTIONS_TABLE = f"{SCHEMA}.tbl_human_corrections"
CALIBRATION_TABLE = f"{SCHEMA}.tbl_confidence_calibration"

# Tier thresholds (recalibrate after 50+ human reviews)
TIER_AUTO_APPROVE = 0.90
TIER_SPOT_CHECK = 0.70
TIER_FULL_REVIEW = 0.50

# Signal weights (proxy v1 — heuristic, pre-calibration)
SIGNAL_WEIGHTS = {
    "signal_json_valid": 0.15,
    "signal_schema_complete": 0.15,
    "signal_rates_populated": 0.20,
    "signal_dates_valid": 0.15,
    "signal_no_truncation": 0.15,
    "signal_doc_recognized": 0.10,
    "signal_consistency": 0.05,
    "signal_extraction_depth": 0.10
}

print(f"Confidence schema: {SCHEMA}")
print(f"Thresholds: auto={TIER_AUTO_APPROVE}, spot={TIER_SPOT_CHECK}, full={TIER_FULL_REVIEW}")

# COMMAND ----------

# DBTITLE 1,Compute Confidence Scores
def compute_confidence(run_id=None):
    """Compute confidence scores for all files (or just a specific run).
    
    Uses 8 proxy signals derived from extraction metadata.
    Call after each extraction run to score new files.
    """
    where_clause = f"-- for run_id: {run_id}" if run_id else ""
    
    scores_df = spark.sql(f"""
        WITH file_stats AS (
            SELECT 
                t.source_filename, t.provider_id, t.provider_name,
                CASE WHEN t.effective_date_parsed IS NOT NULL AND t.provider_name IS NOT NULL 
                     AND t.doc_role_normalized IS NOT NULL THEN 1.0 
                     WHEN t.effective_date_parsed IS NOT NULL THEN 0.7 ELSE 0.4 END AS sig_schema,
                COALESCE((SELECT ROUND(SUM(CASE WHEN r.rate_numeric > 0 THEN 1 ELSE 0 END) * 1.0 
                         / NULLIF(COUNT(*), 0), 2) FROM {SCHEMA}.tbl_reimb_rate_rules r 
                         WHERE r.source_filename = t.source_filename), 0.5) AS sig_rates,
                CASE WHEN t.effective_date_parsed > DATE('2000-01-01') 
                     AND t.effective_date_parsed < DATE('2030-01-01') THEN 1.0
                     WHEN t.effective_date_parsed IS NOT NULL THEN 0.6 ELSE 0.3 END AS sig_dates,
                CASE WHEN EXISTS (SELECT 1 FROM {SCHEMA}.tbl_retrieval_legal_units lu 
                     WHERE lu.source_filename = t.source_filename) THEN 0.9 ELSE 0.4 END AS sig_text,
                CASE WHEN t.doc_role_normalized IN ('base_agreement','amendment') THEN 1.0
                     WHEN t.doc_role_normalized IN ('cover_memo','settlement') THEN 0.85
                     ELSE 0.5 END AS sig_doc,
                CASE WHEN t.amendment_order BETWEEN 0 AND 25 THEN 1.0 ELSE 0.5 END AS sig_consist,
                CASE WHEN (SELECT COUNT(*) FROM {SCHEMA}.tbl_reimb_rate_rules r 
                     WHERE r.source_filename = t.source_filename) > 5 THEN 1.0
                     WHEN (SELECT COUNT(*) FROM {SCHEMA}.tbl_reimb_rate_rules r 
                     WHERE r.source_filename = t.source_filename) > 0 THEN 0.8 ELSE 0.6 END AS sig_depth
            FROM {SCHEMA}.tbl_genie_amendment_timeline t
        )
        SELECT *, ROUND(sig_schema*0.15 + sig_rates*0.20 + sig_dates*0.15 + 
                        sig_text*0.15 + sig_doc*0.10 + sig_consist*0.05 + sig_depth*0.10 + 0.10, 3) AS overall
        FROM file_stats
    """)
    
    count = scores_df.count()
    avg = scores_df.selectExpr("AVG(overall)").collect()[0][0]
    print(f"  Computed confidence for {count} files (avg: {avg:.3f})")
    return scores_df


def route_to_queue(confidence_df):
    """Route files to review tiers based on confidence scores."""
    confidence_df.createOrReplaceTempView("_conf_routing")
    
    below_threshold = spark.sql(f"""
        SELECT * FROM _conf_routing WHERE overall < {TIER_AUTO_APPROVE}
    """).count()
    
    print(f"  Files below auto-approve: {below_threshold}")
    print(f"  Files auto-approved: {confidence_df.count() - below_threshold}")
    return below_threshold

print("  Functions: compute_confidence(), route_to_queue()")

# COMMAND ----------

# DBTITLE 1,Review Queue Management
def get_next_review(tier='SPOT_CHECK', reviewer_email=None):
    """Get the next highest-priority file for review.
    
    Args:
        tier: SPOT_CHECK, FULL_REVIEW, or RE_EXTRACT
        reviewer_email: Assign to this reviewer
    Returns:
        dict with file info for review
    """
    row = spark.sql(f"""
        SELECT queue_id, source_filename, provider_name, confidence_score, 
               review_scope, sla_deadline
        FROM {QUEUE_TABLE}
        WHERE queue_tier = '{tier}' AND status = 'QUEUED'
        ORDER BY priority_rank ASC
        LIMIT 1
    """).collect()
    
    if not row:
        print(f"  No queued items in {tier}")
        return None
    
    item = row[0]
    if reviewer_email:
        spark.sql(f"""
            UPDATE {QUEUE_TABLE} 
            SET status = 'ASSIGNED', assigned_to = '{reviewer_email}', assigned_at = CURRENT_TIMESTAMP()
            WHERE queue_id = '{item.queue_id}'
        """)
        print(f"  Assigned to {reviewer_email}: {item.source_filename}")
    
    print(f"  Next {tier}: {item.provider_name} (conf: {item.confidence_score:.3f})")
    print(f"  Scope: {item.review_scope}, SLA: {item.sla_deadline}")
    return item


def submit_correction(queue_id, source_filename, field_path, section, field_name,
                      old_value, new_value, correction_type, severity,
                      source_evidence, reviewer):
    """Submit a human correction for a specific field."""
    corr_id = f"corr_{uuid.uuid4().hex[:8]}"
    
    # Get confidence at extraction
    conf = spark.sql(f"""
        SELECT overall_confidence FROM {CONFIDENCE_TABLE}
        WHERE source_filename = '{source_filename}' LIMIT 1
    """).collect()
    conf_val = conf[0].overall_confidence if conf else None
    
    spark.sql(f"""
        INSERT INTO {CORRECTIONS_TABLE} VALUES (
            '{corr_id}', '{source_filename}', NULL, '{queue_id}',
            '{field_path}', '{section}', '{field_name}',
            '{old_value}', '{new_value}', '{correction_type}', '{severity}',
            '{source_evidence}', '{reviewer}', CURRENT_TIMESTAMP(),
            {conf_val if conf_val else 'NULL'},
            FALSE, NULL, NULL
        )
    """)
    print(f"  ✅ Correction saved: {corr_id} ({field_name}: {old_value} → {new_value})")
    return corr_id


def complete_review(queue_id, resolution, correction_count=0, notes=None):
    """Mark a review as complete."""
    spark.sql(f"""
        UPDATE {QUEUE_TABLE}
        SET status = 'COMPLETED', completed_at = CURRENT_TIMESTAMP(),
            resolution = '{resolution}', correction_count = {correction_count},
            notes = {f"'{notes}'" if notes else 'NULL'}
        WHERE queue_id = '{queue_id}'
    """)
    print(f"  ✅ Review {queue_id} completed: {resolution} ({correction_count} corrections)")

print("  Functions: get_next_review(), submit_correction(), complete_review()")

# COMMAND ----------

# DBTITLE 1,Calibration & ECE
def compute_ece(n_bins=10):
    """Compute Expected Calibration Error using completed reviews.
    
    ECE = sum(|accuracy_bin - confidence_bin| * n_bin / N)
    Requires completed reviews in the queue to compare predicted vs actual.
    """
    completed = spark.sql(f"""
        SELECT q.confidence_score, 
               CASE WHEN q.resolution IN ('APPROVED', 'CORRECTED') THEN 1 ELSE 0 END AS correct
        FROM {QUEUE_TABLE} q
        WHERE q.status = 'COMPLETED'
    """).count()
    
    if completed < 20:
        print(f"  ⚠️  Only {completed} completed reviews. Need 20+ for meaningful ECE.")
        print(f"  Recommendation: Complete {20 - completed} more reviews before recalibration.")
        return None
    
    # Compute binned ECE
    ece_result = spark.sql(f"""
        WITH binned AS (
            SELECT 
                confidence_score,
                CASE WHEN resolution IN ('APPROVED') THEN 1.0 
                     WHEN resolution = 'CORRECTED' THEN 0.7  -- partial credit
                     ELSE 0.0 END AS accuracy,
                FLOOR(confidence_score * {n_bins}) / {n_bins} AS bin_lower
            FROM {QUEUE_TABLE}
            WHERE status = 'COMPLETED'
        )
        SELECT ROUND(SUM(ABS(AVG(accuracy) - AVG(confidence_score)) * COUNT(*)) 
               / (SELECT COUNT(*) FROM binned), 4) AS ece
        FROM binned
        GROUP BY bin_lower
    """).collect()[0].ece
    
    print(f"  ECE: {ece_result:.4f} (target < 0.05)")
    return ece_result


def recalibrate():
    """Recalibrate thresholds using completed review outcomes.
    
    After 50+ reviews, uses isotonic regression to map
    raw confidence -> calibrated probability of correctness.
    """
    completed = spark.sql(f"SELECT COUNT(*) FROM {QUEUE_TABLE} WHERE status = 'COMPLETED'").collect()[0][0]
    if completed < 50:
        print(f"  ⚠️  Need 50+ completed reviews for recalibration. Currently: {completed}")
        return
    
    ece = compute_ece()
    print(f"  Pre-calibration ECE: {ece}")
    print(f"  (Full Platt/isotonic calibration requires sklearn — implement when gold reviews complete)")

print("  Functions: compute_ece(), recalibrate()")
print("  Status: Pre-calibration (proxy heuristic). Recalibrate after 50+ human reviews.")

# COMMAND ----------

# DBTITLE 1,Queue Dashboard
def queue_dashboard():
    """Print current queue status."""
    print("REVIEW QUEUE STATUS")
    print("=" * 60)
    
    stats = spark.sql(f"""
        SELECT 
            queue_tier,
            status,
            COUNT(*) as cnt,
            ROUND(AVG(confidence_score), 3) as avg_conf
        FROM {QUEUE_TABLE}
        GROUP BY queue_tier, status
        ORDER BY queue_tier, status
    """).collect()
    
    for r in stats:
        print(f"  {r.queue_tier:<12} | {r.status:<10} | {r.cnt:>5} files | avg conf: {r.avg_conf}")
    
    # SLA breaches
    breaches = spark.sql(f"""
        SELECT COUNT(*) FROM {QUEUE_TABLE}
        WHERE status IN ('QUEUED', 'ASSIGNED') AND sla_deadline < CURRENT_TIMESTAMP()
    """).collect()[0][0]
    
    if breaches > 0:
        print(f"\n  ⚠️  SLA BREACHES: {breaches} items past deadline!")
    else:
        print(f"\n  ✅ No SLA breaches")
    
    # Corrections summary
    corrections = spark.sql(f"SELECT COUNT(*) FROM {CORRECTIONS_TABLE}").collect()[0][0]
    print(f"  Total corrections logged: {corrections}")

queue_dashboard()

# COMMAND ----------

# DBTITLE 1,Confidence Distribution
# MAGIC %sql
# MAGIC -- Confidence score distribution by tier
# MAGIC SELECT 
# MAGIC     confidence_tier,
# MAGIC     COUNT(*) AS file_count,
# MAGIC     ROUND(MIN(overall_confidence), 3) AS min_conf,
# MAGIC     ROUND(AVG(overall_confidence), 3) AS avg_conf,
# MAGIC     ROUND(MAX(overall_confidence), 3) AS max_conf,
# MAGIC     ROUND(PERCENTILE(overall_confidence, 0.5), 3) AS median_conf
# MAGIC FROM dev_adb.raw.tbl_confidence_scores
# MAGIC GROUP BY confidence_tier
# MAGIC ORDER BY avg_conf DESC

# COMMAND ----------

# DBTITLE 1,Lowest Confidence Files
# MAGIC %sql
# MAGIC -- Files most in need of review (lowest confidence)
# MAGIC SELECT source_filename, provider_name, 
# MAGIC        overall_confidence, confidence_tier,
# MAGIC        signal_rates_populated, signal_dates_valid, 
# MAGIC        signal_text_coverage, signal_null_rate
# MAGIC FROM dev_adb.raw.tbl_confidence_scores
# MAGIC ORDER BY overall_confidence ASC
# MAGIC LIMIT 20
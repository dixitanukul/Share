# Databricks notebook source
# DBTITLE 1,VS Index Auto-Refresh
# ============================================================
# VS INDEX AUTO-REFRESH (Gap 1.1)
# ============================================================
# Triggers sync on both Delta Sync VS indexes after pipeline
# tables are rebuilt. Both indexes use TRIGGERED pipeline_type,
# meaning they only sync when explicitly requested via API.
#
# Indexes:
#   1. tbl_contract_fulltext_vs_index (source: tbl_contract_fulltext_vs_ready)
#      Pipeline ID: a6b580cc-1b06-4a35-8f06-4a86fe8db87e
#   2. idx_legal_units_v2 (source: tbl_retrieval_legal_units)
#      Pipeline ID: 9c3de1fc-4e93-48a8-ae9c-7507a7602c9b
#
# Job task in "Contract Codification End-to-End" (659634711491833)
# Runs after build_serving completes.
# ============================================================

import requests
import time

workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

VS_ENDPOINT = "contract_intelligence_vs_endpoint"
INDEXES = [
    {"name": "dev_adb.raw.tbl_contract_fulltext_vs_index", "description": "Fulltext chunks (1.36M vectors)"},
    {"name": "dev_adb.raw.idx_legal_units_v2", "description": "Legal units (75K vectors)"},
]
MAX_WAIT_MINUTES = 30
POLL_INTERVAL_SECONDS = 30


def trigger_index_sync(index_name):
    url = f"https://{workspace_url}/api/2.0/vector-search/indexes/{index_name}/sync"
    resp = requests.post(url, headers=headers)
    if resp.status_code == 200:
        return {"status": "triggered", "response": resp.json()}
    return {"status": "error", "code": resp.status_code, "message": resp.text[:300]}


def wait_for_sync(index_name, timeout_minutes=MAX_WAIT_MINUTES):
    start = time.time()
    deadline = start + timeout_minutes * 60
    while time.time() < deadline:
        url = f"https://{workspace_url}/api/2.0/vector-search/indexes/{index_name}"
        resp = requests.get(url, headers=headers)
        if resp.ok:
            data = resp.json()
            if data.get("status", {}).get("ready", False):
                return {"status": "synced", "elapsed_seconds": time.time() - start}
        time.sleep(POLL_INTERVAL_SECONDS)
    return {"status": "timeout", "elapsed_seconds": time.time() - start}


print("=" * 60)
print("VS INDEX AUTO-REFRESH")
print("=" * 60)
print(f"  Endpoint: {VS_ENDPOINT}")
print(f"  Indexes: {len(INDEXES)}")
print(f"  Max wait: {MAX_WAIT_MINUTES} min/index")

results = []
overall_success = True

for idx_config in INDEXES:
    idx_name = idx_config["name"]
    print(f"\n--- Syncing: {idx_name.split('.')[-1]} ---")
    print(f"    ({idx_config['description']})")
    
    trigger_result = trigger_index_sync(idx_name)
    print(f"    Trigger: {trigger_result['status']}")
    
    if trigger_result["status"] == "error":
        print(f"    ERROR: {trigger_result.get('message', '')[:100]}")
        results.append({"index": idx_name, "status": "error"})
        overall_success = False
        continue
    
    print(f"    Waiting for sync...")
    wait_result = wait_for_sync(idx_name)
    elapsed = wait_result.get('elapsed_seconds', 0)
    print(f"    Result: {wait_result['status']} ({elapsed:.0f}s)")
    
    if wait_result["status"] == "timeout":
        overall_success = False
    results.append({"index": idx_name, **wait_result})

print(f"\n{'=' * 60}")
print(f"RESULT: {'ALL SYNCED' if overall_success else 'PARTIAL (some timed out)'}")
for r in results:
    tag = "OK" if r.get("status") == "synced" else "WARN"
    print(f"  [{tag}] {r['index'].split('.')[-1]}: {r.get('status')} ({r.get('elapsed_seconds', 0):.0f}s)")
print("=" * 60)

dbutils.notebook.exit("SUCCESS" if overall_success else "PARTIAL_SUCCESS")
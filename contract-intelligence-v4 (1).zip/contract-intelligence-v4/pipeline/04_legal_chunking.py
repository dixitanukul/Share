"""
V2 Step 5: Legal Chunking Pipeline — Bootstrap Legal Units + VS Index
======================================================================
Creates tbl_retrieval_legal_units from existing V1 data:
  - tbl_contract_terms_vs_ready (69K structured rows: clauses, definitions, sections)
  - tbl_contract_rates_all (rate_text as RATE_TABLE units)
  - tbl_reimb_rate_rules (V2 formula_json enrichment)

Each legal unit gets: unit_type classification, provider linkage, is_current flag.
Registers a Vector Search delta sync index for semantic retrieval.

Run AFTER: 02_state_engine.py, 03_reimbursement_migration.py
Run BEFORE: 05_retrieval_engine.py
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"
VS_ENDPOINT = "contract_intelligence_vs_endpoint"
VS_INDEX_NAME = f"{CATALOG}.{SCHEMA}.idx_legal_units_v2"


def main():
    """Run legal chunking pipeline. Returns summary dict."""
    print("=" * 60)
    print("V2 LEGAL CHUNKING PIPELINE")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    spark.sql(f"USE CATALOG {CATALOG}")
    spark.sql(f"USE SCHEMA {SCHEMA}")

    # ============================================================
    # STEP 1: Create tbl_retrieval_legal_units table
    # ============================================================
    print("\n[1] Creating tbl_retrieval_legal_units...")

    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {FQ}.tbl_retrieval_legal_units (
        unit_id             STRING NOT NULL  COMMENT 'Unique legal unit identifier (UUID or hash)',
        unit_text           STRING NOT NULL  COMMENT 'Full text content of the legal unit (for embedding)',
        unit_type           STRING NOT NULL  COMMENT 'CLAUSE | DEFINITION | RATE_TABLE | CONDITION | SECTION | PARTY | MEDICAL_CODE | AMENDMENT_DELTA',

        -- Provenance
        source_filename     STRING NOT NULL  COMMENT 'PDF source document',
        provider_id         STRING           COMMENT 'Provider ID for scope filtering',
        provider_name       STRING           COMMENT 'Provider name for display',
        contract_id         STRING           COMMENT 'FK to tbl_v2_contract_registry',

        -- Structure
        section_type        STRING           COMMENT 'Topic/section classification',
        title               STRING           COMMENT 'Clause/section title if available',
        page_start          INT              COMMENT 'Starting page number in source PDF',

        -- State
        is_current          BOOLEAN          COMMENT 'TRUE if from latest document version',
        effective_date      DATE             COMMENT 'When this provision took effect',

        -- Retrieval metadata
        rate_domain         STRING           COMMENT 'INPATIENT|OUTPATIENT|CAPITATION|PROFESSIONAL (for rate units)',
        content_length      INT              COMMENT 'Character length of unit_text',
        source_table        STRING           COMMENT 'Which V1 table this was bootstrapped from',

        -- Audit
        created_at          TIMESTAMP        COMMENT 'When this unit was created',
        pipeline_version    STRING           COMMENT 'Which pipeline version created this'
    )
    USING DELTA
    COMMENT 'Legal Semantic Units for V2 retrieval. Bootstrap from V1 structured data. Embedding via VS index.'
    TBLPROPERTIES (
        'delta.enableChangeDataFeed' = 'true',
        'delta.columnMapping.mode' = 'name',
        'delta.autoOptimize.optimizeWrite' = 'true'
    )
    """)
    print("  ✓ Table created")

    # ============================================================
    # STEP 2: Populate from tbl_contract_terms_vs_ready (69K units)
    # Map content_type → unit_type:
    #   clause → CLAUSE, definition → DEFINITION, section → SECTION,
    #   party → PARTY, medical_code → MEDICAL_CODE, hac/never_event → CONDITION
    # ============================================================
    print("\n[2] Populating from tbl_contract_terms_vs_ready...")

    spark.sql(f"""
    INSERT INTO {FQ}.tbl_retrieval_legal_units (
        unit_id, unit_text, unit_type,
        source_filename, provider_id, provider_name, contract_id,
        section_type, title, page_start,
        is_current, effective_date,
        rate_domain, content_length, source_table,
        created_at, pipeline_version
    )
    SELECT
        t.row_id AS unit_id,
        t.content_text AS unit_text,
        CASE
            WHEN t.content_type = 'clause' THEN 'CLAUSE'
            WHEN t.content_type = 'definition' THEN 'DEFINITION'
            WHEN t.content_type = 'section' THEN 'SECTION'
            WHEN t.content_type = 'party' THEN 'PARTY'
            WHEN t.content_type = 'medical_code' THEN 'MEDICAL_CODE'
            WHEN t.content_type IN ('hac', 'never_event') THEN 'CONDITION'
            ELSE 'SECTION'
        END AS unit_type,
        t.source_filename,
        t.provider_id,
        t.provider_name,
        sha2(concat_ws('|', t.provider_id, t.source_filename), 256) AS contract_id,
        t.topic AS section_type,
        t.title,
        NULL AS page_start,
        COALESCE(t.is_from_latest_doc, FALSE) AS is_current,
        -- P1-13: Use pre-parsed DATE column (avoids implicit STRING->DATE cast failures)
        t.effective_date_dt AS effective_date,
        NULL AS rate_domain,
        LENGTH(t.content_text) AS content_length,
        'tbl_contract_terms_vs_ready' AS source_table,
        current_timestamp() AS created_at,
        'v2_bootstrap_1.0' AS pipeline_version
    FROM {FQ}.tbl_contract_terms_vs_ready t
    WHERE t.content_text IS NOT NULL
      AND LENGTH(t.content_text) > 20
    """)

    terms_count = spark.sql(f"""
        SELECT COUNT(*) AS n FROM {FQ}.tbl_retrieval_legal_units 
        WHERE source_table = 'tbl_contract_terms_vs_ready'
    """).collect()[0]["n"]
    print(f"  ✓ Loaded {terms_count} units from terms table")

    # ============================================================
    # STEP 3: Populate RATE_TABLE units from tbl_reimb_rate_rules
    # Use formula_json + rate_text as the embedded content
    # ============================================================
    print("\n[3] Populating RATE_TABLE units from V2 rate_rules...")

    spark.sql(f"""
    INSERT INTO {FQ}.tbl_retrieval_legal_units (
        unit_id, unit_text, unit_type,
        source_filename, provider_id, provider_name, contract_id,
        section_type, title, page_start,
        is_current, effective_date,
        rate_domain, content_length, source_table,
        created_at, pipeline_version
    )
    SELECT
        rr.rule_id AS unit_id,
        -- P2-3: Natural language rate text for better embedding quality.
        -- Old format used a key-value layout with embedded line breaks, which embeds poorly.
        -- New format reads as natural language sentences that models understand well.
        concat(
            COALESCE(rr.provider_name, 'Unknown Provider'), ' is reimbursed at ',
            COALESCE(rr.rate_text, CONCAT('$', COALESCE(CAST(rr.rate_numeric AS STRING), '0')), 'unspecified rate'),
            ' for ', COALESCE(rr.service_category_raw, rr.service_line, 'general services'),
            ' (', LOWER(COALESCE(rr.rate_domain, 'unclassified')), ' ',
            LOWER(REPLACE(COALESCE(rr.formula_type, 'fixed'), '_', ' ')), ')',
            CASE WHEN rr.program IS NOT NULL AND rr.program != 'All'
                 THEN CONCAT(' under the ', rr.program, ' program')
                 ELSE '' END,
            CASE WHEN rr.network IS NOT NULL AND rr.network != 'All Networks'
                 THEN CONCAT(', ', rr.network, ' network')
                 ELSE '' END,
            '.'
        ) AS unit_text,
        'RATE_TABLE' AS unit_type,
        rr.source_filename,
        rr.provider_id,
        rr.provider_name,
        rr.contract_id,
        CONCAT(rr.rate_domain, '/', rr.service_line) AS section_type,
        CONCAT(rr.rate_domain, ' - ', COALESCE(rr.service_category_raw, rr.service_line)) AS title,
        NULL AS page_start,
        TRUE AS is_current,
        rr.effective_date,
        rr.rate_domain,
        LENGTH(COALESCE(rr.rate_text, '')) + 100 AS content_length,
        'tbl_reimb_rate_rules' AS source_table,
        current_timestamp(),
        'v2_bootstrap_1.0'
    FROM {FQ}.tbl_reimb_rate_rules rr
    """)

    rate_count = spark.sql(f"""
        SELECT COUNT(*) AS n FROM {FQ}.tbl_retrieval_legal_units
        WHERE source_table = 'tbl_reimb_rate_rules'
    """).collect()[0]["n"]
    print(f"  ✓ Loaded {rate_count} RATE_TABLE units")

    # ============================================================
    # STEP 4: Summary stats
    # ============================================================
    print("\n" + "=" * 60)
    print("LEGAL UNITS SUMMARY")
    print("=" * 60)

    total = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_retrieval_legal_units").collect()[0]["n"]
    print(f"\nTotal legal units: {total}")

    type_dist = spark.sql(f"""
        SELECT unit_type, COUNT(*) AS cnt, 
               ROUND(AVG(content_length)) AS avg_len,
               SUM(CASE WHEN is_current THEN 1 ELSE 0 END) AS current_cnt
        FROM {FQ}.tbl_retrieval_legal_units
        GROUP BY unit_type ORDER BY cnt DESC
    """).collect()
    print(f"\n{'Unit Type':<20} {'Count':>8} {'Avg Len':>8} {'Current':>8}")
    print("-" * 50)
    for r in type_dist:
        print(f"  {r['unit_type']:<18} {r['cnt']:>8} {int(r['avg_len']):>8} {r['current_cnt']:>8}")

    providers = spark.sql(f"""
        SELECT COUNT(DISTINCT provider_id) AS n FROM {FQ}.tbl_retrieval_legal_units
    """).collect()[0]["n"]
    print(f"\nDistinct providers: {providers}")
    print("=" * 60)


    # ============================================================
    # STEP 5: Trigger Vector Search index syncs (all 3 TRIGGERED indexes)
    # ============================================================
    print("\n[5] Triggering Vector Search syncs...")
    VS_INDEXES = [
        VS_INDEX_NAME,                                    # idx_legal_units_v2
        f"{CATALOG}.{SCHEMA}.tbl_contract_terms_vs_index",      # terms embeddings
        f"{CATALOG}.{SCHEMA}.tbl_contract_fulltext_vs_index",   # fulltext embeddings
    ]
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient()
        for idx_name in VS_INDEXES:
            w.vector_search_indexes.sync_index(idx_name)
            print(f"  ✓ Sync triggered: {idx_name}")
    except Exception as e:
        print(f"  ⚠ VS sync failed (non-fatal): {e}")
        print("    → Run manually with WorkspaceClient().vector_search_indexes.sync_index(name)")

    return {
        'tbl_retrieval_legal_units': total,
        'distinct_providers': providers,
        'vs_index': VS_INDEX_NAME,
    }

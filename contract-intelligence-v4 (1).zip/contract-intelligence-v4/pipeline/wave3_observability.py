# Databricks notebook source
# DBTITLE 1,Wave 3 — Observability
# MAGIC %md
# MAGIC # Wave 3 — Observability
# MAGIC
# MAGIC **Backlog Items**: W3-1 through W3-7  
# MAGIC **Dependencies**: W0-1 (DONE), W1-3 (extraction lineage — W3-1/W3-2 tables created now, write-hooks added later)  
# MAGIC **Purpose**: Full operational telemetry — extraction costs, retrieval latency, freshness, null drift, alerting
# MAGIC
# MAGIC | Item | Title | Effort |
# MAGIC |------|-------|--------|
# MAGIC | W3-1 | Extraction run metrics table | M |
# MAGIC | W3-2 | Per-file extraction metrics | M |
# MAGIC | W3-3 | Retrieval telemetry | M |
# MAGIC | W3-4 | Freshness monitoring | S |
# MAGIC | W3-5 | Null-rate monitoring | M |
# MAGIC | W3-6 | Drift detection stub | L |
# MAGIC | W3-7 | Alert policies doc | S |

# COMMAND ----------

# DBTITLE 1,Config
CATALOG = "dev_adb"
SCHEMA = "raw"
MONITORING_SCHEMA = "raw"  # Could be separate schema in prod

# COMMAND ----------

# DBTITLE 1,W3-1: Create fact_extraction_run
# MAGIC %sql
# MAGIC -- W3-1: Extraction Run Metrics
# MAGIC -- One row per pipeline execution batch
# MAGIC CREATE TABLE IF NOT EXISTS dev_adb.raw.fact_extraction_run (
# MAGIC     run_id STRING NOT NULL COMMENT 'Unique run identifier (UUID)',
# MAGIC     started_at TIMESTAMP NOT NULL COMMENT 'When extraction batch started',
# MAGIC     completed_at TIMESTAMP COMMENT 'When batch finished (NULL if in-progress)',
# MAGIC     duration_seconds DOUBLE COMMENT 'Total wall-clock seconds',
# MAGIC     file_count INT NOT NULL COMMENT 'Number of files attempted',
# MAGIC     success_count INT COMMENT 'Files successfully extracted',
# MAGIC     failure_count INT COMMENT 'Files that errored',
# MAGIC     skip_count INT COMMENT 'Files skipped (already processed)',
# MAGIC     total_input_tokens BIGINT COMMENT 'Sum of input tokens across all LLM calls',
# MAGIC     total_output_tokens BIGINT COMMENT 'Sum of output tokens',
# MAGIC     total_cost_usd DOUBLE COMMENT 'Estimated cost (input*rate + output*rate)',
# MAGIC     model_name STRING COMMENT 'LLM model used (e.g. databricks-claude-sonnet-4-5)',
# MAGIC     prompt_version STRING COMMENT 'Hash or version of extraction prompt',
# MAGIC     config_hash STRING COMMENT 'Hash of full extraction config for reproducibility',
# MAGIC     chunked_file_count INT COMMENT 'Files that required chunking (>150K chars)',
# MAGIC     repair_count INT COMMENT 'Files that needed JSON repair',
# MAGIC     pipeline_version STRING COMMENT 'Code version tag',
# MAGIC     notes STRING COMMENT 'Optional run notes'
# MAGIC )
# MAGIC USING DELTA
# MAGIC COMMENT 'W3-1: One row per extraction pipeline run. Populated by extraction/05_llm_extraction.';
# MAGIC
# MAGIC SELECT 'fact_extraction_run created' AS status, COUNT(*) AS existing_rows FROM dev_adb.raw.fact_extraction_run

# COMMAND ----------

# DBTITLE 1,W3-2: Create fact_file_extraction
# MAGIC %sql
# MAGIC -- W3-2: Per-File Extraction Metrics
# MAGIC -- One row per file per run
# MAGIC CREATE TABLE IF NOT EXISTS dev_adb.raw.fact_file_extraction (
# MAGIC     run_id STRING NOT NULL COMMENT 'FK to fact_extraction_run.run_id',
# MAGIC     source_filename STRING NOT NULL COMMENT 'PDF filename processed',
# MAGIC     provider_id STRING COMMENT 'Provider ID from filename',
# MAGIC     document_type STRING COMMENT 'Detected doc type (BaseAgmtRenew, Amendment, etc.)',
# MAGIC     started_at TIMESTAMP COMMENT 'When this file extraction started',
# MAGIC     completed_at TIMESTAMP COMMENT 'When finished',
# MAGIC     latency_seconds DOUBLE COMMENT 'Wall-clock time for this file',
# MAGIC     input_chars INT COMMENT 'Character count of OCR text sent to LLM',
# MAGIC     input_tokens INT COMMENT 'Token count of input',
# MAGIC     output_tokens INT COMMENT 'Token count of LLM response',
# MAGIC     estimated_cost_usd DOUBLE COMMENT 'Per-file cost estimate',
# MAGIC     was_chunked BOOLEAN COMMENT 'TRUE if file was split into chunks',
# MAGIC     chunk_count INT COMMENT 'Number of chunks (1 if not chunked)',
# MAGIC     repair_strategy STRING COMMENT 'JSON repair applied: none, bracket_close, regex_fix',
# MAGIC     extraction_status STRING NOT NULL COMMENT 'success, error, timeout, skipped',
# MAGIC     error_message STRING COMMENT 'Error details if failed',
# MAGIC     output_sections INT COMMENT 'Number of top-level JSON sections extracted',
# MAGIC     rate_count INT COMMENT 'Number of rate entries extracted',
# MAGIC     clause_count INT COMMENT 'Number of clauses extracted',
# MAGIC     grounding_score DOUBLE COMMENT 'Post-extraction grounding verification score (0-1)',
# MAGIC     confidence_score DOUBLE COMMENT 'LLM self-reported confidence (0-1)'
# MAGIC )
# MAGIC USING DELTA
# MAGIC COMMENT 'W3-2: Per-file extraction telemetry. One row per PDF per run.';
# MAGIC
# MAGIC SELECT 'fact_file_extraction created' AS status, COUNT(*) AS existing_rows FROM dev_adb.raw.fact_file_extraction

# COMMAND ----------

# DBTITLE 1,W3-3: Create fact_retrieval_telemetry
# MAGIC %sql
# MAGIC -- W3-3: Retrieval Telemetry
# MAGIC -- One row per retrieval query executed
# MAGIC CREATE TABLE IF NOT EXISTS dev_adb.raw.fact_retrieval_telemetry (
# MAGIC     query_id STRING NOT NULL COMMENT 'Unique query identifier (UUID)',
# MAGIC     query_timestamp TIMESTAMP NOT NULL COMMENT 'When query was executed',
# MAGIC     query_text STRING COMMENT 'The natural language question',
# MAGIC     route STRING COMMENT 'Pipeline route used (clause_existence, rate_query, etc.)',
# MAGIC     provider_filter STRING COMMENT 'Provider(s) targeted, if any',
# MAGIC     -- Latency breakdown
# MAGIC     total_latency_ms INT COMMENT 'End-to-end query time in milliseconds',
# MAGIC     routing_latency_ms INT COMMENT 'Time for route_question()',
# MAGIC     retrieval_latency_ms INT COMMENT 'Time for vector/SQL retrieval',
# MAGIC     reranking_latency_ms INT COMMENT 'Time for reranking step',
# MAGIC     llm_latency_ms INT COMMENT 'Time for LLM synthesis/classification',
# MAGIC     -- Result quality
# MAGIC     result_count INT COMMENT 'Number of results returned',
# MAGIC     empty_result BOOLEAN COMMENT 'TRUE if no results found',
# MAGIC     temporal_precision DOUBLE COMMENT 'Fraction of results from current-effective docs (0-1)',
# MAGIC     retrieval_channels_used STRING COMMENT 'Comma-separated: vs,sql,fulltext,keyword',
# MAGIC     -- Resource usage
# MAGIC     tokens_used INT COMMENT 'Total LLM tokens consumed',
# MAGIC     source STRING DEFAULT 'notebook' COMMENT 'Origin: notebook, genie, api',
# MAGIC     user_id STRING COMMENT 'Who ran the query'
# MAGIC )
# MAGIC USING DELTA
# MAGIC COMMENT 'W3-3: Query-level retrieval telemetry for latency and quality monitoring.';
# MAGIC
# MAGIC SELECT 'fact_retrieval_telemetry created' AS status, COUNT(*) AS existing_rows FROM dev_adb.raw.fact_retrieval_telemetry

# COMMAND ----------

# DBTITLE 1,W3-4: Freshness Monitoring
# W3-4: Freshness Monitoring
# Checks when key tables were last modified and flags stale ones

from datetime import datetime, timedelta
import pandas as pd

# Define freshness thresholds (days)
FRESHNESS_CONFIG = {
    'tbl_reimb_rate_rules': 30,
    'tbl_retrieval_legal_units': 30,
    'tbl_genie_provider_profile': 14,
    'tbl_genie_amendment_timeline': 30,
    'tbl_v2_contract_registry': 30,
    'tbl_intel_benchmark_results': 14,
    'tbl_intel_renewal_priority': 7,
    'tbl_serving_rate_card': 14,
    'tbl_serving_provider_summary': 14,
    'vw_genie_contract_terms': 30,
}

results = []
for tbl, threshold_days in FRESHNESS_CONFIG.items():
    try:
        hist = spark.sql(f"DESCRIBE HISTORY {CATALOG}.{SCHEMA}.{tbl} LIMIT 1").toPandas()
        if not hist.empty:
            last_modified = pd.Timestamp(hist['timestamp'].iloc[0])
            age_days = (pd.Timestamp.now() - last_modified).days
            status = 'FRESH' if age_days <= threshold_days else 'STALE'
            results.append({
                'table': tbl,
                'last_modified': last_modified.strftime('%Y-%m-%d %H:%M'),
                'age_days': age_days,
                'threshold': threshold_days,
                'status': status
            })
        else:
            results.append({'table': tbl, 'last_modified': 'UNKNOWN', 'age_days': -1, 'threshold': threshold_days, 'status': 'ERROR'})
    except Exception as e:
        # Views don't have HISTORY — check via metadata
        results.append({'table': tbl, 'last_modified': 'N/A (view)', 'age_days': 0, 'threshold': threshold_days, 'status': 'VIEW'})

df_fresh = pd.DataFrame(results)
stale_count = len(df_fresh[df_fresh['status'] == 'STALE'])

print(f"{'='*65}")
print(f"  FRESHNESS MONITOR — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
print(f"{'='*65}")
print(f"  Tables monitored: {len(df_fresh)}")
print(f"  Fresh: {len(df_fresh[df_fresh['status']=='FRESH'])}")
print(f"  Stale: {stale_count}")
print(f"  Views: {len(df_fresh[df_fresh['status']=='VIEW'])}")
print()
for _, r in df_fresh.iterrows():
    icon = '\u2705' if r['status'] == 'FRESH' else '\u274c' if r['status'] == 'STALE' else '\u2139\ufe0f'
    print(f"  {icon} {r['table']:<42} {r['age_days']:>3}d / {r['threshold']}d  {r['last_modified']}")

if stale_count > 0:
    print(f"\n  \u26a0\ufe0f {stale_count} STALE TABLE(S) — refresh needed!")
else:
    print(f"\n  \u2705 All tables within freshness thresholds.")

# COMMAND ----------

# DBTITLE 1,W3-5: Null-Rate Monitoring
# W3-5: Null-Rate Monitoring
# Tracks per-field null percentages across key serving tables
# Stores snapshots for trend analysis and spike detection

from datetime import datetime
import pandas as pd

# Define critical fields to monitor per table
NULL_MONITOR_CONFIG = {
    'tbl_genie_provider_profile': ['avg_inpatient_per_diem', 'total_rates', 'latest_amendment_date'],
    'tbl_serving_provider_summary': ['provider_type', 'total_rates'],
    'tbl_serving_rate_card': ['rate_numeric', 'rate_category', 'provider_name'],
    'tbl_reimb_rate_rules': ['rate_numeric', 'service_line', 'provider_name', 'is_current_effective'],
    'tbl_intel_renewal_priority': ['priority_score', 'days_to_expiry', 'recommended_action'],
    'tbl_genie_amendment_timeline': ['effective_date_parsed', 'amendment_order', 'doc_category'],
}

snapshot_rows = []
print(f"{'='*70}")
print(f"  NULL-RATE MONITOR — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
print(f"{'='*70}")

for tbl, fields in NULL_MONITOR_CONFIG.items():
    fqn = f"{CATALOG}.{SCHEMA}.{tbl}"
    try:
        total = spark.table(fqn).count()
        null_exprs = [f"SUM(CASE WHEN {f} IS NULL THEN 1 ELSE 0 END) as null_{f}" for f in fields]
        null_counts = spark.sql(f"SELECT {', '.join(null_exprs)} FROM {fqn}").toPandas().iloc[0]
        
        print(f"\n  {tbl} ({total:,} rows):")
        for f in fields:
            null_ct = int(null_counts[f'null_{f}'])
            pct = null_ct * 100.0 / total if total > 0 else 0
            icon = '\u2705' if pct < 5 else '\u26a0\ufe0f' if pct < 25 else '\u274c'
            print(f"    {icon} {f:<30} {null_ct:>6} nulls ({pct:.1f}%)")
            snapshot_rows.append({
                'snapshot_date': datetime.now().isoformat(),
                'table_name': tbl,
                'field_name': f,
                'total_rows': total,
                'null_count': null_ct,
                'null_pct': round(pct, 2)
            })
    except Exception as e:
        print(f"\n  \u274c {tbl}: ERROR — {str(e)[:60]}")

# Store snapshot for trend analysis
df_snapshot = pd.DataFrame(snapshot_rows)
print(f"\n{'='*70}")
print(f"  Snapshot: {len(df_snapshot)} field measurements captured")
print(f"  Critical (>25% null): {len(df_snapshot[df_snapshot['null_pct'] > 25])} fields")
print(f"  Warning (5-25% null): {len(df_snapshot[(df_snapshot['null_pct'] > 5) & (df_snapshot['null_pct'] <= 25)])} fields")
print(f"{'='*70}")

# COMMAND ----------

# DBTITLE 1,W3-6: Drift Detection Stub
# W3-6: Distribution Drift Detection
# Tracks value distributions per batch; flags when distributions shift
# Uses simple statistical tests (mean/stddev shift, category proportion change)

from datetime import datetime
import pandas as pd
import numpy as np

# Define monitored distributions
DRIFT_CONFIG = {
    'tbl_reimb_rate_rules': {
        'numeric': ['rate_numeric'],
        'categorical': ['service_line', 'program', 'network']
    },
    'tbl_genie_provider_profile': {
        'numeric': ['avg_inpatient_per_diem', 'total_rates'],
        'categorical': ['provider_type']
    },
    'tbl_intel_renewal_priority': {
        'numeric': ['priority_score', 'days_to_expiry'],
        'categorical': ['recommended_action']
    },
}

print(f"{'='*70}")
print(f"  DRIFT DETECTION — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
print(f"{'='*70}")

drift_results = []

for tbl, config in DRIFT_CONFIG.items():
    fqn = f"{CATALOG}.{SCHEMA}.{tbl}"
    print(f"\n  {tbl}:")
    
    # Numeric distributions
    for col in config.get('numeric', []):
        try:
            stats = spark.sql(f"""
                SELECT COUNT(*) as n,
                       AVG(CAST({col} AS DOUBLE)) as mean_val,
                       STDDEV(CAST({col} AS DOUBLE)) as std_val,
                       MIN(CAST({col} AS DOUBLE)) as min_val,
                       MAX(CAST({col} AS DOUBLE)) as max_val,
                       PERCENTILE(CAST({col} AS DOUBLE), 0.5) as median_val
                FROM {fqn}
                WHERE {col} IS NOT NULL
            """).toPandas().iloc[0]
            print(f"    {col}: mean={stats['mean_val']:.2f}, std={stats['std_val']:.2f}, "
                  f"median={stats['median_val']:.2f}, range=[{stats['min_val']:.0f}, {stats['max_val']:.0f}]")
            drift_results.append({
                'table': tbl, 'column': col, 'type': 'numeric',
                'mean': float(stats['mean_val']), 'std': float(stats['std_val']),
                'median': float(stats['median_val']), 'n': int(stats['n']),
                'snapshot_date': datetime.now().isoformat()
            })
        except Exception as e:
            print(f"    {col}: ERROR — {str(e)[:50]}")
    
    # Categorical distributions (top-5 proportions)
    for col in config.get('categorical', []):
        try:
            dist = spark.sql(f"""
                SELECT {col} as category, COUNT(*) as cnt,
                       COUNT(*) * 100.0 / SUM(COUNT(*)) OVER () as pct
                FROM {fqn}
                WHERE {col} IS NOT NULL
                GROUP BY {col}
                ORDER BY cnt DESC
                LIMIT 5
            """).toPandas()
            top_str = ', '.join(f"{r['category']}:{r['pct']:.1f}%" for _, r in dist.iterrows())
            print(f"    {col}: {top_str}")
            drift_results.append({
                'table': tbl, 'column': col, 'type': 'categorical',
                'top_categories': dict(zip(dist['category'], dist['pct'])),
                'n': int(dist['cnt'].sum()),
                'snapshot_date': datetime.now().isoformat()
            })
        except Exception as e:
            print(f"    {col}: ERROR — {str(e)[:50]}")

print(f"\n{'='*70}")
print(f"  Distributions captured: {len(drift_results)} metrics")
print(f"  Compare against future snapshots to detect drift (KL-div > 0.1 = alert)")
print(f"{'='*70}")
print(f"\n  NOTE: First run = baseline. Re-run periodically to detect shifts.")
print(f"  Future: Store in Delta table + compute KL-divergence between snapshots.")

# COMMAND ----------

# DBTITLE 1,W3-7: Write Alert Policies Doc
# W3-7: Generate alert_policies.md
import os

alert_doc = '''# Alert Policies - BSC Provider Contract Intelligence Platform

**Version**: 1.0  
**Created**: 2026-06-09  
**Status**: Active

---

## 1. Pipeline Stall Alert
- Condition: No new rows in fact_extraction_run for >7 days
- Severity: HIGH
- Action: Notify pipeline owner; check cluster health + API limits

## 2. Extraction Error Spike  
- Condition: failure_count / file_count > 0.10 in any single run
- Severity: HIGH
- Action: Halt batch; inspect error_message distribution

## 3. Cost Overage
- Condition: total_cost_usd > 500/run OR monthly > 5000
- Severity: MEDIUM
- Action: Review chunking strategy; check for retry loops

## 4. Retrieval Empty-Rate Spike
- Condition: >20%% of queries return empty_result=TRUE over 24h
- Severity: HIGH
- Action: Check VS index health; verify table freshness

## 5. Table Freshness Violation
- Condition: Any table exceeds its threshold_days
- Severity: MEDIUM
- Action: Trigger refresh job; notify data engineering

## 6. Null-Rate Spike
- Condition: Any field null%% increases >10pp from baseline
- Severity: MEDIUM
- Action: Investigate upstream extraction or migration

## 7. Distribution Drift
- Condition: KL-divergence >0.1 between snapshots
- Severity: LOW (informational)
- Action: Review; update baseline if intentional

## 8. Quality Regression
- Condition: Regression scorecard <80%% pass rate
- Severity: HIGH  
- Action: Block deployment; investigate failed checks

---

## Notification Channels
- HIGH: Email + Slack + PagerDuty
- MEDIUM: Email + Slack
- LOW: Slack daily digest

## Schedule
- Freshness: Every 6 hours
- Null-rate: Daily
- Drift: Weekly
- Cost: Per-run (real-time)
- Quality: Post-batch-export
'''

doc_path = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/docs/platform/alert_policies.md"
os.makedirs(os.path.dirname(doc_path), exist_ok=True)
with open(doc_path, 'w') as f:
    f.write(alert_doc)
print(f"\u2705 Alert policies written to: {doc_path}")
print(f"   Size: {len(alert_doc)} chars, 8 alert definitions")

# COMMAND ----------

# DBTITLE 1,Wave 3 Summary
print("""
========================================
  WAVE 3 - OBSERVABILITY SUMMARY
========================================

  W3-1: fact_extraction_run        -> Table created (DDL)
  W3-2: fact_file_extraction       -> Table created (DDL)
  W3-3: fact_retrieval_telemetry   -> Table created (DDL)
  W3-4: Freshness monitoring       -> Logic implemented
  W3-5: Null-rate monitoring       -> Logic implemented
  W3-6: Drift detection stub       -> Baseline snapshot logic
  W3-7: Alert policies doc         -> Written to docs/platform/

  REMAINING WIRING:
  - Hook extraction pipeline to INSERT INTO fact_extraction_run + fact_file_extraction
  - Hook retrieval engine to INSERT INTO fact_retrieval_telemetry
  - Schedule W3-4/W3-5/W3-6 as periodic Lakeflow job
  - Configure actual alert delivery (Databricks SQL Alerts or external)
""")
# Databricks notebook source
# DBTITLE 1,W1-2: LLM-Assisted Gold Annotation
# MAGIC %md
# MAGIC # W1-2: LLM-Assisted Gold Annotation Pipeline
# MAGIC
# MAGIC **Purpose**: Automate field-level verification of LLM extraction against source text.  
# MAGIC **Approach**: For each gold sample file, retrieve source passages + extraction data, ask a fresh LLM call to verify accuracy field-by-field.  
# MAGIC **Output**: Annotations in `tbl_eval_gold_annotations` with `confidence_source = 'LLM_VERIFIED'`
# MAGIC
# MAGIC **Human reviewer savings**: Reduces 29-hour manual task to ~8 hours (spot-check LLM verdicts vs full manual review)
# MAGIC
# MAGIC | Step | Action | Human Needed? |
# MAGIC |------|--------|---------------|
# MAGIC | 1 | LLM verifies 13 CRITICAL fields per file against source passages | No (automated) |
# MAGIC | 2 | LLM confirms/dismisses 893 flagged issues | No (automated) |
# MAGIC | 3 | Human spot-checks 20% of LLM_VERIFIED=TRUE | Yes (~3 hrs) |
# MAGIC | 4 | Human reviews all LLM_VERIFIED=FALSE with gold_value | Yes (~5 hrs) |
# MAGIC | 5 | compute_f1() produces real scores | No |

# COMMAND ----------

# DBTITLE 1,Config + Imports
# Configuration
import json, os, time, re, requests
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import pandas as pd

CATALOG = "dev_adb"
SCHEMA = "raw"
LLM_MODEL = "databricks-claude-sonnet-4-5"
BATCH_SIZE = 50  # Milestone 1: process 50 files to reach acceptance threshold
MAX_WORKERS = 3  # Concurrent LLM calls

# LLM endpoint
workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
LLM_ENDPOINT = f"https://{workspace_url}/serving-endpoints/{LLM_MODEL}/invocations"
HEADERS = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

# Critical fields to verify (13 CRITICAL from SOP)
CRITICAL_FIELDS = [
    {'name': 'inpatient_per_diem', 'category': 'RATE', 'description': 'Dollar amount per patient day from rate schedule'},
    {'name': 'outpatient_case_rate', 'category': 'RATE', 'description': 'Case rate dollar amounts (DRG/procedure)'},
    {'name': 'capitation_pmpm', 'category': 'RATE', 'description': 'Per-member-per-month capitation amount'},
    {'name': 'stop_loss_threshold', 'category': 'FINANCIAL', 'description': 'Dollar threshold triggering stop-loss'},
    {'name': 'stop_loss_reimbursement_pct', 'category': 'FINANCIAL', 'description': 'Percentage above threshold'},
    {'name': 'effective_date', 'category': 'DATE', 'description': 'When contract/amendment takes effect'},
    {'name': 'expiration_date', 'category': 'DATE', 'description': 'When contract expires (NULL ok for auto-renewal)'},
    {'name': 'auto_renewal', 'category': 'TERM', 'description': 'Does contract auto-renew? Boolean.'},
    {'name': 'termination_notice_days', 'category': 'TERM', 'description': 'Days of notice required for termination'},
    {'name': 'provider_name', 'category': 'METADATA', 'description': 'Legal entity name from contract header'},
    {'name': 'payment_model', 'category': 'METADATA', 'description': 'FFS, capitation, hybrid, case-rate'},
    {'name': 'prior_rates_superseded', 'category': 'TERM', 'description': 'Does this doc replace prior rate schedules?'},
    {'name': 'has_most_favored_nation', 'category': 'TERM', 'description': 'MFN clause present? (competitive pricing language)'},
]

print(f"\u2705 Config loaded: {LLM_MODEL}, {len(CRITICAL_FIELDS)} critical fields")
print(f"   Batch size: {BATCH_SIZE}, Workers: {MAX_WORKERS}")

# COMMAND ----------

# DBTITLE 1,Load Annotation Queue (Top 50)
# Load top 50 priority files from annotation queue
queue_df = spark.sql(f"""
    SELECT 
        gs.sample_id,
        gs.source_filename,
        gs.provider_id,
        gs.provider_name,
        gs.doc_role,
        gs.complexity_tier,
        gs.annotation_status,
        -- Count existing annotations for this file
        COUNT(ga.annotation_id) as existing_annotations,
        SUM(CASE WHEN ga.confidence_source = 'LLM_FLAGGED' THEN 1 ELSE 0 END) as llm_flagged_count,
        SUM(CASE WHEN ga.confidence_source = 'HUMAN_VERIFIED' THEN 1 ELSE 0 END) as human_verified_count
    FROM {CATALOG}.{SCHEMA}.tbl_eval_gold_sample gs
    LEFT JOIN {CATALOG}.{SCHEMA}.tbl_eval_gold_annotations ga
        ON gs.sample_id = ga.sample_id
    WHERE gs.annotation_status = 'PENDING'
    GROUP BY gs.sample_id, gs.source_filename, gs.provider_id, gs.provider_name,
             gs.doc_role, gs.complexity_tier, gs.annotation_status
    ORDER BY CASE gs.complexity_tier WHEN 'COMPLEX' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END, llm_flagged_count DESC
    LIMIT 50
""").toPandas()

print(f"\u2705 Loaded {len(queue_df)} priority files for annotation")
print(f"   Complexity: {queue_df['complexity_tier'].value_counts().to_dict()}")
print(f"   Doc roles: {queue_df['doc_role'].value_counts().to_dict()}")
print(f"   Total LLM-flagged issues across these files: {queue_df['llm_flagged_count'].sum()}")

# COMMAND ----------

# DBTITLE 1,Source Text Retrieval Helper
# Keywords for field-aware retrieval — maps field domains to search terms
FIELD_KEYWORDS = {
    'stop_loss': ['stop loss', 'stop-loss', 'reinsurance', 'excess loss', 'catastrophic'],
    'rates_inpatient': ['per diem', 'inpatient', 'med/surg', 'medical/surgical', 'icu', 'ccu',
                        'maternity', 'nicu', 'rehabilitation', 'psych', 'snf'],
    'rates_outpatient': ['outpatient', 'case rate', 'ambulatory', 'surgical group',
                         'emergency', 'observation'],
    'capitation': ['capitation', 'pmpm', 'per member', 'global cap', 'subcapitation'],
    'financial': ['reimbursement', 'allowed charges', 'billed charges', 'payment',
                  'fee schedule', 'percent of', '% of'],
    'termination': ['termination', 'notice', 'without cause', 'days prior',
                    'written notice', 'cure period'],
    'renewal': ['renewal', 'auto-renew', 'evergreen', 'successive', 'extend'],
}


def _version_fuzzy_pattern(source_filename):
    """Strip _vN.pdf suffix to create a LIKE pattern for version-fuzzy matching.
    
    Example: '159915416_Coast_Plaza_Hospital_216046538_ThirdAmend_v2.pdf'
           -> '159915416_Coast_Plaza_Hospital_216046538_ThirdAmend_v%.pdf'
    
    Root cause: tbl_eval_gold_sample uses _v2.pdf (latest extraction version)
    but 07_stage_json's version dedup kept _v1 in some cases, so 08_build_rates
    built analytical tables with _v1.pdf as source_filename.
    """
    import re as _re
    return _re.sub(r'_v\d+\.pdf$', '_v%.pdf', source_filename)


def get_source_passages(source_filename, max_chars=50000):
    """Retrieve source text with FIELD-AWARE passage selection.
    
    Strategy: Instead of blindly taking first N chars (which misses stop-loss
    and rate sections in long contracts), we:
    1. Always include the first 12K chars (contract header/overview)
    2. Value-anchor on known extracted numbers (from structured tables)
    3. Keyword-search remaining passages for field-relevant content
    4. Fill any remaining budget with sequential passages
    """
    # Primary source: legal units (chunked, structured)
    passages = spark.sql(f"""
        SELECT unit_text as content_text, title, '' as topic
        FROM {CATALOG}.{SCHEMA}.tbl_retrieval_legal_units
        WHERE source_filename = '{source_filename}'
        ORDER BY title
    """).toPandas()
    
    # FIX: If legal_units is too sparse (<10K chars), supplement with fulltext
    # This handles cases like sample 111 where legal_units has only attachment summaries
    legal_chars = passages['content_text'].apply(lambda x: len(x) if x else 0).sum() if not passages.empty else 0
    
    if passages.empty or legal_chars < 10000:
        fulltext_passages = spark.sql(f"""
            SELECT chunk_text as content_text, CAST(chunk_index AS STRING) as title, '' as topic
            FROM {CATALOG}.{SCHEMA}.tbl_contract_fulltext_vs_ready
            WHERE source_filename = '{source_filename}'
            ORDER BY chunk_index
        """).toPandas()
        
        if passages.empty:
            passages = fulltext_passages
        elif not fulltext_passages.empty:
            import pandas as _pd
            passages = _pd.concat([passages, fulltext_passages], ignore_index=True)
    
    if passages.empty:
        return None, 0
    
    passages['content_len'] = passages['content_text'].apply(lambda x: len(x) if x else 0)
    total_doc_chars = passages['content_len'].sum()
    
    # If document fits within budget, return everything
    if total_doc_chars <= max_chars:
        text_parts = []
        for _, row in passages.iterrows():
            section = f"[{row['title']}]" if row['title'] else ""
            content = row['content_text'] or ""
            text_parts.append(f"{section}\n{content}")
        return "\n\n".join(text_parts), len(passages)
    
    # --- FIELD-AWARE SELECTION for long documents ---
    HEADER_BUDGET = 12000
    ANCHOR_BUDGET = 8000
    KEYWORD_BUDGET = 25000
    FILL_BUDGET = max_chars - HEADER_BUDGET - ANCHOR_BUDGET - KEYWORD_BUDGET
    
    # Phase 1: Header passages
    header_parts = []
    header_chars = 0
    header_indices = set()
    for idx, row in passages.iterrows():
        content = row['content_text'] or ""
        if header_chars + len(content) > HEADER_BUDGET:
            break
        section = f"[{row['title']}]" if row['title'] else ""
        header_parts.append(f"{section}\n{content}")
        header_chars += len(content)
        header_indices.add(idx)
    
    # Phase 2: Value-anchored passages
    anchor_parts = []
    anchor_chars = 0
    anchor_indices = set()
    value_anchors = _get_value_anchors(source_filename)
    
    if value_anchors:
        for idx, row in passages.iterrows():
            if idx in header_indices:
                continue
            content = row['content_text'] or ''
            matched_anchor = None
            for anchor in value_anchors:
                if anchor in content:
                    matched_anchor = anchor
                    break
            if matched_anchor and anchor_chars + len(content) <= ANCHOR_BUDGET:
                section = f"[{row['title']}]" if row['title'] else ""
                anchor_parts.append((idx, f"{section}\n{content}"))
                anchor_chars += len(content)
                anchor_indices.add(idx)
    
    anchor_parts.sort(key=lambda x: x[0])
    
    # Phase 3: Keyword-matched passages
    keyword_scores = []
    for idx, row in passages.iterrows():
        if idx in header_indices or idx in anchor_indices:
            continue
        content = (row['content_text'] or '').lower()
        title = (row['title'] or '').lower()
        domains_hit = 0
        for domain, keywords in FIELD_KEYWORDS.items():
            if any(kw in content or kw in title for kw in keywords):
                domains_hit += 1
        if domains_hit > 0:
            keyword_scores.append((idx, domains_hit, len(row['content_text'] or '')))
    
    keyword_scores.sort(key=lambda x: (-x[1], x[0]))
    
    keyword_parts = []
    keyword_chars = 0
    keyword_indices = set()
    for idx, score, length in keyword_scores:
        if keyword_chars + length > KEYWORD_BUDGET:
            if length > KEYWORD_BUDGET * 0.5:
                continue
            if keyword_chars + length > KEYWORD_BUDGET:
                continue
        row = passages.loc[idx]
        section = f"[{row['title']}]" if row['title'] else ""
        content = row['content_text'] or ""
        keyword_parts.append((idx, f"{section}\n{content}"))
        keyword_chars += length
        keyword_indices.add(idx)
    
    keyword_parts.sort(key=lambda x: x[0])
    
    # Phase 4: Fill remaining budget
    fill_parts = []
    fill_chars = 0
    for idx, row in passages.iterrows():
        if idx in header_indices or idx in anchor_indices or idx in keyword_indices:
            continue
        content = row['content_text'] or ""
        if fill_chars + len(content) > max(FILL_BUDGET, 0):
            break
        section = f"[{row['title']}]" if row['title'] else ""
        fill_parts.append(f"{section}\n{content}")
        fill_chars += len(content)
    
    # Assemble final text
    all_parts = header_parts
    if anchor_parts:
        all_parts.append("\n[... VALUE-ANCHORED SECTIONS ...]\n")
        all_parts.extend([p[1] for p in anchor_parts])
    if keyword_parts:
        all_parts.append("\n[... FIELD-RELEVANT SECTIONS ...]\n")
        all_parts.extend([p[1] for p in keyword_parts])
    if fill_parts:
        all_parts.extend(fill_parts)
    
    return "\n\n".join(all_parts), len(passages)


def _get_value_anchors(source_filename):
    """Build value strings to search for in source text from structured tables."""
    import re as _re
    anchors = []
    
    fp = spark.sql(f"""
        SELECT reimbursement_pct_text, threshold_text
        FROM {CATALOG}.{SCHEMA}.tbl_contract_financial_protections
        WHERE source_filename = '{source_filename}'
    """).toPandas()
    
    for _, row in fp.iterrows():
        pct_text = str(row.get('reimbursement_pct_text', '') or '')
        pct_matches = _re.findall(r'\d+\.?\d*%', pct_text)
        anchors.extend(pct_matches)
        thresh_text = str(row.get('threshold_text', '') or '')
        dollar_matches = _re.findall(r'\$[\d,]+', thresh_text)
        anchors.extend(dollar_matches)
    
    rates = spark.sql(f"""
        SELECT rate_text
        FROM {CATALOG}.{SCHEMA}.tbl_reimb_rate_rules
        WHERE source_filename = '{source_filename}'
          AND rate_text IS NOT NULL AND rate_text != ''
        LIMIT 5
    """).toPandas()
    
    for _, row in rates.iterrows():
        rate_text = str(row.get('rate_text', '') or '')
        dollar_matches = _re.findall(r'\$[\d,]+\.?\d*', rate_text)
        anchors.extend(dollar_matches)
    
    anchors = list(set(a for a in anchors if len(a) >= 3))
    return anchors[:20]


def get_extraction_data(source_filename):
    """Get extracted values for a file from rate_rules + amendment_timeline.
    
    Uses VERSION-FUZZY matching: if exact filename has no data, tries
    matching on the base pattern (ignoring _vN version suffix).
    """
    data = {}
    fuzzy_pattern = _version_fuzzy_pattern(source_filename)
    
    # Rates - try exact match first, then version-fuzzy
    rates = spark.sql(f"""
        SELECT rate_numeric, rate_text, service_line, rate_unit, formula_json, program, network
        FROM {CATALOG}.{SCHEMA}.tbl_reimb_rate_rules
        WHERE source_filename = '{source_filename}'
        LIMIT 2000
    """).toPandas()
    
    rates_source = 'exact'
    rates_source = 'exact'
    if rates.empty:
        rates = spark.sql(f"""
            SELECT rate_numeric, rate_text, service_line, rate_unit, formula_json, program, network
            FROM {CATALOG}.{SCHEMA}.tbl_reimb_rate_rules
            WHERE source_filename LIKE '{fuzzy_pattern}'
            LIMIT 2000
        """).toPandas()
        rates_source = 'version_fuzzy'

    if rates.empty:
        # Tier 3 fallback: upstream version/contractID dedup means this contract's rates
        # often landed under a SIBLING filename for the same provider. Pull from that
        # provider's single richest rate-bearing document to keep one coherent schedule.
        provider_id = source_filename.split('_')[0]
        if provider_id.isdigit():
            rates = spark.sql(f"""
                WITH sib AS (
                    SELECT rate_numeric, rate_text, service_line, rate_unit, formula_json, program, network,
                           source_filename,
                           COUNT(*) OVER (PARTITION BY source_filename) AS doc_rows
                    FROM {CATALOG}.{SCHEMA}.tbl_reimb_rate_rules
                    WHERE startswith(source_filename, '{provider_id}_')
                )
                SELECT rate_numeric, rate_text, service_line, rate_unit, formula_json, program, network
                FROM sib
                WHERE source_filename = (
                    SELECT source_filename FROM sib ORDER BY doc_rows DESC, source_filename LIMIT 1
                )
                LIMIT 2000
            """).toPandas()
            rates_source = 'provider_fallback'
        rates_source = 'version_fuzzy'

    if rates.empty:
        # Tier 3 fallback: upstream version/contractID dedup means this contract's rates
        # often landed under a SIBLING filename for the same provider. Pull from that
        # provider's single richest rate-bearing document to keep one coherent schedule.
        provider_id = source_filename.split('_')[0]
        if provider_id.isdigit():
            rates = spark.sql(f"""
                WITH sib AS (
                    SELECT rate_numeric, rate_text, service_line, rate_unit, formula_json, program, network,
                           source_filename,
                           COUNT(*) OVER (PARTITION BY source_filename) AS doc_rows
                    FROM {CATALOG}.{SCHEMA}.tbl_reimb_rate_rules
                    WHERE startswith(source_filename, '{provider_id}_')
                )
                SELECT rate_numeric, rate_text, service_line, rate_unit, formula_json, program, network
                FROM sib
                WHERE source_filename = (
                    SELECT source_filename FROM sib ORDER BY doc_rows DESC, source_filename LIMIT 1
                )
                LIMIT 2000
            """).toPandas()
            rates_source = 'provider_fallback'
    
    if not rates.empty:
        data['rates'] = rates.to_dict('records')
        data['rate_count'] = len(rates)
        data['rates_source'] = rates_source
        data['rates_source'] = rates_source
    
    # Amendment/contract metadata (provider_name + version-fuzzy)
    meta = spark.sql(f"""
        SELECT provider_name, effective_date_parsed, expiration_date_parsed, auto_renewal,
               contract_term_years, agreement_type, payment_type,
               prior_rates_superseded, document_type, doc_category
        FROM {CATALOG}.{SCHEMA}.tbl_genie_amendment_timeline
        WHERE source_filename = '{source_filename}'
    """).toPandas()
    
    if meta.empty:
        meta = spark.sql(f"""
            SELECT provider_name, effective_date_parsed, expiration_date_parsed, auto_renewal,
                   contract_term_years, agreement_type, payment_type,
                   prior_rates_superseded, document_type, doc_category
            FROM {CATALOG}.{SCHEMA}.tbl_genie_amendment_timeline
            WHERE source_filename LIKE '{fuzzy_pattern}'
            LIMIT 1
        """).toPandas()
    
    if not meta.empty:
        data['metadata'] = meta.iloc[0].to_dict()
    
    # Financial protections (with version-fuzzy fallback)
    fin = spark.sql(f"""
        SELECT protection_type, sub_type, threshold_text, threshold_numeric,
               reimbursement_pct_text, reimbursement_pct_numeric
        FROM {CATALOG}.{SCHEMA}.tbl_contract_financial_protections
        WHERE source_filename = '{source_filename}'
    """).toPandas()
    
    if fin.empty:
        fin = spark.sql(f"""
            SELECT protection_type, sub_type, threshold_text, threshold_numeric,
                   reimbursement_pct_text, reimbursement_pct_numeric
            FROM {CATALOG}.{SCHEMA}.tbl_contract_financial_protections
            WHERE source_filename LIKE '{fuzzy_pattern}'
        """).toPandas()
    
    if not fin.empty:
        data['financial'] = fin.to_dict('records')
    
    return data


print("\u2705 Source retrieval helpers loaded (v3: field-aware + version-fuzzy + sparse fallback)")

# COMMAND ----------

# DBTITLE 1,Validation — Smart Retrieval Test
# === VALIDATION: Smart retrieval + provider_name fix ===
# RESULTS (verified 2026-06-09):
#   Fix 1 (smart retrieval): 8/9 stop-loss values now visible (was 0/9)
#   Fix 2 (provider_name in SELECT): ✅ works — returns actual value
#   Sample 111 sole failure: file has only 4,237 chars in legal_units (incomplete source)

test_fn = "129141563_Adventist_Health_Sonora_129570475_BaseAgmtRenew_v2.pdf"
text, passage_count = get_source_passages(test_fn)

print(f"Total passages available: {passage_count}")
print(f"Returned text length: {len(text):,} chars (budget: 50,000)")

# Critical test: does the stop-loss value now appear?
has_432 = '43.2' in text
has_stop_loss = 'stop loss' in text.lower() or 'stop-loss' in text.lower()
sl_count = text.lower().count('stop loss') + text.lower().count('stop-loss')

print(f"\n  Contains '43.2%' (previously MISSING): {'YES ✅' if has_432 else 'NO ❌'}")
print(f"  Contains 'stop loss' mentions: {sl_count}")

if has_432:
    pos = text.index('43.2')
    print(f"  '43.2' at position {pos:,} (within 40K prompt: {pos < 40000})")
    print(f"  Context: ...{text[max(0,pos-60):pos+80]}...")

# Also test get_extraction_data fix (provider_name in SELECT)
data = get_extraction_data(test_fn)
meta_pn = data.get('metadata', {}).get('provider_name')
print(f"\n  get_extraction_data() provider_name: '{meta_pn}' {'✅' if meta_pn else '❌ STILL MISSING'}")

# Test across all 9 'hallucination' samples — does smart retrieval now expose the values?
import re as _re
print(f"\n{'='*70}")
print(f"  BATCH TEST: All 9 previously 'hallucinated' stop-loss samples")
print(f"  (searching for pct_text anchors, NOT raw numeric)")
print(f"{'='*70}")

halluc_sids = [23, 72, 75, 84, 85, 96, 102, 111, 193]
found_count = 0
for sid in halluc_sids:
    row = spark.sql(f"""
        SELECT gs.source_filename, fp.reimbursement_pct_text, fp.reimbursement_pct_numeric
        FROM dev_adb.raw.tbl_eval_gold_sample gs
        JOIN dev_adb.raw.tbl_contract_financial_protections fp
            ON gs.source_filename = fp.source_filename
        WHERE gs.sample_id = {sid}
          AND LOWER(fp.protection_type) LIKE '%stop%'
        LIMIT 1
    """).collect()
    if not row:
        print(f"  Sample {sid:>3}: no financial_protections row (skip)")
        continue
    fn = row[0]['source_filename']
    pct_text = row[0]['reimbursement_pct_text'] or ''
    pct_num = row[0]['reimbursement_pct_numeric']
    # Search for the percentage pattern (e.g., '57%', '43.2%') which is what's in source
    pct_patterns = _re.findall(r'\d+\.?\d*%', pct_text)
    primary_pct = pct_patterns[0] if pct_patterns else str(pct_num)
    
    txt, pc = get_source_passages(fn)
    found = primary_pct in (txt or '') if txt else False
    if found:
        found_count += 1
    print(f"  Sample {sid:>3}: '{primary_pct}' (from '{pct_text[:30]}') → {'FOUND ✅' if found else 'NOT FOUND ❌'} ({len(txt or ''):,} chars)")

print(f"\n  Result: {found_count}/9 stop-loss values now visible to auditor")
print(f"  (Previously: 0/9 were visible due to sequential truncation)")

# COMMAND ----------

# DBTITLE 1,LLM Verification Engine
VERIFICATION_PROMPT = """You are a contract data quality auditor. You are given:
1. SOURCE TEXT: Passages from a provider contract PDF (OCR'd)
2. EXTRACTED DATA: What our pipeline extracted from this document
3. FIELDS TO VERIFY: Specific fields to check against the source text

For EACH field, determine:
- Whether the extracted value is CORRECT (matches source text)
- If INCORRECT, what the correct value should be (from source text)
- If the field is NOT PRESENT in this document type, mark as NOT_APPLICABLE

Respond in JSON format:
{{
  "verifications": [
    {{
      "field_name": "<field>",
      "field_category": "<RATE|FINANCIAL|DATE|TERM|METADATA>",
      "extracted_value": "<what pipeline extracted or NULL if missing>",
      "is_correct": <true|false|null>,
      "gold_value": "<correct value from source, or NULL if not in document>",
      "error_type": "<HALLUCINATION|OMISSION|WRONG_VALUE|WRONG_SCOPE|null>",
      "severity": "<CRITICAL|MAJOR|MINOR|null>",
      "confidence": <0.0-1.0>,
      "reasoning": "<brief explanation of verdict>",
      "source_excerpt": "<verbatim quote from source text supporting verdict, max 200 chars>"
    }}
  ]
}}

Rules:
- Only mark is_correct=true if value EXACTLY matches source (dates, amounts, names)
- For rates: verify the EXACT dollar amount appears in the source text
- For dates: allow format differences ("Jan 1, 2024" = "01/01/2024" = "1/1/24")
- Mark NOT_APPLICABLE (is_correct=null, gold_value=null) if the field doesn't apply to this document type
- For OMISSION: extracted_value should be null but gold_value should have the correct value from source
- Set confidence < 0.7 if the source text is ambiguous or OCR quality is poor
- NEVER hallucinate a gold_value — only report values you can find in the source text
"""


def _repair_json(s):
    """Balance open quotes/brackets/braces and drop trailing commas in malformed JSON."""
    s = re.sub(r',\s*([}\]])', r'\1', s)
    stack, in_str, esc = [], False, False
    closer = {'{': '}', '[': ']'}
    for ch in s:
        if esc:
            esc = False
        elif ch == '\\':
            esc = True
        elif ch == '"':
            in_str = not in_str
        elif not in_str:
            if ch in closer:
                stack.append(closer[ch])
            elif ch in ('}', ']') and stack and stack[-1] == ch:
                stack.pop()
    if in_str:
        s += '"'
    while stack:
        s += stack.pop()
    return s


def _parse_llm_json(content):
    """Parse LLM JSON tolerating markdown fences and minor malformation; None on failure."""
    fence = chr(96) * 3  # avoid a literal triple-backtick in source
    s = (content or '').strip()
    if s.startswith(chr(96)):
        s = s.lstrip(chr(96))
        if s[:4].lower() == 'json':
            s = s[4:]
    s = s.strip().rstrip(chr(96)).strip()
    for candidate in (s, _repair_json(s)):
        try:
            return json.loads(candidate)
        except Exception:
            continue
    return None


def verify_file(sample_id, source_filename, provider_name, doc_role, extraction_data, source_text):
    """Use LLM to verify extraction accuracy for one file.

    Returns list of annotation dicts ready for INSERT.
    """
    # Build extraction summary for prompt
    extraction_summary = json.dumps(extraction_data, indent=2, default=str)[:8000]

    # Build field list with extracted values
    fields_to_check = []
    for field in CRITICAL_FIELDS:
        extracted = _get_extracted_value(field['name'], extraction_data)
        fields_to_check.append({
            'name': field['name'],
            'category': field['category'],
            'description': field['description'],
            'extracted_value': extracted
        })

    user_msg = f"""DOCUMENT: {source_filename}
PROVIDER: {provider_name}
DOCUMENT TYPE: {doc_role}

=== SOURCE TEXT (from PDF) ===
{source_text[:48000]}

=== EXTRACTED DATA (pipeline output) ===
{extraction_summary}

=== FIELDS TO VERIFY ===
{json.dumps(fields_to_check, indent=2, default=str)}

Verify each field against the source text. Return JSON."""

    payload = {
        "messages": [
            {"role": "system", "content": VERIFICATION_PROMPT},
            {"role": "user", "content": user_msg}
        ],
        "max_tokens": 8192,
        "temperature": 0.0
    }

    resp = requests.post(LLM_ENDPOINT, headers=HEADERS, json=payload, timeout=120)
    resp.raise_for_status()

    content = resp.json()["choices"][0]["message"]["content"]

    # Parse JSON response (tolerate markdown fences + minor malformation)
    result = _parse_llm_json(content)
    if result is None:
        # One corrective retry: stricter instruction + nudged temperature
        retry_payload = dict(payload)
        retry_payload["temperature"] = 0.2
        retry_payload["messages"] = payload["messages"] + [
            {"role": "system", "content": "Your previous response was not valid JSON. Reply with ONLY one valid JSON object; escape all quotes and newlines inside string values."}
        ]
        retry_resp = requests.post(LLM_ENDPOINT, headers=HEADERS, json=retry_payload, timeout=120)
        retry_resp.raise_for_status()
        result = _parse_llm_json(retry_resp.json()["choices"][0]["message"]["content"])
    if result is None:
        raise ValueError("Unparseable LLM JSON after repair + retry")

    # Convert to annotation records
    annotations = []
    for v in result.get("verifications", []):
        if v.get("is_correct") is None and v.get("gold_value") is None:
            continue  # NOT_APPLICABLE — skip

        annotations.append({
            'sample_id': sample_id,
            'source_filename': source_filename,
            'field_category': v.get('field_category', 'METADATA'),
            'field_name': v['field_name'],
            'extracted_value': str(v.get('extracted_value', ''))[:500] if v.get('extracted_value') else None,
            'gold_value': str(v.get('gold_value', ''))[:500] if v.get('gold_value') else None,
            'is_correct': v.get('is_correct'),
            'error_type': v.get('error_type'),
            'severity': v.get('severity', 'CRITICAL'),
            'confidence': v.get('confidence', 0.5),
            'reasoning': v.get('reasoning', '')[:200],
            'source_excerpt': v.get('source_excerpt', '')[:500],
        })

    return annotations


def _summarize_rate(rates, units):
    """Representative summary of all distinct rate_numeric values for the given
    rate_unit set (a single field like inpatient_per_diem maps to many rows)."""
    vals = sorted({float(r['rate_numeric']) for r in rates
                   if r.get('rate_numeric') is not None
                   and str(r.get('rate_unit', '')).strip().lower() in units})
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    shown = '; '.join(f"${v:,.2f}" for v in vals[:8])
    more = f" (+{len(vals) - 8} more)" if len(vals) > 8 else ""
    return f"{len(vals)} distinct rates: {shown}{more}"


def _get_extracted_value(field_name, extraction_data):
    """Extract a specific field value from the extraction data dict."""
    meta = extraction_data.get('metadata', {})
    rates = extraction_data.get('rates', [])
    financial = extraction_data.get('financial', [])

    mapping = {
        'effective_date': meta.get('effective_date_parsed'),
        'expiration_date': meta.get('expiration_date_parsed'),
        'auto_renewal': meta.get('auto_renewal'),
        'provider_name': meta.get('provider_name'),
        'payment_model': meta.get('payment_type'),
        'prior_rates_superseded': meta.get('prior_rates_superseded'),
        'termination_notice_days': None,  # Not in amendment_timeline — check source
        'has_most_favored_nation': None,  # Clause presence — check source
        'inpatient_per_diem': _summarize_rate(rates, {'day'}),
        'outpatient_case_rate': _summarize_rate(rates, {'case'}),
        'capitation_pmpm': _summarize_rate(rates, {'member_month', 'pmpm'}),
        'stop_loss_threshold': next((f.get('threshold_numeric') for f in financial
                                     if 'stop' in str(f.get('protection_type', '')).lower()), None),
        'stop_loss_reimbursement_pct': next((f.get('reimbursement_pct_numeric') for f in financial
                                             if 'stop' in str(f.get('protection_type', '')).lower()), None),
    }
    return mapping.get(field_name)


print("✅ Verification engine loaded (v2: rate_unit mapping + multi-value summary + JSON repair/retry)")

# COMMAND ----------

# DBTITLE 1,TEMP: validate rate extraction
# === TEMP VALIDATION (no LLM): does rate extraction now populate for the original batch? ===
from collections import Counter
val_files = spark.sql(f"""
    SELECT DISTINCT a.sample_id, a.source_filename
    FROM {CATALOG}.{SCHEMA}.tbl_eval_gold_annotations a
    WHERE a.confidence_source = 'LLM_VERIFIED'
""").toPandas()

src = Counter()
nn = {'inpatient_per_diem': 0, 'outpatient_case_rate': 0, 'capitation_pmpm': 0}
total = len(val_files)
for _, r in val_files.iterrows():
    ed = get_extraction_data(r['source_filename'])
    src[ed.get('rates_source', 'NONE')] += 1
    for f in nn:
        if _get_extracted_value(f, ed) is not None:
            nn[f] += 1

print(f"Validated {total} original-batch files (no LLM calls)")
print(f"  rates_source tiers: {dict(src)}")
for f in nn:
    print(f"  {f:22s}: {nn[f]}/{total} now NON-NULL")

# Point the batch at the ORIGINAL files (now IN_PROGRESS, so excluded from the PENDING queue)
# so the corrected pipeline re-verifies them and Cell 8's upsert overwrites in place.
queue_df = spark.sql(f"""
    SELECT DISTINCT gs.sample_id, gs.source_filename, gs.provider_id, gs.provider_name,
           gs.doc_role, gs.complexity_tier, gs.annotation_status
    FROM {CATALOG}.{SCHEMA}.tbl_eval_gold_sample gs
    JOIN {CATALOG}.{SCHEMA}.tbl_eval_gold_annotations a ON gs.sample_id = a.sample_id
    WHERE a.confidence_source = 'LLM_VERIFIED'
""").toPandas().reset_index(drop=True)
print(f"\nqueue_df overridden -> {len(queue_df)} original-batch files for corrective re-run")

# COMMAND ----------

# DBTITLE 1,Batch Execution — Run Verification on First 10 Files
# Run LLM verification on first BATCH_SIZE files
batch = queue_df.head(BATCH_SIZE)

print(f"{'='*70}")
print(f"  LLM-ASSISTED ANNOTATION — Batch of {len(batch)} files")
print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M')}")
print(f"{'='*70}")

all_annotations = []
errors = []

for idx, row in batch.iterrows():
    sample_id = row['sample_id']
    filename = row['source_filename']
    provider = row['provider_name']
    doc_role = row['doc_role']
    
    print(f"\n  [{idx+1}/{len(batch)}] Sample {sample_id}: {provider}")
    print(f"       File: {filename[:60]}...")
    print(f"       Type: {doc_role} | Complexity: {row['complexity_tier']}")
    
    t0 = time.time()
    
    # Step 1: Get source text
    source_text, passage_count = get_source_passages(filename)
    if not source_text:
        print(f"       \u26a0\ufe0f No source passages found — skipping")
        errors.append({'sample_id': sample_id, 'error': 'no_source_text'})
        continue
    
    # Step 2: Get extraction data
    extraction_data = get_extraction_data(filename)
    if not extraction_data:
        print(f"       \u26a0\ufe0f No extraction data found — skipping")
        errors.append({'sample_id': sample_id, 'error': 'no_extraction_data'})
        continue
    
    # Step 3: LLM verification
    try:
        annotations = verify_file(sample_id, filename, provider, doc_role, extraction_data, source_text)
        elapsed = round(time.time() - t0, 1)
        
        correct = sum(1 for a in annotations if a['is_correct'] is True)
        incorrect = sum(1 for a in annotations if a['is_correct'] is False)
        
        print(f"       \u2705 {len(annotations)} annotations ({correct} correct, {incorrect} errors) [{elapsed}s]")
        all_annotations.extend(annotations)
    except Exception as e:
        elapsed = round(time.time() - t0, 1)
        print(f"       \u274c Error [{elapsed}s]: {str(e)[:80]}")
        errors.append({'sample_id': sample_id, 'error': str(e)[:100]})

print(f"\n{'='*70}")
print(f"  BATCH COMPLETE")
print(f"  Total annotations: {len(all_annotations)}")
print(f"  Correct: {sum(1 for a in all_annotations if a['is_correct'] is True)}")
print(f"  Errors found: {sum(1 for a in all_annotations if a['is_correct'] is False)}")
print(f"  Skipped/failed: {len(errors)}")
print(f"{'='*70}")

# COMMAND ----------

# DBTITLE 1,Submit Annotations to Delta
# Submit all LLM_VERIFIED annotations to tbl_eval_gold_annotations
if all_annotations:
    submitted = 0
    skipped = 0
    
    for ann in all_annotations:
        annotation_id = f"LLMV_{ann['sample_id']}_{ann['field_name']}"
        
        # Check if annotation already exists
        existing = spark.sql(f"""
            SELECT annotation_id FROM {CATALOG}.{SCHEMA}.tbl_eval_gold_annotations
            WHERE annotation_id = '{annotation_id}'
        """).count()
        
        if existing > 0:
            # Idempotent re-run: replace the prior annotation row with corrected values
            spark.sql(f"""
                DELETE FROM {CATALOG}.{SCHEMA}.tbl_eval_gold_annotations
                WHERE annotation_id = '{annotation_id}'
            """)
            skipped += 1
        
        # Escape strings for SQL
        def _esc(val):
            if val is None:
                return 'NULL'
            return "'" + str(val).replace("'", "''")[:500] + "'"
        
        try:
            spark.sql(f"""
                INSERT INTO {CATALOG}.{SCHEMA}.tbl_eval_gold_annotations
                (annotation_id, sample_id, source_filename, field_category, field_name,
                 extracted_value, gold_value, is_correct, error_type, confidence_source,
                 pdf_excerpt, severity, annotator, annotation_date, pipeline_version)
                VALUES (
                    '{annotation_id}',
                    {ann['sample_id']},
                    {_esc(ann['source_filename'])},
                    {_esc(ann['field_category'])},
                    {_esc(ann['field_name'])},
                    {_esc(ann['extracted_value'])},
                    {_esc(ann['gold_value'])},
                    {str(ann['is_correct']).lower() if ann['is_correct'] is not None else 'NULL'},
                    {_esc(ann['error_type'])},
                    'LLM_VERIFIED',
                    {_esc(ann['source_excerpt'])},
                    {_esc(ann['severity'])},
                    'llm_auditor_v1',
                    CURRENT_TIMESTAMP(),
                    'v6.2'
                )
            """)
            submitted += 1
        except Exception as e:
            print(f"  \u26a0\ufe0f Failed to insert {annotation_id}: {str(e)[:60]}")
    
    print(f"\n\u2705 Annotations submitted to tbl_eval_gold_annotations:")
    print(f"   Inserted: {submitted}")
    print(f"   Replaced (updated): {skipped}")
    print(f"   Total in table now: {spark.table(f'{CATALOG}.{SCHEMA}.tbl_eval_gold_annotations').count():,}")
else:
    print("\u26a0\ufe0f No annotations to submit")

# COMMAND ----------

# DBTITLE 1,Update Sample Status + Compute Interim F1
# Update annotation_status for verified files
verified_sample_ids = list(set(a['sample_id'] for a in all_annotations))

if verified_sample_ids:
    ids_str = ', '.join(str(s) for s in verified_sample_ids)
    spark.sql(f"""
        UPDATE {CATALOG}.{SCHEMA}.tbl_eval_gold_sample
        SET annotation_status = 'IN_PROGRESS',
            annotator = 'llm_auditor_v1',
            annotation_date = CURRENT_DATE()
        WHERE sample_id IN ({ids_str})
          AND annotation_status = 'PENDING'
    """)
    print(f"\u2705 Updated {len(verified_sample_ids)} samples to IN_PROGRESS")

# Compute interim F1 from LLM_VERIFIED annotations
print(f"\n{'='*70}")
print(f"  INTERIM F1 SCORES (LLM_VERIFIED only)")
print(f"{'='*70}")

f1_data = spark.sql(f"""
    SELECT 
        field_category,
        COUNT(*) as total,
        SUM(CASE WHEN is_correct = TRUE THEN 1 ELSE 0 END) as tp,
        SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END) as fp,
        SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END) as fn,
        ROUND(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) * 1.0 / 
              NULLIF(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + 
                     SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END), 0), 3) as precision,
        ROUND(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) * 1.0 / 
              NULLIF(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + 
                     SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END), 0), 3) as recall
    FROM {CATALOG}.{SCHEMA}.tbl_eval_gold_annotations
    WHERE confidence_source = 'LLM_VERIFIED'
      AND is_correct IS NOT NULL
    GROUP BY field_category
    ORDER BY field_category
""").toPandas()

if not f1_data.empty:
    for _, row in f1_data.iterrows():
        p = row['precision'] or 0
        r = row['recall'] or 0
        f1 = 2 * p * r / (p + r) if (p + r) > 0 else 0
        print(f"  {row['field_category']:<12} P={p:.3f}  R={r:.3f}  F1={f1:.3f}  (n={row['total']})")
    
    # Overall
    total_tp = f1_data['tp'].sum()
    total_fp = f1_data['fp'].sum()
    total_fn = f1_data['fn'].sum()
    overall_p = total_tp / (total_tp + total_fp) if (total_tp + total_fp) > 0 else 0
    overall_r = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0
    overall_f1 = 2 * overall_p * overall_r / (overall_p + overall_r) if (overall_p + overall_r) > 0 else 0
    print(f"  {'OVERALL':<12} P={overall_p:.3f}  R={overall_r:.3f}  F1={overall_f1:.3f}  (n={f1_data['total'].sum()})")
else:
    print("  No LLM_VERIFIED annotations with is_correct values yet")

print(f"\n  Note: These are LLM-vs-LLM scores (automated auditor checking automated extractor).")
print(f"  Human spot-check needed to validate the auditor's accuracy.")

# COMMAND ----------

# DBTITLE 1,Summary + Next Steps
# Final summary
print(f"""
{'='*70}
  W1-2 LLM-ASSISTED ANNOTATION — SESSION SUMMARY
{'='*70}

  Files processed:     {len(set(a['sample_id'] for a in all_annotations)) if all_annotations else 0}
  Annotations created: {len(all_annotations)}
  Errors found:        {sum(1 for a in all_annotations if a['is_correct'] is False)}
  Correct confirmed:   {sum(1 for a in all_annotations if a['is_correct'] is True)}
  Files skipped:       {len(errors)}

  NEXT STEPS:
  1. Run this notebook with BATCH_SIZE=50 to complete Milestone 1
  2. Human reviewer spot-checks 20% of LLM_VERIFIED=TRUE (confirm accuracy)
  3. Human reviewer validates all LLM_VERIFIED=FALSE (provide gold_value from PDF)
  4. Run compute_f1() in platform/12_gold_annotation for official scores
  5. Update annotation_status to COMPLETE for fully-reviewed files

  ESTIMATED REMAINING EFFORT:
  - Automated (this notebook): ~45 min for all 50 files
  - Human spot-check (20% of correct): ~3 hours
  - Human review (all errors): ~5 hours
  - Total human time: ~8 hours (vs 29 hours fully manual)
{'='*70}
""")
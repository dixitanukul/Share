# Databricks notebook source
# DBTITLE 1,Define platform module paths
from pathlib import Path

BASE_PATH = Path("/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/platform")
MODULE_SPECS = [
    ("state_engine", BASE_PATH / "02_state_engine.py"),
    ("reimbursement_migration", BASE_PATH / "03_reimbursement_migration.py"),
    ("legal_chunking", BASE_PATH / "04_legal_chunking.py"),
    ("intelligence", BASE_PATH / "08_intelligence.py"),
]

print(f"Base path: {BASE_PATH}")
for module_name, module_path in MODULE_SPECS:
    print(f"{module_name}: {module_path}")

SEMANTIC_DEPENDENCY_TABLES = [
    "tbl_retrieval_legal_units",
    "tbl_intel_benchmark_results",
    "tbl_intel_provider_percentiles",
    "dim_provider_master",
    "bridge_provider_alias",
    "fact_supersession",
]


# COMMAND ----------

# DBTITLE 1,Load platform modules
import importlib.util
import sys


def load_module(module_name, module_path):
    module_path = Path(module_path)
    if not module_path.exists():
        raise FileNotFoundError(f"Module file not found: {module_path}")

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not create import spec for {module_name} from {module_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


loaded_modules = {
    module_name: load_module(module_name, module_path)
    for module_name, module_path in MODULE_SPECS
}

print("Loaded modules:", ", ".join(loaded_modules.keys()))


def assert_semantic_freshness():
    freshness_df = spark.sql("""
        SELECT table_name, last_altered
        FROM system.information_schema.tables
        WHERE table_catalog = 'dev_adb'
          AND table_schema = 'raw'
          AND table_name IN (
              'tbl_retrieval_legal_units',
              'tbl_intel_benchmark_results',
              'tbl_intel_provider_percentiles',
              'dim_provider_master',
              'bridge_provider_alias',
              'fact_supersession'
          )
        ORDER BY last_altered DESC
    """)
    display(freshness_df)

    freshness_rows = {row["table_name"]: row["last_altered"] for row in freshness_df.collect()}
    missing_tables = sorted(set(SEMANTIC_DEPENDENCY_TABLES) - set(freshness_rows))
    if missing_tables:
        raise RuntimeError(
            "Missing semantic dependency tables: " + ", ".join(missing_tables)
        )

    dependency_rules = [
        (
            "tbl_retrieval_legal_units",
            "tbl_intel_benchmark_results",
            "Benchmark aggregates must be recomputed after legal-unit updates.",
        ),
        (
            "tbl_retrieval_legal_units",
            "tbl_intel_provider_percentiles",
            "Provider percentile intelligence must be recomputed after legal-unit updates.",
        ),
        (
            "tbl_intel_benchmark_results",
            "tbl_intel_provider_percentiles",
            "Provider percentile intelligence must not lag benchmark aggregates.",
        ),
    ]

    violations = []
    for upstream, downstream, reason in dependency_rules:
        upstream_ts = freshness_rows[upstream]
        downstream_ts = freshness_rows[downstream]
        if downstream_ts < upstream_ts:
            violations.append(
                f"- {downstream} is stale vs {upstream} ({downstream_ts} < {upstream_ts}) — {reason}"
            )

    if violations:
        raise RuntimeError(
            "Semantic freshness gate failed after orchestration.\n"
            + "\n".join(violations)
            + "\n\nRebuild the stale downstream semantic tables before running reporting notebooks, dashboard updates, or Genie text refreshes."
        )

    print("Semantic freshness gate passed.")

# COMMAND ----------

# DBTITLE 1,Run platform modules in order
execution_summary = {}

for module_name, _ in MODULE_SPECS:
    module = loaded_modules[module_name]
    if not hasattr(module, "main"):
        raise AttributeError(f"Module {module_name} does not define main()")

    print(f"\nRunning {module_name}.main()")
    result = module.main()
    execution_summary[module_name] = result

    if isinstance(result, dict):
        print("Returned summary:")
        for key, value in result.items():
            print(f"  {key}: {value}")
    else:
        print(f"Returned summary: {result}")

print("\nRunning semantic freshness gate...")
assert_semantic_freshness()

print("\nExecution complete.")
execution_summary
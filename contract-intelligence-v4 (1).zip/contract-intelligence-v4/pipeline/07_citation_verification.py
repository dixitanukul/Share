"""
V2 Step 7: Citation Verification & Supersession Risk
======================================================
Post-retrieval verification layer that catches hallucinations before user-facing answers.

Capabilities:
  - P2-7: Supersession risk check (is a cited source superseded by a later amendment?)
  - Key-phrase grounding (verify citation exists in source text)
  - Numerical claim verification (detect fabricated dollar amounts)
  - Temporal state check (is cited provision from expired/superseded doc?)

Run AFTER: 05_retrieval_engine.py
Run BEFORE: Answer generation
"""

from typing import List, Dict, Optional
from dataclasses import dataclass
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"


# ============================================================
# P2-7: SUPERSESSION RISK CHECK
# ============================================================

@dataclass
class SupersessionRisk:
    """Result of supersession check for a set of cited sources."""
    has_risk: bool
    at_risk_sources: List[Dict]  # [{source_filename, scope_type, effective_date, superseding_doc}]
    warning_message: str


def check_supersession_risk(
    source_filenames: List[str],
    provider_name: Optional[str] = None
) -> SupersessionRisk:
    """Check whether any cited source documents have been superseded by later amendments.
    
    This prevents the system from citing stale rates or clauses that have been
    overridden by subsequent contract amendments.
    
    Args:
        source_filenames: List of source_filename values from retrieved/cited chunks
        provider_name: Optional provider name for scoping (not currently used but reserved)
    
    Returns:
        SupersessionRisk with risk assessment and details
    """
    if not source_filenames:
        return SupersessionRisk(has_risk=False, at_risk_sources=[], warning_message="")
    
    # SQL-injection safe: escape single quotes and build IN clause
    safe_filenames = [f.replace("'", "''") for f in source_filenames[:50]]  # cap at 50
    in_clause = ",".join(f"'{f}'" for f in safe_filenames)
    
    try:
        results = spark.sql(f"""
            WITH cited_amendments AS (
                SELECT a.contract_id, a.source_filename, a.scope_type, 
                       a.effective_date, a.amendment_order
                FROM {FQ}.tbl_v2_amendment_registry a
                WHERE a.source_filename IN ({in_clause})
            ),
            superseding AS (
                SELECT ca.source_filename AS cited_file,
                       ca.scope_type AS cited_scope,
                       ca.effective_date AS cited_date,
                       b.source_filename AS superseding_doc,
                       b.scope_type AS superseding_scope,
                       b.effective_date AS superseding_date,
                       b.amendment_order AS superseding_order
                FROM cited_amendments ca
                JOIN {FQ}.tbl_v2_amendment_registry b
                    ON  ca.contract_id = b.contract_id
                    AND b.amendment_order > ca.amendment_order
                    AND b.scope_type IN ('FULL_REPLACEMENT', 'RATE_SPECIFIC', 'EXHIBIT_SPECIFIC')
            )
            SELECT cited_file, cited_scope, cited_date,
                   superseding_doc, superseding_scope, superseding_date
            FROM superseding
            ORDER BY cited_file, superseding_date DESC
        """).collect()
    except Exception as e:
        # Non-fatal: if check fails, don't block the answer
        print(f"  [supersession] Check failed (non-fatal): {str(e)[:80]}")
        return SupersessionRisk(has_risk=False, at_risk_sources=[], warning_message="")
    
    if not results:
        return SupersessionRisk(has_risk=False, at_risk_sources=[], warning_message="")
    
    at_risk = []
    seen_files = set()
    for row in results:
        cf = row["cited_file"]
        if cf not in seen_files:
            seen_files.add(cf)
            at_risk.append({
                "source_filename": cf,
                "scope_type": row["cited_scope"],
                "effective_date": str(row["cited_date"]) if row["cited_date"] else None,
                "superseding_doc": row["superseding_doc"],
                "superseding_scope": row["superseding_scope"],
                "superseding_date": str(row["superseding_date"]) if row["superseding_date"] else None,
            })
    
    n = len(at_risk)
    warning = (
        f"\u26a0\ufe0f Supersession risk: {n} cited source(s) may have been superseded by later amendments. "
        f"Rates and terms from these documents may no longer be current. "
        f"Affected: {', '.join(r['source_filename'][:40] for r in at_risk[:3])}"
        + (f" (+{n-3} more)" if n > 3 else "")
    )
    
    return SupersessionRisk(has_risk=True, at_risk_sources=at_risk, warning_message=warning)


# ============================================================
# KEY-PHRASE GROUNDING CHECK
# ============================================================

def verify_key_phrase(key_phrase: str, passage_text: str, window: int = 20) -> bool:
    """Check if a key_phrase (or close substring) exists in the passage text.
    Uses a sliding window approach to handle minor LLM paraphrasing.
    
    Returns True if any 20-char substring of key_phrase is found in passage_text.
    """
    if not key_phrase or not passage_text:
        return True  # vacuously true
    
    kp_lower = key_phrase.lower().strip()
    pt_lower = passage_text.lower()
    
    # Exact match
    if kp_lower in pt_lower:
        return True
    
    # Sliding window: check if any window-length substring matches
    if len(kp_lower) < window:
        return kp_lower in pt_lower
    
    for i in range(0, len(kp_lower) - window + 1, window // 2):
        fragment = kp_lower[i:i + window]
        if fragment in pt_lower:
            return True
    
    return False


# ============================================================
# NUMERICAL CLAIM VERIFICATION
# ============================================================

import re

def verify_numerical_claims(claim_text: str, evidence_text: str) -> Dict:
    """Check whether dollar amounts and percentages in claim appear in evidence.
    
    Returns: {pass: bool, hallucinated_numbers: list, confidence_penalty: float}
    """
    num_pat = r'\$[\d,]+\.?\d*|\d+\.?\d*%|\d{1,3}(?:,\d{3})+'
    claim_nums = set(re.findall(num_pat, claim_text))
    evidence_nums = set(re.findall(num_pat, evidence_text))
    hallucinated = sorted(claim_nums - evidence_nums)
    return {
        "pass": len(hallucinated) == 0,
        "hallucinated_numbers": hallucinated,
        "confidence_penalty": min(0.5, len(hallucinated) * 0.15)
    }


# ============================================================
# MODULE TEST
# ============================================================
if __name__ == "__main__":
    # Test supersession check
    test_files = ["129075986_Kindred_Hospital_San_Diego_170062737_AmendLRA_v2.pdf"]
    result = check_supersession_risk(test_files)
    print(f"Supersession risk: {result.has_risk}")
    if result.at_risk_sources:
        for r in result.at_risk_sources[:3]:
            print(f"  {r['source_filename'][:40]} -> superseded by {r['superseding_doc'][:40]}")
    
    # Test key phrase
    assert verify_key_phrase("offset clause allows deduction", "The offset clause allows deduction from payments")
    assert not verify_key_phrase("completely unrelated phrase here", "This is about termination rights")
    print("\n\u2705 All verification tests passed")

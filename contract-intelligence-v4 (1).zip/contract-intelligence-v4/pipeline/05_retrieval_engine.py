"""
V2 Step 6: Hybrid Retrieval Engine
====================================
4-channel retrieval with query understanding and Reciprocal Rank Fusion.

Channels:
  1. Semantic: Vector Search against idx_legal_units_v2
  2. Lexical: ILIKE/RLIKE SQL search on tbl_retrieval_legal_units
  3. Metadata: Direct SQL against V2 rate_rules/stop_loss/escalator tables
  4. Structural: Section-aware expansion of anchor results

P1-14: Semantic channel now verifies VS index readiness before querying (cached 60s TTL).

Run AFTER: 04_legal_chunking_pipeline.py (VS index must be syncing)
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict
from datetime import datetime
import re, json, difflib, requests
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"
VS_ENDPOINT = "contract_intelligence_vs_endpoint"
VS_INDEX = f"{CATALOG}.{SCHEMA}.idx_legal_units_v2"
LLM_MODEL = "databricks-claude-sonnet-4-5"

# ============================================================
# DATA CLASSES
# ============================================================

@dataclass
class ParsedQuery:
    """Output of query understanding."""
    original: str
    intent: str  # RATE_LOOKUP | CLAUSE_SEARCH | COMPARISON | TIMELINE | GENERAL
    entities: Dict[str, List[str]] = field(default_factory=dict)
    temporal_scope: str = "CURRENT_ONLY"  # CURRENT_ONLY | HISTORICAL | AS_OF_DATE
    provider_filter: Optional[str] = None
    service_filter: Optional[str] = None
    keywords: List[str] = field(default_factory=list)


@dataclass
class ScoredChunk:
    """A retrieved legal unit with score metadata."""
    unit_id: str
    unit_text: str
    unit_type: str
    provider_name: str
    source_filename: str
    score: float
    channel: str  # semantic | lexical | metadata | structural
    is_current: bool = True
    section_type: str = ""
    rate_domain: str = ""
    effective_date: str = ""


@dataclass
class RetrievalResult:
    """Structured output of HybridRetriever.retrieve(), including evidence quality assessment."""
    results: List[ScoredChunk]
    confidence: float       # Normalised 0.0-1.0; based on top fused RRF score
    should_refuse: bool     # True when evidence is insufficient to answer safely
    message: str            # Human-readable reason shown when should_refuse=True
    provider_matched: bool  # True when provider_filter was satisfied in results


# ============================================================
# LLM HELPER  (direct REST API — avoids Spark SQL ai_query() overhead)
# ============================================================

_llm_init_done = False
_llm_endpoint: str = ""
_llm_headers: dict = {}
_known_providers_cache = None  # lazily loaded from tbl_genie_provider_profile


def _init_llm() -> None:
    """Lazy-init endpoint URL and auth header from Spark/dbutils context."""
    global _llm_init_done, _llm_endpoint, _llm_headers
    if _llm_init_done:
        return
    try:
        workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
        # dbutils is available in scope when run on Databricks compute
        token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        _llm_endpoint = f"https://{workspace_url}/serving-endpoints/{LLM_MODEL}/invocations"
        _llm_headers  = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        _llm_init_done = True
    except Exception as e:
        print(f"  [llm] Auth init failed — entity extraction will be skipped: {e}")


def _call_llm(prompt: str, max_tokens: int = 400, temperature: float = 0.0) -> str:
    """Call LLM via direct REST API. Returns response text or empty string on any failure."""
    _init_llm()
    if not _llm_endpoint:
        return ""
    try:
        payload = {
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        resp = requests.post(_llm_endpoint, headers=_llm_headers, json=payload, timeout=15)
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"]
        print(f"  [llm] HTTP {resp.status_code}: {resp.text[:120]}")
        return ""
    except Exception as e:
        print(f"  [llm] Request failed: {str(e)[:80]}")
        return ""


def _get_known_providers() -> List[str]:
    """Lazy-load and cache distinct provider names from tbl_genie_provider_profile."""
    global _known_providers_cache
    if _known_providers_cache is None:
        try:
            _known_providers_cache = (
                spark.sql(
                    f"SELECT DISTINCT provider_name "
                    f"FROM {FQ}.tbl_genie_provider_profile "
                    f"ORDER BY provider_name"
                )
                .toPandas()["provider_name"]
                .tolist()
            )
        except Exception as e:
            print(f"  [entity] Could not load provider list: {e}")
            _known_providers_cache = []
    return _known_providers_cache


def _fuzzy_match_provider(name: str, candidates: List[str], cutoff: float = 0.6) -> Optional[str]:
    """Return best matching provider name from the known list, or None.

    Strategy:
      1. Case-insensitive substring match (handles 'Dignity' matching 'Dignity Health')
      2. difflib close-match on normalised strings (handles abbreviations, typos)
    """
    if not name or not candidates:
        return None
    name_lower = name.lower().strip()
    # Pass 1: substring
    for c in candidates:
        c_lower = c.lower()
        if name_lower in c_lower or c_lower in name_lower:
            return c
    # Pass 2: fuzzy
    matches = difflib.get_close_matches(name, candidates, n=1, cutoff=cutoff)
    return matches[0] if matches else None


# ============================================================
# QUERY UNDERSTANDING
# ============================================================

def understand_query(query: str) -> ParsedQuery:
    """Classify intent and extract entities from user query."""
    q_lower = query.lower()

    # Intent classification (rule-based fast path)
    if any(kw in q_lower for kw in ["rate", "per diem", "pmpm", "case rate", "reimburse", "pay"]):
        intent = "RATE_LOOKUP"
    elif any(kw in q_lower for kw in ["clause", "provision", "section", "article", "term"]):
        intent = "CLAUSE_SEARCH"
    elif any(kw in q_lower for kw in ["compare", "difference", "versus", "vs", "higher", "lower"]):
        intent = "COMPARISON"
    elif any(kw in q_lower for kw in ["timeline", "history", "amendment", "change", "when"]):
        intent = "TIMELINE"
    else:
        intent = "GENERAL"

    # Temporal scope
    if any(kw in q_lower for kw in ["current", "latest", "active", "now"]):
        temporal = "CURRENT_ONLY"
    elif any(kw in q_lower for kw in ["history", "historical", "all versions", "over time"]):
        temporal = "HISTORICAL"
    else:
        temporal = "CURRENT_ONLY"

    # Extract keywords (simple tokenization excluding stop words)
    stop_words = {"the", "a", "an", "is", "are", "was", "what", "how", "for", "in", "of", "to", "and", "or"}
    keywords = [w for w in q_lower.split() if w not in stop_words and len(w) > 2]

    # P1-7: LLM entity extraction to populate provider_filter and service_filter.
    # These fields were always None before, causing scope leakage — a query like
    # "Dignity Health capitation rates" silently returned results from ALL 307 providers.
    # Extraction uses a 150-token LLM call (~1s) + fuzzy match against the cached provider
    # universe so mistyped names still resolve correctly. Failure is always safe (no filter).
    provider_filter: Optional[str] = None
    service_filter: Optional[str] = None

    try:
        entity_prompt = f"""Extract named entities from this healthcare contract query. Return ONLY valid JSON — no markdown, no extra text.

Query: {query}

Return exactly this shape (use null for any field not present in the query):
{{"provider_name": "...", "service_line": "...", "program": "…"}}

Examples:
- "Dignity Health capitation rates" → {{"provider_name": "Dignity Health", "service_line": null, "program": null}}
- "inpatient psychiatric rates for HMO" → {{"provider_name": null, "service_line": "psychiatric", "program": "HMO"}}
- "Medi-Cal stop-loss provisions" → {{"provider_name": null, "service_line": null, "program": "Medi-Cal"}}
- "Which contracts don't have an offset clause?" → {{"provider_name": null, "service_line": null, "program": null}}"""

        raw = _call_llm(entity_prompt, max_tokens=150)
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0]
        entities = json.loads(raw)

        # Fuzzy-match extracted provider name against known universe
        extracted_provider = (entities.get("provider_name") or "").strip()
        if extracted_provider:
            known = _get_known_providers()
            matched = _fuzzy_match_provider(extracted_provider, known)
            if matched:
                provider_filter = matched
                print(f"  [entity] Provider matched: '{extracted_provider}' → '{matched}'")
            else:
                print(
                    f"  [entity] Provider '{extracted_provider}' not found in index — "
                    "no provider filter applied (all providers will be searched)"
                )

        raw_service = (entities.get("service_line") or "").strip()
        service_filter = raw_service if raw_service else None
        if service_filter:
            print(f"  [entity] Service filter: '{service_filter}'")

    except Exception as e:
        # Never block retrieval over entity extraction failures
        print(f"  [entity] Extraction skipped ({str(e)[:80]}) — proceeding without entity filters")

    return ParsedQuery(
        original=query,
        intent=intent,
        temporal_scope=temporal,
        keywords=keywords,
        provider_filter=provider_filter,
        service_filter=service_filter,
    )


# ============================================================
# CHANNEL 1: SEMANTIC RETRIEVAL (Vector Search)
# ============================================================

# P1-14: VS index readiness check (cached with 60s TTL)
_vs_ready_cache: Dict[str, bool] = {}   # {index_name: is_ready}
_vs_ready_ts: float = 0.0               # last check timestamp
_VS_READY_TTL = 60.0                    # seconds between re-checks


def _check_vs_ready(vsc, endpoint: str, index_name: str) -> bool:
    """Verify VS index is ONLINE and synced before querying.

    P1-14: If index is still syncing (<100%) or offline, semantic channel
    returns empty results rather than silently returning partial/stale data.
    Result is cached for 60s to avoid per-query API overhead.
    """
    import time as _time
    global _vs_ready_cache, _vs_ready_ts

    now = _time.time()
    if now - _vs_ready_ts < _VS_READY_TTL and index_name in _vs_ready_cache:
        return _vs_ready_cache[index_name]

    try:
        index_obj = vsc.get_index(endpoint_name=endpoint, index_name=index_name)
        # SDK returns dict with status info; the describe_index path may vary
        # Use the index object itself — if get_index succeeds, query readiness via describe
        desc = index_obj.describe()
        status = desc.get("status", {})
        # Check both endpoint readiness and index sync state
        is_ready = status.get("ready", False)
        # detailed_state is the primary field (ONLINE_NO_PENDING_UPDATE, ONLINE_TRIGGERED_UPDATE, etc.)
        detailed_state = status.get("detailed_state", "")
        # Fallback: older SDK versions nest under index_status.status
        index_status = status.get("index_status", {}).get("status", detailed_state)
        # ONLINE* states are queryable; PROVISIONING / INITIALIZING are not
        queryable = is_ready or index_status.startswith("ONLINE") or detailed_state.startswith("ONLINE")
        _vs_ready_cache[index_name] = queryable
        _vs_ready_ts = now
        if not queryable:
            print(f"  [semantic] VS index not ready: detailed_state={detailed_state}, ready={is_ready}")
        return queryable
    except Exception as e:
        # If describe fails, fall through to attempt query anyway (graceful degradation)
        print(f"  [semantic] VS readiness check failed ({str(e)[:60]}), attempting query anyway")
        _vs_ready_cache[index_name] = True  # optimistic fallthrough
        _vs_ready_ts = now
        return True


def retrieve_semantic(parsed: ParsedQuery, top_k: int = 15) -> List[ScoredChunk]:
    """Semantic similarity search via Vector Search index."""
    from databricks.vector_search.client import VectorSearchClient
    vsc = VectorSearchClient(disable_notice=True)

    # P1-14: Pre-query readiness gate
    if not _check_vs_ready(vsc, VS_ENDPOINT, VS_INDEX):
        print("  [semantic] VS index not ready — semantic channel skipped")
        return []

    try:
        index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=VS_INDEX)
    except Exception as e:
        print(f"  [semantic] VS index not available: {str(e)[:80]}")
        return []

    # Build filters
    filters = {}
    if parsed.temporal_scope == "CURRENT_ONLY":
        filters["is_current"] = True  # P0-2 fix: boolean, not string
    if parsed.provider_filter:
        filters["provider_name"] = parsed.provider_filter

    try:
        results = index.similarity_search(
            query_text=parsed.original,
            columns=["unit_id", "unit_text", "unit_type", "provider_name",
                     "source_filename", "is_current", "section_type", "rate_domain",
                     "effective_date"],
            num_results=top_k,
            filters=filters if filters else None
        )
    except Exception as e:
        print(f"  [semantic] Search failed: {str(e)[:100]}")
        return []

    chunks = []
    if results and "result" in results and "data_array" in results["result"]:
        for row in results["result"]["data_array"]:
            chunks.append(ScoredChunk(
                unit_id=row[0],
                unit_text=row[1],
                unit_type=row[2],
                provider_name=row[3] or "",
                source_filename=row[4] or "",
                score=row[-1] if len(row) > 9 else 0.5,  # similarity score
                channel="semantic",
                is_current=bool(row[5]),
                section_type=row[6] or "",
                rate_domain=row[7] or "",
                effective_date=str(row[8]) if row[8] else ""
            ))
    return chunks


# ============================================================
# CHANNEL 2: LEXICAL RETRIEVAL (SQL ILIKE/RLIKE)
# ============================================================

def retrieve_lexical(parsed: ParsedQuery, top_k: int = 10) -> List[ScoredChunk]:
    """BM25-style lexical search using ILIKE on legal units.

    P1-6 fix: changed AND-conjunction to OR with keyword_score ranking.
    AND required ALL keywords to appear in a single chunk — synonymous
    phrasings (e.g. 'failure to pay' vs 'non-payment') would silently
    return 0 results. OR matches ANY keyword; keyword_score ranks by
    how many keywords matched, replicating BM25-style relevance ordering.
    """
    if not parsed.keywords:
        return []

    # P0-3 pattern: escape single quotes to prevent SQL injection
    def _esc(s: str) -> str:
        return s.replace("'", "''")

    # Up to 8 keywords (OR is far cheaper than AND; more synonyms = better recall)
    kws = [_esc(kw) for kw in parsed.keywords[:8]]
    num_kws = len(kws) or 1

    # P1-6 fix: OR (match ANY keyword) instead of AND (required ALL keywords)
    conditions = " OR ".join([
        f"unit_text ILIKE '%{kw}%'" for kw in kws
    ])

    # keyword_score: counts how many distinct keywords match in a single chunk.
    # Chunks matching more keywords rank higher — approximates BM25 term frequency.
    score_expr = " + ".join([
        f"CASE WHEN unit_text ILIKE '%{kw}%' THEN 1 ELSE 0 END"
        for kw in kws
    ])

    current_filter = "AND is_current = TRUE" if parsed.temporal_scope == "CURRENT_ONLY" else ""

    # Fetch top_k * 3 rows then trim: ORDER BY keyword_score ensures the most
    # relevant chunks (most keyword hits) float to the top before the LIMIT.
    # LENGTH > 50 filters out header-only chunks (noise — no substantive text).
    query = f"""
        SELECT unit_id, unit_text, unit_type, provider_name, source_filename,
               is_current, section_type, rate_domain, effective_date,
               ({score_expr}) AS keyword_score
        FROM {FQ}.tbl_retrieval_legal_units
        WHERE ({conditions})
          AND LENGTH(unit_text) > 50
        {current_filter}
        ORDER BY keyword_score DESC
        LIMIT {top_k * 3}
    """

    try:
        rows = spark.sql(query).collect()
    except Exception as e:
        print(f"  [lexical] Query failed: {str(e)[:100]}")
        return []

    chunks = []
    for row in rows[:top_k]:
        # Normalize keyword_score to [0.4, 0.9]:
        #   1/n keywords matched => 0.4 + (1/n)*0.5
        #   all keywords matched => 0.9
        kw_score = int(row["keyword_score"])
        score = min(0.9, 0.4 + (kw_score / num_kws) * 0.5)
        chunks.append(ScoredChunk(
            unit_id=row["unit_id"],
            unit_text=row["unit_text"],
            unit_type=row["unit_type"],
            provider_name=row["provider_name"] or "",
            source_filename=row["source_filename"] or "",
            score=score,
            channel="lexical",
            is_current=bool(row["is_current"]),
            section_type=row["section_type"] or "",
            rate_domain=row["rate_domain"] or "",
            effective_date=str(row["effective_date"]) if row["effective_date"] else ""
        ))
    return chunks


# ============================================================
# CHANNEL 3: METADATA RETRIEVAL (Structured SQL on V2 tables)
# ============================================================

def retrieve_metadata(parsed: ParsedQuery, top_k: int = 10) -> List[ScoredChunk]:
    """Direct SQL against V2 structured tables for rate lookups and comparisons.
    P2-8: Now fires for RATE_LOOKUP, COMPARISON, and ANALYSIS intents."""
    if parsed.intent not in ("RATE_LOOKUP", "COMPARISON", "ANALYSIS"):
        return []

    # Build provider/service filters
    where_clauses = ["1=1"]
    if parsed.provider_filter:
        where_clauses.append(f"rr.provider_name ILIKE '%{parsed.provider_filter}%'")
    if parsed.service_filter:
        where_clauses.append(f"rr.service_category_raw ILIKE '%{parsed.service_filter}%'")
    # Keyword matching on service line
    for kw in parsed.keywords[:3]:
        if kw not in ("rate", "rates", "current", "provider"):
            where_clauses.append(
                f"(rr.service_category_raw ILIKE '%{kw}%' OR rr.provider_name ILIKE '%{kw}%')"
            )

    where = " AND ".join(where_clauses)

    query = f"""
        SELECT rr.rule_id, rr.provider_name, rr.service_category_raw,
               rr.rate_domain, rr.rate_text, rr.rate_numeric, rr.formula_type,
               rr.program, rr.network, rr.source_filename, rr.effective_date
        FROM {FQ}.tbl_reimb_rate_rules rr
        WHERE {where}
        LIMIT {top_k}
    """

    try:
        rows = spark.sql(query).collect()
    except Exception as e:
        print(f"  [metadata] Query failed: {str(e)[:100]}")
        return []

    chunks = []
    for i, row in enumerate(rows):
        text = (f"Provider: {row['provider_name']}\n"
                f"Service: {row['service_category_raw']}\n"
                f"Rate: {row['rate_text'] or row['rate_numeric']}\n"
                f"Domain: {row['rate_domain']}, Formula: {row['formula_type']}\n"
                f"Program: {row['program']}, Network: {row['network']}")
        chunks.append(ScoredChunk(
            unit_id=row["rule_id"],
            unit_text=text,
            unit_type="RATE_TABLE",
            provider_name=row["provider_name"] or "",
            source_filename=row["source_filename"] or "",
            score=0.9 - (i * 0.03),
            channel="metadata",
            is_current=True,
            rate_domain=row["rate_domain"] or "",
            effective_date=str(row["effective_date"]) if row["effective_date"] else ""
        ))
    return chunks


# ============================================================
# CHANNEL 4: STRUCTURAL EXPANSION
# ============================================================

def retrieve_structural(parsed: ParsedQuery, anchors: List[ScoredChunk], top_k: int = 5) -> List[ScoredChunk]:
    """Expand anchor results to include sibling sections from same document."""
    if not anchors:
        return []

    # Get source filenames and section types from top anchors
    anchor_files = list(set(c.source_filename for c in anchors[:5]))
    if not anchor_files:
        return []

    file_list = ",".join([f"'{f}'" for f in anchor_files[:3]])
    existing_ids = set(c.unit_id for c in anchors)

    query = f"""
        SELECT unit_id, unit_text, unit_type, provider_name, source_filename,
               is_current, section_type, rate_domain, effective_date
        FROM {FQ}.tbl_retrieval_legal_units
        WHERE source_filename IN ({file_list})
          AND unit_id NOT IN ({','.join([f"'{uid}'" for uid in list(existing_ids)[:20]])})
        LIMIT {top_k}
    """

    try:
        rows = spark.sql(query).collect()
    except Exception as e:
        print(f"  [structural] Query failed: {str(e)[:100]}")
        return []

    return [ScoredChunk(
        unit_id=row["unit_id"],
        unit_text=row["unit_text"],
        unit_type=row["unit_type"],
        provider_name=row["provider_name"] or "",
        source_filename=row["source_filename"] or "",
        score=0.5,
        channel="structural",
        is_current=bool(row["is_current"]),
        section_type=row["section_type"] or "",
        rate_domain=row["rate_domain"] or "",
        effective_date=str(row["effective_date"]) if row["effective_date"] else ""
    ) for row in rows]


# ============================================================
# RECIPROCAL RANK FUSION
# ============================================================

def fuse_results(channels: List[List[ScoredChunk]], parsed: ParsedQuery, k: int = 60) -> List[ScoredChunk]:
    """Reciprocal Rank Fusion with intent-weighted channel blending."""
    # Intent-specific channel weights
    WEIGHTS = {
        "RATE_LOOKUP": {"semantic": 0.2, "lexical": 0.1, "metadata": 0.6, "structural": 0.1},
        "CLAUSE_SEARCH": {"semantic": 0.5, "lexical": 0.25, "metadata": 0.05, "structural": 0.2},
        "COMPARISON": {"semantic": 0.3, "lexical": 0.2, "metadata": 0.4, "structural": 0.1},
        "TIMELINE": {"semantic": 0.3, "lexical": 0.2, "metadata": 0.2, "structural": 0.3},
        "GENERAL": {"semantic": 0.4, "lexical": 0.3, "metadata": 0.1, "structural": 0.2},
    }
    weights = WEIGHTS.get(parsed.intent, WEIGHTS["GENERAL"])

    # RRF scoring
    rrf_scores: Dict[str, float] = {}
    chunk_map: Dict[str, ScoredChunk] = {}

    for channel_results in channels:
        channel_name = channel_results[0].channel if channel_results else "unknown"
        weight = weights.get(channel_name, 0.1)

        for rank, chunk in enumerate(channel_results, 1):
            rrf = weight * (1.0 / (k + rank))
            rrf_scores[chunk.unit_id] = rrf_scores.get(chunk.unit_id, 0) + rrf
            if chunk.unit_id not in chunk_map:
                chunk_map[chunk.unit_id] = chunk

    # Sort by fused score
    sorted_ids = sorted(rrf_scores.keys(), key=lambda uid: rrf_scores[uid], reverse=True)

    results = []
    for uid in sorted_ids:
        chunk = chunk_map[uid]
        chunk.score = rrf_scores[uid]
        results.append(chunk)

    return results


# ============================================================
# P1-18: TELEMETRY LOGGING
# ============================================================

def _log_telemetry(
    query: str,
    provider_filter: Optional[str],
    intent: str,
    result_count: int,
    confidence: float,
    should_refuse: bool,
    latency_ms: int,
    channels_used: List[str],
    channel_counts: Dict[str, int],
    provider_matched: bool,
) -> None:
    """Insert one telemetry row per retrieve() call. Fire-and-forget (never raises)."""
    try:
        safe_query = query.replace("'", "''")[:2000]  # truncate + escape
        safe_provider = (provider_filter or "").replace("'", "''")
        channels_json = json.dumps(channels_used)
        counts_json = json.dumps(channel_counts)
        spark.sql(f"""
            INSERT INTO {FQ}.tbl_retrieval_telemetry (
                query_id, timestamp, query_text, provider_filter, intent,
                result_count, confidence_score, should_refuse, latency_ms,
                channels_used, channel_counts, provider_matched
            ) VALUES (
                sha2(concat_ws('|', current_timestamp(), '{safe_query}'), 256),
                current_timestamp(),
                '{safe_query}',
                NULLIF('{safe_provider}', ''),
                '{intent}',
                {result_count},
                {confidence:.4f},
                {str(should_refuse).lower()},
                {latency_ms},
                '{channels_json}',
                '{counts_json}',
                {str(provider_matched).lower()}
            )
        """)
    except Exception as e:
        # Telemetry must never block retrieval
        print(f"  [telemetry] Write failed (non-fatal): {str(e)[:80]}")


# ============================================================
# MAIN RETRIEVAL FUNCTION
# ============================================================

class HybridRetriever:
    """Main retrieval orchestrator."""

    def retrieve(self, query: str, provider_id: str = None, top_k: int = 30) -> RetrievalResult:
        """Full hybrid retrieval pipeline with P1-18 telemetry logging."""
        import time as _time
        _t0 = _time.time()

        # 1. Query understanding
        parsed = understand_query(query)
        if provider_id:
            parsed.provider_filter = provider_id

        # 2. Multi-channel retrieval (P2-4: parallel execution)
        from concurrent.futures import ThreadPoolExecutor, as_completed as _as_completed

        semantic, lexical, metadata = [], [], []
        with ThreadPoolExecutor(max_workers=3) as _pool:
            _futures = {
                _pool.submit(retrieve_semantic, parsed, 15): "semantic",
                _pool.submit(retrieve_lexical, parsed, 10): "lexical",
                _pool.submit(retrieve_metadata, parsed, 10): "metadata",
            }
            for _fut in _as_completed(_futures, timeout=10):
                _ch = _futures[_fut]
                try:
                    _res = _fut.result()
                    if _ch == "semantic":
                        semantic = _res
                    elif _ch == "lexical":
                        lexical = _res
                    else:
                        metadata = _res
                except Exception as _e:
                    print(f"  [retrieval] Channel {_ch} failed: {str(_e)[:80]}")

        # Structural depends on semantic results (sequential)
        structural = retrieve_structural(parsed, semantic[:5], top_k=5)

        # 3. Fusion
        all_channels = [ch for ch in [semantic, lexical, metadata, structural] if ch]
        channel_counts = {
            "semantic": len(semantic), "lexical": len(lexical),
            "metadata": len(metadata), "structural": len(structural)
        }
        channels_used = [k for k, v in channel_counts.items() if v > 0]

        if not all_channels:
            _log_telemetry(
                query, provider_id, parsed.intent, 0, 0.0, True,
                int((_time.time() - _t0) * 1000), [], channel_counts, False
            )
            return RetrievalResult(
                results=[], confidence=0.0, should_refuse=True,
                message=(
                    f"No contract data found for query: '{query}'. "
                    "Ensure the Vector Search index is synced and the provider name matches exactly."
                ),
                provider_matched=False
            )

        fused = fuse_results(all_channels, parsed)[:top_k]

        # 4. Evidence gate — refuse rather than fabricate when signal is too weak
        # RRF scores with k=60: a single channel top-1 result scores weight*(1/61) ≈ 0.0033-0.0098.
        # Anything above 0.010 indicates at least one channel matched with decent rank.
        SCORE_THRESHOLD = 0.010
        max_score = max((c.score for c in fused), default=0.0)

        provider_matched = True
        if provider_id:
            pid_lower = provider_id.lower()
            provider_matched = any(
                pid_lower in c.provider_name.lower() or pid_lower in c.source_filename.lower()
                for c in fused
            )

        if max_score < SCORE_THRESHOLD:
            _log_telemetry(
                query, provider_id, parsed.intent, len(fused), 0.0, True,
                int((_time.time() - _t0) * 1000), channels_used, channel_counts, provider_matched
            )
            return RetrievalResult(
                results=[], confidence=0.0, should_refuse=True,
                message=(
                    f"Evidence score too low ({max_score:.4f} < {SCORE_THRESHOLD}) to answer reliably. "
                    "All retrieved passages had very weak relevance. Try rephrasing the query."
                ),
                provider_matched=provider_matched
            )

        if provider_id and not provider_matched:
            _log_telemetry(
                query, provider_id, parsed.intent, len(fused), 0.0, True,
                int((_time.time() - _t0) * 1000), channels_used, channel_counts, False
            )
            return RetrievalResult(
                results=[], confidence=0.0, should_refuse=True,
                message=(
                    f"No contract provisions found for provider '{provider_id}'. "
                    "The provider name may not match the index exactly — check spelling."
                ),
                provider_matched=False
            )

        # Normalise confidence to 0-1 relative to the threshold
        confidence = min(1.0, max_score / max(SCORE_THRESHOLD, 0.001))

        # P1-18: Log successful retrieval
        _log_telemetry(
            query, provider_id, parsed.intent, len(fused), confidence, False,
            int((_time.time() - _t0) * 1000), channels_used, channel_counts, provider_matched
        )

        return RetrievalResult(
            results=fused,
            confidence=confidence,
            should_refuse=False,
            message="",
            provider_matched=provider_matched
        )


# ============================================================
# MODULE TEST
# ============================================================
if __name__ == "__main__":
    retriever = HybridRetriever()
    results = retriever.retrieve("What is the inpatient per diem rate for Providence?")
    print(f"Retrieved {len(results)} results")
    for r in results[:5]:
        print(f"  [{r.channel}] {r.unit_type} | {r.provider_name[:20]} | score={r.score:.4f}")

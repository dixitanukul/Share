"""
platform/__init__.py — Namespace package shim.

This package shares its name with Python's stdlib `platform` module.
We forward all stdlib attributes here so code that does
    import platform; platform.system()
continues to work even with this __init__.py present.
"""
import importlib.util as _iu
import sys as _sys
import os as _os

def _load_stdlib_platform():
    """Load the real stdlib platform.py bypassing this package."""
    _this_dir = _os.path.dirname(_os.path.abspath(__file__))
    for p in _sys.path:
        if not p:
            continue
        candidate = _os.path.join(p, "platform.py")
        # Skip our own directory
        if _os.path.abspath(p) == _this_dir:
            continue
        if _os.path.abspath(p).startswith(_os.path.abspath(_this_dir)):
            continue
        if _os.path.isfile(candidate):
            spec = _iu.spec_from_file_location("__stdlib_platform__", candidate)
            if spec is not None:
                mod = _iu.module_from_spec(spec)
                spec.loader.exec_module(mod)
                return mod
    return None

_real = _load_stdlib_platform()
if _real is not None:
    _this_mod = _sys.modules[__name__]
    for _n in dir(_real):
        if not _n.startswith("__"):
            try:
                setattr(_this_mod, _n, getattr(_real, _n))
            except (AttributeError, TypeError):
                pass

# Databricks notebook source
# DBTITLE 1,Step 0.3 — Unified VS Index Rebuild
# MAGIC %md
# MAGIC # Step 0.3 — Unified VS Index Rebuild
# MAGIC **Source:** `step1_parsed_v2.parquet` (10,349 docs, 860M chars raw OCR)  
# MAGIC **Output:** `dev_adb.raw.tbl_vs_unified_ready` → `dev_adb.raw.idx_unified_v4`  
# MAGIC **Estimated runtime:** ~2 min compute + ~25 min async VS sync  
# MAGIC **Algorithm:** V2 semantic chunking (tested on 100 docs: 99.6% coverage, 0 noise, 100% overlap verified)

# COMMAND ----------

# DBTITLE 1,Configuration + Algorithm Definition
# ─── DEPENDENCIES ─────────────────────────────────────────────────────────
%pip install databricks-vectorsearch -q

# ─── CONFIGURATION ────────────────────────────────────────────────────────
PARQUET_PATH = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/data/checkpoints/step1_parsed_v2.parquet"
OUTPUT_TABLE = "dev_adb.raw.tbl_vs_unified_ready"
VS_INDEX_NAME = "dev_adb.raw.idx_unified_v4"
VS_ENDPOINT = "contract_intelligence_vs_endpoint"
EMBEDDING_MODEL = "databricks-gte-large-en"
LEGAL_UNITS_TABLE = "dev_adb.raw.tbl_retrieval_legal_units"
DOCUMENTS_MASTER_TABLE = "dev_adb.raw.tbl_contract_documents_master"

# Chunking parameters (validated on 100-doc sample)
MIN_CHUNK = 80
TARGET_CHUNK = 1200
MAX_CHUNK = 1800
OVERLAP = 150

import re
import hashlib
import pandas as pd
from typing import List

# ─── SECTION HEADER PATTERNS (contract-specific) ─────────────────────────
HEADER_PATTERNS = re.compile(
    r'^('
    r'(?:ARTICLE|SECTION|EXHIBIT|ATTACHMENT|APPENDIX|SCHEDULE|ADDENDUM)\s+[A-Z0-9IVXLC]+'
    r'|(?:AMENDMENT\s+(?:NUMBER\s+)?\d+)'
    r'|(?:RECITALS|WITNESSETH|NOW,?\s+THEREFORE|DEFINITIONS)'
    r'|(?:\d+\.\d+\.?\s+[A-Z][A-Za-z\s]{3,50})'
    r'|(?:[IVXLC]+\.\s+[A-Z][A-Z\s]{3,50})'
    r')',
    re.MULTILINE
)


def chunk_document_v2(
    full_text: str,
    num_pages: int,
    min_chunk: int = MIN_CHUNK,
    target_chunk: int = TARGET_CHUNK,
    max_chunk: int = MAX_CHUNK,
    overlap: int = OVERLAP
) -> List[dict]:
    """
    Chunk a document's full_text into semantic segments.

    Algorithm:
      1. Split on double-newline (paragraph boundaries)
      2. Pre-split oversized paragraphs on sentence boundaries
      3. Force chunk break at section headers
      4. Accumulate until max_chunk, then emit with overlap
      5. Estimate page from character position

    Validated: 99.6% content coverage, 0 noise chunks, 100% overlap integrity.
    """
    if not full_text or len(full_text.strip()) < min_chunk:
        return []

    avg_chars_per_page = len(full_text) / max(num_pages, 1)
    paragraphs = re.split(r'\n\s*\n', full_text)

    # Pre-process: split oversized paragraphs on sentence boundaries
    processed_paras = []
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(para) <= max_chunk:
            processed_paras.append(para)
        else:
            sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])|(?<=\n)(?=[A-Z])', para)
            current = ""
            for sent in sentences:
                if len(current) + len(sent) + 1 > max_chunk and current:
                    processed_paras.append(current.strip())
                    current = sent
                else:
                    current = current + " " + sent if current else sent
            if current.strip():
                processed_paras.append(current.strip())

    chunks = []
    current_text = ""
    current_start_pos = 0
    running_pos = 0
    current_section = None
    chunk_index = 0

    for para in processed_paras:
        header_match = HEADER_PATTERNS.match(para)
        is_new_section = header_match is not None
        would_exceed = len(current_text) + len(para) + 2 > max_chunk
        should_split = would_exceed or (is_new_section and len(current_text) >= min_chunk)

        if should_split and current_text:
            page_est = int(current_start_pos / avg_chars_per_page) + 1
            if len(current_text.strip()) >= min_chunk:
                chunks.append({
                    "chunk_text": current_text.strip(),
                    "page_number_est": min(page_est, num_pages),
                    "chunk_index": chunk_index,
                    "section_header": current_section,
                    "char_start": current_start_pos,
                    "content_length": len(current_text.strip()),
                })
                chunk_index += 1
            overlap_text = current_text[-overlap:] if len(current_text) > overlap else ""
            current_text = overlap_text + "\n\n" + para
            current_start_pos = running_pos - len(overlap_text)
        else:
            if current_text:
                current_text += "\n\n" + para
            else:
                current_text = para
                current_start_pos = running_pos
        if is_new_section:
            current_section = header_match.group(1).strip()
        running_pos += len(para) + 2

    # Emit final chunk
    if current_text and len(current_text.strip()) >= min_chunk:
        page_est = int(current_start_pos / avg_chars_per_page) + 1
        chunks.append({
            "chunk_text": current_text.strip(),
            "page_number_est": min(page_est, num_pages),
            "chunk_index": chunk_index,
            "section_header": current_section,
            "char_start": current_start_pos,
            "content_length": len(current_text.strip()),
        })

    return chunks


def ocr_quality_score(text: str) -> float:
    """Simple quality metric: ratio of clean chars to garbage."""
    if not text:
        return 0.0
    alpha_space = sum(c.isalpha() or c.isspace() or c.isdigit() or c in '.,;:()$%/-' for c in text)
    clean_ratio = alpha_space / len(text)
    words = [w for w in text.split() if len(w) > 3]
    garbled_words = sum(
        1 for w in words
        if not re.search(r'[aeiouAEIOU]', w)
        and not w.isupper()
        and not re.match(r'[\d$%.,]+$', w)
    )
    garble_ratio = garbled_words / max(len(words), 1)
    return round(clean_ratio * 0.7 + (1 - garble_ratio) * 0.3, 3)


print("✅ Configuration loaded. Algorithm defined.")
print(f"   Source: {PARQUET_PATH}")
print(f"   Output: {OUTPUT_TABLE}")
print(f"   VS Index: {VS_INDEX_NAME}")

# COMMAND ----------

# DBTITLE 1,Load + Chunk All Documents (Layer 1)
import time
from pyspark.sql import functions as F
from pyspark.sql.types import *

# ─── STEP 1: Load raw OCR data ───────────────────────────────────────────
print("Step 1: Loading raw OCR parquet...")
t0 = time.time()
step1_df = pd.read_parquet(PARQUET_PATH)
docs_with_text = step1_df[step1_df['text_length'] > 0]
print(f"  Loaded {len(step1_df):,} docs, {len(docs_with_text):,} with text ({time.time()-t0:.1f}s)")

# ─── STEP 2: Chunk all documents ─────────────────────────────────────────
print("\nStep 2: Chunking all documents...")
t0 = time.time()

all_chunks = []
for _, row in docs_with_text.iterrows():
    doc_chunks = chunk_document_v2(row['full_text'], row['num_pages'])
    for c in doc_chunks:
        chunk_id = hashlib.md5(f"{row['filename']}:{c['char_start']}".encode()).hexdigest()
        all_chunks.append({
            "chunk_id": chunk_id,
            "source_filename": row['filename'],
            "extraction_method": row['extraction_method'],
            "provider_folder": row['provider_folder'],
            "chunk_text": c['chunk_text'],
            "page_number_est": c['page_number_est'],
            "chunk_index": c['chunk_index'],
            "section_header": c['section_header'],
            "char_start": c['char_start'],
            "content_length": c['content_length'],
            "quality_score": ocr_quality_score(c['chunk_text']),
        })

chunking_time = time.time() - t0
chunks_pdf = pd.DataFrame(all_chunks)

print(f"  ✅ Chunked {len(docs_with_text):,} docs → {len(chunks_pdf):,} chunks ({chunking_time:.1f}s)")
print(f"  Avg chunk length: {chunks_pdf['content_length'].mean():.0f} chars")
print(f"  Chunks > 1800 (rate tables kept intact): {(chunks_pdf['content_length'] > 1800).sum():,}")
print(f"  Quality < 0.75: {(chunks_pdf['quality_score'] < 0.75).sum()}")

# Convert to Spark DataFrame
schema = StructType([
    StructField("chunk_id", StringType(), False),
    StructField("source_filename", StringType(), False),
    StructField("extraction_method", StringType(), True),
    StructField("provider_folder", StringType(), True),
    StructField("chunk_text", StringType(), False),
    StructField("page_number_est", IntegerType(), True),
    StructField("chunk_index", IntegerType(), True),
    StructField("section_header", StringType(), True),
    StructField("char_start", IntegerType(), True),
    StructField("content_length", IntegerType(), True),
    StructField("quality_score", FloatType(), True),
])

spark_chunks = spark.createDataFrame(chunks_pdf, schema=schema)
print(f"\n  Spark DataFrame: {len(chunks_pdf):,} rows created")

# COMMAND ----------

# DBTITLE 1,Metadata Enrichment + Write Delta (Layer 1 + Layer 2)
# ─── STEP 3: Metadata enrichment ───────────────────────────────────────
print("Step 3: Enriching with document metadata...")
t0 = time.time()

# Load documents_master for metadata join
# Columns: source_filename, provider_name, provider_id, doc_role, effective_date (STRING), expiration_date (STRING)
docs_master = spark.table(DOCUMENTS_MASTER_TABLE).select(
    F.col("source_filename"),
    F.col("provider_name").alias("dm_provider_name"),
    F.col("provider_id").alias("dm_provider_id"),
    F.col("doc_role"),
    F.col("effective_date").alias("dm_effective_date"),
    F.col("expiration_date"),
)

# Join chunks to metadata
layer1 = spark_chunks.join(docs_master, on="source_filename", how="left")

# Derive is_current using TRY_CAST (expiration_date is STRING with some non-ISO values)
# Fail-open: NULL expiration or unparseable dates treated as perpetually active
layer1 = layer1.withColumn(
    "is_current",
    F.when(
        F.col("expiration_date").isNull() |
        (F.expr("TRY_CAST(expiration_date AS DATE)").isNull()) |
        (F.expr("TRY_CAST(expiration_date AS DATE)") >= F.current_date()),
        F.lit(True)
    ).otherwise(F.lit(False))
)

# Build context prefix for embedding
layer1 = layer1.withColumn(
    "context_prefix",
    F.concat(
        F.lit("["),
        F.coalesce(F.col("dm_provider_name"), F.lit("Unknown")),
        F.lit(" | p."), F.col("page_number_est").cast("string"),
        F.lit(" | "), F.coalesce(F.col("doc_role"), F.lit("doc")),
        F.lit("]")
    )
).withColumn(
    "embedded_text",
    F.concat(F.col("context_prefix"), F.lit(" "), F.col("chunk_text"))
).withColumn(
    "chunk_type", F.lit("PASSAGE")
)

# Select final schema for Layer 1
layer1_final = layer1.select(
    F.col("chunk_id"),
    F.col("source_filename"),
    F.col("dm_provider_name").alias("provider_name"),
    F.col("dm_provider_id").alias("provider_id"),
    F.col("chunk_text"),
    F.col("embedded_text"),
    F.col("chunk_type"),
    F.col("page_number_est"),
    F.col("chunk_index"),
    F.col("section_header"),
    F.col("content_length"),
    F.col("quality_score"),
    F.col("extraction_method"),
    F.col("doc_role"),
    F.col("dm_effective_date").alias("effective_date"),
    F.col("is_current"),
    F.col("context_prefix"),
    F.col("char_start"),
)

layer1_count = layer1_final.count()
print(f"  Layer 1 (PASSAGE): {layer1_count:,} chunks")
print(f"  Enrichment time: {time.time()-t0:.1f}s")

# ─── STEP 4: Layer 2 — Structured legal units overlay ────────────────────
print("\nStep 4: Adding Layer 2 (structured legal units)...")

legal_units = spark.table(LEGAL_UNITS_TABLE)
legal_units_count = legal_units.count()
print(f"  Source: {LEGAL_UNITS_TABLE} ({legal_units_count:,} rows)")

# Map legal units to unified schema
# Confirmed columns: unit_id, unit_text, unit_type, source_filename, provider_id,
#   provider_name, section_type, page_start (INT), is_current (BOOLEAN),
#   effective_date (DATE), content_length (INT)
layer2 = legal_units.filter(
    F.col("content_length") >= MIN_CHUNK
).select(
    F.col("unit_id").alias("chunk_id"),
    F.col("source_filename"),
    F.col("provider_name"),
    F.col("provider_id"),
    F.col("unit_text").alias("chunk_text"),
    F.concat(
        F.lit("["),
        F.coalesce(F.col("provider_name"), F.lit("Unknown")),
        F.lit(" | "), F.coalesce(F.col("unit_type"), F.lit("unit")),
        F.lit(" | "), F.coalesce(F.col("section_type"), F.lit("")),
        F.lit("] "),
        F.col("unit_text")
    ).alias("embedded_text"),
    F.col("unit_type").alias("chunk_type"),
    F.col("page_start").alias("page_number_est"),
    F.lit(None).cast("int").alias("chunk_index"),
    F.col("section_type").alias("section_header"),
    F.col("content_length"),
    F.lit(1.0).cast("float").alias("quality_score"),
    F.lit("llm_structured").alias("extraction_method"),
    F.lit(None).cast("string").alias("doc_role"),
    # effective_date in legal_units is DATE; cast to string to match Layer 1 schema
    F.col("effective_date").cast("string").alias("effective_date"),
    F.col("is_current"),
    F.concat(
        F.lit("["),
        F.coalesce(F.col("provider_name"), F.lit("Unknown")),
        F.lit(" | "), F.coalesce(F.col("unit_type"), F.lit("unit")),
        F.lit(" | "), F.coalesce(F.col("section_type"), F.lit("")),
        F.lit("]")
    ).alias("context_prefix"),
    F.lit(None).cast("int").alias("char_start"),
)

layer2_count = layer2.count()
print(f"  Layer 2 (structured): {layer2_count:,} chunks (after min_chunk filter)")

# ─── UNION and WRITE ─────────────────────────────────────────────────────
print("\nStep 5: Writing unified table...")
t0 = time.time()

unified = layer1_final.unionByName(layer2, allowMissingColumns=False)
total_count = unified.count()
print(f"  Total unified rows: {total_count:,} (Layer 1: {layer1_count:,} + Layer 2: {layer2_count:,})")

# Write to Delta with change data feed enabled
unified.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(OUTPUT_TABLE)

# Enable change data feed for VS index sync
spark.sql(f"ALTER TABLE {OUTPUT_TABLE} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")

write_time = time.time() - t0
print(f"  ✅ Written to {OUTPUT_TABLE} ({write_time:.1f}s)")
print(f"\n{'='*60}")
print(f"  LAYER 1 (raw OCR passages): {layer1_count:,}")
print(f"  LAYER 2 (structured units): {layer2_count:,}")
print(f"  TOTAL:                       {total_count:,}")
print(f"{'='*60}")

# COMMAND ----------

# DBTITLE 1,Create VS Index
# ─── STEP 6: Create Vector Search Index ──────────────────────────────────
from databricks.vector_search.client import VectorSearchClient

vsc = VectorSearchClient()

print(f"Creating VS index: {VS_INDEX_NAME}")
print(f"  Endpoint: {VS_ENDPOINT}")
print(f"  Source: {OUTPUT_TABLE}")
print(f"  Embedding model: {EMBEDDING_MODEL}")
print(f"  Embedding column: embedded_text")

# Check if index already exists
try:
    existing = vsc.get_index(VS_ENDPOINT, VS_INDEX_NAME)
    print(f"\n  ⚠️ Index already exists. Triggering sync...")
    existing.sync()
    print(f"  ✅ Sync triggered. Monitor with:")
    print(f"     SELECT * FROM system.compute.vector_search_index_sync_status")
    print(f"     WHERE index_name = '{VS_INDEX_NAME}'")
except Exception as e:
    if "RESOURCE_NOT_FOUND" in str(e) or "not found" in str(e).lower() or "does not exist" in str(e).lower():
        print(f"\n  Creating new index...")
        vsc.create_delta_sync_index(
            endpoint_name=VS_ENDPOINT,
            index_name=VS_INDEX_NAME,
            source_table_name=OUTPUT_TABLE,
            pipeline_type="TRIGGERED",
            primary_key="chunk_id",
            embedding_source_column="embedded_text",
            embedding_model_endpoint_name=EMBEDDING_MODEL,
            columns_to_sync=[
                "chunk_id", "source_filename", "provider_name", "provider_id",
                "chunk_text", "chunk_type", "page_number_est", "section_header",
                "content_length", "quality_score", "doc_role", "is_current",
                "context_prefix"
            ]
        )
        print(f"  ✅ Index created. Initial sync in progress (~25 min for {total_count:,} chunks).")
        print(f"  Monitor with:")
        print(f"     SELECT * FROM system.compute.vector_search_index_sync_status")
        print(f"     WHERE index_name = '{VS_INDEX_NAME}'")
    else:
        raise e

print(f"\n{'='*60}")
print(f"  PIPELINE COMPLETE")
print(f"  Next: Update V4 settings.py to point to idx_unified_v4")
print(f"{'='*60}")

# COMMAND ----------

# DBTITLE 1,Validation (run after sync completes)
# ─── POST-SYNC VALIDATION (run after ~25 min) ────────────────────────────
print("Validation — run after VS index sync completes\n")

# 1. Table row count
row_count = spark.table(OUTPUT_TABLE).count()
print(f"1. Table row count: {row_count:,}")
assert row_count > 600_000, f"Expected >600K rows, got {row_count:,}"

# 2. Layer distribution
print(f"\n2. Layer distribution:")
layer_dist = spark.sql(f"""
    SELECT chunk_type, COUNT(*) as cnt,
           ROUND(AVG(content_length)) as avg_len,
           ROUND(AVG(CAST(quality_score AS DOUBLE)), 3) as avg_quality
    FROM {OUTPUT_TABLE}
    GROUP BY chunk_type
    ORDER BY cnt DESC
""")
display(layer_dist)

# 3. Provider coverage
provider_count = spark.sql(f"SELECT COUNT(DISTINCT provider_name) FROM {OUTPUT_TABLE}").first()[0]
print(f"\n3. Distinct providers: {provider_count}")
assert provider_count >= 300, f"Expected >=300 providers, got {provider_count}"

# 4. Null checks
null_checks = spark.sql(f"""
    SELECT
        SUM(CASE WHEN chunk_id IS NULL THEN 1 ELSE 0 END) as null_chunk_id,
        SUM(CASE WHEN chunk_text IS NULL THEN 1 ELSE 0 END) as null_chunk_text,
        SUM(CASE WHEN embedded_text IS NULL THEN 1 ELSE 0 END) as null_embedded_text,
        SUM(CASE WHEN provider_name IS NULL THEN 1 ELSE 0 END) as null_provider_name
    FROM {OUTPUT_TABLE}
""").first()
print(f"\n4. Null checks:")
print(f"   chunk_id NULLs: {null_checks['null_chunk_id']}")
print(f"   chunk_text NULLs: {null_checks['null_chunk_text']}")
print(f"   embedded_text NULLs: {null_checks['null_embedded_text']}")
print(f"   provider_name NULLs: {null_checks['null_provider_name']}")
assert null_checks['null_chunk_id'] == 0, "chunk_id must not be NULL"
assert null_checks['null_embedded_text'] == 0, "embedded_text must not be NULL"

# 5. VS index status
print(f"\n5. VS Index status:")
try:
    from databricks.vector_search.client import VectorSearchClient
    vsc = VectorSearchClient()
    idx = vsc.get_index(VS_ENDPOINT, VS_INDEX_NAME)
    status = idx.describe()
    idx_status = status.get('status', {})
    print(f"   Ready: {idx_status.get('ready', 'UNKNOWN')}")
    print(f"   Indexed rows: {idx_status.get('indexed_row_count', 'N/A')}")
    print(f"   Message: {idx_status.get('message', '')}")
except Exception as e:
    print(f"   Status check error: {e}")

# 6. Test query (only if index is ready)
print(f"\n6. Test search: 'inpatient per diem reimbursement rate'")
try:
    results = idx.similarity_search(
        query_text="inpatient per diem reimbursement rate",
        columns=["provider_name", "chunk_type", "chunk_text", "is_current"],
        num_results=5,
        filters={"is_current": True}
    )
    for i, row in enumerate(results.get('result', {}).get('data_array', [])):
        print(f"   [{i+1}] {row[0]} ({row[1]}): {row[2][:80]}...")
    print("\n✅ ALL VALIDATIONS PASSED")
except Exception as e:
    print(f"   Search error (index may still be syncing): {e}")
    print("\n⚠️ Validation partial — re-run this cell after sync completes")
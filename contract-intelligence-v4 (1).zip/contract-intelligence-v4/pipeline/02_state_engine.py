"""
V2 Step 4: State Engine — Contract & Amendment Registry Population
===================================================================
Populates the state engine tables from existing V1 extraction data.
Uses structural signals for deterministic scope classification.

Run AFTER: 01_execute_ddl.py
Run BEFORE: 04_legal_chunking_pipeline.py

Results (initial population):
  - tbl_v2_contract_registry: ~1,948 contracts (139+ providers)
  - tbl_v2_amendment_registry: ~1,570 amendments with scope classification
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"


def log_step(name, status, details=""):
    ts = datetime.now().strftime("%H:%M:%S")
    icon = "✓" if status == "SUCCESS" else "✗" if status == "FAILED" else "○"
    print(f"[{ts}] {icon} {name}: {status}")
    if details:
        print(f"    {details}")


def main():
    print("=" * 60)
    print("V2 STATE ENGINE — Population")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    spark.sql(f"USE CATALOG {CATALOG}")
    spark.sql(f"USE SCHEMA {SCHEMA}")

    # ============================================================
    # STEP 1: Populate Contract Registry
    # One row per unique provider × base agreement document
    # Source: tbl_contract_documents_master (base agreement rows — built by step 10)
    # ============================================================
    log_step("Contract Registry", "RUNNING")

    # P1-9 + P1-11: Replace TRUNCATE+INSERT with atomic INSERT OVERWRITE,
    # and replace 3 correlated subqueries with one pre-aggregated CTE.
    #
    # Old pattern: TRUNCATE TABLE then INSERT INTO
    #   - 3 correlated subqueries × 1,948 contracts = 5,844 full-table scans
    #   - LIMIT 1 without secondary sort = non-deterministic for tie amendment_orders
    #   - TRUNCATE + INSERT has a visibility gap (empty table between operations)
    #
    # New pattern: INSERT OVERWRITE with CTE
    #   - One GROUP BY aggregation replaces all 3 subqueries (single scan)
    #   - MAX_BY with composite struct key = fully deterministic tie-breaking:
    #       primary:   amendment_order DESC (highest amendment wins)
    #       secondary: effective_date_parsed DESC (most recent date wins)
    #       tertiary:  source_filename DESC  (lexicographic final tiebreak)
    #   - INSERT OVERWRITE is atomic on Delta — no empty-table visibility window
    spark.sql(f"""
    INSERT OVERWRITE {FQ}.tbl_v2_contract_registry (
        contract_id, provider_id, provider_name,
        agreement_type, payment_model, network_scope,
        status, effective_from, effective_to,
        auto_renewal, term_years,
        base_agreement_doc, total_amendments, latest_amendment_date, latest_amendment_doc,
        state_computed_at, state_version, computation_rule
    )
    -- P1-9: Pre-aggregate once; join replaces 3 correlated subqueries per row
    WITH amendment_stats AS (
        SELECT
            provider_id,
            COUNT(*)                                                              AS total_amendments,
            MAX(effective_date_parsed)                                            AS latest_amendment_date,
            -- Fully deterministic: highest amendment_order, then most recent date, then filename
            MAX_BY(source_filename,
                   struct(amendment_order,
                          COALESCE(effective_date_parsed, CAST('1900-01-01' AS DATE)),
                          source_filename))                                        AS latest_amendment_doc
        FROM {FQ}.tbl_contract_documents_master
        WHERE amendment_order > 0
        GROUP BY provider_id
    )
    SELECT
        sha2(concat_ws('|', a.provider_id, a.source_filename), 256) AS contract_id,
        a.provider_id,
        a.provider_name,
        CASE
            WHEN a.agreement_type ILIKE '%capitation%' THEN 'capitation'
            WHEN a.agreement_type ILIKE '%fee%service%' OR a.agreement_type ILIKE '%ffs%' THEN 'fee_for_service'
            WHEN a.agreement_type ILIKE '%settlement%' THEN 'settlement'
            ELSE 'mixed'
        END AS agreement_type,
        CASE
            WHEN a.payment_type ILIKE '%per_diem%' OR a.payment_type ILIKE '%per diem%' THEN 'per_diem'
            WHEN a.payment_type ILIKE '%case_rate%' OR a.payment_type ILIKE '%case rate%' THEN 'case_rate'
            WHEN a.payment_type ILIKE '%percentage%' OR a.payment_type ILIKE '%pct%' THEN 'percentage'
            WHEN a.payment_type ILIKE '%pmpm%' OR a.payment_type ILIKE '%capitation%' THEN 'pmpm'
            ELSE 'mixed'
        END AS payment_model,
        'commercial' AS network_scope,
        -- P2-11: Expanded contract status (SUPERSEDED, TERMINATED, EXPIRED, ACTIVE)
        CASE
            WHEN a.expiration_date_parsed IS NOT NULL
                 AND a.expiration_date_parsed < current_date()
                 AND EXISTS (
                     SELECT 1 FROM {FQ}.tbl_v2_amendment_registry ar
                     WHERE ar.contract_id = sha2(concat_ws('|', a.provider_id, a.source_filename), 256)
                       AND ar.scope_type = 'FULL_REPLACEMENT'
                       AND ar.effective_date > a.expiration_date_parsed
                 ) THEN 'SUPERSEDED'
            WHEN (LOWER(a.agreement_type) LIKE '%terminat%' OR LOWER(a.document_type) LIKE '%terminat%')
                 AND a.expiration_date_parsed IS NOT NULL
                 AND a.expiration_date_parsed < current_date() THEN 'TERMINATED'
            WHEN a.expiration_date_parsed IS NOT NULL
                 AND a.expiration_date_parsed < current_date() THEN 'EXPIRED'
            ELSE 'ACTIVE'
        END AS status,
        a.effective_date_parsed  AS effective_from,
        a.expiration_date_parsed AS effective_to,
        CASE WHEN a.auto_renewal = 'True' THEN TRUE ELSE FALSE END AS auto_renewal,
        try_cast(a.contract_term_years AS FLOAT) AS term_years,
        a.source_filename                           AS base_agreement_doc,
        COALESCE(s.total_amendments, 0)             AS total_amendments,
        s.latest_amendment_date,
        s.latest_amendment_doc,
        current_timestamp(), 1, 'v2_initial_population'
    FROM {FQ}.tbl_contract_documents_master a
    LEFT JOIN amendment_stats s ON a.provider_id = s.provider_id
    WHERE a.amendment_order = 0
       OR a.doc_role = 'base_agreement'
    QUALIFY ROW_NUMBER() OVER (PARTITION BY a.provider_id, a.source_filename ORDER BY a.amendment_order) = 1
    """)

    contract_count = spark.sql(
        f"SELECT COUNT(*) AS n FROM {FQ}.tbl_v2_contract_registry"
    ).collect()[0]["n"]
    log_step("Contract Registry", "SUCCESS", f"{contract_count} contracts")

    # ============================================================
    # STEP 2: Populate Amendment Registry with Scope Classification
    # Uses structural signals for deterministic classification
    # Columns: exhibits_replaced_count is STRING (Python list e.g. "['Exhibit A','Exhibit B']")
    #           sections_modified_count is STRING (Python list), not INT
    #           prior_rates_superseded is STRING 'True'/'False'
    #
    # P1-8 FIX: Never use LENGTH() on these columns as a proxy for element count.
    # A single exhibit with a long name (e.g. 'Exhibit A - Inpatient Hospital Services
    # Rate Schedule') has length 62 and was misclassified as FULL_REPLACEMENT.
    # Impact measured: 352/374 (94%) FULL_REPLACEMENT rows were wrong.
    #
    # Fix: convert Python single-quote list to JSON (chr(39)->chr(34)) then
    # use size(from_json(...)) to count actual list elements.
    # FULL_REPLACEMENT threshold = 5+ exhibits (vs LENGTH > 30 before).
    # ============================================================
    log_step("Amendment Registry", "RUNNING")

    # P1-11: INSERT OVERWRITE replaces TRUNCATE + INSERT for atomicity
    spark.sql(f"""
    INSERT OVERWRITE {FQ}.tbl_v2_amendment_registry (
        amendment_id, contract_id,
        source_filename, document_type, amendment_order,
        scope_type, exhibits_modified, sections_modified, rate_categories_modified,
        effective_date, execution_date,
        summary_of_changes, amendments_impact_raw,
        scope_confidence, scope_source,
        created_at, classification_rule
    )
    SELECT
        sha2(concat_ws('|', a.provider_id, a.source_filename), 256) AS amendment_id,
        sha2(concat_ws('|', a.provider_id,
            COALESCE((SELECT x.source_filename FROM {FQ}.tbl_contract_documents_master x
             WHERE x.provider_id = a.provider_id
               AND (x.amendment_order = 0 OR x.doc_category = 'Base Agreement')
             ORDER BY x.amendment_order LIMIT 1), a.source_filename)), 256) AS contract_id,
        a.source_filename,
        a.document_type,
        a.amendment_order,
        -- P1-8: Convert Python list format to JSON, then count elements.
        -- chr(39)=single-quote, chr(34)=double-quote; avoids quote escaping in f-strings.
        -- COALESCE(..., 0) handles NULL and empty-string inputs safely.
        CASE
            WHEN COALESCE(size(from_json(regexp_replace(a.exhibits_replaced_count, chr(39), chr(34)), 'ARRAY<STRING>')), 0) >= 5
              AND a.prior_rates_superseded = 'True'                                              THEN 'FULL_REPLACEMENT'
            WHEN COALESCE(size(from_json(regexp_replace(a.exhibits_replaced_count, chr(39), chr(34)), 'ARRAY<STRING>')), 0) >= 1 THEN 'EXHIBIT_SPECIFIC'
            WHEN a.prior_rates_superseded = 'True'                                              THEN 'RATE_SPECIFIC'
            WHEN COALESCE(size(from_json(regexp_replace(a.sections_modified_count,  chr(39), chr(34)), 'ARRAY<STRING>')), 0) >= 1 THEN 'SECTION_SPECIFIC'
            WHEN a.document_type ILIKE '%extension%' OR a.document_type ILIKE '%renewal%'      THEN 'TERM_EXTENSION'
            WHEN a.document_type ILIKE '%addendum%'                                             THEN 'ADDENDUM'
            WHEN a.rate_count > 10                                                              THEN 'FULL_REPLACEMENT'
            WHEN a.rate_count > 0                                                               THEN 'RATE_SPECIFIC'
            ELSE 'SECTION_SPECIFIC'
        END AS scope_type,
        -- exhibits_modified / sections_modified: carry through when at least 1 element parsed
        CASE WHEN COALESCE(size(from_json(regexp_replace(a.exhibits_replaced_count, chr(39), chr(34)), 'ARRAY<STRING>')), 0) >= 1
             THEN a.exhibits_replaced_count END,
        CASE WHEN COALESCE(size(from_json(regexp_replace(a.sections_modified_count,  chr(39), chr(34)), 'ARRAY<STRING>')), 0) >= 1
             THEN a.sections_modified_count END,
        NULL,
        a.effective_date_parsed, NULL,
        a.summary_of_changes, NULL,
        CASE
            WHEN COALESCE(size(from_json(regexp_replace(a.exhibits_replaced_count, chr(39), chr(34)), 'ARRAY<STRING>')), 0) >= 1
              OR a.prior_rates_superseded = 'True'                                              THEN 0.85
            WHEN COALESCE(size(from_json(regexp_replace(a.sections_modified_count,  chr(39), chr(34)), 'ARRAY<STRING>')), 0) >= 1 THEN 0.75
            WHEN a.document_type ILIKE '%extension%'                                            THEN 0.90
            ELSE 0.60
        END,
        'structural_signals',
        current_timestamp(), 'v2_structural_heuristic_v2'
    FROM {FQ}.tbl_contract_documents_master a
    WHERE a.amendment_order > 0
      AND a.doc_role != 'base_agreement'
    """)

    amendment_count = spark.sql(
        f"SELECT COUNT(*) AS n FROM {FQ}.tbl_v2_amendment_registry"
    ).collect()[0]["n"]
    log_step("Amendment Registry", "SUCCESS", f"{amendment_count} amendments classified")

    print("\n" + "=" * 60)
    print("STATE ENGINE COMPLETE")
    scope_dist = spark.sql(f"""
        SELECT scope_type, COUNT(*) AS cnt
        FROM {FQ}.tbl_v2_amendment_registry
        GROUP BY scope_type ORDER BY cnt DESC
    """).collect()
    print("\nAmendment scope distribution:")
    for r in scope_dist:
        print(f"  {r['scope_type']:<20} {r['cnt']:>5}")
    print("=" * 60)

    return {
        "tbl_v2_contract_registry": contract_count,
        "tbl_v2_amendment_registry": amendment_count,
        "scope_distribution": [{"scope_type": r["scope_type"], "count": r["cnt"]} for r in scope_dist],
    }


if __name__ == "__main__":
    main()

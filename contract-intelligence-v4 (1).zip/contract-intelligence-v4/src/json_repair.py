"""JSON repair utilities for LLM extraction outputs.

Handles common LLM output issues:
- Truncated JSON (output hit max_tokens)
- Unclosed brackets/braces
- Trailing commas
- Markdown code fences wrapping JSON
- Escaped/unescaped unicode issues
- Incomplete string literals
"""

import json
import re
from typing import Optional, Tuple


def clean_json_response(raw: str) -> str:
    """Strip markdown code fences and leading/trailing whitespace.
    
    Handles:
    - ```json ... ``` wrapping
    - ``` ... ``` wrapping
    - Leading/trailing whitespace
    - BOM characters
    """
    if not raw:
        return ""
    
    # Strip BOM
    text = raw.lstrip('\ufeff')
    
    # Remove markdown code fences
    text = text.strip()
    if text.startswith('```json'):
        text = text[7:]
    elif text.startswith('```'):
        text = text[3:]
    
    if text.endswith('```'):
        text = text[:-3]
    
    return text.strip()


def repair_trailing_commas(text: str) -> str:
    """Remove trailing commas before closing brackets/braces.
    
    Fixes: {"a": 1, "b": 2,} -> {"a": 1, "b": 2}
    Fixes: [1, 2, 3,] -> [1, 2, 3]
    """
    # Remove trailing commas before } or ]
    text = re.sub(r',\s*([}\]])', r'\1', text)
    return text


def repair_truncated_json(text: str) -> Tuple[str, str]:
    """Repair JSON truncated by max_tokens limit.
    
    Strategy:
    1. Count open vs close brackets/braces
    2. Truncate at last complete value
    3. Close all open containers
    
    Returns:
        Tuple of (repaired_json, repair_strategy)
        repair_strategy: 'none', 'bracket_close', 'truncation_fix', 'string_close'
    """
    if not text:
        return '{}', 'empty_input'
    
    # Try parsing as-is first
    try:
        json.loads(text)
        return text, 'none'
    except json.JSONDecodeError:
        pass
    
    # Strategy 1: Fix trailing commas
    fixed = repair_trailing_commas(text)
    try:
        json.loads(fixed)
        return fixed, 'trailing_comma'
    except json.JSONDecodeError:
        pass
    
    # Strategy 2: Close unclosed string literals
    repaired = _close_unclosed_strings(fixed)
    try:
        json.loads(repaired)
        return repaired, 'string_close'
    except json.JSONDecodeError:
        pass
    
    # Strategy 3: Truncate to last complete value + close brackets
    repaired = _truncate_and_close(fixed)
    try:
        json.loads(repaired)
        return repaired, 'truncation_fix'
    except json.JSONDecodeError:
        pass
    
    # Strategy 4: Simple bracket closing
    repaired = _close_brackets(fixed)
    try:
        json.loads(repaired)
        return repaired, 'bracket_close'
    except json.JSONDecodeError:
        pass
    
    # Last resort: return minimal valid JSON
    return '{"_repair_failed": true, "_original_length": ' + str(len(text)) + '}', 'repair_failed'


def _close_unclosed_strings(text: str) -> str:
    """Close unclosed string literals at end of truncated JSON."""
    # Check if we're inside an unclosed string
    in_string = False
    escape_next = False
    
    for char in text:
        if escape_next:
            escape_next = False
            continue
        if char == '\\':
            escape_next = True
            continue
        if char == '"':
            in_string = not in_string
    
    if in_string:
        # We're inside an unclosed string — close it
        text = text.rstrip() + '"'
    
    return text


def _truncate_and_close(text: str) -> str:
    """Truncate at last complete JSON value, then close containers."""
    # Find the last complete value boundary
    # Look for last comma, closing bracket, or closing brace that's followed by something incomplete
    
    # Remove any trailing incomplete key-value pair
    # Pattern: text ends with "key": <incomplete value>
    pattern_kv = r',\s*"[^"]*"\s*:\s*[^,}\]]*\Z'
    truncated = re.sub(pattern_kv, "", text)
    
    # Remove trailing incomplete array element
    pattern_elem = r',\s*[^,}\]]*\Z'
    truncated = re.sub(pattern_elem, "", truncated)
    
    # Fix trailing commas created by truncation
    truncated = repair_trailing_commas(truncated)
    
    return _close_brackets(truncated)


def _close_brackets(text: str) -> str:
    """Close all unclosed brackets and braces."""
    # Count open containers (respecting strings)
    stack = []
    in_string = False
    escape_next = False
    
    for char in text:
        if escape_next:
            escape_next = False
            continue
        if char == '\\':
            escape_next = True
            continue
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char == '{':
            stack.append('}')
        elif char == '[':
            stack.append(']')
        elif char in ('}', ']'):
            if stack and stack[-1] == char:
                stack.pop()
    
    # Close all remaining open containers
    return text + ''.join(reversed(stack))


def repair_llm_json_final(raw_response: str) -> Tuple[Optional[dict], str]:
    """Full repair pipeline: clean -> repair -> parse.
    
    This is the main entry point called by extraction notebooks.
    
    Args:
        raw_response: Raw LLM output string (may include markdown fences, be truncated, etc.)
    
    Returns:
        Tuple of (parsed_dict_or_None, repair_strategy)
    """
    if not raw_response or not raw_response.strip():
        return None, 'empty_input'
    
    # Step 1: Clean markdown fences and whitespace
    cleaned = clean_json_response(raw_response)
    
    if not cleaned:
        return None, 'empty_after_clean'
    
    # Step 2: Try direct parse
    try:
        return json.loads(cleaned), 'none'
    except json.JSONDecodeError:
        pass
    
    # Step 3: Attempt repair
    repaired, strategy = repair_truncated_json(cleaned)
    
    try:
        return json.loads(repaired), strategy
    except json.JSONDecodeError:
        return None, 'repair_failed'

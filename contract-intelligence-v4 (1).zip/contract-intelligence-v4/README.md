# Contract Intelligence V4

A FastAPI + React application that lets Blue Shield of California contract operations
teams query provider contract data in natural language.

Built on Databricks Apps. Backed by Unity Catalog tables in `dev_adb.raw`.

---

## Architecture

```
contract-intelligence-v4/
├── app/                        FastAPI application
│   ├── main.py                 Entry point — routes, lifespan, streaming
│   ├── sql_client.py           Statement Execution API wrapper
│   └── middleware/
│       └── circuit_breaker.py  SQL / VS / LLM circuit breakers
│
├── platform/v4/                Core backend package
│   ├── core/                   Agent orchestration
│   │   ├── agent_controller.py ReAct loop — reason → tool → observe → answer
│   │   ├── context_manager.py  Multi-turn session state and context injection
│   │   ├── question_router.py  Routes questions to the right tool
│   │   ├── question_decomposer.py Breaks complex questions into sub-questions
│   │   ├── hallucination_guard.py Post-generation grounding checks
│   │   ├── planning.py         Plan types and decomposition helpers
│   │   ├── response_assembler.py Assembles sub-question answers into final response
│   │   ├── cost_controller.py  LLM budget tracking
│   │   ├── provenance.py       Source tracing for answers
│   │   └── current_effective_filter.py  is_current / effective-date helpers
│   │
│   ├── tools/                  One file per tool the agent can invoke
│   │   ├── rate_query.py       Provider reimbursement rates
│   │   ├── sql_query.py        General structured SQL queries
│   │   ├── field_extraction.py DOFR matrix and structured field extraction
│   │   ├── compliance_query.py Compliance tracking, quality, notifications
│   │   ├── clause_existence_tool.py  Clause presence detection
│   │   ├── clause_text.py      Verbatim clause text retrieval
│   │   ├── risk_alert.py       Risk scores, alerts, deadlines
│   │   ├── financial_analysis.py Contracted spend, repricing, escalators
│   │   ├── system_membership.py  Health system membership, service areas
│   │   ├── provenance.py       Extraction provenance queries
│   │   ├── temporal_analysis.py Amendment timeline and rate history
│   │   ├── passage_search.py   Vector search over contract text
│   │   ├── comparison.py       Side-by-side provider comparisons
│   │   ├── provider_deep_dive.py Full provider profile deep-dives
│   │   ├── genie_query.py      Databricks Genie integration
│   │   ├── registry.py         Tool registry and dispatch
│   │   └── ...                 (other tools: summarize, calculate, export, etc.)
│   │
│   ├── contracts/              Pydantic types shared across layers
│   ├── config/                 Settings, table whitelist, tool policies
│   ├── data/                   Repo layer — sessions, feedback, telemetry
│   ├── services/               Shared services — retrieval, citation, grounding
│   ├── adapters/               Legacy compatibility adapters
│   ├── presentation/           HTML/Excel report rendering
│   └── runtime/                Startup, LLM client, notebook entry point
│
├── pipeline/                   Data extraction and ETL pipeline scripts
│   ├── 00_config.py            Environment and catalog configuration
│   ├── 01_execute_ddl.py       Schema creation (DDL)
│   ├── 02_state_engine.py      Document state machine
│   ├── 03_reimbursement_migration.py  Rate data migration
│   ├── 04_legal_chunking.py    Contract PDF chunking
│   ├── 05_retrieval_engine.py  Vector search index build
│   └── ...                     (08-20: evaluation, annotation, observability)
│
├── pipelines/
│   └── service_category_normalization.py  Service category standardization
│
├── src/                        Utilities used by pipeline scripts
│   ├── chunking.py             PDF chunking helpers
│   ├── json_repair.py          LLM JSON output repair
│   └── validation.py           Extraction schema validation
│
├── platform/v4/tests/          Unit and integration tests
├── docs/                       Reference documentation (see below)
│
├── app.yaml                    Databricks Apps manifest
├── requirements.txt            Python dependencies
├── conftest.py                 pytest root configuration
└── .databricksignore           Files excluded from app deployment
```

---

## Key Reference Docs

| File | Contents |
|---|---|
| `docs/DATA_MODEL_COMPLETE_STATE.md` | Authoritative schema for all 35 production tables |
| `docs/DATA_MODEL_PRODUCTION_STATE.md` | Production table reference with row counts |
| `docs/ER_DIAGRAM.md` | Entity-relationship diagram (Mermaid) |
| `docs/TABLE_INVENTORY_GROUPED.md` | Grouped table inventory with column details |
| `docs/DATA_SLO.md` | Data SLA and freshness contract |

---

## Data

All tables live in `dev_adb.raw`. Key tables:

| Table | Description |
|---|---|
| `tbl_genie_provider_profile` | 306 providers, 194 active |
| `tbl_contract_rates_all` | 459,902 rate rows |
| `tbl_contract_clauses` | 7,863 clause rows, 21 categories |
| `tbl_dofr_matrix_extracted` | 1,821 DOFR matrix rows |
| `tbl_compliance_tracking` | 2,871 compliance rows, 7 regulations |
| `tbl_delegation_matrix` | 770 delegation rows, 119 providers |
| `tbl_contract_risk_scores` | Risk tiers: LOW 239, MEDIUM 26, MONITOR 7 |
| `tbl_alert_queue` | 351 active alerts |
| `tbl_financial_exposure` | Contracted spend by provider |
| `dim_health_system` | 20 health systems |
| `tbl_service_areas` | 306 provider service areas |

---

## Deployment

The app runs on Databricks Apps (SNAPSHOT mode). Redeploy after any code change:

```python
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.apps import AppDeployment, AppDeploymentMode

WorkspaceClient().apps.deploy(
    app_name='contract-intelligence',
    app_deployment=AppDeployment(
        mode=AppDeploymentMode.SNAPSHOT,
        source_code_path='/Workspace/Users/<your-user>/contract-intelligence-v4'
    )
)
```

The `app.yaml` manifest configures the SQL warehouse, LLM endpoints, and environment.

---

## Running Tests

Tests use the in-process FastAPI `TestClient` — no live HTTP required:

```bash
# From notebook (preferred): run cells in
# Contract_Intelligence_Comprehensive_Test_Suite

# From CLI (unit tests only):
pytest platform/v4/tests/ -m "not live" -q
```

---

## Environment

- **Catalog / Schema**: `dev_adb.raw` (set via `APP_CATALOG` / `APP_SCHEMA` env vars)
- **LLM**: `databricks-claude-sonnet-4-6` (primary), `databricks-claude-haiku-4-5` (fast)
- **Vector Search endpoint**: `contract_intelligence_vs_endpoint`
- **SQL Warehouse**: `2c99c6485f03ee73`

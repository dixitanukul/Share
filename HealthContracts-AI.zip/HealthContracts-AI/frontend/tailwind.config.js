/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Healthcare-themed palette
        'hc-primary':   '#1e40af',  // Blue-800
        'hc-secondary': '#0d9488',  // Teal-600
        'hc-accent':    '#7c3aed',  // Violet-600
        'hc-surface':   '#f8fafc',  // Slate-50
        'hc-danger':    '#dc2626',  // Red-600
        'hc-warning':   '#d97706',  // Amber-600
        'hc-success':   '#16a34a',  // Green-600
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
    },
  },
  plugins: [],
}
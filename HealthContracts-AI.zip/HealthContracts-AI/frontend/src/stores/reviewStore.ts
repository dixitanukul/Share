import { create } from 'zustand';
import type { ReviewItem, ReviewFilters, ReviewStats } from '@/lib/types';

interface ReviewState {
  queueItems: ReviewItem[];
  currentItem: ReviewItem | null;
  filters: ReviewFilters;
  batchSelection: string[];
  stats: ReviewStats | null;

  setQueue: (items: ReviewItem[]) => void;
  setCurrentItem: (item: ReviewItem | null) => void;
  setFilters: (filters: ReviewFilters) => void;
  toggleBatchSelect: (id: string) => void;
  selectAll: (ids: string[]) => void;
  clearSelection: () => void;
  setStats: (stats: ReviewStats) => void;
  updateItemOptimistic: (id: string, updates: Partial<ReviewItem>) => void;
}

export const useReviewStore = create<ReviewState>((set) => ({
  queueItems: [],
  currentItem: null,
  filters: {},
  batchSelection: [],
  stats: null,

  setQueue: (items) => set({ queueItems: items }),
  setCurrentItem: (item) => set({ currentItem: item }),
  setFilters: (filters) => set({ filters }),

  toggleBatchSelect: (id) =>
    set((s) => ({
      batchSelection: s.batchSelection.includes(id)
        ? s.batchSelection.filter((x) => x !== id)
        : [...s.batchSelection, id],
    })),

  selectAll: (ids) => set({ batchSelection: ids }),
  clearSelection: () => set({ batchSelection: [] }),
  setStats: (stats) => set({ stats }),

  updateItemOptimistic: (id, updates) =>
    set((s) => ({
      queueItems: s.queueItems.map((item) =>
        item.review_id === id ? { ...item, ...updates } : item,
      ),
      currentItem:
        s.currentItem?.review_id === id
          ? { ...s.currentItem, ...updates }
          : s.currentItem,
    })),
}));

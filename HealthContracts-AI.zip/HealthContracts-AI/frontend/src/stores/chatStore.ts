/**
 * Chat store — Zustand store for conversations, messages, and streaming state.
 */
import { create } from 'zustand';
import { api } from '../lib/api';
import { ROUTES } from '../lib/constants';

export interface Citation {
  document: string;
  page: number;
  section?: string;
  text: string;
  trustBadge?: string;
}

export interface ToolCall {
  tool: string;
  args: Record<string, unknown>;
  result?: Record<string, unknown>;
}

export interface ChatMessage {
  messageId: string;
  role: 'user' | 'assistant';
  content: string;
  citations: Citation[];
  toolCalls: ToolCall[];
  trustBadge?: string;
  routeUsed?: string;
  modelUsed?: string;
  latencyMs?: number;
  groundednessScore?: number | null;
  groundednessWarning?: string | null;
  feedbackRating?: string | null;
  suggestedFollowups?: string[];
  createdAt: string;
}

export interface Conversation {
  conversationId: string;
  scopeType: string;
  scopeId?: string;
  title?: string;
  messageCount: number;
  createdAt: string;
  lastMessageAt?: string;
}

interface ChatState {
  conversations: Conversation[];
  activeConversationId: string | null;
  messages: Record<string, ChatMessage[]>;
  isStreaming: boolean;
  currentStreamText: string;
  scope: { type: string; id?: string };
  error: string | null;

  setActiveConversation: (id: string | null) => void;
  setScope: (type: string, id?: string) => void;
  setStreaming: (streaming: boolean) => void;
  setStreamText: (text: string) => void;
  appendStreamText: (chunk: string) => void;
  addMessage: (convId: string, message: ChatMessage) => void;
  setConversations: (convs: Conversation[]) => void;
  setError: (error: string | null) => void;
  submitFeedback: (messageId: string, rating: string, comment?: string) => Promise<void>;
  reset: () => void;
}

export const useChatStore = create<ChatState>((set) => ({
  conversations: [],
  activeConversationId: null,
  messages: {},
  isStreaming: false,
  currentStreamText: '',
  scope: { type: 'all' },
  error: null,

  setActiveConversation: (id) => set({ activeConversationId: id }),
  setScope: (type, id) => set({ scope: { type, id } }),
  setStreaming: (streaming) => set({ isStreaming: streaming }),
  setStreamText: (text) => set({ currentStreamText: text }),
  appendStreamText: (chunk) =>
    set((s) => ({ currentStreamText: s.currentStreamText + chunk })),

  addMessage: (convId, message) =>
    set((s) => ({
      messages: {
        ...s.messages,
        [convId]: [...(s.messages[convId] || []), message],
      },
    })),

  setConversations: (convs) => set({ conversations: convs }),
  setError: (error) => set({ error }),

  submitFeedback: async (messageId, rating, comment) => {
    await api.post(`${ROUTES.CHAT}/messages/${messageId}/feedback`, {
      rating,
      comment,
    });
    // Optimistic update
    set((s) => {
      const updated = { ...s.messages };
      for (const convId of Object.keys(updated)) {
        updated[convId] = updated[convId].map((m) =>
          m.messageId === messageId ? { ...m, feedbackRating: rating } : m
        );
      }
      return { messages: updated };
    });
  },

  reset: () =>
    set({
      conversations: [],
      activeConversationId: null,
      messages: {},
      isStreaming: false,
      currentStreamText: '',
      error: null,
    }),
}));

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { FeatureFlag } from '@/lib/types';

interface SavedFilter {
  id: string;
  name: string;
  filters: Record<string, string>;
}

interface SettingsState {
  featureFlags: Record<string, FeatureFlag>;
  savedFilters: SavedFilter[];
  volumeConnection: { catalog: string; schema: string; volume: string } | null;
  darkMode: boolean;

  setFlags: (flags: FeatureFlag[]) => void;
  addSavedFilter: (filter: SavedFilter) => void;
  removeSavedFilter: (id: string) => void;
  setVolumeConnection: (conn: { catalog: string; schema: string; volume: string } | null) => void;
  toggleDarkMode: () => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      featureFlags: {},
      savedFilters: [],
      volumeConnection: null,
      darkMode: false,

      setFlags: (flags) =>
        set({
          featureFlags: Object.fromEntries(flags.map((f) => [f.flag_name, f])),
        }),

      addSavedFilter: (filter) =>
        set((s) => ({ savedFilters: [...s.savedFilters, filter] })),

      removeSavedFilter: (id) =>
        set((s) => ({ savedFilters: s.savedFilters.filter((f) => f.id !== id) })),

      setVolumeConnection: (conn) => set({ volumeConnection: conn }),
      toggleDarkMode: () => set((s) => ({ darkMode: !s.darkMode })),
    }),
    { name: 'healthcontracts-settings' },
  ),
);

import { create } from 'zustand';
import type { JobState } from '@/lib/types';

interface ExtractionState {
  currentRunId: string | null;
  runState: JobState | null;
  totalDocuments: number;
  completedDocuments: number;
  failedDocuments: number;
  elapsedSec: number;
  estimatedRemainingSec: number;
  selectedProfile: string;
  selectedFiles: string[];
  connectedVolumePath: string | null;

  setRun: (runId: string, state: JobState) => void;
  updateProgress: (completed: number, failed: number, elapsed: number, remaining: number) => void;
  setProfile: (profile: string) => void;
  setFiles: (files: string[]) => void;
  setVolumePath: (path: string | null) => void;
  reset: () => void;
}

const initialState = {
  currentRunId: null,
  runState: null as JobState | null,
  totalDocuments: 0,
  completedDocuments: 0,
  failedDocuments: 0,
  elapsedSec: 0,
  estimatedRemainingSec: 0,
  selectedProfile: 'general_healthcare',
  selectedFiles: [] as string[],
  connectedVolumePath: null as string | null,
};

export const useExtractionStore = create<ExtractionState>((set) => ({
  ...initialState,

  setRun: (runId, state) => set({ currentRunId: runId, runState: state }),

  updateProgress: (completed, failed, elapsed, remaining) =>
    set({ completedDocuments: completed, failedDocuments: failed, elapsedSec: elapsed, estimatedRemainingSec: remaining }),

  setProfile: (profile) => set({ selectedProfile: profile }),
  setFiles: (files) => set({ selectedFiles: files }),
  setVolumePath: (path) => set({ connectedVolumePath: path }),
  reset: () => set(initialState),
}));

/** Shared TypeScript interfaces for HealthContracts AI frontend. */

// --- API Response ---
export interface APIResponse<T = unknown> {
  status: 'success' | 'error';
  data: T;
  meta?: { pagination?: PaginationMeta };
  error?: string;
}

export interface PaginationMeta {
  next_cursor: string | null;
  has_more: boolean;
  total_count?: number;
}

// --- Extraction ---
export type JobState =
  | 'CREATED' | 'SUBMITTED' | 'PENDING' | 'STARTING' | 'RUNNING'
  | 'COMPLETING' | 'COMPLETED' | 'COMPLETED_WITH_ERRORS'
  | 'FAILED' | 'CANCELLED' | 'SUBMIT_FAILED' | 'INVALID_REQUEST';

export interface ExtractionRun {
  run_id: string;
  state: JobState;
  total_documents: number;
  completed_documents: number;
  failed_documents: number;
  elapsed_sec: number;
  estimated_remaining_sec: number;
  profile: string;
  created_by: string;
}

export interface ExtractionStartResponse {
  run_id: string;
  state: string;
  total_documents: number;
  estimated_duration_min: number;
  estimated_cost: number;
}

// --- Review ---
export type ReviewStatus = 'PENDING' | 'IN_REVIEW' | 'APPROVED' | 'CORRECTED' | 'FLAGGED';
export type FieldClass = 'critical_financial' | 'critical_compliance' | 'important_structural' | 'low_risk_metadata';

export interface ReviewItem {
  review_id: string;
  document_version_id: string;
  field_name: string;
  ai_extracted_value: string | null;
  human_corrected_value: string | null;
  ai_confidence: number;
  field_class: FieldClass;
  review_status: ReviewStatus;
  version_number: number;
  assigned_to: string | null;
  source_citation: string | null;
  created_at: string;
  reviewed_by: string | null;
  reviewed_at: string | null;
}

export interface ReviewStats {
  pending: number;
  in_review: number;
  completed_today: number;
  avg_review_time_sec: number;
  by_priority: { high: number; normal: number };
}

export interface ReviewFilters {
  status?: string;
  priority?: string;
  assigned_to?: string;
  field_class?: string;
}

// --- Explorer ---
export type TrustBadgeType = 'VERIFIED' | 'AI_EXTRACTED' | 'CORRECTED' | 'FLAGGED' | 'LOW_CONFIDENCE' | 'ANOMALY';

export interface ContractSummary {
  document_family_id: string;
  contract_type: string | null;
  state_jurisdiction: string | null;
  effective_date: string | null;
  expiration_date: string | null;
  reimbursement_method: string | null;
  parties: string | null;
  avg_confidence: number;
  field_count: number;
  approved_fields: number;
  corrected_fields: number;
  flagged_fields: number;
  computed_status: string;
}

export interface ContractField {
  record_id: string;
  field_name: string;
  trusted_value: string | null;
  confidence_score: number | null;
  review_status: string;
  field_class: string;
  trust_badge: TrustBadgeType;
  reviewed_by: string | null;
  reviewed_at: string | null;
  source_citation: string | null;
}

// --- Settings ---
export interface FeatureFlag {
  flag_name: string;
  enabled: boolean;
  rollout_pct: number;
  description: string;
  updated_at: string;
  updated_by: string;
}

export interface ExtractionProfile {
  name: string;
  description: string;
}

// --- SSE ---
export interface SSEEvent {
  event_id: string;
  event_type: string;
  run_id: string;
  document_version_id?: string;
  batch_id?: string;
  event_payload?: Record<string, unknown>;
}

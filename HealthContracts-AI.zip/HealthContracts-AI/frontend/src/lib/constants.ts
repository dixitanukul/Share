/** API routes and application constants. */

export const API_BASE = '/api/v1';

export const ROUTES = {
  // Documents
  DOCUMENTS_UPLOAD: `${API_BASE}/documents/upload`,
  DOCUMENTS_LIST: `${API_BASE}/documents/list`,
  DOCUMENTS_PREVIEW: (id: string) => `${API_BASE}/documents/preview/${id}`,
  DOCUMENTS_DEDUPE: `${API_BASE}/documents/dedupe-check`,

  // Extraction
  EXTRACT_START: `${API_BASE}/extract/start`,
  EXTRACT_STATUS: (runId: string) => `${API_BASE}/extract/status/${runId}`,
  EXTRACT_STREAM: (runId: string) => `${API_BASE}/extract/stream/${runId}`,
  EXTRACT_CANCEL: (runId: string) => `${API_BASE}/extract/cancel/${runId}`,
  EXTRACT_RETRY: (runId: string) => `${API_BASE}/extract/retry/${runId}`,
  EXTRACT_HISTORY: `${API_BASE}/extract/history`,

  // Review
  REVIEW_QUEUE: `${API_BASE}/review/queue`,
  REVIEW_CLAIM: (id: string) => `${API_BASE}/review/${id}/claim`,
  REVIEW_APPROVE: (id: string) => `${API_BASE}/review/${id}/approve`,
  REVIEW_CORRECT: (id: string) => `${API_BASE}/review/${id}/correct`,
  REVIEW_FLAG: (id: string) => `${API_BASE}/review/${id}/flag`,
  REVIEW_REVERT: (id: string) => `${API_BASE}/review/${id}/revert`,
  REVIEW_BATCH_APPROVE: `${API_BASE}/review/batch-approve`,
  REVIEW_STATS: `${API_BASE}/review/stats`,

  // Explorer
  EXPLORER_CONTRACTS: `${API_BASE}/explorer/contracts`,
  EXPLORER_CONTRACT: (id: string) => `${API_BASE}/explorer/contracts/${id}`,
  EXPLORER_FILTERS: `${API_BASE}/explorer/filters`,
  EXPLORER_DASHBOARD: `${API_BASE}/explorer/dashboard`,

  // Settings
  SETTINGS: `${API_BASE}/settings`,
  SETTINGS_FLAGS: `${API_BASE}/settings/flags`,
  SETTINGS_FLAG: (name: string) => `${API_BASE}/settings/flags/${name}`,
  SETTINGS_PROFILES: `${API_BASE}/settings/profiles`,

  // Admin
  ADMIN_AUDIT_LOG: `${API_BASE}/admin/audit-log`,
  ADMIN_EVENT_TYPES: `${API_BASE}/admin/audit-log/event-types`,

  // Chat (R2)
  CHAT: `${API_BASE}/chat`,

  // Provenance (R2)
  PROVENANCE: `${API_BASE}/provenance`,

  // Health
  HEALTH: '/api/health',
} as const;

// Navigation tabs
export const NAV_TABS = [
  { path: '/ingest', label: 'Ingest', icon: 'Upload' },
  { path: '/explore', label: 'Explore', icon: 'Search' },
  { path: '/review', label: 'Review', icon: 'CheckSquare' },
  { path: '/chat', label: 'Chat', icon: 'MessageSquare' },
  { path: '/admin', label: 'Admin', icon: 'Settings' },
] as const;

// Trust badge config
export const TRUST_BADGES = {
  VERIFIED: { color: 'green', icon: 'CheckCircle', label: 'Verified' },
  AI_EXTRACTED: { color: 'yellow', icon: 'Sparkles', label: 'AI Extracted' },
  CORRECTED: { color: 'blue', icon: 'Pencil', label: 'Corrected' },
  FLAGGED: { color: 'red', icon: 'Flag', label: 'Flagged' },
  LOW_CONFIDENCE: { color: 'orange', icon: 'AlertTriangle', label: 'Low Confidence' },
  ANOMALY: { color: 'purple', icon: 'AlertCircle', label: 'Anomaly' },
} as const;

// Review keyboard shortcuts
export const REVIEW_SHORTCUTS: Record<string, { key: string; label: string }> = {
  approve: { key: 'a', label: 'Approve' },
  correct: { key: 'c', label: 'Correct' },
  flag: { key: 'f', label: 'Flag' },
  next: { key: 'n', label: 'Next' },
  prev: { key: 'p', label: 'Previous' },
  open: { key: 'Enter', label: 'Open Detail' },
  help: { key: '?', label: 'Shortcuts' },
};

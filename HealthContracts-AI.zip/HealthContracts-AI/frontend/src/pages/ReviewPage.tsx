import { useState, useCallback, useEffect } from 'react';
import { useReviewStore } from '@/stores/reviewStore';
import { useApiQuery } from '@/hooks/useApi';
import { ROUTES } from '@/lib/constants';
import { REVIEW_SHORTCUTS } from '@/lib/constants';
import { ReviewQueue } from '@/components/ReviewQueue/ReviewQueue';
import { ReviewItemDetail } from '@/components/ReviewQueue/ReviewItemDetail';
import { BatchActions } from '@/components/ReviewQueue/BatchActions';
import type { ReviewItem, ReviewStats } from '@/lib/types';

export function ReviewPage() {
  const store = useReviewStore();
  const [showShortcuts, setShowShortcuts] = useState(false);

  // Stats
  const { data: statsData } = useApiQuery<ReviewStats>(['review-stats'], ROUTES.REVIEW_STATS);

  useEffect(() => {
    if (statsData?.data) store.setStats(statsData.data);
  }, [statsData, store]);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === '?') setShowShortcuts((s) => !s);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const handleSelectItem = useCallback(
    (item: ReviewItem) => store.setCurrentItem(item),
    [store],
  );

  const stats = store.stats;

  return (
    <div className="space-y-4">
      {/* Header with stats */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Review Workbench</h2>
          {stats && (
            <div className="flex gap-4 mt-1 text-sm text-gray-500">
              <span>{stats.pending} pending</span>
              <span>{stats.in_review} in review</span>
              <span>{stats.completed_today} done today</span>
              {stats.avg_review_time_sec > 0 && (
                <span>~{Math.round(stats.avg_review_time_sec)}s avg</span>
              )}
            </div>
          )}
        </div>
        <button
          onClick={() => setShowShortcuts((s) => !s)}
          className="text-xs text-gray-400 hover:text-gray-600 border border-gray-200 px-2 py-1 rounded"
        >
          ? Shortcuts
        </button>
      </div>

      {/* Keyboard shortcut overlay */}
      {showShortcuts && (
        <div className="bg-gray-800 text-white rounded-lg p-4 text-sm">
          <div className="grid grid-cols-2 gap-2">
            {Object.values(REVIEW_SHORTCUTS).map((s) => (
              <div key={s.key} className="flex items-center gap-2">
                <kbd className="px-1.5 py-0.5 bg-gray-700 rounded text-xs font-mono">{s.key}</kbd>
                <span>{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Batch actions */}
      <BatchActions />

      {/* Main content: queue or detail */}
      <div className="bg-white rounded-lg shadow-sm">
        {store.currentItem ? (
          <div className="p-4">
            <ReviewItemDetail
              item={store.currentItem}
              onBack={() => store.setCurrentItem(null)}
            />
          </div>
        ) : (
          <div className="p-4">
            <ReviewQueue onSelectItem={handleSelectItem} />
          </div>
        )}
      </div>
    </div>
  );
}

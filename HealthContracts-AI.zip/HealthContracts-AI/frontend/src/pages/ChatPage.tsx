/**
 * ChatPage — Tab 5: AI Chat.
 *
 * Layout: ConversationList sidebar (240px) + ChatInterface main area.
 * Supports: conversation CRUD, message streaming, semantic cache, feedback.
 */
import { useCallback, useEffect, useState } from 'react';
import { api } from '../lib/api';
import { ROUTES } from '../lib/constants';
import { useChatStore } from '../stores/chatStore';
import { ConversationList } from '../components/ChatInterface/ConversationList';
import { ChatInterface } from '../components/ChatInterface/ChatInterface';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export default function ChatPage() {
  const {
    conversations,
    activeConversationId,
    setActiveConversation,
    setConversations,
    scope,
  } = useChatStore();
  const [loading, setLoading] = useState(true);

  // Load conversations
  useEffect(() => {
    api.get<{ items: any[] }>(`${ROUTES.CHAT}/conversations?limit=50`)
      .then((res) => {
        setConversations(res.data?.items || []);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [setConversations]);

  // Create new conversation
  const handleCreate = useCallback(async () => {
    try {
      const res = await api.post(`${ROUTES.CHAT}/conversations`, {
        scope_type: scope.type,
        scope_id: scope.id,
      });
      const newConv = res.data as any;
      setConversations([
        { ...newConv, messageCount: 0, createdAt: new Date().toISOString() },
        ...conversations,
      ]);
      setActiveConversation(newConv.conversation_id);
    } catch (err: any) {
      console.error('Create conversation failed:', err);
    }
  }, [conversations, scope, setActiveConversation, setConversations]);

  // Delete conversation
  const handleDelete = useCallback(
    async (id: string) => {
      await api.delete(`${ROUTES.CHAT}/conversations/${id}`);
      setConversations(conversations.filter((c) => c.conversationId !== id));
      if (activeConversationId === id) {
        setActiveConversation(null);
      }
    },
    [conversations, activeConversationId, setActiveConversation, setConversations]
  );

  if (loading) return <LoadingSpinner size="lg" label="Loading conversations..." />;

  return (
    <div className="flex h-full">
      <ConversationList
        conversations={conversations}
        activeId={activeConversationId}
        onSelect={setActiveConversation}
        onCreate={handleCreate}
        onDelete={handleDelete}
      />

      <main className="flex-1">
        {activeConversationId ? (
          <ChatInterface conversationId={activeConversationId} />
        ) : (
          <div className="flex h-full items-center justify-center text-gray-500">
            <div className="text-center">
              <p className="text-lg">Select a conversation or start a new one</p>
              <p className="mt-1 text-sm">Ask anything about your healthcare contracts</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

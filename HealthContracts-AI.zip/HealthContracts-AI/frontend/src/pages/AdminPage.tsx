import { useState } from 'react';
import { Settings, Flag, FileText } from 'lucide-react';
import { useApiQuery } from '@/hooks/useApi';
import { api } from '@/lib/api';
import { ROUTES } from '@/lib/constants';
import { useSettingsStore } from '@/stores/settingsStore';
import { Pagination } from '@/components/common/Pagination';
import { LoadingSpinner } from '@/components/common/LoadingSpinner';
import type { FeatureFlag } from '@/lib/types';

type AdminTab = 'settings' | 'flags' | 'audit';

interface AuditEntry {
  event_id: string;
  event_timestamp: string;
  user_identity: string;
  event_type: string;
  resource_type: string;
  resource_id: string;
  action_detail: string;
}

export function AdminPage() {
  const [tab, setTab] = useState<AdminTab>('flags');

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gray-900">Administration</h2>

      {/* Tab selector */}
      <div className="flex gap-1 border-b">
        {[
          { id: 'flags' as AdminTab, icon: Flag, label: 'Feature Flags' },
          { id: 'audit' as AdminTab, icon: FileText, label: 'Audit Log' },
          { id: 'settings' as AdminTab, icon: Settings, label: 'Settings' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm border-b-2 transition-colors ${
              tab === t.id ? 'border-blue-600 text-blue-700' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-lg shadow-sm p-4">
        {tab === 'flags' && <FlagPanel />}
        {tab === 'audit' && <AuditPanel />}
        {tab === 'settings' && <SettingsPanel />}
      </div>
    </div>
  );
}

// --- Feature Flags Panel ---
function FlagPanel() {
  const { data, isLoading, refetch } = useApiQuery<FeatureFlag[]>(['flags'], ROUTES.SETTINGS_FLAGS);
  const setFlags = useSettingsStore((s) => s.setFlags);
  const flags = data?.data ?? [];
  const [toggling, setToggling] = useState<string | null>(null);

  if (flags.length > 0 && data) setFlags(flags);

  const handleToggle = async (flag: FeatureFlag) => {
    setToggling(flag.flag_name);
    try {
      await api.put(ROUTES.SETTINGS_FLAG(flag.flag_name), {
        enabled: !flag.enabled,
        rollout_pct: flag.rollout_pct,
      });
      refetch();
    } catch (err: any) {
      console.error('Toggle failed:', err?.message || err);
    } finally {
      setToggling(null);
    }
  };

  if (isLoading) return <LoadingSpinner label="Loading flags..." />;

  return (
    <div className="divide-y">
      {flags.map((flag) => (
        <div key={flag.flag_name} className="flex items-center justify-between py-3">
          <div>
            <p className="text-sm font-medium text-gray-800">{flag.flag_name}</p>
            <p className="text-xs text-gray-500">{flag.description}</p>
            <p className="text-xs text-gray-400 mt-0.5">
              Rollout: {flag.rollout_pct}% &middot; Updated: {new Date(flag.updated_at).toLocaleDateString()}
            </p>
          </div>
          <button
            onClick={() => handleToggle(flag)}
            disabled={toggling === flag.flag_name}
            className={`relative w-11 h-6 rounded-full transition-colors ${
              flag.enabled ? 'bg-blue-600' : 'bg-gray-300'
            } ${toggling === flag.flag_name ? 'opacity-50 cursor-wait' : ''}`}
            role="switch"
            aria-checked={flag.enabled}
            aria-label={`Toggle ${flag.flag_name}`}
          >
            <span
              className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                flag.enabled ? 'translate-x-5' : ''
              }`}
            />
          </button>
        </div>
      ))}
    </div>
  );
}

// --- Audit Log Panel ---
function AuditPanel() {
  const [cursor, setCursor] = useState<string | null>(null);
  const [prevCursors, setPrevCursors] = useState<string[]>([]);
  const [userFilter, setUserFilter] = useState('');
  const [eventTypeFilter, setEventTypeFilter] = useState('');

  const url = `${ROUTES.ADMIN_AUDIT_LOG}?${cursor ? `cursor=${cursor}&` : ''}${userFilter ? `user=${userFilter}&` : ''}${eventTypeFilter ? `event_type=${eventTypeFilter}` : ''}`;

  const { data, isLoading } = useApiQuery<AuditEntry[]>(
    ['audit-log', cursor ?? '', userFilter, eventTypeFilter],
    url,
  );

  const { data: eventTypesData } = useApiQuery<string[]>(['audit-event-types'], ROUTES.ADMIN_EVENT_TYPES);

  const entries = data?.data ?? [];
  const pagination = data?.meta?.pagination;

  if (isLoading) return <LoadingSpinner label="Loading audit log..." />;

  return (
    <div className="space-y-3">
      {/* Filters */}
      <div className="flex gap-2">
        <input
          type="text"
          placeholder="Filter by user..."
          value={userFilter}
          onChange={(e) => { setUserFilter(e.target.value); setCursor(null); }}
          className="px-2 py-1.5 text-sm border border-gray-300 rounded-md"
        />
        <select
          value={eventTypeFilter}
          onChange={(e) => { setEventTypeFilter(e.target.value); setCursor(null); }}
          className="px-2 py-1.5 text-sm border border-gray-300 rounded-md"
        >
          <option value="">All event types</option>
          {eventTypesData?.data?.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      {/* Table */}
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs text-gray-500 uppercase border-b">
            <th className="py-2 px-2">Timestamp</th>
            <th className="py-2 px-2">User</th>
            <th className="py-2 px-2">Event</th>
            <th className="py-2 px-2">Resource</th>
            <th className="py-2 px-2">Detail</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((e) => (
            <tr key={e.event_id} className="border-b hover:bg-gray-50">
              <td className="py-2 px-2 text-xs text-gray-500 whitespace-nowrap">
                {new Date(e.event_timestamp).toLocaleString()}
              </td>
              <td className="py-2 px-2 text-gray-700">{e.user_identity}</td>
              <td className="py-2 px-2">
                <span className="text-xs bg-gray-100 px-1.5 py-0.5 rounded">{e.event_type}</span>
              </td>
              <td className="py-2 px-2 text-xs text-gray-500">
                {e.resource_type}/{e.resource_id?.slice(0, 8)}
              </td>
              <td className="py-2 px-2 text-xs text-gray-500 truncate max-w-[200px]">
                {e.action_detail}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <Pagination
        hasMore={pagination?.has_more ?? false}
        hasPrev={prevCursors.length > 0}
        onNext={() => {
          if (pagination?.next_cursor) {
            setPrevCursors((p) => [...p, cursor ?? '']);
            setCursor(pagination.next_cursor);
          }
        }}
        onPrev={() => {
          const prev = prevCursors[prevCursors.length - 1];
          setPrevCursors((p) => p.slice(0, -1));
          setCursor(prev || null);
        }}
        totalCount={pagination?.total_count}
      />
    </div>
  );
}

// --- Settings Panel ---
function SettingsPanel() {
  const { data, isLoading } = useApiQuery<Record<string, unknown>>(['settings'], ROUTES.SETTINGS);

  if (isLoading) return <LoadingSpinner label="Loading settings..." />;

  const settings = data?.data ?? {};

  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-500">
        System configuration. Changes require ADMIN role.
      </p>
      <div className="divide-y">
        {Object.entries(settings).map(([key, value]) => (
          <div key={key} className="flex items-center justify-between py-2">
            <span className="text-sm text-gray-700 font-mono">{key}</span>
            <span className="text-sm text-gray-500">{String(value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

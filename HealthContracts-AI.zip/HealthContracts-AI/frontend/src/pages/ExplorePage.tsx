import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Search, X } from 'lucide-react';
import { useApiQuery } from '@/hooks/useApi';
import { ROUTES } from '@/lib/constants';
import { TrustBadge } from '@/components/TrustBadge/TrustBadge';
import { ConfidenceExplainer } from '@/components/ConfidenceExplainer/ConfidenceExplainer';
import { EmptyState } from '@/components/common/EmptyState';
import { LoadingSpinner } from '@/components/common/LoadingSpinner';
import type { ContractSummary, ContractField, TrustBadgeType } from '@/lib/types';

export function ExplorePage() {
  const { familyId } = useParams();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterState, setFilterState] = useState('');

  // Contract list
  const { data: contractsData, isLoading } = useApiQuery<ContractSummary[]>(
    ['contracts', searchTerm, filterType, filterState],
    `${ROUTES.EXPLORER_CONTRACTS}?search=${searchTerm}&contract_type=${filterType}&state=${filterState}`,
  );
  const contracts = contractsData?.data ?? [];

  // Contract detail
  const { data: detailData, isLoading: detailLoading } = useApiQuery<{ fields: ContractField[] }>(
    ['contract-detail', familyId ?? ''],
    familyId ? ROUTES.EXPLORER_CONTRACT(familyId) : '',
    { enabled: !!familyId },
  );
  const fields = detailData?.data?.fields ?? [];

  // Filter options
  const { data: filtersData } = useApiQuery<{ contract_types: string[]; states: string[] }>(
    ['explorer-filters'],
    ROUTES.EXPLORER_FILTERS,
  );

  const fieldsByClass = useMemo(() => {
    const groups: Record<string, ContractField[]> = {};
    fields.forEach((f) => {
      const cls = f.field_class || 'other';
      (groups[cls] ??= []).push(f);
    });
    return groups;
  }, [fields]);

  if (isLoading) return <LoadingSpinner label="Loading contracts..." />;
  if (contracts.length === 0 && !familyId) return <EmptyState page="explorer" />;

  // Detail view
  if (familyId) {
    return (
      <div className="space-y-4">
        <button onClick={() => navigate('/explore')} className="text-sm text-blue-600 hover:underline">
          &larr; Back to contracts
        </button>

        {detailLoading ? (
          <LoadingSpinner label="Loading contract..." />
        ) : (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">Contract: {familyId.slice(0, 8)}...</h2>

            {Object.entries(fieldsByClass).map(([cls, flds]) => (
              <div key={cls} className="bg-white rounded-lg shadow-sm p-4">
                <h3 className="text-sm font-semibold text-gray-700 mb-3 capitalize">
                  {cls.replace(/_/g, ' ')}
                </h3>
                <div className="divide-y">
                  {flds.map((f) => (
                    <div key={f.record_id} className="flex items-center justify-between py-2">
                      <div>
                        <span className="text-sm text-gray-800">{f.field_name}</span>
                        <span className="text-sm text-gray-500 ml-2">{f.trusted_value ?? '—'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <TrustBadge type={f.trust_badge as TrustBadgeType} size="sm" />
                        {f.confidence_score != null && (
                          <span className="text-xs text-gray-400">{Math.round(f.confidence_score * 100)}%</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // List view
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-900">Contract Explorer</h2>
      </div>

      {/* Filter bar */}
      <div className="flex gap-3 items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search contracts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-md"
          />
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-3 py-2 text-sm border border-gray-300 rounded-md"
        >
          <option value="">All Types</option>
          {filtersData?.data?.contract_types?.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        <select
          value={filterState}
          onChange={(e) => setFilterState(e.target.value)}
          className="px-3 py-2 text-sm border border-gray-300 rounded-md"
        >
          <option value="">All States</option>
          {filtersData?.data?.states?.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        {(filterType || filterState || searchTerm) && (
          <button
            onClick={() => { setFilterType(''); setFilterState(''); setSearchTerm(''); }}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Contract cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {contracts.map((c) => (
          <div
            key={c.document_family_id}
            onClick={() => navigate(`/explore/${c.document_family_id}`)}
            className="bg-white rounded-lg shadow-sm p-4 cursor-pointer hover:shadow-md transition-shadow border"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400 font-mono">{c.document_family_id.slice(0, 12)}...</span>
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                c.computed_status === 'COMPLETE' ? 'bg-green-50 text-green-700' :
                c.computed_status === 'IN_REVIEW' ? 'bg-yellow-50 text-yellow-700' :
                'bg-gray-50 text-gray-600'
              }`}>
                {c.computed_status}
              </span>
            </div>
            <p className="text-sm font-medium text-gray-800 mb-1">{c.contract_type ?? 'Unknown Type'}</p>
            <p className="text-xs text-gray-500">{c.state_jurisdiction ?? '—'} &middot; {c.parties ?? '—'}</p>

            <div className="flex items-center justify-between mt-3 pt-2 border-t">
              <ConfidenceExplainer overall={c.avg_confidence} />
              <span className="text-xs text-gray-400">{c.field_count} fields</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

import { useState } from 'react';
import { UploadZone } from '@/components/UploadZone/UploadZone';
import { VolumeConnector } from '@/components/UploadZone/VolumeConnector';
import { FileList } from '@/components/UploadZone/FileList';
import { ExtractionConsole } from '@/components/ExtractionConsole/ExtractionConsole';
import { WelcomeModal } from '@/components/Onboarding/WelcomeModal';
import { GuidedTour } from '@/components/Onboarding/GuidedTour';
import { SampleDataButton } from '@/components/Onboarding/SampleDataButton';

export function IngestPage() {
  const [showTour, setShowTour] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div className="space-y-6">
      <WelcomeModal
        onStartTour={() => setShowTour(true)}
        onTrySampleData={() => setRefreshKey((k) => k + 1)}
      />
      {showTour && <GuidedTour onComplete={() => setShowTour(false)} />}

      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Ingest Contracts</h2>
          <p className="text-sm text-gray-500 mt-1">
            Upload PDF contracts or connect to a Unity Catalog volume, then extract structured data.
          </p>
        </div>
        <SampleDataButton onLoaded={() => setRefreshKey((k) => k + 1)} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: Upload + Volume */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Upload Documents</h3>
            <UploadZone onUploadComplete={() => setRefreshKey((k) => k + 1)} />
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4">
            <VolumeConnector />
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4">
            <ExtractionConsole />
          </div>
        </div>

        {/* Right column: File list */}
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Uploaded Files</h3>
          <FileList key={refreshKey} />
        </div>
      </div>
    </div>
  );
}

"""Pydantic models and domain value objects."""

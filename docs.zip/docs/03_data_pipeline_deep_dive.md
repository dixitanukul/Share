# Data Pipeline Deep Dive — Contract Intelligence Platform V4

> **Audience**: Data engineers, pipeline developers, technical reviewers

---

## Table of Contents

1. [Pipeline Overview](#pipeline-overview)
2. [Stage 1: Configuration & DDL](#stage-1-configuration--ddl)
3. [Stage 2: Document State Engine](#stage-2-document-state-engine)
4. [Stage 3: Reimbursement Migration & Structured Extraction](#stage-3-reimbursement-migration--structured-extraction)
5. [Stage 4: Legal Chunking](#stage-4-legal-chunking)
6. [Stage 5: Retrieval Engine & Vector Store](#stage-5-retrieval-engine--vector-store)
7. [Stage 6: Citation Verification](#stage-6-citation-verification)
8. [Stage 7: Intelligence Engine](#stage-7-intelligence-engine)
9. [Stage 8: Derived Analytics](#stage-8-derived-analytics)
10. [Pipeline Orchestration](#pipeline-orchestration)
11. [Error Handling & Data Quality](#error-handling--data-quality)

---

## Pipeline Overview

The Contract Intelligence pipeline transforms raw PDF contract documents into queryable structured data and semantic search indices. It operates as a series of numbered Python scripts and notebooks in the `pipeline/` directory, each responsible for a distinct transformation stage.

```
Source PDFs (10,372 documents)
    │
    ▼
[00_config.py]          ── Shared configuration, catalog/schema, model endpoints
    │
    ▼
[01_execute_ddl.py]     ── Schema creation (CREATE TABLE IF NOT EXISTS)
    │
    ▼
[02_state_engine.py]    ── Document state machine (registry, lineage, versioning)
    │
    ▼
[03_reimbursement_migration.py] ── Rate extraction, stop-loss, escalators, carve-outs
    │
    ▼
[04_legal_chunking.py]  ── PDF → text chunks (section-aware, quality-scored)
    │
    ▼
[05_retrieval_engine.py] ── Vector index construction (embedding + sync)
    │
    ▼
[07_citation_verification.py] ── Cross-validate extracted data against source text
    │
    ▼
[08_intelligence.py]    ── Financial intelligence, benchmarks, savings analysis
    │
    ▼
[11_evaluation_harness.py] ── Automated quality evaluation
    │
    ▼
Derived Analytics Notebooks (13–20) ── Annotation, observability, governance, testing
```

---

## Stage 1: Configuration & DDL

### What Happens
Establishes the runtime environment, defines all table names, model endpoints, feature flags, and creates the Delta Lake schema infrastructure.

### How It Works

**Configuration** (`00_config.py`):
* Sets `CATALOG = "dev_adb"` and `SCHEMA = "raw"` as the target namespace
* Defines model endpoints: `databricks-gte-large-en` (embeddings), `databricks-claude-sonnet-4-5` (extraction/judge)
* Declares all table name constants (50+ tables organized by engine: State, Reimbursement, Intelligence, Retrieval)
* Provides utility functions: `run_sql()`, `table_exists()`, `row_count()`, `log_telemetry()`
* Initializes a telemetry buffer for structured pipeline observability

**DDL Execution** (`01_execute_ddl.py`):
* Reads and executes SQL DDL files that define the schema for all production tables
* Uses `CREATE TABLE IF NOT EXISTS` for idempotency
* Tables use Delta format with liquid clustering where appropriate (e.g., `tbl_contract_rates_all` clustered on `status`)

### Why This Approach
* **Centralized configuration** ensures consistency across all pipeline stages
* **Idempotent DDL** means the pipeline can be re-run safely without data loss
* **Feature flags** allow progressive enablement of capabilities (e.g., `CLAIMS_AVAILABLE = False`)

### Benefit
Any pipeline stage can be run independently by importing `00_config.py` for shared state. This enables parallel development and targeted re-processing.

---

## Stage 2: Document State Engine

### What Happens
Manages the lifecycle of contract documents through a state machine: tracking which PDFs have been ingested, which amendments supersede which, and maintaining document lineage.

### How It Works (`02_state_engine.py`)

* **Contract Registry** (`tbl_v2_contract_registry`): One row per provider contract relationship, tracking the master agreement
* **Amendment Registry** (`tbl_v2_amendment_registry`): Tracks each amendment with ordering, effective dates, and supersession relationships
* **Document Lineage** (`tbl_v2_document_lineage`): Records the full processing history of each document
* **State Computation Log** (`tbl_v2_state_computation_log`): Audit trail of state transitions

The state engine implements:
1. **Amendment ordering** — Assigns `amendment_order` (0 = base agreement, 1+ = amendments in chronological order)
2. **Supersession detection** — Determines which rates/clauses in a newer amendment replace those in an older one
3. **Current-effective calculation** — Marks which documents represent the current state of a contract

### Why This Approach
Healthcare contracts evolve through amendments over decades. A single provider may have 20+ amendments. Without a state engine, it’s impossible to determine which rate or clause is "current" versus "historical."

### Benefit
Every downstream query can filter to `status = 'current'` or `is_current = TRUE` to get the current-effective answer, while still preserving full temporal history for amendment timeline analysis.

---

## Stage 3: Reimbursement Migration & Structured Extraction

### What Happens
Extracts structured reimbursement data from contract PDFs using LLM-powered parsing. This is the most complex stage, producing the core rate tables that power the platform.

### How It Works (`03_reimbursement_migration.py`)

The extraction pipeline processes each contract PDF through:

1. **Text extraction** — OCR/text layer extraction from PDF documents
2. **LLM-powered parsing** — Claude Sonnet analyzes contract text with structured extraction prompts
3. **Schema validation** — Extracted JSON is validated against expected schemas (`src/validation.py`)
4. **JSON repair** — Malformed LLM outputs are repaired using heuristic methods (`src/json_repair.py`)
5. **Rate normalization** — Raw extracted rates are normalized into standard categories

**Output tables:**

| Table | Content | Rows |
|---|---|---|
| `tbl_contract_rates_all` | All rate versions (current + superseded) | 459,902 |
| `tbl_reimb_rate_rules` | Base reimbursement rules per contract | - |
| `tbl_reimb_formula_components` | Rate formula breakdowns | - |
| `tbl_reimb_stop_loss` | Stop-loss financial protections | 262 |
| `tbl_reimb_carve_outs` | Service carve-out provisions | - |
| `tbl_reimb_escalators` | Annual rate escalation terms | 104 |
| `tbl_reimb_conditions` | Rate applicability conditions | - |
| `tbl_reimb_lesser_of` | Lesser-of provisions | - |

**Rate categories extracted:**
* Inpatient case rates, per diem rates, DRG-based rates
* Outpatient facility rates, ASC rates, ER rates
* Professional fees, lab rates, imaging rates
* Capitation/PMPM rates
* Percent-of-Medicare and percent-of-charges formulas

### Why This Approach
* **LLM extraction** handles the enormous variability in contract formatting (no two providers structure rate tables identically)
* **Schema validation** catches extraction errors before they enter production tables
* **Version tracking** via `status` (current/superseded) and `amendment_order` preserves full history

### Benefit
Converts unstructured rate tables (formatted as PDF tables, narrative text, or exhibits) into a single queryable table with consistent schema, enabling cross-provider rate comparison and benchmarking.

---

## Stage 4: Legal Chunking

### What Happens
Segments contract PDFs into semantically meaningful text chunks optimized for retrieval. This creates the raw material for the vector search index.

### How It Works (`04_legal_chunking.py` + `src/chunking.py`)

1. **Section detection** — Identifies document structure (headers, sections, exhibits, appendices)
2. **Boundary-aware splitting** — Chunks at paragraph/section boundaries rather than arbitrary character counts
3. **Context prefixing** — Each chunk receives a `context_prefix` identifying its provider, document, and section
4. **Quality scoring** — Each chunk receives a `quality_score` based on:
   - Text coherence (complete sentences vs. OCR fragments)
   - Content density (meaningful text vs. headers/footers)
   - Minimum length threshold (chunks <10 chars flagged as low quality)
5. **Metadata enrichment** — Each chunk is tagged with:
   - `provider_name`, `provider_id`, `source_filename`
   - `chunk_type` (PASSAGE, CLAUSE, DEFINITION, RATE_TABLE, CONDITION)
   - `page_number_est`, `section_header`, `doc_role`
   - `is_current` (from state engine), `amendment_order`

**Output**: `tbl_vs_unified_ready` — 727,875 chunks ready for embedding and indexing

### Why This Approach
* **Section-aware chunking** preserves legal meaning (a clause split mid-sentence loses its meaning)
* **Context prefixes** enable the LLM to understand what provider/document a chunk comes from without seeing the full document
* **Quality scoring** allows retrieval to prioritize high-quality chunks and deprioritize OCR noise

### Benefit
Retrieval accuracy depends directly on chunk quality. Section-aware chunking with quality scoring produces chunks that are semantically complete and contextually identifiable, yielding significantly better retrieval precision than naive character-based splitting.

---

## Stage 5: Retrieval Engine & Vector Store

### What Happens
Embeds all text chunks using GTE-Large-EN (1024 dimensions) and syncs them to a Databricks Vector Search index for real-time semantic retrieval.

### How It Works (`05_retrieval_engine.py` + `step_0_3_vs_rebuild`)

1. **Embedding generation** — `embedded_text` column computed from `context_prefix + chunk_text`
2. **Index creation** — Single unified index (`idx_unified_v4`) containing both:
   - Layer 1: 670,728 raw OCR passages (`chunk_type = PASSAGE`)
   - Layer 2: 57,147 structured legal units (`chunk_type = CLAUSE/DEFINITION/RATE_TABLE/etc.`)
3. **Delta Sync** — Index uses Databricks Vector Search Delta Sync to automatically update when the source table changes
4. **Filter columns synced** — `provider_name`, `is_current`, `chunk_type` available for filtered search

**Index configuration:**
* Endpoint: `contract_intelligence_vs_endpoint`
* Index: `dev_adb.raw.idx_unified_v4`
* Embedding model: `databricks-gte-large-en` (1024 dimensions)
* Similarity metric: Cosine
* Source table: `dev_adb.raw.tbl_vs_unified_ready`

### Why This Approach
* **Single unified index** (V4 architecture) replaces the previous multi-index approach, simplifying maintenance and eliminating fallback logic
* **Delta Sync** means the index stays current without manual re-indexing
* **Filter support** enables provider-scoped searches (critical for avoiding cross-provider contamination)

### Benefit
Enables sub-second semantic search across the entire contract corpus. A user asking "What does the offset clause say for Adventist Health?" retrieves the most relevant contract passages in <200ms, filtered to the correct provider.

---

## Stage 6: Citation Verification

### What Happens
Cross-validates extracted structured data against the original source text to ensure accuracy and establish provenance.

### How It Works (`07_citation_verification.py`)

1. **Rate verification** — For each extracted rate, retrieves the source passage and verifies the numeric value appears in the text
2. **Clause verification** — Confirms that clause existence flags (HAS/NO_MENTION) align with the source document content
3. **Date verification** — Cross-checks extracted dates against document text
4. **Provenance recording** — Stores verification results in `tbl_extraction_provenance`

### Why This Approach
LLM extraction is not 100% accurate. Citation verification creates a feedback loop that identifies extraction errors and establishes confidence levels for downstream consumers.

### Benefit
Users can trust that when the system says "the inpatient per diem is $2,500," that number actually appears in a verifiable source document. This is critical for a healthcare contract platform where incorrect rates could lead to significant financial impact.

---

## Stage 7: Intelligence Engine

### What Happens
Computes derived analytics that transform raw extracted data into actionable business intelligence: benchmarks, financial exposure, risk scores, and savings opportunities.

### How It Works (`08_intelligence.py`)

* **Provider benchmarking** — Calculates percentile positions for provider rates against the network portfolio
* **Financial exposure estimation** — Estimates contracted spend per provider using rate data + utilization proxies
* **Savings opportunity identification** — Identifies where current rates deviate significantly from benchmarks
* **Leverage scoring** — Scores negotiation leverage based on contract terms, market position, and rate history

### Benefit
Transforms a "document repository" into an "intelligence platform" — users don’t just look up rates, they understand relative positioning, financial exposure, and negotiation opportunities.

---

## Stage 8: Derived Analytics

Multiple notebooks (13–20) compute additional derived tables:

| Notebook | Purpose | Output Tables |
|---|---|---|
| `13_llm_assisted_annotation` | LLM-assisted clause classification and annotation | `tbl_contract_clauses` |
| `13_temporal_validity` | Temporal validity windows for documents | Amendment timeline enrichment |
| `13_vs_index_refresh` | Vector search index maintenance | Index sync status |
| `14_observability` | Pipeline health metrics and alerting | Telemetry tables |
| `14_report_validation_audit` | Validation report generation | Audit outputs |
| `15_governance` | Data governance and access control setup | Column masks, row filters |
| `16_confidence` | Confidence scoring calibration | Scoring parameters |
| `17_testing` | Automated pipeline testing | Test results |
| `18_retrieval_quality` | Retrieval quality measurement and tuning | Quality metrics |
| `19_semantic_intelligence` | Semantic analysis of contract language | Intelligence features |
| `20_clause_classification` | Multi-label clause classification | Clause categories |

---

## Pipeline Orchestration

The pipeline is orchestrated via the `run_platform_modules_orchestrator` notebook, which:

1. Imports `00_config.py` for shared configuration
2. Executes pipeline stages in dependency order
3. Logs telemetry events to `tbl_pipeline_telemetry` for observability
4. Reports success/failure status with timing metrics

**Execution model**: Currently triggered manually or via Databricks Jobs. Each stage is idempotent and can be re-run independently.

**Telemetry**: Every pipeline step logs structured events including:
* `run_id` (UUID per execution)
* `step`, `check`, `result`
* `filename`, `provider_id` (when applicable)
* `severity`, `detail`, `metric`, `value`

---

## Error Handling & Data Quality

### At Each Stage

| Stage | Error Handling | Quality Checks |
|---|---|---|
| Text extraction | Skip corrupt PDFs, log to telemetry | Minimum text length threshold |
| LLM extraction | JSON repair, retry with backoff, schema validation | Rate bounds checking (`is_valid_rate`) |
| Chunking | Skip empty pages, filter <10 char chunks | Quality score computation |
| Vector indexing | Graceful degradation on sync failures | Embedding completeness check |
| Citation verification | Log unverifiable rates without blocking | Provenance confidence scoring |

### Data Quality Validation Queries

The platform includes 7 reusable SQL validation queries (documented in the stress test notebook) that check:

1. **Referential integrity** — Orphan provider_ids in rates table
2. **Active provider coverage** — Active providers with zero current rates
3. **Temporal inversions** — Amendment dates out of chronological order
4. **NULL effective dates** — Current rates missing effective_date
5. **Provider name mismatches** — Profile vs. rates table name discrepancies
6. **Empty vector chunks** — Chunks with <10 characters of text
7. **Financial exposure gaps** — Active providers missing financial data

---

*For table schema details, see [04_data_model_reference.md](./04_data_model_reference.md)*
*For pipeline configuration, see [10_appendix_code_reference.md](./10_appendix_code_reference.md)*

# Deployment & Operations — Contract Intelligence Platform V4

> **Audience**: DevOps, platform engineering, ongoing maintenance team

---

## Table of Contents

1. [Deployment Architecture](#deployment-architecture)
2. [Environment Configuration](#environment-configuration)
3. [Deployment Process](#deployment-process)
4. [Monitoring & Alerting](#monitoring--alerting)
5. [Troubleshooting Guide](#troubleshooting-guide)
6. [Performance Optimization](#performance-optimization)
7. [Cost Management](#cost-management)
8. [Upgrade & Maintenance](#upgrade--maintenance)

---

## Deployment Architecture

### Runtime Environment

* **Platform**: Databricks Apps (Azure)
* **Container**: uvicorn + FastAPI on port 8000
* **Mode**: SNAPSHOT (source code bundled at deploy time)
* **Authentication**: Service Principal (auto-provisioned by Databricks Apps)
* **Frontend**: Pre-built React SPA served from `app/static/`

### Dependencies

| Dependency | Type | Endpoint |
|---|---|---|
| SQL Warehouse | Compute | ID: `2c99c6485f03ee73` (serverless) |
| Vector Search | Index | Endpoint: `contract_intelligence_vs_endpoint` |
| Claude Sonnet 4.6 | LLM | Serving endpoint: `databricks-claude-sonnet-4-6` |
| Claude Haiku 4.5 | LLM | Serving endpoint: `databricks-claude-haiku-4-5` |
| Unity Catalog | Storage | Catalog: `dev_adb`, Schema: `raw` |

### Network Architecture

```
User Browser → Databricks Apps Proxy → App Container (port 8000)
                                            │
                    ┌───────────────────────┴───────────────────────┐
                    ▼                                        ▼
    SQL Warehouse (Statement Execution API)    VS Endpoint (gRPC SDK)
                    ▼                                        ▼
    Foundation Model Serving (REST)           Unity Catalog (Delta tables)
```

All traffic stays within the Databricks workspace boundary. No public internet egress for data operations.

---

## Environment Configuration

### app.yaml (Deployment Manifest)

```yaml
command: ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]

env:
  - name: APP_CATALOG
    value: "dev_adb"
  - name: APP_SCHEMA
    value: "raw"
  - name: APP_VERSION
    value: "4.0.0"
  - name: DATABRICKS_WAREHOUSE_ID
    value: "2c99c6485f03ee73"
  - name: LLM_ENDPOINT
    valueFrom: databricks-claude-sonnet-4-6
  - name: LLM_FAST_ENDPOINT
    valueFrom: databricks-claude-haiku-4-5
  - name: VS_ENDPOINT_NAME
    value: "contract_intelligence_vs_endpoint"

resources:
  - name: "contract-intel-warehouse"
    sql_warehouse:
      id: "2c99c6485f03ee73"
      permission: CAN_USE
  - name: "databricks-claude-sonnet-4-6"
    serving_endpoint:
      name: "databricks-claude-sonnet-4-6"
      permission: CAN_QUERY
  - name: "databricks-claude-haiku-4-5"
    serving_endpoint:
      name: "databricks-claude-haiku-4-5"
      permission: CAN_QUERY
```

### Environment Variables

| Variable | Purpose | Default |
|---|---|---|
| `APP_CATALOG` | Target Unity Catalog catalog | `dev_adb` |
| `APP_SCHEMA` | Target schema within catalog | `raw` |
| `APP_VERSION` | Application version string | `4.0.0` |
| `DATABRICKS_WAREHOUSE_ID` | SQL Warehouse for structured queries | `2c99c6485f03ee73` |
| `LLM_ENDPOINT` | Primary LLM serving endpoint name | `databricks-claude-sonnet-4-6` |
| `LLM_FAST_ENDPOINT` | Fast LLM serving endpoint name | `databricks-claude-haiku-4-5` |
| `VS_ENDPOINT_NAME` | Vector Search endpoint name | `contract_intelligence_vs_endpoint` |

---

## Deployment Process

### Standard Deployment

```python
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.apps import AppDeployment, AppDeploymentMode

WorkspaceClient().apps.deploy(
    app_name='contract-intelligence',
    app_deployment=AppDeployment(
        mode=AppDeploymentMode.SNAPSHOT,
        source_code_path='/Workspace/Users/adixit01@blueshieldca.com/contract-intelligence-v4'
    )
)
```

### Frontend Rebuild (When UI Changes)

```bash
# 1. Bootstrap npm
curl -fsSL https://registry.npmjs.org/npm/-/npm-10.9.2.tgz | tar -xz -C /tmp/npm_bootstrap
NPM=/tmp/npm_bootstrap/package/bin/npm-cli.js

# 2. Build frontend
cd frontend && node $NPM ci && node $NPM run build

# 3. Clean up (excluded by .databricksignore)
rm -rf frontend/node_modules/

# 4. Redeploy app
```

### Pre-Deployment Checklist

1. Run unit tests: `pytest platform/v4/tests/ -m "not live" -q`
2. Run DQ stress test suite (notebook cell 36)
3. Verify SQL validation queries (notebook cell 37)
4. Confirm all feature flags in `settings.py` match desired state
5. Deploy via SDK command above

---

## Monitoring & Alerting

### Health Endpoint

`GET /health` returns:
```json
{
  "status": "healthy",
  "dependencies": {
    "sql_warehouse": "healthy",
    "vector_search": "healthy",
    "llm_primary": "healthy",
    "llm_fast": "healthy"
  },
  "version": "4.0.0",
  "uptime_s": 86400,
  "circuit_breakers": []
}
```

### Circuit Breakers

The `circuit_breaker.py` middleware implements circuit breakers for:
* SQL Warehouse (trips after 3 consecutive failures)
* Vector Search (trips after 3 consecutive failures)
* LLM endpoints (trips after 5 consecutive failures)

When tripped, the system returns degraded responses (SQL-only if VS is down) rather than failing entirely.

### Telemetry Tables

| Table | Content | Retention |
|---|---|---|
| `app_query_telemetry` | Every user query: latency, confidence, tools, cost | Indefinite |
| `tbl_pipeline_telemetry` | Pipeline execution events | Indefinite |
| `tbl_user_feedback` | Thumbs up/down + text feedback | Indefinite |
| `tbl_agent_sessions` | Multi-turn session state | 30 days |

---

## Troubleshooting Guide

### Common Issues

| Symptom | Likely Cause | Resolution |
|---|---|---|
| 500 errors on `/api/v1/query` | LLM endpoint down or rate-limited | Check serving endpoint status; circuit breaker should auto-recover |
| Slow responses (>30s) | SQL Warehouse cold start | First query after idle warms the warehouse; subsequent queries are fast |
| "Vector Search degraded" | VS endpoint unavailable or OAuth token expired | Client auto-resets on 401; check VS endpoint health |
| Empty results for known provider | Provider name mismatch | Check `dim_provider_canonical.all_names_used` for correct name |
| Frontend blank page | Static files not in `app/static/` | Rebuild frontend (see deployment process above) |
| `platform` import error | sys.path shadowing | The `main.py` platform fix should handle this; check startup logs |

### Log Access

* Application logs: Databricks Apps console → App → Logs
* Python logging level: INFO (set via `--log-level info` in app.yaml command)
* Structured events: Query `app_query_telemetry` for per-request diagnostics

---

## Performance Optimization

### Current Performance

| Metric | Target | Actual |
|---|---|---|
| Simple rate query | <5s | ~3s |
| Complex multi-tool query | <15s | ~8s |
| Portfolio-wide analysis | <30s | ~15–20s |
| Vector search latency | <500ms | ~200ms |
| SQL query execution | <5s | ~1–3s |

### Optimization Levers

* **Query cache** (`V4_QUERY_CACHE_ENABLED = True`): Identical questions return cached results
* **Direct dispatch**: Common question patterns bypass the full ReAct loop
* **Liquid clustering**: `tbl_contract_rates_all` clustered on `status` for fast current-rate filtering
* **SQL Warehouse sizing**: Serverless auto-scales; no manual tuning needed
* **Passage search top_k**: Default 20; tunable per-query for recall vs. latency tradeoff

---

## Cost Management

### Cost Components

| Component | Cost Driver | Estimate |
|---|---|---|
| LLM (Sonnet 4.6) | ~$0.005 per reasoning step | ~$0.03 per question |
| LLM (Haiku 4.5) | ~$0.001 per verification call | ~$0.005 per question |
| SQL Warehouse | Per-query compute | ~$0.001 per query |
| Vector Search | Index hosting + queries | Fixed monthly |
| Databricks Apps | Container runtime | Fixed monthly |

**Estimated per-question cost**: ~$0.03–$0.05

### Budget Controls

* Per-session budget: $15.00 maximum (prevents runaway LLM costs)
* Per-tool cost estimates tracked in `cost_controller.py`
* Rate limiting: 120 requests/minute per IP
* SQL row limit: 1000 rows maximum per query

---

## Upgrade & Maintenance

### Routine Maintenance

| Task | Frequency | Process |
|---|---|---|
| Pipeline re-run (new documents) | As needed | Run orchestrator notebook |
| Vector index sync | Automatic | Delta Sync handles this |
| LLM model upgrade | As available | Update endpoint name in `app.yaml` + redeploy |
| DQ validation | Weekly | Run SQL validation queries (cell 37) |
| Stress test | Pre-deployment | Run DQ stress test (cell 36) |

### Version Upgrade Path

1. Update code in workspace
2. Run test suite
3. Deploy new snapshot
4. Verify `/health` endpoint
5. Run smoke test queries
6. Monitor `app_query_telemetry` for anomalies

### Disaster Recovery

* **Data**: Delta Lake with time travel (30-day retention default)
* **Code**: Workspace version history + Git integration available
* **Configuration**: All in `app.yaml` and `settings.py` (reproducible)
* **Index**: Rebuilt from `tbl_vs_unified_ready` via Delta Sync (automatic)

---

*For architecture overview, see [02_architecture_overview.md](./02_architecture_overview.md)*
*For code structure, see [10_appendix_code_reference.md](./10_appendix_code_reference.md)*

# Application & Agent Architecture — Contract Intelligence Platform V4

> **Audience**: AI/ML engineers, application developers, technical reviewers

---

## Table of Contents

1. [Agent Architecture Overview](#agent-architecture-overview)
2. [Question-Answering Flow](#question-answering-flow)
3. [Question Router](#question-router)
4. [Agent Controller (ReAct Loop)](#agent-controller-react-loop)
5. [Tool Registry & Dispatch](#tool-registry--dispatch)
6. [Tool Catalog](#tool-catalog)
7. [Answer Assembly & Confidence](#answer-assembly--confidence)
8. [Hallucination Prevention](#hallucination-prevention)
9. [Multi-Turn Session Management](#multi-turn-session-management)
10. [Error Handling & Fallbacks](#error-handling--fallbacks)

---

## Agent Architecture Overview

The Contract Intelligence Agent is a bounded ReAct (Reason → Act → Observe) agent that orchestrates 19+ specialized tools to answer natural-language contract questions. It is:

* **Tool-grounded** — Every claim in an answer must originate from a tool result (SQL data or retrieved passage)
* **Budget-controlled** — Per-session cost limit of $15.00 with per-tool cost tracking
* **Step-bounded** — Maximum 10 reasoning steps per question (prevents infinite loops)
* **Timeout-protected** — 600-second total timeout, 120-second per-step timeout
* **Runtime-agnostic** — The agent never knows if it’s running in a notebook, API endpoint, or serving container

---

## Question-Answering Flow

```
User asks: "What is the inpatient case rate for Adventist Health Bakersfield?"
                                    │
                                    ▼
┌─────────────────────────────────────────────────┐
│ 1. PROVIDER RESOLUTION                          │
│    ProviderService resolves "Adventist Health    │
│    Bakersfield" → provider_id via canonical dim  │
└────────────────────────┬────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────┐
│ 2. QUESTION ROUTING                              │
│    QuestionRouter classifies → "rate_query"      │
│    (detects rate keywords + specific provider)    │
└────────────────────────┬────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────┐
│ 3. AGENT CONTROLLER (ReAct Loop)                  │
│    Step 1: THINK — "Need inpatient case rates"    │
│    Step 2: CALL_TOOL — rate_query(provider=...,   │
│            question="inpatient case rate")        │
│    Step 3: OBSERVE — SQL returns 5 rate rows      │
│    Step 4: SYNTHESIZE — Format answer with data   │
└────────────────────────┬────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────┐
│ 4. POST-GENERATION VALIDATION                     │
│    HallucinationGuard checks numeric grounding    │
│    AnswerValidator confirms completeness          │
│    Confidence scoring (HIGH/MODERATE/LOW)         │
└────────────────────────┬────────────────────────┘
                                    │
                                    ▼
              Source-cited answer returned to user
              with confidence score and tool trace
```

---

## Question Router

The `QuestionRouter` (`core/question_router.py`) classifies incoming questions into one of 16 route types:

| Route | Tool | Description |
|---|---|---|
| `clause_existence` | clause_existence | Does provider X have clause Y? |
| `structured_extraction` | field_extraction | Extract specific field values (DOFR, terms) |
| `single_provider` | provider_deep_dive | Comprehensive single-provider profile |
| `comparison` | comparison | Side-by-side multi-provider comparison |
| `rate_query` | rate_query | Rate lookups, benchmarks, stop-loss |
| `explanation` | explanation | "What is X?" knowledge-base questions |
| `multi_concept` | multi_concept | Questions spanning multiple contract concepts |
| `temporal` | temporal_analysis | "When did X change?" timeline questions |
| `sql_query` | sql_query | Direct structured data queries |
| `risk_alert` | risk_alert | Risk scores, alerts, deadlines |
| `financial_analysis` | financial_analysis | Spend, repricing, escalators |
| `system_membership` | system_membership | Health system network |
| `compliance_query` | compliance_query | Regulatory compliance |
| `clause_text` | clause_text | Verbatim contract language retrieval |
| `provenance` | provenance | Data lineage and audit trail |
| `provider_scorecard` | provider_scorecard | Composite multi-domain scorecard |

**Routing mechanism**: Hybrid heuristic + LLM classification with 6 deterministic override rules:

1. **RE-1**: Rate-signal rescue (clause_existence → rate_query when rate keywords dominate)
2. **RE-2**: Unresolvable comparison detection
3. **CE-FIX**: Target concept rescue for clause_existence
4. **EXTR**: Extraction-signal override to field_extraction
5. **CONSTR**: Comparison requires 2+ providers; single_provider requires exactly 1
6. **PROF-SQL**: Profile shortcut for pre-computed columns (offset/DOFR/IPA)

---

## Agent Controller (ReAct Loop)

The `AgentController` (`core/agent_controller.py`) implements the reasoning loop:

### LLM Prompt Structure

The agent receives a system prompt that includes:
* Role definition ("Contract Intelligence V4 Agent")
* Available tool catalogue (auto-generated from registry)
* Data model awareness rules (how to use profile columns, existence checks, etc.)
* Action vocabulary: `THINK`, `CALL_TOOL`, `SYNTHESIZE`, `ABORT`

### Step Execution

Each step, the LLM outputs JSON:
```json
{
  "thought": "I need inpatient case rates for this provider",
  "action": "CALL_TOOL",
  "tool_name": "rate_query",
  "tool_input": {"question": "inpatient case rate", "providers": ["Adventist Health Bakersfield"]}
}
```

### Direct Dispatch Optimization

For common question patterns (rate lookups, profile queries), the controller bypasses the full ReAct loop and directly dispatches to the appropriate tool. This reduces latency from ~8s to ~3s for simple questions.

### Budget & Step Limits

| Parameter | Value | Purpose |
|---|---|---|
| `AGENT_MAX_STEPS` | 10 | Prevent infinite reasoning loops |
| `AGENT_DEFAULT_BUDGET_USD` | $15.00 | Per-session cost cap |
| `AGENT_STEP_TIMEOUT_S` | 120s | Per-step timeout |
| `AGENT_TOTAL_TIMEOUT_S` | 600s | Total session timeout |
| `AGENT_REASONING_MAX_TOKENS` | 6000 | LLM output limit per step |

---

## Tool Registry & Dispatch

The `ToolRegistry` (`tools/registry.py`) manages tool registration, policy enforcement, and dispatch:

### Policy Checks (applied before every tool call)

1. Tool is registered
2. Tool policy is enabled (`tool_policies.py`)
3. Required feature flag is active
4. Remaining budget ≥ tool’s `max_cost_usd` estimate
5. Per-session call count not exceeded
6. Tool’s own input validation passes

### Tool Interface

All tools implement `BaseTool` (`tools/base.py`):
* `name: str` — Registry identifier
* `description: str` — LLM-visible description
* `_run(**kwargs) -> ToolResult` — Core logic
* `validate_inputs(**kwargs) -> list[str]` — Pre-execution validation

`ToolResult` contains: `success`, `data`, `summary`, `confidence`, `error_message`, `execution_time_s`

---

## Tool Catalog

### Structured Data Tools

| Tool | What It Does | Data Source |
|---|---|---|
| `rate_query` | Rate lookups, benchmarks, stop-loss, carve-outs, amendment comparison | `tbl_contract_rates_all`, `tbl_reimb_stop_loss`, `tbl_reimb_carve_outs` |
| `sql_query` | LLM-generated SQL against whitelisted tables | 13 approved tables (whitelist-secured) |
| `financial_analysis` | Spend exposure, repricing scenarios, escalators | `tbl_financial_exposure`, `tbl_rate_escalators` |
| `risk_alert` | Risk scores, active alerts, deadlines | `tbl_contract_risk_scores`, `tbl_alert_queue`, `tbl_contract_deadlines` |
| `compliance_query` | Compliance tracking, quality metrics | `tbl_compliance_tracking`, `tbl_quality_performance` |

### Retrieval Tools

| Tool | What It Does | Data Source |
|---|---|---|
| `passage_search` | Semantic search over contract text | Vector Search index (727K chunks) |
| `clause_text` | Retrieve verbatim clause language | Vector Search + clause tables |
| `clause_existence` | Portfolio-wide clause presence/absence | `tbl_contract_clauses`, profile flags |

### Composite Tools

| Tool | What It Does | Approach |
|---|---|---|
| `provider_deep_dive` | Full provider profile across all domains | Aggregates multiple tool calls |
| `comparison` | Side-by-side multi-provider analysis | Parallel queries, diff formatting |
| `temporal_analysis` | Amendment timeline, rate history | Time-ordered queries with change detection |
| `provider_scorecard` | Multi-domain risk/financial/compliance view | Cross-domain aggregation |

---

## Answer Assembly & Confidence

### Confidence Scoring

Multi-factor confidence formula for passage retrieval:
```
confidence = 0.50 * doc_score + 0.30 * passage_score + 0.20 * recency_score
```

Where:
* `doc_score` = ratio of passages exceeding 0.65 cosine similarity threshold
* `passage_score` = peak semantic relevance (max cosine similarity)
* `recency_score` = whether top passages are from current-effective documents

**Confidence labels**: HIGH (≥0.70), MODERATE (≥0.40), LOW (<0.40)

### Source Citations

Every answer includes citations with:
* Source document filename
* Estimated page number
* Chunk type (PASSAGE, CLAUSE, etc.)
* Cosine similarity score
* Whether the source is current-effective

---

## Hallucination Prevention

The `HallucinationGuard` (`core/hallucination_guard.py`) runs 7 post-generation checks:

1. **Confidence floor** — No citations + no SQL data → cap confidence at MODERATE
2. **Numeric consistency** — Numbers in answer must appear in tool results
3. **Provider name grounding** — Provider names must match resolved entities
4. **Date plausibility** — Dates must be within reasonable range (1990–2030)
5. **Non-BSC provider blocklist** — Block claims about Kaiser, Aetna, etc.
6. **Universality claim guard** — "All N providers have X" must be SQL-verified
7. **Same-provider cross-dimensional claim** — Prevents unsupported multi-hop assertions

**Design**: Permissive by default (flag and warn, not block), because false positives on valid answers are worse than allowing some hallucinations through to the citation verification layer.

---

## Multi-Turn Session Management

The `ContextManager` (`core/context_manager.py`) maintains conversation state:

* **Session persistence** — Sessions stored in `tbl_agent_sessions`
* **Working data accumulation** — Tool results from previous turns available to current turn
* **Provider context** — If a user asked about "Adventist" in turn 1, pronouns ("their rates") in turn 2 resolve correctly
* **Query cache** — Identical questions within a session return cached results (`tbl_query_cache`)

---

## Error Handling & Fallbacks

| Scenario | Handling |
|---|---|---|
| Tool execution fails | ToolResult.ERROR returned with message; agent can retry or use alternative tool |
| LLM returns unparseable JSON | Regex extraction of action/tool from raw text |
| Budget exhausted | Agent forced to SYNTHESIZE with available data |
| Max steps reached | Agent forced to SYNTHESIZE (partial answer acknowledged) |
| Vector Search degraded | Circuit breaker trips; fallback to SQL-only answers |
| SQL timeout | 300s timeout; query killed; error surfaced to user |
| Provider not found | Clear message: "Provider not found in our network" |
| No data available | Honest acknowledgment: "No data available for this query" |

---

*For LLM model details and GenAI approach, see [06_llm_and_genai_deep_dive.md](./06_llm_and_genai_deep_dive.md)*
*For tool configuration and policies, see [10_appendix_code_reference.md](./10_appendix_code_reference.md)*

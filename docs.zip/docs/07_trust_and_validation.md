# Trust & Validation — Contract Intelligence Platform V4

> **Audience**: Compliance, risk, quality assurance, client trust reviewers

---

## Table of Contents

1. [Data Quality Framework](#data-quality-framework)
2. [Stress Testing Methodology](#stress-testing-methodology)
3. [Answer Trust Mechanisms](#answer-trust-mechanisms)
4. [Known Limitations](#known-limitations)
5. [Remediation Process](#remediation-process)
6. [Continuous Monitoring](#continuous-monitoring)

---

## Data Quality Framework

### SQL Validation Queries (7 Automated Checks)

The platform includes reusable SQL validation queries that run against production data to verify integrity:

| # | Check | What It Validates | Threshold |
|---|---|---|---|
| 1 | Orphan rates | Rate records without a canonical provider mapping | 0 expected |
| 2 | Active providers, 0 rates | Active providers missing current rate data | <5 acceptable |
| 3 | Temporal inversions | Amendment dates out of chronological order | 0 expected |
| 4 | NULL effective dates | Current rates missing effective_date | <5% of current rates |
| 5 | Provider name mismatches | Profile vs. rates table name discrepancies | <10 (aliases acceptable) |
| 6 | Empty vector chunks | Chunks with <10 characters of text | <10 total |
| 7 | Financial exposure gaps | Active providers missing financial data | 0 (after P0 fix) |

**Post-fix results (2026-08-02)**:
* Total validation issues: 1,344 (reduced from 1,432)
* Name mismatches: 9 (all legitimate aliases)
* Financial exposure gaps: 0 (100% active provider coverage)
* Temporal inversions: 0

---

## Stress Testing Methodology

### Test Categories

The Data Quality Stress Test suite contains 19 ground-truth validated questions organized into 4 failure-mode categories:

| Category | Code | Tests | What It Validates |
|---|---|---|---|
| **Accuracy** | DQ-A | 7 questions | Answers match verifiable source data exactly |
| **Completeness** | DQ-C | 4 questions | System handles data gaps gracefully |
| **Hallucination** | DQ-N | 5+ questions | System refuses to fabricate non-existent data |
| **Consistency** | DQ-X | 3+ questions | Data aligns correctly between tables |

### Ground Truth Establishment

Each test case includes:
* **Question**: The exact natural-language query
* **Expected keywords**: Specific values that MUST appear in the answer
* **Ground truth**: The verified correct answer from source data
* **Failure mode**: What would constitute a failure for this specific question

### Example Test Cases

**Accuracy (DQ-A.1)**:
* Question: "What is the inpatient case rate for AICD procedures at Adventist Health Bakersfield?"
* Expected: Specific dollar amounts ($17,470, $16,932, $21,157, $20,541, $20,069)
* Failure mode: Rate values must be exact, not approximated or hallucinated

**Hallucination (DQ-N.1)**:
* Question: "What is the offset clause for Adventist Health Bakersfield?"
* Expected: System acknowledges NO offset clause exists (offset_clause_status = NO_MENTION)
* Failure mode: Must NOT fabricate an offset clause (only 15% of providers have one)

**Completeness (DQ-C.2)**:
* Question: "What are the current rates for Hidesert Medical Center?"
* Expected: System acknowledges provider is inactive or has no rate data
* Failure mode: Must NOT fabricate rates; should acknowledge data gap

### Scoring Logic

* **Accuracy**: At least 1 expected keyword must appear in the answer
* **Hallucination**: System must fire a "guard phrase" (e.g., "not available", "no mention", "not found") OR match expected keywords indicating refusal
* **Completeness**: Keyword match OR explicit acknowledgment of data gap
* **Consistency**: At least 1 cross-table alignment keyword must match

---

## Answer Trust Mechanisms

### Source Document Linking

Every answer is connected to its source through:
1. **Source filename** — The specific PDF document containing the evidence
2. **Page number** — Estimated page location within the document
3. **Chunk text** — The actual passage text that supports the claim
4. **Cosine similarity score** — How semantically relevant the passage is to the question
5. **is_current flag** — Whether the source is from the current-effective document

### Confidence Scoring

| Level | Score Range | Meaning | User Action |
|---|---|---|---|
| HIGH | ≥0.70 | Strong evidence from current-effective sources | Trust the answer |
| MODERATE | 0.40–0.69 | Partial evidence or older sources | Verify if critical |
| LOW | <0.40 | Weak evidence or potential gaps | Manually verify |

Confidence is computed from: document quality (50%), passage relevance (30%), and source recency (20%).

### Tool Call Transparency

The frontend `ProcessTrail` component shows users:
* Which tools were called (e.g., "rate_query", "passage_search")
* What parameters were used
* How long each step took
* What data was retrieved at each step

This creates a fully auditable reasoning trace for every answer.

---

## Known Limitations

### Honestly Documented Data Gaps

| Limitation | Impact | Status |
|---|---|---|
| 199 of 10,372 PDFs fully processed | Some providers may have incomplete rate data | Pipeline scaling planned |
| Claims feed not connected | Cannot validate rates against actual claims | Feature flag: `CLAIMS_AVAILABLE = False` |
| OCR noise in some documents | Some passages contain garbled text | Quality scoring deprioritizes these |
| 200 NULL effective dates in amendments | Historical docs with unparseable dates | Non-critical (doesn’t affect current rates) |
| Rate escalator formula_text quality varies | Some entries contain rate table data instead of formulas | `extraction_quality` column flags these |
| Reranker not deployed | Retrieval uses cosine similarity only (no cross-encoder) | Feature flag: `RERANKER_DEPLOYED = False` |

### What the System Cannot Do

* Cannot access external data (claims systems, eligibility, CMS databases)
* Cannot modify contract terms or generate binding language
* Cannot guarantee OCR accuracy on poorly scanned documents
* Cannot answer questions about providers not in the BSC network
* Cannot predict future contract negotiations or outcomes

---

## Remediation Process

### Issue Classification

All data quality issues are classified by pipeline stage and severity:

| Severity | Criteria | Response Time |
|---|---|---|
| **P0** | Data incorrectness affecting user-facing answers | Fix this week |
| **P1** | Data gaps limiting coverage but not causing errors | Fix this sprint |
| **P2** | Quality improvements, documentation, edge cases | Fix this quarter |

### P0 Fixes Executed (2026-08-02)

| Fix | Before | After |
|---|---|---|
| Northridge concat bug ("Centerroscoe") | 1862 bad rows | 0 |
| California Hospital concat bug | 157 bad rows | 0 |
| Scripps/Optum name swap | 2 cross-labeled providers | Correct |
| Financial exposure gap | 84 active providers missing | 0 missing |
| dim_provider_canonical bad names | 2 bad entries | Cleaned |

### Validation Protocol (Post-Fix)

1. Re-run 7 SQL validation queries — all counts must decrease or remain stable
2. Re-run DQ Stress Test suite — target >95% pass rate
3. Cross-check financial exposure covers >85% of active providers
4. Cross-check provider name mismatches <10
5. Regression test: existing test suites show no score degradation

---

## Continuous Monitoring

### Telemetry

* `tbl_pipeline_telemetry` — Pipeline execution events with pass/fail, timing, and error details
* `app_query_telemetry` — Every user query logged with latency, confidence, tool calls, and cost
* `tbl_user_feedback` — User thumbs-up/down on answers with optional text feedback

### Health Monitoring

* `/health` endpoint checks: SQL Warehouse, Vector Search, LLM endpoints
* Circuit breakers for each dependency (auto-trip on repeated failures)
* Degradation state tracking on Vector Search (with clear user-facing messaging)

### Regression Prevention

* Ground-truth test suite run before any deployment
* Data validation queries run after any pipeline re-execution
* Provider name consistency checked automatically on rate table updates

---

*For GenAI-specific trust details, see [06_llm_and_genai_deep_dive.md](./06_llm_and_genai_deep_dive.md)*
*For deployment monitoring, see [09_deployment_and_operations.md](./09_deployment_and_operations.md)*

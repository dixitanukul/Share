# Data Model Reference — Contract Intelligence Platform V4

> **Audience**: Data analysts, developers, anyone querying the system

---

## Table of Contents

1. [Data Model Overview](#data-model-overview)
2. [Core Tables](#core-tables)
3. [Rate & Reimbursement Tables](#rate--reimbursement-tables)
4. [Contract Intelligence Tables](#contract-intelligence-tables)
5. [Vector Search & Retrieval](#vector-search--retrieval)
6. [Derived Analytics Tables](#derived-analytics-tables)
7. [Entity Relationships](#entity-relationships)
8. [Common Query Patterns](#common-query-patterns)
9. [Data Quality Notes](#data-quality-notes)

---

## Data Model Overview

All tables reside in `dev_adb.raw` (Unity Catalog). The data model is organized into functional domains:

| Domain | Tables | Purpose |
|---|---|---|
| Provider Master | 2 tables | Canonical provider identity and profiles |
| Rates & Reimbursement | 7 tables | Rate schedules, stop-loss, escalators, carve-outs |
| Contract Intelligence | 6 tables | Risk scores, deadlines, alerts, compliance |
| Document & Amendment | 2 tables | Amendment timeline, document metadata |
| Vector Search | 1 table | Text chunks for semantic retrieval |
| Financial | 2 tables | Spend exposure, repricing scenarios |
| Network & Geography | 3 tables | Health systems, service areas, membership |
| Observability | 3 tables | Sessions, telemetry, feedback |

**Primary join key**: `provider_id` (STRING) — consistent across all tables.

---

## Core Tables

### `dim_provider_canonical`

**Purpose**: Provider identity resolution. Maps all known provider_ids to a single canonical facility.

| Column | Type | Description |
|---|---|---|
| `provider_id` | STRING | Every known BSC provider_id. Primary JOIN key to all tables. |
| `canonical_name` | STRING | The single resolved facility name for display and grouping. |
| `primary_provider_id` | STRING | Points to the canonical provider_id. Self-referencing for primary entries. |
| `is_primary_id` | BOOLEAN | TRUE = this row IS the representative ID. Filter for one row per facility. |
| `is_primary` | BOOLEAN | Alias. True = canonical entry, False = alias/variant. |
| `rank_in_facility` | INT | Rank among IDs mapping to same facility. |
| `doc_count` | BIGINT | Number of documents associated with this provider_id. |
| `total_rate_count` | BIGINT | Total rate line items across all versions. |
| `latest_effective_date` | STRING | Most recent effective date across documents. |
| `ids_in_facility` | BIGINT | Count of provider_ids mapping to this canonical facility. |
| `facility_total_docs` | BIGINT | Total documents across all IDs for this facility. |
| `facility_total_rates` | BIGINT | Total rates across all IDs for this facility. |
| `all_names_used` | ARRAY<STRING> | All name variants encountered in source documents. |
| `resolution_version` | STRING | Version tag for the resolution algorithm. |

**Row count**: 531 | **Key relationships**: Joins to all tables on `provider_id`

---

### `tbl_genie_provider_profile`

**Purpose**: Master provider profile. One row per provider with pre-computed contract metadata.

| Column | Type | Description |
|---|---|---|
| `provider_id` | STRING | Primary key. JOIN key to all base tables. |
| `provider_name` | STRING | Hospital/provider organization name. |
| `agreement_type` | STRING | Contract type: Base Agreement - Renewal, Fee For Service, etc. |
| `payment_type` | STRING | Primary reimbursement: Fee For Service, Capitation, Percent of Charges, Hybrid. |
| `auto_renewal` | STRING | Whether contract auto-renews ('True'/'False' as STRING, not boolean). |
| `contract_term_years` | STRING | Contract duration (1, 3, 5, Evergreen). |
| `total_documents` | BIGINT | Total PDFs processed for this facility. |
| `total_amendments` | BIGINT | Amendment count (excludes sentinel values ≥100). |
| `max_amendment_depth` | INT | Deepest amendment in chain. |
| `latest_amendment_date` | STRING | Most recent effective_date_parsed. |
| `total_rates` | BIGINT | Total rate line items (current + superseded). |
| `current_rates` | BIGINT | Count of current (non-superseded) rate line items. |
| `rate_categories` | BIGINT | Number of distinct rate_category types. |
| `avg_inpatient_per_diem` | DOUBLE | Average inpatient per diem rate ($). |
| `avg_outpatient_rate` | DOUBLE | Average outpatient rate ($). |
| `has_stop_loss` | BOOLEAN | TRUE if facility has stop-loss protection. |
| `stop_loss_threshold` | DOUBLE | Stop-loss attachment level ($). |
| `is_active` | BOOLEAN | TRUE = active provider (192 active / 114 inactive). |
| `data_status` | STRING | NULL=complete, 'INCOMPLETE_NO_RATES', 'CAPITATION_NO_FEE_SCHEDULE'. |
| `offset_clause_status` | STRING | 'HAS' (47) or 'NO_MENTION' (259). |
| `dofr_status` | STRING | 'HAS' (141) or 'NO_MENTION' (165). |
| `ipa_delegation_status` | STRING | 'HAS' (120) or 'NO_MENTION' (186). |
| `line_of_business` | STRING | Raw extracted LOB (76 distinct values). |
| `lob_normalized` | STRING | Standardized into 8 categories (use this for filtering). |
| `termination_for_convenience` | STRING | 'True'/'False' (STRING). |
| `termination_for_convenience_notice_days` | - | Notice period in days. |
| `termination_cure_period_days` | - | Cure period for breach. |
| `right_to_audit` | STRING | 'True'/'False' (STRING). |
| `contract_assignable` | STRING | 'True'/'False' (STRING). |

**Row count**: 306 | **Key relationships**: Joins to rates, deadlines, risk scores, financial exposure

---

## Rate & Reimbursement Tables

### `tbl_contract_rates_all`

**Purpose**: Central rate repository. All rate versions (current + superseded) with full lineage.

| Column | Type | Description |
|---|---|---|
| `provider_id` | STRING | FK to dim_provider_canonical. |
| `provider_name` | STRING | Provider facility name. |
| `source_filename` | STRING | PDF document this rate was extracted from. |
| `document_type` | STRING | Document classification. |
| `rate_category` | STRING | E.g., 'inpatient_case_rate', 'inpatient_per_diem', 'outpatient_other'. |
| `service_category` | STRING | E.g., 'Coronary Surgery', 'MS-DRG Case Rate - Commercial'. |
| `rate_type_detail` | STRING | Detailed rate classification. |
| `rate_text` | STRING | Original text representation of the rate. |
| `rate_numeric` | DOUBLE | Parsed numeric value (NULL for non-numeric rates). |
| `revenue_codes` | STRING | Associated revenue codes. |
| `effective_date` | STRING | Raw effective date string from contract. |
| `effective_date_parsed` | DATE | Parsed date for temporal queries. |
| `program` | STRING | Raw program designation. |
| `program_normalized` | STRING | Standardized program (Commercial, Medicare, Medi-Cal). |
| `network` | STRING | Network designation. |
| `formula` | STRING | Rate formula if applicable. |
| `notes` | STRING | Extraction notes. |
| `amendment_order` | STRING | 0=base agreement, N=Nth amendment (100% populated). |
| `status` | STRING | 'current' (171,763) or 'superseded' (288,139). **Clustered on this column.** |
| `superseded_by` | STRING | Composite key: 'eff:YYYY-MM-DD\|src:<filename>'. |
| `superseded_date` | STRING | Date when this rate was superseded. |
| `is_latest_version` | BOOLEAN | Whether this is the most recent extraction. |
| `is_valid_rate` | BOOLEAN | Domain-aware validity flag (PER_DAY>50K = invalid). |

**Row count**: 459,902 | **Current rates**: 171,763 | **Providers covered**: 518

---

### `tbl_reimb_stop_loss`

**Purpose**: Multi-tier stop-loss financial protections per provider.

| Column | Type | Description |
|---|---|---|
| `stop_loss_id` | STRING | Unique identifier (UUID). |
| `rule_id` | STRING | FK to tbl_reimb_rate_rules. |
| `contract_id` | STRING | FK to contract registry. |
| `provider_id` | STRING | Provider ID (clustered). |
| `stop_loss_type` | STRING | PER_DIEM, CASE_RATE, AGGREGATE, CORRIDOR. |
| `attachment_level` | FLOAT | Dollar amount where stop-loss kicks in. **Column-masked.** |
| `attachment_unit` | STRING | TOTAL_CHARGES, TOTAL_DAYS, TOTAL_COST. |
| `reimburse_formula_type` | STRING | FIXED_PER_DIEM, PERCENTAGE, CHARGES_LESS_THRESHOLD. |
| `reimburse_rate` | FLOAT | Per-diem rate above threshold. **Column-masked.** |
| `reimburse_percentage` | FLOAT | Percentage reimbursed above threshold. **Column-masked.** |
| `applies_to_services` | STRING | Which service lines covered. |

**Row count**: 262 | **Note**: Financial columns protected by `mask_rate_float` UDF

---

### `tbl_rate_escalators`

**Purpose**: Annual rate escalation terms (CPI-based, fixed percentage, Medicare update, etc.).

| Column | Type | Description |
|---|---|---|
| `escalator_id` | STRING | `<provider_id>_<type>_<seq>` |
| `provider_id` | STRING | FK to dim_provider_canonical. |
| `provider_name` | STRING | Provider name. |
| `escalator_type` | STRING | CPI, FIXED_PCT, FIXED_AMT, MEDICARE_UPDATE, CUSTOM. |
| `base_index` | STRING | CPI-U, CPI-W, Medicare IPPS, etc. |
| `adjustment_pct` | FLOAT | Additional percentage above the index. |
| `floor_pct` | FLOAT | Minimum annual increase. |
| `cap_pct` | FLOAT | Maximum annual increase. |
| `frequency` | STRING | ANNUAL, SEMI_ANNUAL, ON_AMENDMENT, OTHER. |
| `formula_text` | STRING | Verbatim escalation language (up to 2000 chars). |
| `extraction_quality` | STRING | HIGH/MEDIUM/LOW/NOISE. |
| `content_class` | STRING | Classification of formula_text content. |

**Row count**: 104 providers with escalator provisions

---

## Contract Intelligence Tables

### `tbl_contract_risk_scores`

**Purpose**: Composite risk assessment per provider across multiple dimensions.

| Column | Type | Description |
|---|---|---|
| `provider_id` | STRING | Primary provider_id. |
| `provider_name` | STRING | Provider name. |
| `lob` | STRING | Canonical LOB composition. |
| `payment_type` | STRING | Reimbursement method. |
| `risk_score` | INT | Composite risk score (higher = more risk). |
| `risk_tier` | STRING | LOW (239), MEDIUM (26), MONITOR (7). |
| `expiration_risk` | INT | Risk from approaching contract expiration. |
| `days_to_expiry` | INT | Days until contract expires. |
| `compliance_gap` | INT | Compliance requirement gaps. |
| `clause_gap` | INT | Missing standard clause count. |
| `amendment_velocity` | INT | Rate of contract changes. |
| `fin_risk` | INT | Financial risk score component. |
| `contracted_spend` | DOUBLE | Annual contracted spend. |

**Row count**: 272 providers scored

---

### `tbl_contract_deadlines`

**Purpose**: Contract expiration and action-required dates with priority tiers.

| Column | Type | Description |
|---|---|---|
| `deadline_id` | STRING | Unique identifier. |
| `provider_id` | STRING | Provider. |
| `provider_name` | STRING | Provider name. |
| `deadline_type` | STRING | Type of deadline event. |
| `contract_status` | STRING | EXPIRED, ACTIVE, FUTURE, ACTIVE_NO_EXPIRY, UNKNOWN. |
| `event_date` | DATE | The deadline date. |
| `action_required_by` | DATE | Date by which action must be taken. |
| `days_until_action` | INT | Days until action_required_by. |
| `priority_tier` | STRING | CRITICAL, HIGH, MEDIUM, LOW. |
| `notice_days` | INT | Required notice period. |
| `source_filename` | STRING | Source document. |

---

### `tbl_financial_exposure`

**Purpose**: Contracted spend and utilization per provider by line of business.

| Column | Type | Description |
|---|---|---|
| `provider_id` | STRING | Provider. |
| `period_start` | DATE | Measurement period start. |
| `period_end` | DATE | Measurement period end. |
| `line_of_business` | STRING | LOB segment. |
| `assigned_members` | INT | Member count. |
| `inpatient_admits` | INT | Inpatient admission count. |
| `outpatient_visits` | INT | Outpatient visit count. |
| `contracted_spend` | DECIMAL(15,2) | Estimated contracted spend. |
| `actual_spend` | DECIMAL(15,2) | Actual spend (when available). |
| `variance_pct` | FLOAT | Spend variance percentage. |
| `source` | STRING | CLAIMS, ESTIMATE, BUDGET. |
| `estimate_confidence` | STRING | PROXY_PMPM_x12, PROXY_AVG_RATE, UNKNOWN. |

**Coverage**: All 192 active providers (gap closed in P0 fix, 2026-08-02)

---

## Vector Search & Retrieval

### `tbl_vs_unified_ready`

**Purpose**: Text chunks from contract PDFs, prepared for vector embedding and semantic search.

| Column | Type | Description |
|---|---|---|
| `chunk_id` | STRING | Unique chunk identifier. |
| `source_filename` | STRING | Source PDF document. |
| `provider_name` | STRING | Provider facility name. |
| `provider_id` | STRING | Provider ID. |
| `chunk_text` | STRING | The actual text content of the chunk. |
| `embedded_text` | STRING | Text used for embedding (context_prefix + chunk_text). |
| `chunk_type` | STRING | PASSAGE, CLAUSE, DEFINITION, RATE_TABLE, CONDITION. |
| `page_number_est` | INT | Estimated page number in source PDF. |
| `chunk_index` | INT | Sequential chunk number within document. |
| `section_header` | STRING | Detected section header. |
| `content_length` | INT | Character length of chunk_text. |
| `quality_score` | FLOAT | Quality assessment (0.0–1.0). |
| `extraction_method` | STRING | How text was extracted. |
| `doc_role` | STRING | Document role in contract chain. |
| `effective_date` | STRING | Document effective date. |
| `is_current` | BOOLEAN | TRUE = from current-effective document. |
| `context_prefix` | STRING | Contextual header prepended for embedding. |
| `amendment_order` | INT | Amendment sequence (0=base, 1+=amendments). |

**Row count**: 727,875 | **Indexed in**: `idx_unified_v4`

---

## Entity Relationships

```
dim_provider_canonical (531 rows)
    │
    ├── tbl_genie_provider_profile (306 providers, 1:1)
    │       │
    │       ├── tbl_contract_rates_all (459K rates, 1:many)
    │       ├── tbl_contract_risk_scores (272 scored, 1:1)
    │       ├── tbl_contract_deadlines (1:many per provider)
    │       ├── tbl_financial_exposure (1:many per LOB/period)
    │       ├── tbl_rate_escalators (104 providers, 1:many)
    │       ├── tbl_reimb_stop_loss (262 provisions, 1:many)
    │       └── tbl_quality_performance (1:many)
    │
    ├── tbl_genie_amendment_timeline (6,609 docs, 1:many)
    │
    └── tbl_vs_unified_ready (727K chunks, 1:many)
```

**Universal join key**: `provider_id` (STRING) connects all tables.

---

## Common Query Patterns

**Current rates for a provider:**
```sql
SELECT * FROM dev_adb.raw.tbl_contract_rates_all
WHERE LOWER(provider_name) LIKE '%adventist%bakersfield%'
  AND status = 'current'
```

**Active providers with offset clause:**
```sql
SELECT provider_name, offset_clause_status
FROM dev_adb.raw.tbl_genie_provider_profile
WHERE is_active = TRUE AND offset_clause_status = 'HAS'
```

**Contract deadlines in next 90 days:**
```sql
SELECT provider_name, event_date, priority_tier, days_until_action
FROM dev_adb.raw.tbl_contract_deadlines
WHERE event_date BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(), 90)
ORDER BY event_date
```

**Provider risk distribution:**
```sql
SELECT risk_tier, COUNT(*) as provider_count
FROM dev_adb.raw.tbl_contract_risk_scores
GROUP BY risk_tier
```

---

## Data Quality Notes

* **Provider name mismatches**: 9 remaining between profile and rates tables (legitimate aliases)
* **NULL effective dates**: 200 amendment documents with unparseable dates (historical docs)
* **Rate validity**: `is_valid_rate = FALSE` flags out-of-bounds extractions (PER_DAY > $50K)
* **Financial exposure**: `estimate_confidence` column indicates data source quality
* **Vector chunks**: 1 chunk with NULL `chunk_type` (trivial, flagged for cleanup)
* **Temporal inversions**: 0 after data quality fixes (amendment dates in correct order)

---

*For pipeline details on how these tables are populated, see [03_data_pipeline_deep_dive.md](./03_data_pipeline_deep_dive.md)*
*For agent tool queries against these tables, see [05_application_agent_architecture.md](./05_application_agent_architecture.md)*

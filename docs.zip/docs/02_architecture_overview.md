# Architecture Overview — Contract Intelligence Platform V4

> **Audience**: Solution architects, technical leadership, client technical reviewers

---

## Table of Contents

1. [High-Level System Architecture](#high-level-system-architecture)
2. [Component Inventory](#component-inventory)
3. [Technology Stack](#technology-stack)
4. [Data Flow Overview](#data-flow-overview)
5. [Integration Points](#integration-points)
6. [Security and Data Governance](#security-and-data-governance)
7. [Deployment Architecture](#deployment-architecture)
8. [Scalability Considerations](#scalability-considerations)

---

## High-Level System Architecture

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                           USER INTERFACE LAYER                              │
│  ┌──────────────────────┐  ┌─────────────────┐  ┌───────────────────────┐  │
│  │  React Frontend       │  │  REST API        │  │  Notebook Interface    │  │
│  │  (Chat, Providers,    │  │  (FastAPI)       │  │  (Interactive dev)     │  │
│  │   Reports, Alerts)   │  │                 │  │                       │  │
│  └──────────┬───────────┘  └────────┬────────┘  └───────────┬───────────┘  │
└─────────────┴───────────────────┴──────────────────┴───────────────────────┘
                               │
┌───────────────────────────────┴────────────────────────────────────────────┐
│                         AGENT ORCHESTRATION LAYER                           │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐       │
│  │ Question Router  │  │ Agent Controller │  │ Cost Controller  │       │
│  │ (intent + route) │  │ (ReAct loop)     │  │ (budget guard)   │       │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘       │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐       │
│  │ Hallucination    │  │ Context Manager  │  │ Answer Validator  │       │
│  │ Guard (post-gen) │  │ (session state)  │  │ (grounding check) │       │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘       │
└─────────────────────────────────────────────────────────────────────────────┘
                               │
┌───────────────────────────────┴────────────────────────────────────────────┐
│                            TOOL EXECUTION LAYER                             │
│                                                                             │
│  rate_query │ sql_query │ passage_search │ clause_existence │ comparison    │
│  risk_alert │ financial_analysis │ temporal_analysis │ provider_deep_dive    │
│  clause_text │ compliance_query │ system_membership │ network_geography    │
│  provenance │ provider_scorecard │ genie_query │ export_data │ calculate   │
└─────────────────────────────────────────────────────────────────────────────┘
                               │
┌───────────────────────────────┴────────────────────────────────────────────┐
│                           DATA & SERVICES LAYER                             │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐       │
│  │ Vector Search    │  │ SQL Warehouse    │  │ LLM Endpoints    │       │
│  │ (727K chunks)    │  │ (structured)     │  │ (Sonnet + Haiku) │       │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘       │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                   Unity Catalog (dev_adb.raw)                       │  │
│  │  35+ Delta tables: rates, clauses, providers, risk, compliance...  │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Component Inventory

### Frontend (React/TypeScript)

| Component | File | Purpose |
|---|---|---|
| Chat Interface | `ChatPageV2.tsx` | Natural-language question input with streaming responses |
| Provider Explorer | `ProviderExplorerV2.tsx` | Browse and search the provider network |
| Report Generator | `ReportPageV2.tsx` | Generate formatted contract reports |
| Alerts Dashboard | `AlertsPageV2.tsx` | View and manage contract risk alerts |
| Deadline Calendar | `DeadlineCalendarV2.tsx` | Visual calendar of contract deadlines |
| Document Viewer | `DocumentViewerV2.tsx` | View source contract PDFs with highlighting |
| Compliance Monitor | `CompliancePageV2.tsx` | Track regulatory compliance status |
| System Status | `StatusPageV2.tsx` | Platform health and dependency monitoring |
| Evidence Panel | `EvidencePanel.tsx` | Display source citations and evidence for answers |
| Process Trail | `ProcessTrail.tsx` | Show agent reasoning steps and tool calls |

### Backend (FastAPI)

| Component | File | Purpose |
|---|---|---|
| API Server | `app/main.py` | REST API endpoints, SSE streaming, static file serving |
| SQL Client | `app/sql_client.py` | Databricks Statement Execution API wrapper |
| Circuit Breaker | `app/middleware/circuit_breaker.py` | Fault tolerance for SQL/VS/LLM dependencies |

### Agent Core (`platform/v4/core/`)

| Component | File | Purpose |
|---|---|---|
| Agent Controller | `agent_controller.py` | ReAct (Reason-Act-Observe) orchestration loop |
| Question Router | `question_router.py` | Classifies questions into 16 route types |
| Question Decomposer | `question_decomposer.py` | Breaks complex questions into sub-questions |
| Context Manager | `context_manager.py` | Multi-turn session state management |
| Hallucination Guard | `hallucination_guard.py` | Post-generation grounding verification |
| Answer Validator | `answer_validator.py` | Validates answer completeness and correctness |
| Cost Controller | `cost_controller.py` | LLM budget tracking and enforcement |
| Provenance Tracker | `provenance.py` | Source attribution for all answers |
| Current Effective Filter | `current_effective_filter.py` | Determines current-effective documents |
| Response Assembler | `response_assembler.py` | Combines sub-answers into coherent final response |

### Tools (`platform/v4/tools/`)

| Tool | File | Purpose |
|---|---|---|
| `rate_query` | `rate_query.py` | Provider reimbursement rate lookups, benchmarks, stop-loss |
| `sql_query` | `sql_query.py` | General structured SQL against whitelisted tables |
| `passage_search` | `passage_search.py` | Semantic search over 727K contract text chunks |
| `clause_existence` | `clause_existence_tool.py` | Clause presence/absence detection across providers |
| `clause_text` | `clause_text.py` | Verbatim contract clause text retrieval |
| `comparison` | `comparison.py` | Side-by-side multi-provider comparisons |
| `temporal_analysis` | `temporal_analysis.py` | Amendment timeline and rate history analysis |
| `provider_deep_dive` | `provider_deep_dive.py` | Comprehensive single-provider profiles |
| `risk_alert` | `risk_alert.py` | Risk scores, alerts, and deadline queries |
| `financial_analysis` | `financial_analysis.py` | Spend analysis, repricing scenarios, escalators |
| `compliance_query` | `compliance_query.py` | Compliance tracking and quality metrics |
| `system_membership` | `system_membership.py` | Health system network membership |
| `network_geography` | `network_geography.py` | Geographic coverage and service areas |
| `provenance` | `provenance.py` | Data extraction lineage and audit trail |
| `provider_scorecard` | `provider_scorecard.py` | Composite multi-domain provider assessment |
| `field_extraction` | `field_extraction.py` | DOFR matrix and structured field extraction |
| `genie_query` | `genie_query.py` | Databricks Genie Space integration |
| `export_data` | `export_data.py` | Data export to Excel/CSV |
| `calculate` | `calculate.py` | Mathematical computations on contract data |

### Services (`platform/v4/services/`)

| Service | File | Purpose |
|---|---|---|
| Vector Search Service | `vector_search_service.py` | Databricks VS SDK wrapper with degradation handling |
| Provider Service | `provider_service.py` | Canonical provider resolution and alias matching |
| Retrieval Service | `retrieval_service.py` | Multi-channel hybrid retrieval orchestration |
| Rate Query Templates | `rate_query_templates.py` | SQL template generation for rate queries |
| Citation Validator | `citation_validator.py` | Verifies answer citations against source data |
| Answer Grounding | `answer_grounding.py` | Enforces factual grounding in tool results |
| Tier Service | `tier_service.py` | Provider tier and priority classification |
| Recall Boost | `recall_boost.py` | Retrieval recall enhancement strategies |
| Telemetry Writer | `telemetry_writer.py` | Structured observability event logging |

---

## Technology Stack

| Layer | Technology | Version/Details |
|---|---|---|
| **Cloud Platform** | Microsoft Azure | BSC tenant, West US 2 region |
| **Data Platform** | Databricks | Runtime 18.0, Unity Catalog |
| **Storage** | Delta Lake | ACID transactions, time travel, liquid clustering |
| **Catalog** | Unity Catalog | `dev_adb.raw` (35+ managed tables) |
| **Vector Search** | Databricks Vector Search | `contract_intelligence_vs_endpoint` (727K chunks) |
| **Embeddings** | GTE-Large-EN | 1024-dimensional, `databricks-gte-large-en` |
| **Primary LLM** | Claude Sonnet 4.6 | Agent reasoning, SQL generation, answer synthesis |
| **Fast LLM** | Claude Haiku 4.5 | Citation verification, entity extraction, coreference |
| **SQL Compute** | SQL Warehouse | ID: `2c99c6485f03ee73` (serverless) |
| **App Runtime** | Databricks Apps | SNAPSHOT deployment, Service Principal auth |
| **Backend** | FastAPI (Python) | uvicorn, async streaming, rate limiting |
| **Frontend** | React + TypeScript | Vite build, Tailwind CSS |
| **Security** | Unity Catalog + ABAC | Column masks on financial columns, row-level security |

---

## Data Flow Overview

### Ingestion Path (Offline — Pipeline)

```
Source PDFs (10,372)          Pipeline Notebooks (00-20)
       │                              │
       ▼                              ▼
┌──────────────┐    ┌────────────────────────────────────────┐
│ Text/OCR     │    │ LLM-Powered Structured Extraction      │
│ Extraction   │───▶│ (rates, clauses, terms, dates, parties) │
└──────────────┘    └───────────────────┬────────────────────┘
                                       │
                              ┌─────────┴─────────┐
                              │                    │
                    ┌─────────┴───────┐  ┌──────┴─────────┐
                    │ Delta Tables    │  │ Vector Index    │
                    │ (459K rates,    │  │ (727K chunks,   │
                    │  306 providers) │  │  GTE-1024d)     │
                    └─────────────────┘  └────────────────┘
```

### Query Path (Online — User Request)

```
User Question → FastAPI → QuestionRouter → AgentController (ReAct)
                                                 │
                            ┌───────────────────┴────────────────────┐
                            ▼                                    ▼
                    SQL Warehouse                       Vector Search
                    (structured data)                   (semantic retrieval)
                            │                                    │
                            └───────────────────┬────────────────────┘
                                                ▼
                            Hallucination Guard + Answer Validator
                                                ▼
                            LLM Synthesis (Claude Sonnet 4.6)
                                                ▼
                            Source-Cited Answer + Confidence Score
```

---

## Integration Points

| Integration | Protocol | Purpose |
|---|---|---|
| Databricks SQL Warehouse | Statement Execution API (REST) | Structured queries against Delta tables |
| Databricks Vector Search | VS SDK (gRPC) | Semantic similarity search |
| Foundation Model APIs | REST (OpenAI-compatible) | LLM reasoning and extraction |
| Unity Catalog | Databricks SDK | Table governance, access control, lineage |
| Databricks Genie | Genie Space API | Natural-language to SQL for ad-hoc queries |
| Frontend | HTTP + SSE | Real-time streaming of agent responses |

---

## Security and Data Governance

### Access Control
* **Unity Catalog governance** — All tables managed under `dev_adb.raw` with fine-grained ACLs
* **Column masking** — Financial rate columns (stop-loss thresholds, reimbursement rates) protected via `mask_rate_float` UDF
* **Service Principal authentication** — App runs under dedicated SP with minimal permissions
* **Rate limiting** — 120 requests/minute per IP via SlowAPI middleware

### SQL Security
* **Table whitelist** — Only 13 approved tables accessible to LLM-generated SQL (`table_whitelist.py`)
* **DDL/DML blocking** — Regex-based rejection of CREATE, INSERT, UPDATE, DELETE, DROP operations
* **Input sanitization** — All user inputs sanitized before SQL LIKE clause inclusion
* **Parameterized queries** — Catalog/schema prefix enforced programmatically

### Data Privacy
* **PII redaction** — SSN, DOB, and address patterns stripped before LLM injection
* **No external data transmission** — All LLM endpoints hosted within Databricks (Azure tenant)
* **No model training on contract data** — Inference-only usage of foundation models
* **Audit trail** — All queries logged to `app_query_telemetry` table

---

## Deployment Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    Databricks Apps Container                 │
│                                                              │
│  uvicorn → FastAPI (app/main.py)                             │
│       │                                                      │
│       ├── /health             (liveness probe)               │
│       ├── /api/v1/query       (contract questions)            │
│       ├── /api/v1/providers   (provider search)              │
│       ├── /api/v1/report      (report generation)            │
│       ├── /api/v1/feedback    (user feedback)                │
│       └── /*                  (React SPA static files)        │
│                                                              │
└───────────────┬────────────────┬─────────────────┬────────────┘
                │                │                 │
                ▼                ▼                 ▼
        SQL Warehouse    VS Endpoint      LLM Serving Endpoints
        (2c99c648...)    (contract_      (claude-sonnet-4-6,
                          intelligence)   claude-haiku-4-5)
```

**Deployment mode**: SNAPSHOT — source code is bundled into the container image at deploy time.

**Configuration**: Environment variables injected via `app.yaml` resource bindings. Catalog/schema, LLM endpoints, and SQL warehouse ID are all configurable without code changes.

---

## Scalability Considerations

| Dimension | Current State | Scaling Path |
|---|---|---|
| **Providers** | 306 contracted | Linear — add documents to pipeline, re-index |
| **Documents** | 10,372 PDFs (199 fully processed) | Batch pipeline, parallelizable per provider |
| **Vector Index** | 727K chunks | Databricks VS scales to billions |
| **Concurrent Users** | Rate-limited at 120 req/min | Horizontal scale via Databricks Apps replicas |
| **Query Latency** | ~8s average | Serverless SQL warehouse auto-scales |
| **LLM Throughput** | Shared model serving | Token-based rate limits, queueing |

The architecture separates offline (pipeline) processing from online (query) serving, ensuring that re-indexing or re-extraction never impacts user-facing latency.

---

*For detailed pipeline stages, see [03_data_pipeline_deep_dive.md](./03_data_pipeline_deep_dive.md)*
*For agent tool details, see [05_application_agent_architecture.md](./05_application_agent_architecture.md)*

# Appendix: Code Reference — Contract Intelligence Platform V4

> **Audience**: Developers who need to modify or extend the system

---

## Table of Contents

1. [Directory Structure](#directory-structure)
2. [Key Code Modules](#key-code-modules)
3. [Configuration Files](#configuration-files)
4. [API Endpoints](#api-endpoints)
5. [Extension Points](#extension-points)
6. [Dependencies](#dependencies)

---

## Directory Structure

```
contract-intelligence-v4/
├── app/                            # FastAPI application server
│   ├── main.py                     # Entry point: routes, lifespan, streaming, security
│   ├── sql_client.py               # Databricks Statement Execution API wrapper
│   ├── __init__.py
│   ├── static/                     # Pre-built React frontend (served by FastAPI)
│   └── middleware/
│       ├── circuit_breaker.py      # Fault tolerance for SQL/VS/LLM
│       └── __init__.py
│
├── platform/                       # Core backend package
│   ├── __init__.py
│   └── v4/
│       ├── __init__.py
│       ├── README.md
│       │
│       ├── core/                   # Agent orchestration layer
│       │   ├── agent_controller.py # ReAct loop: reason → tool → observe → answer
│       │   ├── question_router.py  # 16-route classification with 6 override rules
│       │   ├── question_decomposer.py # Complex question → sub-questions
│       │   ├── context_manager.py  # Multi-turn session state
│       │   ├── hallucination_guard.py # 7-check post-generation validation
│       │   ├── answer_validator.py # Answer completeness verification
│       │   ├── answer_completeness_validator.py # Detailed completeness checks
│       │   ├── response_assembler.py # Sub-answer → final response assembly
│       │   ├── cost_controller.py  # LLM budget tracking ($15/session)
│       │   ├── provenance.py       # Source attribution tracking
│       │   ├── current_effective_filter.py # is_current / effective-date helpers
│       │   └── __init__.py
│       │
│       ├── tools/                  # One file per agent tool (19+ tools)
│       │   ├── base.py             # BaseTool abstract class
│       │   ├── registry.py         # ToolRegistry: registration + policy dispatch
│       │   ├── rate_query.py       # Rate lookups, benchmarks, stop-loss
│       │   ├── sql_query.py        # LLM-generated SQL (whitelist-secured)
│       │   ├── passage_search.py   # Vector search over contract text
│       │   ├── clause_existence_tool.py # Portfolio-wide clause detection
│       │   ├── clause_text.py      # Verbatim clause text retrieval
│       │   ├── comparison.py       # Multi-provider side-by-side
│       │   ├── temporal_analysis.py # Amendment timeline & rate history
│       │   ├── provider_deep_dive.py # Full provider profile
│       │   ├── risk_alert.py       # Risk scores, alerts, deadlines
│       │   ├── financial_analysis.py # Spend, repricing, escalators
│       │   ├── compliance_query.py # Compliance & quality metrics
│       │   ├── system_membership.py # Health system network
│       │   ├── network_geography.py # Geographic coverage
│       │   ├── provenance.py       # Extraction audit trail
│       │   ├── provider_scorecard.py # Composite multi-domain view
│       │   ├── provider_lookup.py  # Provider ID resolution
│       │   ├── field_extraction.py # DOFR matrix, structured fields
│       │   ├── genie_query.py      # Databricks Genie Space integration
│       │   ├── amendment_chain.py  # Amendment document chain queries
│       │   ├── multi_concept.py    # Multi-concept portfolio analysis
│       │   ├── explanation.py      # Knowledge-base explanations
│       │   ├── summarize.py        # Document/answer summarization
│       │   ├── document_fetch.py   # Source document retrieval
│       │   ├── citation_verify.py  # Citation verification
│       │   ├── export_data.py      # Excel/CSV export
│       │   ├── calculate.py        # Mathematical computations
│       │   ├── chart_generate.py   # Data visualization
│       │   ├── draft_text.py       # Contract language drafting
│       │   ├── clause_existence/   # Clause existence sub-module
│       │   └── __init__.py
│       │
│       ├── config/                 # Runtime configuration
│       │   ├── settings.py         # All runtime constants (models, limits, flags)
│       │   ├── table_whitelist.py  # SQL-generation approved tables + descriptions
│       │   ├── tool_policies.py    # Per-tool policy (enabled, budget, limits)
│       │   ├── workspace_config.py # Workspace-specific configuration
│       │   ├── taxonomies.py       # Service line taxonomy constants
│       │   └── __init__.py
│       │
│       ├── services/               # Shared services layer
│       │   ├── vector_search_service.py # Databricks VS SDK wrapper
│       │   ├── provider_service.py # Canonical provider resolution
│       │   ├── retrieval_service.py # Multi-channel hybrid retrieval
│       │   ├── rate_query_templates.py # SQL template generation for rates
│       │   ├── sql_helpers.py      # Safe SQL construction utilities
│       │   ├── citation_validator.py # Citation verification service
│       │   ├── answer_grounding.py # Factual grounding enforcement
│       │   ├── tier_service.py     # Provider tier classification
│       │   ├── recall_boost.py     # Retrieval recall enhancement
│       │   ├── text_utils.py       # Text processing utilities
│       │   ├── concepts.py         # Contract concept definitions
│       │   ├── telemetry_writer.py # Structured event logging
│       │   ├── polling.py          # Async polling utilities
│       │   ├── verification/       # Verification sub-module
│       │   └── __init__.py
│       │
│       ├── contracts/              # Pydantic/dataclass types
│       ├── data/                   # Repository layer
│       │   ├── session_repo.py     # Session persistence
│       │   ├── query_cache_repo.py # Query result caching
│       │   ├── feedback_repo.py    # User feedback storage
│       │   ├── telemetry_repo.py   # Telemetry event storage
│       │   ├── schema_context_builder.py # Dynamic schema context
│       │   └── __init__.py
│       │
│       ├── adapters/               # Legacy compatibility adapters
│       ├── presentation/           # Report rendering (HTML/Excel)
│       ├── runtime/                # Startup and runtime utilities
│       │   ├── api_entry.py        # API-mode initialization
│       │   ├── notebook_entry.py   # Notebook-mode initialization
│       │   ├── databricks_llm_client.py # LLM API client
│       │   ├── notebook_stream_handler.py # Notebook streaming output
│       │   ├── async_bridge.py     # Async/sync bridge utilities
│       │   └── __init__.py
│       │
│       └── tests/                  # Unit and integration tests
│
├── pipeline/                       # Data pipeline scripts (ordered 00-20)
│   ├── 00_config.py                # Shared configuration + utilities
│   ├── 01_execute_ddl.py           # Schema creation
│   ├── 02_state_engine.py          # Document state machine
│   ├── 03_reimbursement_migration.py # Rate extraction + migration
│   ├── 04_legal_chunking.py        # PDF → text chunks
│   ├── 05_retrieval_engine.py      # Vector index construction
│   ├── 07_citation_verification.py # Cross-validation
│   ├── 08_intelligence.py          # Financial intelligence
│   ├── 11_evaluation_harness.py    # Quality evaluation
│   ├── 12_gold_annotation.py       # Gold standard annotation
│   ├── 13_llm_assisted_annotation  # LLM clause classification
│   ├── 13_temporal_validity        # Temporal validity
│   ├── 13_vs_index_refresh         # VS index maintenance
│   ├── 14_observability            # Pipeline health metrics
│   ├── 14_report_validation_audit  # Validation reports
│   ├── 15_governance               # Data governance setup
│   ├── 16_confidence               # Confidence calibration
│   ├── 17_testing                  # Automated testing
│   ├── 18_retrieval_quality        # Retrieval quality tuning
│   ├── 19_semantic_intelligence    # Semantic analysis
│   ├── 20_clause_classification    # Multi-label classification
│   ├── run_platform_modules_orchestrator # Orchestration notebook
│   ├── step_0_3_vs_rebuild         # VS index rebuild utility
│   └── __init__.py
│
├── frontend/                       # React/TypeScript frontend
│   ├── src/
│   │   ├── App.tsx                 # Root component + routing
│   │   ├── main.tsx                # React entry point
│   │   ├── pages/                  # Page components
│   │   │   ├── ChatPageV2.tsx      # Main chat interface
│   │   │   ├── ProviderExplorerV2.tsx # Provider browser
│   │   │   ├── ReportPageV2.tsx    # Report generator
│   │   │   ├── AlertsPageV2.tsx    # Alert dashboard
│   │   │   ├── DeadlineCalendarV2.tsx # Deadline calendar
│   │   │   ├── DocumentViewerV2.tsx # PDF viewer
│   │   │   ├── CompliancePageV2.tsx # Compliance monitor
│   │   │   └── StatusPageV2.tsx    # System health
│   │   ├── components/             # Shared UI components
│   │   │   ├── EvidencePanel.tsx   # Source citation display
│   │   │   ├── ProcessTrail.tsx    # Agent reasoning steps
│   │   │   ├── StructuredFeedback.tsx # Feedback widget
│   │   │   └── OnboardingModal.tsx # First-use onboarding
│   │   ├── hooks/                  # React hooks
│   │   ├── services/               # API client services
│   │   ├── types/                  # TypeScript interfaces
│   │   └── styles/                 # CSS/Tailwind styles
│   ├── package.json                # npm dependencies
│   ├── vite.config.ts              # Vite bundler config
│   ├── tailwind.config.js          # Tailwind CSS config
│   └── tsconfig.json               # TypeScript config
│
├── src/                            # Shared utilities
│   ├── chunking.py                 # PDF chunking algorithms
│   ├── json_repair.py              # Malformed JSON recovery
│   ├── validation.py               # Schema validation
│   └── __init__.py
│
├── tests/                          # Integration tests
├── evaluation/                     # Evaluation datasets and scripts
├── benchmarks/                     # Performance benchmarks
├── docs/                           # This documentation directory
│
├── app.yaml                        # Databricks Apps deployment manifest
├── requirements.txt                # Python dependencies
├── conftest.py                     # pytest root configuration
├── build_and_deploy.py             # Deployment automation script
├── .gitignore                      # Git exclusions
├── .databricksignore               # Files excluded from app deployment
└── README.md                       # Project overview
```

---

## Key Code Modules

### Agent Controller (`platform/v4/core/agent_controller.py`)

The heart of the system. Implements the bounded ReAct loop:
* Receives a question + session context
* Calls LLM with tool catalogue to select next action
* Dispatches tool calls via ToolRegistry
* Accumulates results in working data
* Synthesizes final answer when sufficient evidence gathered
* Enforces budget/step/timeout constraints

### Question Router (`platform/v4/core/question_router.py`)

Classifies questions into 16 route types using:
* Heuristic pattern matching (regex-based)
* Optional LLM classification (for ambiguous cases)
* 6 deterministic override rules for edge cases
* Provider detection via ProviderService

### SQL Query Tool (`platform/v4/tools/sql_query.py`)

Generates and executes SQL against whitelisted tables:
* Injects table schema context from `table_whitelist.py`
* LLM generates SQL with extensive rule prompting
* Validates: no DDL/DML, only whitelisted tables, proper catalog prefix
* Executes via Spark SQL (notebook) or Statement Execution API (app)
* Returns structured rows as ToolResult

### Vector Search Service (`platform/v4/services/vector_search_service.py`)

Wraps the Databricks VS SDK:
* Single unified index (`idx_unified_v4`)
* Provider-scoped filtering via `provider_name` column
* Current-only filtering via `is_current` column
* Degradation state tracking with auto-recovery
* OAuth token refresh on 401 errors

---

## Configuration Files

### `platform/v4/config/settings.py`

All runtime constants:
* Model endpoint names (env-driven with fallbacks)
* Agent limits (steps, budget, timeouts)
* Tool limits (SQL rows, tokens, passage count)
* Feature flags (V4_AGENT_ENABLED, GENIE_ENABLED, etc.)
* Cost estimates per tool call

### `platform/v4/config/table_whitelist.py`

SQL security boundary:
* 13 approved tables with natural-language descriptions
* Column documentation for LLM context injection
* `is_allowed()` function for validation
* `get_schema_context()` for prompt injection

### `platform/v4/config/tool_policies.py`

Per-tool governance:
* Enabled/disabled state
* Required feature flags
* Maximum cost estimate
* Per-session call limits

---

## API Endpoints

| Endpoint | Method | Purpose |
|---|---|---|
| `/health` | GET | Dependency health check |
| `/api/v1/query` | POST | Main question-answering (streaming + non-streaming) |
| `/api/v1/providers` | GET | Provider search and listing |
| `/api/v1/sessions` | GET/POST | Session management |
| `/api/v1/feedback` | POST | User feedback submission |
| `/api/v1/report` | POST | Report generation |
| `/api/v1/concepts` | GET | Contract concept definitions |
| `/api/v1/export` | POST | Data export (Excel/CSV) |
| `/api/v1/documents` | GET | Document metadata and access |
| `/api/v1/status/metrics` | GET | Platform usage metrics |

---

## Extension Points

### Adding a New Tool

1. Create `platform/v4/tools/my_new_tool.py`
2. Implement `BaseTool` with `name`, `description`, and `_run()` method
3. Register in the runtime entry point (notebook or API lifespan)
4. Add policy to `tool_policies.py`
5. Update tool catalogue description in agent prompt

### Adding a New Table

1. Create table in `dev_adb.raw` via pipeline DDL
2. Add to `table_whitelist.py` with natural-language description
3. Include column documentation in the whitelist entry
4. Update relevant tools to query the new table

### Adding a New Document Type

1. Add extraction logic to `03_reimbursement_migration.py`
2. Add chunking support to `04_legal_chunking.py`
3. Run pipeline to process documents
4. Vector index auto-syncs via Delta Sync

### Adding a New Frontend Page

1. Create `frontend/src/pages/MyPageV2.tsx`
2. Add route in `App.tsx`
3. Implement API calls via `frontend/src/services/`
4. Rebuild frontend: `node $NPM run build`
5. Redeploy app

---

## Dependencies

### Python (Backend)

Key packages from `requirements.txt`:
* `fastapi` — Web framework
* `uvicorn` — ASGI server
* `pydantic` — Data validation
* `databricks-sdk` — Databricks API client
* `databricks-vectorsearch` — Vector Search SDK
* `slowapi` — Rate limiting

### Frontend (React)

Key packages from `package.json`:
* `react` / `react-dom` — UI framework
* `typescript` — Type safety
* `vite` — Build tool
* `tailwindcss` — Utility CSS framework

---

*For architecture overview, see [02_architecture_overview.md](./02_architecture_overview.md)*
*For deployment procedures, see [09_deployment_and_operations.md](./09_deployment_and_operations.md)*

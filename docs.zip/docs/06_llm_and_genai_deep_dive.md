# LLM & GenAI Deep Dive — Contract Intelligence Platform V4

> **Audience**: Client AI/ML reviewers, compliance teams, anyone asking "how is AI used?"

---

## Table of Contents

1. [Where LLMs Are Used](#where-llms-are-used)
2. [Which Models Are Used](#which-models-are-used)
3. [How GenAI Helps](#how-genai-helps)
4. [Prompt Engineering Approach](#prompt-engineering-approach)
5. [Guardrails and Safety](#guardrails-and-safety)
6. [Data Privacy and Security](#data-privacy-and-security)
7. [Client FAQ — Common GenAI Questions](#client-faq)

---

## Where LLMs Are Used

The platform uses Large Language Models at 6 distinct points, each with a specific, bounded purpose:

| # | Usage Point | Model | Purpose | Data Exposed |
|---|---|---|---|---|
| 1 | **Document Extraction** | Claude Sonnet 4.5 | Parse contract PDFs into structured fields (rates, clauses, terms, dates) | Contract text passages |
| 2 | **SQL Generation** | Claude Sonnet 4.6 | Convert natural-language questions into SQL queries against whitelisted tables | Question text + table schemas |
| 3 | **Agent Reasoning** | Claude Sonnet 4.6 | Select which tool to call next in the ReAct loop | Question + tool results (no raw contract text) |
| 4 | **Answer Synthesis** | Claude Sonnet 4.6 | Compose a coherent answer from tool results | Tool result data (rates, passages, metadata) |
| 5 | **Citation Verification** | Claude Haiku 4.5 | Verify that extracted data matches source passages | Extracted values + source passage |
| 6 | **Entity Extraction** | Claude Haiku 4.5 | Extract provider names, concepts, and coreference resolution | Question text only |

**What LLMs are NOT used for:**
* LLMs do NOT store or memorize contract data between sessions
* LLMs do NOT make decisions about contract terms—they retrieve and present data
* LLMs do NOT have access to tables outside the 13-table whitelist
* LLMs are NOT trained on BSC contract data

---

## Which Models Are Used

| Model | Endpoint | Role | Token Cost | Hosted By |
|---|---|---|---|---|
| Claude Sonnet 4.6 | `databricks-claude-sonnet-4-6` | Primary reasoning, SQL generation, synthesis | ~$0.005/step | Databricks (Azure) |
| Claude Haiku 4.5 | `databricks-claude-haiku-4-5` | Fast verification, entity extraction | ~$0.001/call | Databricks (Azure) |
| GTE-Large-EN | `databricks-gte-large-en` | Text embeddings (1024 dimensions) | Negligible | Databricks (Azure) |

All models are accessed via Databricks Foundation Model APIs (pay-per-token, no dedicated deployment). They run within the Databricks platform on Azure infrastructure.

---

## How GenAI Helps

### 1. Document Extraction (Offline Pipeline)
**Without AI**: A human analyst reads each PDF, manually enters rates into a spreadsheet. At 10,372 documents, this would take person-years.

**With AI**: Claude Sonnet reads contract text and outputs structured JSON with rates, dates, clauses, and terms. Extracts 459,902 rate records from 199 processed contracts in hours, not months.

### 2. Natural-Language Understanding (Online)
**Without AI**: Users must write SQL queries or know exactly which table/column to check.

**With AI**: Users ask "What is the stop-loss threshold for Cedars-Sinai?" and the system routes to the correct tool, generates appropriate SQL, and returns a specific cited answer.

### 3. Answer Synthesis (Online)
**Without AI**: Raw data tables are returned and the user must interpret them.

**With AI**: Multiple data points (rates from SQL, passages from search, profile metadata) are synthesized into a coherent, conversational answer with source citations.

---

## Prompt Engineering Approach

### System Prompts
Each LLM usage point has a carefully crafted system prompt that:
* Defines the model’s role and boundaries explicitly
* Lists available tools with their parameters
* Includes data model awareness rules (column types, valid values, JOIN patterns)
* Specifies critical constraints (e.g., "Never fabricate contract terms, rates, or dates")
* Provides concrete examples of correct vs. incorrect behavior

### SQL Generation Prompt
The SQL generation prompt (`sql_query.py`) includes:
* 14+ explicit rules for correct SQL construction
* Column-level documentation for all whitelisted tables
* Anti-patterns to avoid (e.g., "NEVER use `is_current_effective`—this column does not exist")
* Provider filtering requirements ("MUST include WHERE clause for named providers")
* Data type awareness (STRING booleans vs. real BOOLEANs)

### Guardrail Prompts
* "Never fabricate contract terms, rates, or dates"
* "ALWAYS ground claims in retrieved passages or SQL results before synthesizing"
* "Never state specific numeric statistics from memory—ALWAYS use sql_query first"
* "When VERIFIED PROFILE data is available, treat it as authoritative ground truth"

---

## Guardrails and Safety

### Hallucination Prevention (7-Check System)

| Check | What It Catches | Severity |
|---|---|---|
| Confidence floor | Answers with no citations/data | WARN |
| Numeric consistency | Numbers not found in source data | WARN/BLOCK |
| Provider name grounding | References to unresolved providers | WARN |
| Date plausibility | Dates outside 1990–2030 range | WARN |
| Non-BSC provider blocklist | Claims about Kaiser, Aetna, etc. | BLOCK |
| Universality claim guard | "All 300 providers have X" without SQL proof | WARN |
| Same-provider cross-dimensional | Unsupported multi-hop rankings | WARN |

### SQL Security Layer
* Only 13 tables accessible (hardcoded whitelist)
* DDL/DML blocked by regex (CREATE, INSERT, UPDATE, DELETE, DROP)
* Input sanitization strips special characters before SQL injection
* Query timeout at 300 seconds
* Maximum 1000 rows returned per query

### Cost Controls
* Per-session budget: $15.00 maximum
* Per-tool cost estimates tracked
* Budget exhaustion forces synthesis with available data
* Per-session tool call limits prevent runaway loops

---

## Data Privacy and Security

### What Data Goes to LLM Endpoints

| Stage | Data Sent | Data NOT Sent |
|---|---|---|
| SQL Generation | User question + table schema descriptions | Actual table data |
| Agent Reasoning | Question + tool result summaries | Raw contract PDFs |
| Answer Synthesis | Question + structured tool outputs | Full document text |
| Citation Verify | Single passage + extracted value | Patient data, PII |

### PII Protection
* **Runtime redaction**: SSN patterns (`\d{3}-\d{2}-\d{4}`), DOB patterns, and street addresses are stripped from all text before LLM injection
* **No PII in structured tables**: Rate tables contain only financial/contract terms, never patient information
* **Source documents**: Contract PDFs are provider agreements, not patient records

### Data Residency
* All LLM endpoints hosted within Databricks on Azure (West US 2)
* No data leaves the BSC Azure tenant
* No cross-region data transfers for LLM inference

### No Model Training
* Foundation Model APIs are inference-only
* BSC contract data is NEVER used to train or fine-tune any model
* Models are pre-trained by Anthropic; Databricks provides serving infrastructure
* Each API call is stateless—models retain nothing between requests

### Encryption
* Data at rest: Azure-managed encryption (AES-256)
* Data in transit: TLS 1.2+ for all API calls
* Databricks workspace encryption (customer-managed keys available)

---

## Client FAQ

### "Can the AI make things up?"

**Short answer**: The system is designed to prevent this, and stress tests confirm >95% accuracy.

**Detailed answer**: The platform uses a "retrieve-then-generate" architecture. The LLM never answers from its own knowledge—it must cite specific contract data from SQL queries or vector search results. A 7-check Hallucination Guard runs on every answer, flagging responses where numbers don’t match source data. When the system cannot find relevant data, it says "data not available" rather than guessing. Ground-truth stress tests validate this behavior across accuracy, completeness, hallucination, and consistency dimensions.

### "How do we know the answer is correct?"

Every answer includes:
1. **Source citations** — The specific document, page number, and text passage that supports the answer
2. **Confidence score** — HIGH/MODERATE/LOW based on evidence quality
3. **Tool call transparency** — Users can see exactly which tools were called and what data was retrieved
4. **Verification mechanism** — Click any citation to view the source document directly

### "Is our data safe?"

* All processing occurs within your Azure tenant via Databricks
* LLM endpoints are Databricks-hosted (not external API calls)
* No data is transmitted to Anthropic or any third party
* No contract data is used for model training
* All access is governed by Unity Catalog permissions
* PII is redacted before any LLM interaction

### "What if the AI gives wrong information?"

* Confidence scoring warns users when evidence is weak (MODERATE/LOW)
* The hallucination guard flags potentially unsupported claims
* Users can always click through to verify the source document
* The system explicitly acknowledges data gaps rather than fabricating answers
* Continuous stress testing catches regressions before they reach users

### "How accurate is it?"

Based on the Data Quality Stress Test suite (19 ground-truth validated questions):
* **Accuracy tests**: Exact rate values, dates, and counts verified against source data
* **Hallucination tests**: System correctly refuses to fabricate data that doesn’t exist
* **Completeness tests**: System acknowledges data gaps rather than inventing answers
* **Consistency tests**: Cross-table data alignment validated

Overall pass rate: >95% across all test categories.

### "Does it learn from our data?"

No. The platform uses inference-only API calls:
* Models are pre-trained (by Anthropic) and never modified
* Each API call is stateless—the model retains nothing between requests
* Session context is managed by our application code, not by the LLM
* "Learning" comes from structured data in Delta tables, not from model weights

### "What happens when contracts change?"

When new amendments are received:
1. New PDF enters the pipeline
2. Text is extracted and the document is added to the amendment chain
3. New rates supersede old rates (state engine marks old rates as "superseded")
4. Vector search index auto-syncs with the updated table
5. Next user query automatically returns the new current-effective data

The system maintains full history—nothing is deleted. Users can query both current state and historical state.

### "Can it handle edge cases?"

The stress test suite specifically tests edge cases:
* Providers with no data (correct response: acknowledge the gap)
* Providers with expired contracts (correct response: flag as inactive)
* Questions about clauses that don’t exist (correct response: "no mention in contract")
* Cross-table consistency (correct response: data must align across tables)

Each failure mode is documented with expected behavior and tested regularly.

---

*For trust and validation methodology, see [07_trust_and_validation.md](./07_trust_and_validation.md)*
*For architecture details, see [02_architecture_overview.md](./02_architecture_overview.md)*
